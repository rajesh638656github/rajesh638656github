package com.printing.service.impl;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import com.printing.model.*;
import com.printing.DTO.BillDTO;
import com.printing.DTO.BillOrderDTO;
import com.printing.DTO.DepartmentDTO;
import com.printing.DTO.InstitutionDTO;
import com.printing.DTO.ItemDTO;
import com.printing.DTO.OrderMasterDTO;
import com.printing.DTO.SizeDTO;
import com.printing.DTO.UnitDTO;
import com.printing.DTO.ItemRateDTO;
import com.printing.DTO.ItemRatePhaseDTO;
import com.printing.DTO.ItemStatusDTO;
import com.printing.DTO.OrderItemPriceDTO;
import com.printing.dao.*;
import com.printing.service.*;
import java.util.List;
import java.util.Date;
import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.beans.factory.annotation.Autowired;

@Service
@AllArgsConstructor

public class PopulateOrderScreenServiceImpl implements PopulateOrderScreenService {

	@Autowired
	private PopulateOrderScreenServiceDAO populateOrderScreenServiceDAO;

	@Override
	public List<InstitutionDTO> findAllInstitutions() {
		try {

			return populateOrderScreenServiceDAO.findAllInstitutions();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public List<DepartmentDTO> findAllDepartments() {
		try {

			return populateOrderScreenServiceDAO.findAllDepartments();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	
	public List<ItemDTO> findAllItems() {
		try {

			return populateOrderScreenServiceDAO.findAllItems();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<ItemRateDTO> findAllItemRates() {
		try {

			return populateOrderScreenServiceDAO.findAllItemRates();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public List<SizeDTO> findAllSizes() {
		try {

			return populateOrderScreenServiceDAO.findAllSizes();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public List<UnitDTO> findAllUnits() {
		try {

			return populateOrderScreenServiceDAO.findAllUnits();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<ItemRatePhaseDTO> findAllItemRatePhase(){
		try {

			return populateOrderScreenServiceDAO.findAllItemRatePhase();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<ItemStatusDTO> findAllItemStatus() {
		try {

			return populateOrderScreenServiceDAO.findAllItemStatus();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public List<OrderSearchDTO> findOrderByOrderIdorInstitutionIdorDepartmentId(OrderSearchDTO OrderSearchBillingDTO) {
		try {

			return populateOrderScreenServiceDAO.findOrderByOrderIdorInstitutionIdorDepartmentId(OrderSearchBillingDTO);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<OrderSearchDTO> findAllOrderForBillDraft() {
		try {

			return populateOrderScreenServiceDAO.findAllOrderForBillDraft();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<BillDTO> findRevenueDetails(Date startDate,Date endDate) {
		try {

			return populateOrderScreenServiceDAO.findRevenueDetails(startDate, endDate);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<BillDTO> findBillByInstitution(Date startDate,Date endDate,long institutionId) {
		try {

			return populateOrderScreenServiceDAO.findBillByInstitution(startDate, endDate,institutionId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<BillDTO> findBillByInstitutionOrBillId(BillSearchDTO billSearchDTO) {
		try {

			return populateOrderScreenServiceDAO.findBillByInstitutionOrBillId(billSearchDTO);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<BillOrderDTO> findBillOrderDetailByBillId(long billId) {
		try {

			return populateOrderScreenServiceDAO.findBillOrderDetailByBillId(billId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<OrderItemPriceDTO> findOrderItemPriceDetailByOrderItemId(List<Long> orderItemIds) {
		try {
			
			return populateOrderScreenServiceDAO.findOrderItemPriceDetailByOrderItemId(orderItemIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	public List<BillDTO> findBillByInstitutionOrBillIdForDuplicateBill(BillSearchDTO billSearchDTO) {
		try {

			return populateOrderScreenServiceDAO.findBillByInstitutionOrBillIdForDuplicateBill(billSearchDTO);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<OrderItemDetailDTO> findOrderItemDetailsForDuplicateBill(List<Long> orderIds) {
		try {

			return populateOrderScreenServiceDAO.findOrderItemDetailsForDuplicateBill(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	
	public List<BillOrderDTO> findBillOrderDetail() {
		try {

			return populateOrderScreenServiceDAO.findBillOrderDetail();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public List<OrderItemDetailDTO> findOrderItemDetails(List orderIds) {
		try {

			return populateOrderScreenServiceDAO.findOrderItemDetails(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<OrderItemDetailDTO> findOrderItemDetailsforBilling(List orderIds) {
		try {

			return populateOrderScreenServiceDAO.findOrderItemDetailsforBilling(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	
	public List<OrderItemDetailDTO> findAllActiveOrderItemDetails() {
		try {

			return populateOrderScreenServiceDAO.findAllActiveOrderItemDetails();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<OrderItemDetailDTO> findQuotationOrderItemDetails(List orderIds,Long quotationId) {
		try {

			return populateOrderScreenServiceDAO.findQuotationOrderItemDetails(orderIds,quotationId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	
	
	 public List<OrderMasterDTO> findOrderMasterDetails(List orderIds) {
		try {

			return populateOrderScreenServiceDAO.findOrderMasterDetails(orderIds);
			
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	} 
	 
	 public List<OrderMasterDTO> findAllActiveOrders() {
	 try {

			return populateOrderScreenServiceDAO.findAllActiveOrders();
			
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	} 

	 
	 public List<OrderItemDetailDTO> findAllOrdersByItemType(List itemIds) {
			try {

				return populateOrderScreenServiceDAO.findAllOrdersByItemType(itemIds);
				
			} catch (Exception e) {
				System.out.println(e);
				throw new RuntimeException(e);
			}

		} 

	
		public List<OrderSubTotalDTO> findSubTotalForBilling(List<Long> orderIds) {
		try {

			return populateOrderScreenServiceDAO.findSubTotalForBilling(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
		
		public List<QuotationSubTotalDTO> findSubTotalForQuotation(Long quotationId) {
			try {

				return populateOrderScreenServiceDAO.findSubTotalForQuotation(quotationId);
			} catch (Exception e) {
				System.out.println(e);
				throw new RuntimeException(e);
			}

		}

	public List<OrderSubTotalDTO> findSubTotalforEachOrderId() {
		try {

			return populateOrderScreenServiceDAO.findSubTotalforEachOrderId();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public void updateQuoatationItems(long quotationId,int quantity,double price,double amount) {
		try {

		 populateOrderScreenServiceDAO.updateQuoatationItems(quotationId,quantity,price,amount);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public void deleteOrderItem(long orderItemId) {
		try {

			 populateOrderScreenServiceDAO.deleteOrderItem(orderItemId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public void deleteOrderItemPrice(long orderItemId) {
		try {

			 populateOrderScreenServiceDAO.deleteOrderItemPrice(orderItemId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}


	public int findMaxOrderID() {
		try {

			return populateOrderScreenServiceDAO.findMaxOrderID();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public int createInstitution(String institutionName) {
		try {

			return populateOrderScreenServiceDAO.createInstitution(institutionName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public int createDepartment(String departmentName) {
		try {

			return populateOrderScreenServiceDAO.createDepartment(departmentName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	

	public int createItem(String itemName) {
		try {

			return populateOrderScreenServiceDAO.createItem(itemName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public int createSize(String sizeName) {
		try {

			return populateOrderScreenServiceDAO.createSize(sizeName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public int createUnit(String unitName) {
		try {

			return populateOrderScreenServiceDAO.createUnit(unitName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public int createItemRate(String costItemName) {
		try {

			return populateOrderScreenServiceDAO.createCostItem(costItemName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

}
