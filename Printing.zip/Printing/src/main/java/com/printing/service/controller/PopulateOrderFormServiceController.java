package com.printing.service.controller;

import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.printing.service.*;
import com.printing.service.impl.*;
import com.printing.model.*;
import com.printing.frontend.controller.OrderForm;

import java.util.List;

@RestController
@AllArgsConstructor

public class PopulateOrderFormServiceController {

	/*
	 * @Autowired private PopulateOrderScreenService populateOrderScreenService;
	 * 
	 * 
	 * 
	 * 
	 * @RequestMapping("/api/institutions") public ResponseEntity<List<Institution>>
	 * getAllInstitutions(){
	 * System.out.println("From PopulateOrderFormController.getAllInstitutions");
	 * List<Institution> institutions =
	 * populateOrderScreenService.getAllInstitutions(); return new
	 * ResponseEntity<>(institutions, HttpStatus.OK); }
	 * 
	 * @RequestMapping(value = "/api/departments", method = RequestMethod.GET)
	 * public ResponseEntity<List<Department>> getAllDepartments() {
	 * 
	 * // int institutionID = Integer.parseInt(institutionId);
	 * System.out.println("From PopulateOrderFormController.getAllInstitutions"); //
	 * List<InstitutionDepartment> departments =
	 * populateOrderScreenService.getAllDepartmentsByInstitution(institutionID);
	 * return new ResponseEntity<>(departments, HttpStatus.OK); }
	 * 
	 * @RequestMapping("/api/items") public ResponseEntity<List<Item>>
	 * getAllItems(){
	 * System.out.println("From PopulateOrderFormController.getAllItems");
	 * List<Item> items = populateOrderScreenService.getAllItems(); return new
	 * ResponseEntity<>(items, HttpStatus.OK); }
	 * 
	 * @RequestMapping("/api/sizes") public ResponseEntity<List<Size>>
	 * getAllSizes(){
	 * System.out.println("From PopulateOrderFormController.getAllSizes");
	 * List<Size> sizes = populateOrderScreenService.getAllSizes(); return new
	 * ResponseEntity<>(sizes, HttpStatus.OK); }
	 * 
	 * @RequestMapping("/api/units") public ResponseEntity<List<Unit>>
	 * getAllUnits(){
	 * System.out.println("From PopulateOrderFormController.getAllUnits");
	 * List<Unit> units = populateOrderScreenService.getAllUnits(); return new
	 * ResponseEntity<>(units, HttpStatus.OK); }
	 * 
	 * @RequestMapping("/api/orderdetails") public ResponseEntity<List<OrderDTO>>
	 * getOrderDetails(int orderId) {
	 * System.out.println("From PopulateOrderFormController.getOrderDetails");
	 * List<OrderDTO> orderDetails =
	 * populateOrderScreenService.getOrderDetails(orderId); return new
	 * ResponseEntity<>(orderDetails, HttpStatus.OK);
	 * 
	 * }
	 */

}
