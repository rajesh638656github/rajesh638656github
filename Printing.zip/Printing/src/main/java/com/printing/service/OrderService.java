package com.printing.service;

import org.springframework.stereotype.Component;
import com.printing.entity.*;

@Component
public interface OrderService {

	public Order saveOrder(Order order);

	public Order findByOrderId(int orderId);

}
