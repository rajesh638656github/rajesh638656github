package com.printing.service.impl;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.printing.entity.Order;
import com.printing.entity.OrderItem;
import com.printing.repository.OrderRepository;
import com.printing.service.OrderService;

public class OrderServiceImpl {
//public class OrderServiceImpl implements OrderService {
	/*
	 * @Autowired private OrderRepository orderRepository; public Order
	 * saveOrder(Order order) { List<Item> itemList = new ArrayList<>(); // create
	 * first item
	 * 
	 * Item item1 = new Item(); item1.setItemId(1); item1.setSizeId(1);
	 * item1.setQuantity(1); item1.setUnitId(1); item1.setPrice(5000.00);
	 * 
	 * itemList.add(item1);
	 * 
	 * order.setItemList(itemList); order = orderRepository.saveOrder(order); return
	 * order; } public Order findByOrderId(int orderId) { Order order =
	 * orderRepository.findByOrderId(orderId); return order; }
	 * 
	 */

}
