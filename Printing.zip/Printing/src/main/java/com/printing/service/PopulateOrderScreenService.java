package com.printing.service;

import com.printing.DTO.ItemStatusDTO;
import com.printing.DTO.OrderItemPriceDTO;
import com.printing.DTO.DepartmentDTO;
import com.printing.DTO.InstitutionDTO;
import com.printing.DTO.ItemDTO;
import com.printing.DTO.ItemRateDTO;
import com.printing.DTO.SizeDTO;
import com.printing.DTO.UnitDTO;
import com.printing.DTO.BillDTO;
import com.printing.DTO.BillOrderDTO;
import com.printing.DTO.OrderMasterDTO;
import com.printing.DTO.PhaseNameDTO;
import com.printing.DTO.ItemRatePhaseDTO;
import com.printing.model.*;
import java.util.List;
import java.util.Date;

public interface PopulateOrderScreenService {
	public List<InstitutionDTO> findAllInstitutions();

	public List<DepartmentDTO> findAllDepartments();

	public List<ItemDTO> findAllItems();
	
	public List<ItemRateDTO> findAllItemRates();

	public List<SizeDTO> findAllSizes();

	public List<UnitDTO> findAllUnits();
	
	public List<ItemStatusDTO> findAllItemStatus();
	
	public List<ItemRatePhaseDTO> findAllItemRatePhase(); 
	
	public List<OrderMasterDTO> findAllActiveOrders();
	
	//public List<PhaseNameDTO> findAllPhaseNames();
	
	public List<BillDTO> findRevenueDetails(Date startDate,Date endDate);
	
	public List<BillDTO> findBillByInstitution(Date startDate,Date endDate,long institutionId);
	
	public List<BillDTO> findBillByInstitutionOrBillId(BillSearchDTO billSearchDTO);
	
	public List<BillDTO> findBillByInstitutionOrBillIdForDuplicateBill(BillSearchDTO billSearchDTO);
	
	public List<BillOrderDTO> findBillOrderDetailByBillId(long billId);
	
	public List<OrderItemPriceDTO> findOrderItemPriceDetailByOrderItemId(List<Long> orderItemIds) ;
	
	public List<BillOrderDTO> findBillOrderDetail();
	
	public List<OrderItemDetailDTO> findAllOrdersByItemType(List itemIds);
	
	public List<OrderMasterDTO> findOrderMasterDetails(List orderIds);

	public List<OrderItemDetailDTO> findOrderItemDetails(List orderId);
	
	public List<OrderItemDetailDTO> findOrderItemDetailsforBilling(List orderId);
	
	public List<OrderItemDetailDTO> findOrderItemDetailsForDuplicateBill(List<Long> orderIds);
	
	public List<OrderItemDetailDTO> findAllActiveOrderItemDetails();
	
	public List<OrderItemDetailDTO> findQuotationOrderItemDetails(List orderId,Long quotationId);

	public List<OrderSearchDTO> findOrderByOrderIdorInstitutionIdorDepartmentId(OrderSearchDTO OrderSearchBillingDTO);
	
	public List<OrderSearchDTO> findAllOrderForBillDraft();
	
	//public List<OrderSearchDTO> findAllBillForPrint();
	
	public void deleteOrderItem(long orderItemId);
	
	public void deleteOrderItemPrice(long orderItemPriceId);
	
	public void updateQuoatationItems(long quotationId,int quantity,double price,double amount);

	public int findMaxOrderID();

	public List<OrderSubTotalDTO> findSubTotalforEachOrderId();

	public List<OrderSubTotalDTO> findSubTotalForBilling(List<Long> orderIds);
	
	public List<QuotationSubTotalDTO> findSubTotalForQuotation(Long quotationId);

	public int createInstitution(String institutionName);

	public int createDepartment(String departmentName);

	public int createItem(String itemName);

	public int createSize(String itemSize);

	public int createUnit(String unitName);
	
	public int createItemRate(String itemName);

}
