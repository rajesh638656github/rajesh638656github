package com.printing.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.printing.entity.OrderItemPrice;
import java.util.List;
import java.util.ArrayList;

@Entity
@Table(name = "order_items")

public class OrderItem {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "item_id")
	private int itemId;
	@Column(name = "item_description")
	private String itemDescription;
	@Column(name = "size_id")
	private int sizeId;
	@Column(name = "note")
	private String note;
	@Column(name = "quantity")
	private Integer quantity;
	@Column(name = "unit_id")
	private int unitId;
	@Column(name = "price")
	private Double price;
	@Column(name = "amount")
	private Double amount;
	
	
	@Column(name = "item_status_id")
	private int itemStatusId;


	@Column(name = "comments",length = 500)
	private String comments;
	// @Column(name = "order_id")
	// private long orderId;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "order_id")
	//@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	//@JoinColumn(name = "order_id", nullable = false)
	//@OnDelete(action = OnDeleteAction.CASCADE)
	private Order order;

	
	//new 
	@OneToMany(mappedBy = "orderItem",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<OrderItemPrice> orderItemPrices;
	

	public OrderItem() {
		//new
		orderItemPrices= new ArrayList<>();
		// super();
		// TODO Auto-generated constructor stub
	}

	

	public OrderItem(int itemId,String itemDescription, int sizeId,String note, Integer quantity, int unitId, Double price,Double amount, int itemStatusId,
			String comments) {
		super();
		this.itemId = itemId;
		this.itemDescription  = itemDescription;
		this.sizeId = sizeId;
		this.note = note;
		this.quantity = quantity;
		this.unitId = unitId;
		this.price = price;
		this.amount = amount;
		this.itemStatusId = itemStatusId;
		this.comments = comments;
	}



	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public int getSizeId() {
		return sizeId;
	}

	public void setSizeId(int sizeId) {
		this.sizeId = sizeId;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public int getUnitId() {
		return unitId;
	}

	public void setUnitId(int unitId) {
		this.unitId = unitId;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public int getItemStatusId() {
		return itemStatusId;
	}
	public void setItemStatusId(int itemStatusId) {
		this.itemStatusId = itemStatusId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
	
	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}
	
	//new
	public void add(OrderItemPrice item) {

        if (item != null) {
            if (orderItemPrices == null) {
            	orderItemPrices = new ArrayList<>();
            }

            orderItemPrices.add(item);
          item.setOrderItem(this);
        }
    }
	
	public void remove(OrderItemPrice item) {
       
		orderItemPrices.remove(item);
           item.setOrderItem(null);
       
    }
	
	public List<OrderItemPrice> getOrderItemPrices() {
		return orderItemPrices;
	}



	public void setOrderItemPrices(List<OrderItemPrice> orderItemPrices) {
		this.orderItemPrices = orderItemPrices;
	}



	/*
	 * public long getOrderId() { return orderId; } public void setOrderId(long
	 * orderId) { this.orderId = orderId; }
	 */
	@Override
	public String toString() {
		return "OrderItem [id=" + id + ", itemId=" + itemId + ", sizeId=" + sizeId + ", quantity=" + quantity
				+ ", unitId=" + unitId + ", price=" + price + "]";
	}

}
