package com.printing.entity;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.*;

@Entity
@Table(name = "bill")
public class Bill {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bill_id")
	private long billId;
	@Column(name = "transaction_date")
	// @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private Date transactionDate = new Date();
	
	@Column(name = "total_amount")
	private double totalAmount;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	@JoinColumn(name = "bill_id")

	private List<BillOrder> billOrders;

	public Bill() {
		billOrders = new ArrayList<>();
	}

	public Bill(Date transactionDate, double totalAmount) {

	
		this.totalAmount = totalAmount;
	}

	public long getBillId() {
		return billId;
	}

	public void setBillId(long billId) {
		this.billId = billId;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}


	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public List<BillOrder> getBillOrders() {
		return billOrders;
	}

	public void setBillOrders(List<BillOrder> billOrders) {
		this.billOrders = billOrders;
	}

	@Override
	public String toString() {
		return "Bill [billId=" + billId + ", transactionDate=" + transactionDate + ",  totalAmount=" + totalAmount + ", billOrders=" + billOrders + "]";
	}

}
