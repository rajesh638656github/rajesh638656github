package com.printing.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "quotation_order_items")
public class QuotationOrderItem  {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "item_id")
	private int itemId;
	@Column(name = "quantity")
	private Integer quantity;
	@Column(name = "price")
	private Double price;
	@Column(name = "amount")
	private Double amount;
	@Column(name = "order_id")
	private Double orderId;
	
	
	// @Column(name = "order_id")
	// private long orderId;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "quotation_id")
	//@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	//@JoinColumn(name = "order_id", nullable = false)
	//@OnDelete(action = OnDeleteAction.CASCADE)
	private Quotation quotation;

	
	public QuotationOrderItem() {
		// super();
		// TODO Auto-generated constructor stub
	}

	

	public QuotationOrderItem(int itemId,Integer quantity, Double price,Double amount,Double orderId) {
		super();
		this.itemId = itemId;
		this.quantity = quantity;
		this.price = price;
		this.orderId = orderId;
		this.amount = amount;
	}



	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	
	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getOrderId() {
		return orderId;
	}
	public void setOrderId(Double orderId) {
		this.orderId = orderId;
	}
	public Quotation getQuotation() {
		return quotation;
	}



	public void setQuotation(Quotation quotation) {
		this.quotation = quotation;
	}



	public Double getAmount() {
		return amount;
	}



	public void setAmount(Double amount) {
		this.amount = amount;
	}
	

	/*
	 * public long getOrderId() { return orderId; } public void setOrderId(long
	 * orderId) { this.orderId = orderId; }
	 */
	

}

