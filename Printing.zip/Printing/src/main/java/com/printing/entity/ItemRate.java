package com.printing.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "item_rate")

public class ItemRate {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_rate_id")
	private long itemRateId;
	@Column(name = "item_rate_phase_name")
	private String itemRatePhaseName;
	@Column(name = "item_rate_name")
	private String itemRateName;
	@Column(name = "item_rate")
	private Double itemRate;
	

	public ItemRate() {
		super();
		// TODO Auto-generated constructor stub
	}


	public long getItemRateId() {
		return itemRateId;
	}


	public void setItemRateId(long itemRateId) {
		this.itemRateId = itemRateId;
	}


	
	public String getItemRatePhaseName() {
		return itemRatePhaseName;
	}


	public void setItemRatePhaseName(String itemRatePhaseName) {
		this.itemRatePhaseName = itemRatePhaseName;
	}


	public String getItemRateName() {
		return itemRateName;
	}


	public void setItemRateName(String itemRateName) {
		this.itemRateName = itemRateName;
	}


	public Double getItemRate() {
		return itemRate;
	}


	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}


	
	
	

}
