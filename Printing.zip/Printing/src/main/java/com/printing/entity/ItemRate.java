package com.printing.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "item_rate", uniqueConstraints = @UniqueConstraint(columnNames = {"item_rate_phase_id","item_rate_name"}))

public class ItemRate {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_rate_id")
	private long itemRateId;
	@NotNull
	@Column(name = "item_rate_phase_id", nullable = false)
	private long itemRatePhaseId;
	@NotNull
	@Column(name = "item_rate_name", nullable = false)
	private String itemRateName;
	@Column(name = "item_rate")
	private Double itemRate;
	

	public ItemRate() {
		super();
		// TODO Auto-generated constructor stub
	}


	public long getItemRateId() {
		return itemRateId;
	}


	public void setItemRateId(long itemRateId) {
		this.itemRateId = itemRateId;
	}

	public long getItemRatePhaseId() {
		return itemRatePhaseId;
	}


	public void setItemRatePhaseId(long itemRatePhaseId) {
		this.itemRatePhaseId = itemRatePhaseId;
	}


	public String getItemRateName() {
		return itemRateName;
	}


	public void setItemRateName(String itemRateName) {
		this.itemRateName = itemRateName;
	}


	public Double getItemRate() {
		return itemRate;
	}


	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}


	
	
	

}
