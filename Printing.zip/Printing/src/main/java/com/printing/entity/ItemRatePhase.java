package com.printing.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "item_rate_phase", uniqueConstraints = @UniqueConstraint(columnNames = {"item_rate_phase_name"}))

public class ItemRatePhase {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_rate_phase_id")
	private long itemRatePhaseId;
    @NotNull
	@Column(name = "item_rate_phase_name", nullable = false)
	private String itemRatePhaseName;
	
	
	public ItemRatePhase() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getItemRatePhaseId() {
		return itemRatePhaseId;
	}
	public void setItemRatePhaseId(long itemRatePhaseId) {
		this.itemRatePhaseId = itemRatePhaseId;
	}
	public String getItemRatePhaseName() {
		return itemRatePhaseName;
	}
	public void setItemRatePhaseName(String itemRatePhaseName) {
		this.itemRatePhaseName = itemRatePhaseName;
	}
	
	


}
