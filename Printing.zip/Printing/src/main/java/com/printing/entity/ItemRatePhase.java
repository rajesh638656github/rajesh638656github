package com.printing.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "item_rate_phase")

public class ItemRatePhase {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_rate_phase_id")
	private long itemRatePhaseId;
	@Column(name = "item_rate_phase_name")
	private String itemRatePhaseName;
	
	
	public ItemRatePhase() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getItemRatePhaseId() {
		return itemRatePhaseId;
	}
	public void setItemRatePhaseId(long itemRatePhaseId) {
		this.itemRatePhaseId = itemRatePhaseId;
	}
	public String getItemRatePhaseName() {
		return itemRatePhaseName;
	}
	public void setItemRatePhaseName(String itemRatePhaseName) {
		this.itemRatePhaseName = itemRatePhaseName;
	}
	
	


}
