package com.printing.entity;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;


@Entity
@Table(name = "order_item_price")
public class OrderItemPrice {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name= "item_rate_id")
	private long itemRateId;
	
	@Column(name= "item_rate")
	private double itemRate;
	
	@Column(name= "no_of_items")
	private int noOfItems;
	@Column(name= "amount")
	private double amount;
	
	
	//new
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "order_item_id")
	private OrderItem orderItem;
	
	
	public OrderItemPrice() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getItemRateId() {
		return itemRateId;
	}
	public void setItemRateId(long itemRateId) {
		this.itemRateId = itemRateId;
	}
	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getNoOfItems() {
		return noOfItems;
	}

	public void setNoOfItems(int noOfItems) {
		this.noOfItems = noOfItems;
	}
	public double getItemRate() {
		return itemRate;
	}

	public void setItemRate(double itemRate) {
		this.itemRate = itemRate;
	}

	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}

	public OrderItem getOrderItem() {
		return orderItem;
	}

	public void setOrderItem(OrderItem orderItem) {
		this.orderItem = orderItem;
	}
	
	
	
}
