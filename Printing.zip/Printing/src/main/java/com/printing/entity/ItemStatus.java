package com.printing.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "item_status", uniqueConstraints = @UniqueConstraint(columnNames = {"item_status_name"}))
public class ItemStatus {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_status_id")
	private long itemStatusId;
	@NotNull
	@Column(name = "item_status_name", nullable = false)
	private String itemStatusName;
	public ItemStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getItemStatusId() {
		return itemStatusId;
	}
	public void setItemStatusId(long itemStatusId) {
		this.itemStatusId = itemStatusId;
	}
	public String getItemStatusName() {
		return itemStatusName;
	}
	public void setItemStatusName(String itemStatusName) {
		this.itemStatusName = itemStatusName;
	}
	@Override
	public String toString() {
		return "ItemStatus [itemStatusId=" + itemStatusId + ", itemStatusName=" + itemStatusName + "]";
	}
	
}
