package com.printing.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "institution")

public class Institution {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "institution_id")
	private long institutionId;
	@Column(name = "institution_name")
	private String institutionName;

	public Institution() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(long institutionId) {
		this.institutionId = institutionId;
	}

	public String getInstitutionName() {
		return institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}

}
