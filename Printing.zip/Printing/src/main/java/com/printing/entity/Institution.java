package com.printing.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "institution", uniqueConstraints = @UniqueConstraint(columnNames = {"institution_name"}))


public class Institution {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "institution_id")
	private long institutionId;
	 @NotNull
	@Column(name = "institution_name", nullable = false)
	private String institutionName;

	public Institution() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(long institutionId) {
		this.institutionId = institutionId;
	}

	public String getInstitutionName() {
		return institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}

}
