package com.printing.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "bill_order")
public class BillOrder {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bill_order_id")
	private long billOrderId;
	private Date transactionDate = new Date();
	@Column(name = "order_id")
	private long orderId;
	@Column(name = "order_total_amount")
	private double orderTotalAmount;

	public BillOrder() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BillOrder(long billOrderId,Date transactionDate, long orderId, long orderTotalAmount) {
		super();
		this.billOrderId = billOrderId;
		this.transactionDate = transactionDate;
		this.orderId = orderId;
		this.orderTotalAmount = orderTotalAmount;
	}

	public long getBillOrderId() {
		return billOrderId;
	}

	public void setBillOrderId(long billOrderId) {
		this.billOrderId = billOrderId;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public double getOrderTotalAmount() {
		return orderTotalAmount;
	}

	public void setOrderTotalAmount(double d) {
		this.orderTotalAmount = d;
	}

	@Override
	public String toString() {
		return "BillOrder [billOrderId=" + billOrderId + ", orderId=" + orderId + ", orderTotalAmount="
				+ orderTotalAmount + "]";
	}

}
