package com.printing.entity;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.*;

@Entity
@Table(name = "quotations")
public class Quotation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	//@Column(name = "quotation_id")
	private long id;
	@Column(name = "transaction_date")
	// @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private Date transactionDate = new Date();
	@Column(name = "total")
	private double total;
	
	@OneToMany(mappedBy = "quotation",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	//@JoinColumn(name = "quotation_id")

	private List<QuotationOrderItem> quotationOrderItems;

	public Quotation() {
		quotationOrderItems = new ArrayList<>();
	}

	public Quotation(Date transactionDate, double total) {

		this.transactionDate = transactionDate;
	
		this.total = total;
	}
	
/*	public long getQuotationId() {
		return quotationId;
	}

	public void setQuotationId(long quotationId) {
		this.quotationId = quotationId;
	}*/
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public List<QuotationOrderItem> getQuotationOrderItems() {
		return quotationOrderItems;
	}

	public void setQuotationOrderItems(List<QuotationOrderItem> quotationOrderItems) {
		this.quotationOrderItems = quotationOrderItems;
	}


	public void add(QuotationOrderItem item) {

        if (item != null) {
            if (quotationOrderItems == null) {
            	quotationOrderItems = new ArrayList<>();
            }

            quotationOrderItems.add(item);
          item.setQuotation(this);
        }
    }
	
	public void remove(QuotationOrderItem item) {
       
		quotationOrderItems.remove(item);
           item.setQuotation(null);
       
    }
	
}
