package com.printing.util;
import com.lowagie.text.DocumentException;
import com.printing.model.OrderItemDetailDTO;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.spring6.*;
import org.thymeleaf.context.Context;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

public class PDFThymeleafExampleModified {
	public void generatePdfFromHtml(String html) throws IOException, DocumentException {
		  
		String outputFolder = "E:\\SimpleSolution\\order.pdf";
       // String outputFolder = System.getProperty("user.home") + File.separator + "thymeleaf.pdf";
        OutputStream outputStream = new FileOutputStream(outputFolder);

        ITextRenderer renderer = new ITextRenderer();
        renderer.setDocumentFromString(html);
        renderer.layout();
        renderer.createPDF(outputStream);

        outputStream.close();
    }
	/* public String parseThymeleafTemplate() {
	        

	        Context context = new Context();
	        context.setVariable("to", "Baeldung.com");

	        return templateEngine.process("thymeleaf_template", context);
	    }*/
	
	   private TemplateEngine createTemplateEngine() {
		   ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
	        templateResolver.setSuffix(".html");
	        templateResolver.setPrefix("pdf-templates/");
	        templateResolver.setTemplateMode(TemplateMode.HTML);

	      //  TemplateEngine templateEngine = new TemplateEngine();
	        SpringTemplateEngine templateEngine = new SpringTemplateEngine();
	        templateEngine.setTemplateResolver(templateResolver);
	        return templateEngine;
	   }
	   
		private String generateHtml(String templateFileName, Map<String, Object> data) {
	        TemplateEngine templateEngine = createTemplateEngine();
	        Context context = new Context();
	        context.setVariables(data);
	        String htmlContent = templateEngine.process(templateFileName, context);
	        return htmlContent;
	    }
		private String generateHtmlList(String templateFileName, List<OrderItemDetailDTO> data) {
	        TemplateEngine templateEngine = createTemplateEngine();
	        Context context = new Context();
	        context.setVariable("orderdretail",data);
	        String htmlContent = templateEngine.process(templateFileName, context);
	        return htmlContent;
	    }
		
		public ByteArrayInputStream  exportPdfFile(String templateFileName, Map<String, Object> data) {
	        String htmlContent = generateHtml(templateFileName, data);
	      /*  try {
	        	String outputFolder = "E:\\SimpleSolution\\order.pdf";
	            FileOutputStream fileOutputStream = new FileOutputStream(outputFolder);
	            ITextRenderer renderer = new ITextRenderer();
	            renderer.setDocumentFromString(htmlContent);
	            renderer.layout();
	            renderer.createPDF(fileOutputStream, false);
	            renderer.finishPDF();
	        } 
	        catch (FileNotFoundException e) {
	            e.printStackTrace();*/
	        ByteArrayInputStream byteArrayInputStream = null;
	        try {
	            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	            ITextRenderer renderer = new ITextRenderer();
	            renderer.setDocumentFromString(htmlContent);
	            renderer.layout();
	            renderer.createPDF(byteArrayOutputStream, false);
	            renderer.finishPDF();
	            byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
	            
	        } catch (DocumentException e) {
	            e.printStackTrace();
	        }
	        return byteArrayInputStream;
	    }
		
		public ByteArrayInputStream  exportPdfFileList(String templateFileName, List<OrderItemDetailDTO> data) {
	        String htmlContent = generateHtmlList(templateFileName, data);
	      /*  try {
	        	String outputFolder = "E:\\SimpleSolution\\order.pdf";
	            FileOutputStream fileOutputStream = new FileOutputStream(outputFolder);
	            ITextRenderer renderer = new ITextRenderer();
	            renderer.setDocumentFromString(htmlContent);
	            renderer.layout();
	            renderer.createPDF(fileOutputStream, false);
	            renderer.finishPDF();
	        } 
	        catch (FileNotFoundException e) {
	            e.printStackTrace();*/
	        ByteArrayInputStream byteArrayInputStream = null;
	        try {
	            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	            ITextRenderer renderer = new ITextRenderer();
	            renderer.setDocumentFromString(htmlContent);
	            renderer.layout();
	            renderer.createPDF(byteArrayOutputStream, false);
	            renderer.finishPDF();
	            byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
	            
	        } catch (DocumentException e) {
	            e.printStackTrace();
	        }
	        return byteArrayInputStream;
	    }
}
