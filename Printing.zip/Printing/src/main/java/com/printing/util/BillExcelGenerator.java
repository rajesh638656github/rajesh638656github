package com.printing.util;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.printing.DTO.BillDTO;



public class BillExcelGenerator {
	 
	 private List < BillDTO > billDTOList;
	    private XSSFWorkbook workbook;
	    private XSSFSheet sheet;
		public BillExcelGenerator(List<BillDTO> billDTOList) {
			
			this.billDTOList = billDTOList;
			workbook =  new XSSFWorkbook();
			
		}
	    
		  private void writeHeader() {
		        sheet = workbook.createSheet("BillDetail");
		        Row row = sheet.createRow(0);
		        CellStyle style = workbook.createCellStyle();
		        XSSFFont font = workbook.createFont();
		        font.setBold(true);
		        font.setFontHeight(16);
		        style.setFont(font);
		        createCell(row, 0, "Institution Name", style);
		        createCell(row, 1, "Bill ID", style);
		        createCell(row, 2, "Bill Date", style);
		        createCell(row, 3, "Total", style);
		        
		    }
		  
		   private void createCell(Row row, int columnCount, Object valueOfCell, CellStyle style) {
		        sheet.autoSizeColumn(columnCount);
		        Cell cell = row.createCell(columnCount);
		        if (valueOfCell instanceof Integer) {
		            cell.setCellValue((Integer) valueOfCell);
		        } else if (valueOfCell instanceof Long) {
		            cell.setCellValue((Long) valueOfCell);
		        } else if (valueOfCell instanceof String) {
		            cell.setCellValue((String) valueOfCell);
		           
		        }  else if (valueOfCell instanceof Double) {
		            cell.setCellValue((Double) valueOfCell);
		        	        }
		        else {
		            cell.setCellValue((Boolean) valueOfCell);
		        }
		        cell.setCellStyle(style);
		    }
		   
		   private void write() {
		        int rowCount = 1;
		        CellStyle style = workbook.createCellStyle();
		        XSSFFont font = workbook.createFont();
		        font.setFontHeight(14);
		        style.setFont(font);
		        for (BillDTO bill: billDTOList) {
		            Row row = sheet.createRow(rowCount++);
		            int columnCount = 0;
		            createCell(row, columnCount++, bill.getInstitutionName(), style);
		            createCell(row, columnCount++, bill.getBillId(), style);
		            createCell(row, columnCount++, bill.getTransactionDate(), style);
		            createCell(row, columnCount++, bill.getTotalAmount(), style);
		            
		        }
	    
}
		   public void generateExcelFile(HttpServletResponse response) throws IOException {
		        writeHeader();
		        write();
		        ServletOutputStream outputStream = response.getOutputStream();
		        workbook.write(outputStream);
		        workbook.close();
		        outputStream.close();
		    }
}
