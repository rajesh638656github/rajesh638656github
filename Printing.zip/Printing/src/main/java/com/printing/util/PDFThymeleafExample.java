package com.printing.util;
import com.lowagie.text.DocumentException;
//import org.thymeleaf.TemplateEngine;
import org.thymeleaf.spring6.*;
import org.thymeleaf.context.Context;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class PDFThymeleafExample {
	public void generatePdfFromHtml(String html) throws IOException, DocumentException {
		String outputFolder = "E:\\SimpleSolution\\order.pdf";
       // String outputFolder = System.getProperty("user.home") + File.separator + "thymeleaf.pdf";
        OutputStream outputStream = new FileOutputStream(outputFolder);

        ITextRenderer renderer = new ITextRenderer();
        renderer.setDocumentFromString(html);
        renderer.layout();
        renderer.createPDF(outputStream);

        outputStream.close();
    }
	public String parseThymeleafTemplate() {
	        ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
	        templateResolver.setSuffix(".html");
	        templateResolver.setPrefix("pdf-templates/");
	        templateResolver.setTemplateMode(TemplateMode.HTML);

	     // TemplateEngine templateEngine = new TemplateEngine();
	       SpringTemplateEngine templateEngine = new SpringTemplateEngine();
	        templateEngine.setTemplateResolver(templateResolver);

	        Context context = new Context();
	        context.setVariable("to", "Baeldung.com");

	        return templateEngine.process("thymeleaf_template", context);
	    }

}
