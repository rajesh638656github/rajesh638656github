package com.printing.util;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.printing.model.OrderItemDetailDTO;



public class ExcelGenerator {
	 private List < OrderItemDetailDTO > orderDetailList;
	 
	    private XSSFWorkbook workbook;
	    private XSSFSheet sheet;

	    public ExcelGenerator(List < OrderItemDetailDTO > orderDetailList) {
	        this.orderDetailList = orderDetailList;
	        workbook = new XSSFWorkbook();
	    }
	   
	    private void writeHeader() {
	        sheet = workbook.createSheet("OrderDetail");
	        Row row = sheet.createRow(0);
	        CellStyle style = workbook.createCellStyle();
	        XSSFFont font = workbook.createFont();
	        font.setBold(true);
	        font.setFontHeight(16);
	        style.setFont(font);
	        createCell(row, 0, "Order No", style);
	        createCell(row, 1, "Institution Name", style);
	        createCell(row, 2, "Department Name", style);
	    //    createCell(row, 3, "Contact Person Name", style);
	    //    createCell(row, 4, "Contact Number", style);
	        createCell(row, 3, "Item No", style);
	        createCell(row, 4, "Item Name", style);
	        createCell(row, 5, "Item Description", style);
	        createCell(row, 6, "Size", style);
	        createCell(row, 7, "Note", style);
	        createCell(row, 8, "Quantity", style);
	        createCell(row, 9, "Unit", style);
	      //  createCell(row, 9, "Price", style);
	        createCell(row, 10, "Item Status", style);
	      //  createCell(row, 13, "Comments", style);
	    //    createCell(row, 14, "Amount", style);
	    //    createCell(row, 15, "Total", style);
	    }
	    
	    private void writeHeaderForShortPendingOrderReport() {
	        sheet = workbook.createSheet("OrderDetail");
	        Row row = sheet.createRow(0);
	        CellStyle style = workbook.createCellStyle();
	        XSSFFont font = workbook.createFont();
	        font.setBold(true);
	        font.setFontHeight(16);
	        style.setFont(font);
	        createCell(row, 0, "Order No", style);
	        createCell(row, 1, "Institution Name", style);
	        createCell(row, 2, "Department Name", style);
	        createCell(row, 3, "Contact Person Name", style);
	        createCell(row, 4, "Contact Number", style);
	        createCell(row, 5, "Start Date", style);
	        createCell(row, 6, "Total", style);
	    }
	    private void createCell(Row row, int columnCount, Object valueOfCell, CellStyle style) {
	        sheet.autoSizeColumn(columnCount);
	        Cell cell = row.createCell(columnCount);
	        if (valueOfCell instanceof Integer) {
	            cell.setCellValue((Integer) valueOfCell);
	        } else if (valueOfCell instanceof Long) {
	            cell.setCellValue((Long) valueOfCell);
	        } else if (valueOfCell instanceof String) {
	            cell.setCellValue((String) valueOfCell);
	        } else {
	            cell.setCellValue((Boolean) valueOfCell);
	        }
	        cell.setCellStyle(style);
	    }
	    private void write() {
	        int rowCount = 1;
	        CellStyle style = workbook.createCellStyle();
	        XSSFFont font = workbook.createFont();
	        font.setFontHeight(14);
	        style.setFont(font);
	        for (OrderItemDetailDTO order: orderDetailList) {
	            Row row = sheet.createRow(rowCount++);
	            int columnCount = 0;
	            createCell(row, columnCount++, order.getOrderId(), style);
	            createCell(row, columnCount++, order.getInstitutionName(), style);
	            createCell(row, columnCount++, order.getDepartmentName(), style);
	          //  createCell(row, columnCount++, order.getContactPersonName(), style);
	          //  createCell(row, columnCount++, order.getContactNumber(), style);
	            createCell(row, columnCount++, order.getOrderItemId(), style);
	            createCell(row, columnCount++, order.getItemName(), style);
	            createCell(row, columnCount++, order.getItemDescription(), style);
	            createCell(row, columnCount++, order.getSizeName(), style);
	            createCell(row, columnCount++, order.getNote(), style);
	            createCell(row, columnCount++, order.getQuantity(), style);
	            createCell(row, columnCount++, order.getUnitName(), style);
	           // createCell(row, columnCount++, order.getPrice(), style);
	            createCell(row, columnCount++, order.getItemStatus(), style);
	          //  createCell(row, columnCount++, order.getComments(), style);
	         //   createCell(row, columnCount++, order.getAmount(), style);
	          //  createCell(row, columnCount++, order.getTotalAmount(), style);
	        }
	    }
	    private void writeForShortPendingOrderReport() {
	        int rowCount = 1;
	        CellStyle style = workbook.createCellStyle();
	        XSSFFont font = workbook.createFont();
	        font.setFontHeight(14);
	        style.setFont(font);
	        for (OrderItemDetailDTO order: orderDetailList) {
	            Row row = sheet.createRow(rowCount++);
	            int columnCount = 0;
	            createCell(row, columnCount++, order.getOrderId(), style);
	            createCell(row, columnCount++, order.getInstitutionName(), style);
	            createCell(row, columnCount++, order.getDepartmentName(), style);
	            createCell(row, columnCount++, order.getContactPersonName(), style);
	            createCell(row, columnCount++, order.getContactNumber(), style);
	            createCell(row, columnCount++, order.getStartDate(), style);
	            createCell(row, columnCount++, order.getTotalAmount(), style);
	        }
	    }
	    public void generateExcelFile(HttpServletResponse response) throws IOException {
	        writeHeader();
	        write();
	        ServletOutputStream outputStream = response.getOutputStream();
	        workbook.write(outputStream);
	        workbook.close();
	        outputStream.close();
	    }
	    public void generateExcelFileForShortPendingOrderReport(HttpServletResponse response) throws IOException {
	    	writeHeaderForShortPendingOrderReport();
	    	writeForShortPendingOrderReport();
	        ServletOutputStream outputStream = response.getOutputStream();
	        workbook.write(outputStream);
	        workbook.close();
	        outputStream.close();
	    }
}
