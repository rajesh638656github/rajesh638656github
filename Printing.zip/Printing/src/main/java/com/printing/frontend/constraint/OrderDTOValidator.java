package com.printing.frontend.constraint;

import com.printing.DTO.OrderDTO;
import com.printing.DTO.OrderItemDTO;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
/* import com.printing.frontend.constraint.*;
import java.util.Calendar;
import java.util.Date;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.lang.Object; */
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.printing.frontend.controller.*;

public class OrderDTOValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return OrderDTO.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		OrderDTO orderDTO = (OrderDTO) obj;
		long institutionId = orderDTO.getInstitutionId();
		int departmentId = orderDTO.getDepartmentId();
		Date startDate = orderDTO.getStartDate();
		Date endDate = orderDTO.getEndDate();
		List<OrderItemDTO> orderitems = orderDTO.getOrderitems();

		if (institutionId == 0L) {

		}

		for (OrderItemDTO orderitemDTO : orderitems) {
			orderitemDTO.getItemId();
			orderitemDTO.getSizeId();
			orderitemDTO.getUnitId();

		}

	}

}
