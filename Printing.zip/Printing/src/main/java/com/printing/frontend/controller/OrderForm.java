package com.printing.frontend.controller;

public class OrderForm {
	private String orderId;
	private String institutionId;
	private String departmentId;
	private String itemId;
	private String sizeId;
	private String unitId;
	private String quantity;
	private String price;
	private String transactionDate;

	public OrderForm() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderForm(String orderId, String institutionId, String departmentId, String itemId, String sizeId,
			String unitId, String quantity, String price, String transactionDate) {
		super();
		this.orderId = orderId;
		this.institutionId = institutionId;
		this.departmentId = departmentId;
		this.itemId = itemId;
		this.sizeId = sizeId;
		this.unitId = unitId;
		this.quantity = quantity;
		this.price = price;
		this.transactionDate = transactionDate;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getSizeId() {
		return sizeId;
	}

	public void setSizeId(String sizeId) {
		this.sizeId = sizeId;
	}

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	@Override
	public String toString() {
		return "OrderForm [orderId=" + orderId + ", institutionId=" + institutionId + ", departmentId=" + departmentId
				+ ", itemId=" + itemId + ", sizeId=" + sizeId + ", unitId=" + unitId + ", quantity=" + quantity
				+ ", price=" + price + ", transactionDate=" + transactionDate + "]";
	}

}