package com.printing.frontend.controller;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;


import java.util.Arrays;
import java.lang.Math;
import java.time.YearMonth;
import org.modelmapper.ModelMapper;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.dao.DataIntegrityViolationException;
//import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.transaction.annotation.Transactional;

import com.printing.registrationlogin.dto.UserDto;
import com.printing.registrationlogin.entity.User;
import com.printing.registrationlogin.service.UserService;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;

import java.time.LocalDate;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.text.*;
import java.util.HashSet;
import java.util.Iterator;
/*
import java.text.*;
 
import java.util.Locale;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
*/

/*import javax.validation.Configuration;
import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.constraints.*;*/


import jakarta.validation.Valid;

import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.validation.ConstraintValidatorFactory;
import jakarta.validation.Configuration;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintViolation;
import com.printing.service.PopulateOrderScreenService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import com.printing.model.*;
import com.printing.registrationlogin.dto.UserDto;
import com.printing.registrationlogin.entity.User;
import com.printing.registrationlogin.service.UserService;
//import com.printing.model.SizeDTO;
import com.printing.frontend.constraint.*;
import com.printing.DTO.BillDTO;
import com.printing.DTO.BillOrderDTO;
import com.printing.DTO.DepartmentDTO;
import com.printing.DTO.InstitutionDTO;
import com.printing.DTO.ItemDTO;
import com.printing.DTO.ItemPriceDTO;
import com.printing.DTO.ItemRateBatchDTO;
import com.printing.DTO.ItemRateDTO;
import com.printing.DTO.ItemStatusDTO;
import com.printing.DTO.ItemRatePhaseDTO;
import com.printing.DTO.OrderDTO;
import com.printing.DTO.OrderItemDTO;
import com.printing.DTO.QuotationDTO;
import com.printing.DTO.QuotationOrderItemDTO;
import com.printing.DTO.OrderUpdateDTO;
import com.printing.DTO.PhaseNameDTO;
import com.printing.DTO.OrderItemUpdateDTO;
import com.printing.DTO.OrderMasterDTO;
import com.printing.DTO.OrderAddItemDTO;
import com.printing.DTO.OrderItemAddItemDTO;
import com.printing.DTO.SizeDTO;
import com.printing.DTO.UnitDTO;
import com.printing.DTO.OrderItemPriceDTO;
import com.printing.entity.*;
import com.printing.entity.OrderItem;
import com.printing.repository.*;
import com.printing.util.*;
import com.printing.util.ConvertNumberToWords;

import jakarta.servlet.http.HttpServletResponse;

import com.printing.util.PDFThymeleaf;
import com.lowagie.text.DocumentException;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import org.apache.commons.io.IOUtils;
import jakarta.servlet.ServletOutputStream;

@Controller
//@SessionAttributes("orderId")

public class OrderFormFrontendController {
	@Autowired
	private PopulateOrderScreenService populateOrderScreenService;
	@Autowired
	private UserService userService;
	@Autowired
	private OrderFormValidator validator;
	@Autowired
	private OrderRepository orderrepository;
	@Autowired
	private OrderItemRepository orderitemrepository;
	@Autowired
	private BillRepository billRepository;
	@Autowired
	private BillOrderRepository billOrderRepository;
	@Autowired
	private InstitutionRepository institutionRepository;
	@Autowired
	private DepartmentRepository departmentRepository;
	@Autowired
	private ItemRepository itemRepository;
	@Autowired
	private UnitRepository unitRepository;
	@Autowired
	private SizeRepository sizeRepository;
	@Autowired
	private ItemStatusRepository itemStatusRepository;
	@Autowired
	private ItemRateRepository itemRateRepository;
	@Autowired
	private OrderItemPriceRepository orderItemPriceRepository;
	@Autowired
	private ItemRatePhaseRepository itemRatePhaseRepository;
	@Autowired
	private QuotationRepository quotationRepository;
	@Autowired
	private QuotationOrderItemRepository quotationOrderItemRepository;
	@PersistenceContext
	private EntityManager entityManager;

	SecurityContextLogoutHandler logoutHandler = new SecurityContextLogoutHandler();
	
	 private static final int ITEMS_PER_PAGE = 16; 

	// @DateTimeFormat(pattern = "dd/MM/yyyy")

	/*
	 * @RequestMapping(value = { "/welcome" }, method = RequestMethod.GET)
	 * 
	 * public String showIndexPage() { return "index";
	 * 
	 * }
	 */

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		System.out.println("Init Binder is invoked");

		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));

	}

	@RequestMapping(value = { "/welcome" }, method = RequestMethod.GET)
	public String showWelcome(Model model) {
		System.out.println("Printing from welcome");
		return "welcome";
	}
	


	@GetMapping("testing")
	public String testing() {
		return "responsivescreen";
	}
	

	@GetMapping("index")
	public String home() {
		return "index";
	}

	@GetMapping("/login")
	public String loginForm() {
		return "login";
	}

	@PostMapping("/my/logout")
	public String performLogout(Authentication authentication, HttpServletRequest request) {
		// .. perform logout
		// this.logoutHandler.doLogout(request, response, authentication);
		this.logoutHandler.setInvalidateHttpSession(true);
		return "redirect:/home";
	}

	@GetMapping("register")
	public String showRegistrationForm(Model model) {
		UserDto user = new UserDto();
		model.addAttribute("user", user);
		return "register";
	}


	@GetMapping("/update-password")
	public String updatePasswordForm(Model model) {
		UserDto user = new UserDto();
		model.addAttribute("user", user);
		return "update-password";
	}
	
	
	
	@PostMapping("/update-password")
	public String saveNewPassword(@ModelAttribute("user") UserDto user, BindingResult result, Model model) {
		 try {
			 System.out.println("Printing Email ID"+user.getEmail());
		User existing = userService.findByEmail(user.getEmail());
		//System.out.println("Printing existing user id" + existing.getEmail());
    	//System.out.println("Printing existing Password" + existing.getPassword());
		model.addAttribute("user", user);
	
		if (existing == null) {
            model.addAttribute("error", "New passwords do not match");
            return "update-password";
        }
			
		userService.updatePassword(user);
        model.addAttribute("message", "Password updated successfully");
    } catch (Exception e) {
        // Handles exceptions during password update process.
        model.addAttribute("error", e.getMessage());
    }
    return "redirect:/update-password?success";
}
		
		
	

	
	// handler method to handle register user form submit request
	@PostMapping("/register/save")
	public String registration(@Valid @ModelAttribute("user") UserDto user, BindingResult result, Model model) {
		User existing = userService.findByEmail(user.getEmail());
		if (existing != null) {
			result.rejectValue("email", null, "There is already an account registered with that email");
		}
		if (result.hasErrors()) {
			model.addAttribute("user", user);
			return "register";
		}
		userService.saveUser(user);
		return "redirect:/register?success";
	}

	@GetMapping("/users")
	public String listRegisteredUsers(Model model) {
		List<UserDto> users = userService.findAllUsers();
		model.addAttribute("users", users);
		return "users";
	}

	@GetMapping("/export-to-pdf")
	public void generatePdfFile(HttpServletResponse response) throws DocumentException, IOException {
		response.setContentType("application/pdf");
		DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-DD:HH:MM:SS");
		String currentDateTime = dateFormat.format(new Date());
		String headerkey = "Content-Disposition";
		String headervalue = "attachment; filename=student" + currentDateTime + ".pdf";
		response.setHeader(headerkey, headervalue);
		/*
		 * List < Student > listofStudents = studentService.getStudentList();
		 * PdfGenerator generator = new PdfGenerator();
		 * generator.generate(listofStudents, response);
		 */
	}

	@GetMapping("/export-to-excel")
	public void exportIntoExcelFile(HttpServletResponse response) throws IOException {
		response.setContentType("application/octet-stream");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=student" + currentDateTime + ".xlsx";
		response.setHeader(headerKey, headerValue);

		/*
		 * List <Student> listOfStudents = studentService.getTheListStudent();
		 * ExcelGenerator generator = new ExcelGenerator(listOfStudents);
		 * generator.generateExcelFile(response);
		 */
	}

	@PostMapping(value = "/ordermanager", params = { "addItem" })
	public String addItem(OrderDTO orderDTO, BindingResult bindingResult, Model model) {
		orderDTO.getOrderitems().add(new OrderItemDTO());
		populateDropDowns(model);
		return "createorder";
	}

	@PostMapping(value = "/ordermanager", params = { "removeItem" })
	public String removeItem(OrderDTO orderDTO, BindingResult bindingResult, HttpServletRequest request, Model model) {
		int itemId = Integer.valueOf(request.getParameter("removeItem"));
		orderDTO.getOrderitems().remove(itemId);
		populateDropDowns(model);
		return "createorder";
	}

	@PostMapping(value = "/ordermanager", params = { "updatePrice" })
	public String updatePrice(@Valid @ModelAttribute("orderDTO") OrderDTO orderDTO, BindingResult bindingResult,
			HttpServletRequest request, Model model, RedirectAttributes redirectAttributes) {
		// int itemId = Integer.valueOf(request.getParameter("updatePrice"));
		int selectedRow = Integer.valueOf(request.getParameter("updatePrice"));
		System.out.println("Printing Selected Row Value"+ selectedRow);

		System.out.println("Printing from save method");
		if (bindingResult.hasErrors()) {
			System.out.println("Error block");
			System.out.println("printing error count" + bindingResult.getErrorCount());
			Map<String, Object> errorMessages = new HashMap();
			if (bindingResult.hasErrors()) {

				List<FieldError> fes = bindingResult.getFieldErrors();
				for (FieldError fe : fes) {
					errorMessages.put(fe.getField(), fe.getDefaultMessage());
				}

			}

			redirectAttributes.addFlashAttribute("errorMessages", errorMessages);
			redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.orderDTO",
					bindingResult);
			redirectAttributes.addFlashAttribute("orderDTO", orderDTO);
			return "redirect:/ordermanager";

		}

		Order order = new Order();
		order.setInstitutionId(orderDTO.getInstitutionId());
		order.setDepartmentId(orderDTO.getDepartmentId());
		order.setStartDate(new Date());
		order.setProfitMargin(orderDTO.getProfitMargin());
		order.setContactPersonName(orderDTO.getContactPersonName());
		order.setContactNumber(orderDTO.getContactNumber());
		orderrepository.save(order);

		double totalAmount = 0.0;
		List<OrderItemDTO> orderitemList = orderDTO.getOrderitems();

		List<OrderItem> orderItemlist = new ArrayList<>();
		for (OrderItemDTO orderItemDTO : orderitemList) {

			System.out.println("Printing Order Item" + orderItemDTO.getItemId() + orderItemDTO.getSizeId()
					+ orderItemDTO.getSizeId() + orderItemDTO.getUnitId() + orderItemDTO.getQuantity()
					+ orderItemDTO.getPrice());
			OrderItem orderItem = new OrderItem();
			orderItem.setItemId(orderItemDTO.getItemId());
			orderItem.setItemDescription(orderItemDTO.getItemDescription());
			orderItem.setSizeId(orderItemDTO.getSizeId());
			orderItem.setNote(orderItemDTO.getNote());
			orderItem.setUnitId(orderItemDTO.getUnitId());
			orderItem.setQuantity(orderItemDTO.getQuantity());
			orderItem.setPrice(orderItemDTO.getPrice());
			if (orderItemDTO.getPrice() != null && orderItemDTO.getQuantity() != null) {
				double amount = orderItemDTO.getPrice() * orderItemDTO.getQuantity();
				totalAmount = totalAmount + amount;
				orderItem.setAmount(amount);
			}
			orderItem.setItemStatusId(orderItemDTO.getItemStatusId());

			orderItem.setComments(orderItemDTO.getComments());

			System.out.println("Printing Status Id" + orderItemDTO.getItemStatusId());

			// orderItem.setComments(orderItemDTO.getComments());
			if (orderItemDTO.getItemStatusId() >= 1) {
				ItemStatus itemStatus = itemStatusRepository.findByItemStatusId(orderItemDTO.getItemStatusId());
				Date date = new Date();
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				String strDate = formatter.format(date);
				String commentWithDate = " : " + strDate + " : " + itemStatus.getItemStatusName();
				System.out.println("Printing Comments inside if block" + commentWithDate);
				orderItem.setComments(orderItemDTO.getComments() + commentWithDate);
			}
			orderItem.setOrder(order);
			orderitemrepository.save(orderItem);
		}

		
		order.setTotal(totalAmount);
		orderrepository.save(order);

		long orderId = order.getId();
		Order orderEntity = orderrepository.findById(Long.valueOf(orderId));
		System.out.println("Printing Newly Generated Order Id" + orderEntity.getId());
	    
	    List<Long> orderIds = new ArrayList<Long>();
		orderIds.add(Long.valueOf(orderId));
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIds);
		
		System.out.println("Order Details Size" + orderdetails.size());
		OrderItemDetailDTO orderItemDetailDTO = orderdetails.get(selectedRow);
		String orderItemId = orderItemDetailDTO.getOrderItemId();
		String orderItemName= orderItemDetailDTO.getItemName();
		
		int orderItemQuantity =  Integer.parseInt(orderItemDetailDTO.getQuantity());
		List<ItemPriceDTO> itemRateList = new ArrayList<ItemPriceDTO>();

		ItemPriceCalculation itemPriceCalculation = new ItemPriceCalculation();
		itemPriceCalculation.setOrderId(orderId);
	    itemPriceCalculation.setOrderItemId(Long.parseLong(orderItemId));
	    
		itemPriceCalculation.setOrderItemName(orderItemName);
		itemPriceCalculation.setOrderItemQuantity(orderItemQuantity);
		
	//	List<ItemRate> ItemRateEntityList = itemRateRepository.findAll();
		List<ItemRate> ItemRateEntityList = itemRateRepository.findAllByOrderByItemRatePhaseId();
		List<String> phaseNames = new ArrayList<String>();
		
		ItemRateEntityList.forEach(item -> {
		//	String phaseName = item.getItemRatePhaseName();
			ItemPriceDTO itemPriceDTO = new ItemPriceDTO();
			itemPriceDTO.setItemRateIdDB(item.getItemRateId());
			itemPriceDTO.setPhaseIdDB(item.getItemRatePhaseId());
			itemPriceDTO.setItemNameDB(item.getItemRateName());
			itemPriceDTO.setItemRate(item.getItemRate());
			itemPriceCalculation.add(itemPriceDTO);
		//	ItemPriceDTO itemPhaseName = new ItemPriceDTO();
		//	itemPhaseName.setItemNameDB(item.getItemRatePhaseName());
			
		//	phaseNames.add(item.getItemRatePhaseName());

			

		}); 
		

		
		List<ItemRatePhaseDTO> itemRatePhaseList = populateOrderScreenService.findAllItemRatePhase();

		
		
	//	System.out.println("Printing Size of Item Price DTOs Array" + sizeOfItemPriceArray2);
		model.addAttribute("itemPriceCalculation", itemPriceCalculation);
		//model.addAttribute("itemRateList", itemRateList);
	//	model.addAttribute("ItemRateEntityList", ItemRateEntityList);
		model.addAttribute("itemRatePhaseList", itemRatePhaseList);
		

	
		return "calculateitempriceadd";

	}

	@GetMapping(value = { "/ordermanager" })

	public String showOrder(OrderDTO orderDTO, Model model) {

		model.addAttribute("orderDTO", orderDTO);

		populateDropDowns(model);
		return "createorder";
	}

	@PostMapping(value = "/ordermanager", params = { "save" })

	public String saveOrder(@Valid @ModelAttribute("orderDTO") OrderDTO orderDTO, BindingResult bindingResult,
			Model model, RedirectAttributes redirectAttributes) {

		System.out.println("Printing from save method");
		if (bindingResult.hasErrors()) {
			System.out.println("Error block");
			System.out.println("printing error count" + bindingResult.getErrorCount());
			Map<String, Object> errorMessages = new HashMap();
			if (bindingResult.hasErrors()) {

				List<FieldError> fes = bindingResult.getFieldErrors();
				for (FieldError fe : fes) {
					errorMessages.put(fe.getField(), fe.getDefaultMessage());
				}

			}

			redirectAttributes.addFlashAttribute("errorMessages", errorMessages);
			redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.orderDTO",
					bindingResult);
			redirectAttributes.addFlashAttribute("orderDTO", orderDTO);
			return "redirect:/ordermanager";

		}

		int institutionId = orderDTO.getInstitutionId();
		int departmentId = orderDTO.getDepartmentId();
		Date startDT = orderDTO.getStartDate();
		Date endDT = orderDTO.getEndDate();

		List orderItems = orderDTO.getOrderitems();
		OrderItemDTO oitem = (OrderItemDTO) orderItems.get(0);
		long id = oitem.getId();
		int itemid = oitem.getItemId();
		int size = oitem.getSizeId();
		Integer quantity = oitem.getQuantity();
		int unit = oitem.getUnitId();
		Double price = oitem.getPrice();
		System.out.println(orderItems.size());
		System.out.println("Order Details" + institutionId + departmentId + startDT + endDT);
		System.out.println("Item Details" + id + itemid + size + quantity + unit + price);

		ModelMapper modelMapper = new ModelMapper();

		System.out.println("Printing Order Master Details" + orderDTO.getInstitutionId() + orderDTO.getDepartmentId()
				+ orderDTO.getStartDate() + orderDTO.getEndDate());
		Order order = new Order();
		order.setInstitutionId(orderDTO.getInstitutionId());
		order.setDepartmentId(orderDTO.getDepartmentId());
		order.setStartDate(new Date());
		// order.setEndDate();
		order.setContactPersonName(orderDTO.getContactPersonName());
		order.setContactNumber(orderDTO.getContactNumber());
		order.setTotal(orderDTO.getTotal());
		order.setProfitMargin(orderDTO.getProfitMargin());
		
		orderrepository.save(order);

		double totalAmount = 0.0;
		List<OrderItemDTO> orderitemList = orderDTO.getOrderitems();

		List<OrderItem> orderItemlist = new ArrayList<>();
		for (OrderItemDTO orderItemDTO : orderitemList) {

			System.out.println("Printing Order Item" + orderItemDTO.getItemId() + orderItemDTO.getSizeId()
					+ orderItemDTO.getSizeId() + orderItemDTO.getUnitId() + orderItemDTO.getQuantity()
					+ orderItemDTO.getPrice());
			OrderItem orderItem = new OrderItem();
			orderItem.setItemId(orderItemDTO.getItemId());
			orderItem.setItemDescription(orderItemDTO.getItemDescription());
			orderItem.setSizeId(orderItemDTO.getSizeId());
			orderItem.setNote(orderItemDTO.getNote());
			orderItem.setUnitId(orderItemDTO.getUnitId());
			orderItem.setQuantity(orderItemDTO.getQuantity());
			orderItem.setPrice(orderItemDTO.getPrice());
			if (orderItemDTO.getPrice() != null && orderItemDTO.getQuantity() != null) {
				double amount = orderItemDTO.getPrice() * orderItemDTO.getQuantity();
				totalAmount = totalAmount + amount;
				orderItem.setAmount(amount);
			}
			orderItem.setItemStatusId(orderItemDTO.getItemStatusId());

			orderItem.setComments(orderItemDTO.getComments());

			System.out.println("Printing Status Id" + orderItemDTO.getItemStatusId());

			// orderItem.setComments(orderItemDTO.getComments());
			if (orderItemDTO.getItemStatusId() >= 1) {
				ItemStatus itemStatus = itemStatusRepository.findByItemStatusId(orderItemDTO.getItemStatusId());
				Date date = new Date();
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				String strDate = formatter.format(date);
				String commentWithDate = " : " + strDate + " : " + itemStatus.getItemStatusName();
				System.out.println("Printing Comments inside if block" + commentWithDate);
				orderItem.setComments(orderItemDTO.getComments() + commentWithDate);
			}
			orderItem.setOrder(order);
			orderitemrepository.save(orderItem);
		}

		long orderId = order.getId();
		order.setTotal(totalAmount);
		orderrepository.save(order);
		System.out.println("Printing Newly Generated Order Id" + orderId);
		model.addAttribute("orderId", orderId);
		List<Long> orderIds = new ArrayList<Long>();
		orderIds.add(Long.valueOf(orderId));
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIds);
		System.out.println("Order Details Size" + orderdetails.size());
		model.addAttribute("orderdetails", orderdetails);

		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIds);
		
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("contactPersonName", orderMasterDTO.getContactPersonName());
		model.addAttribute("contactNumber", orderMasterDTO.getContactNumber());
		model.addAttribute("orderTotal", orderMasterDTO.getTotal());
		model.addAttribute("profitMargin", orderMasterDTO.getProfitMargin());
		

		model.addAttribute("orderdetails", orderdetails);
		
			
		

		/*
		 * Map<String, Object> data = new HashMap<>();
		 * data.put("masterdetail",orderMasterDTO);
		 * data.put("itemdetails",orderdetails); PdfFileExporter pdfFileExporter = new
		 * PdfFileExporter(); String pdfFileName = "E:\\SimpleSolution\\order.pdf";
		 * pdfFileExporter.exportPdfFile("createordersuccesstemplate", data,
		 * pdfFileName);
		 */
		return "createordersuccess";
	}

	@GetMapping("/showallactiveorderforedit")
	public String showAllActiveOrderForEdit(Model model, HttpServletRequest request) throws Exception {

		List<OrderItemDetailDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrderItemDetails();
		model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
		
		return "showallactiveorderforedit";
	}

	@GetMapping("/showdeditorder/{orderId}")
	public String showdEditOrder(@PathVariable("orderId") long orderId, HttpServletResponse response,
			HttpServletRequest request, Model model) throws IOException {

		// long orderid = Long.parseLong(request.getParameter("orderId"));
		long orderid = orderId;

		updatePopulateDropDowns(model);

		Order orderEntity = orderrepository.findById(orderid);
		ModelMapper modelMapper = new ModelMapper();
		OrderUpdateDTO orderUpdateDTO = modelMapper.map(orderEntity, OrderUpdateDTO.class);
		System.out.println("Printing Order Id From showeditorderitems" + orderUpdateDTO.getId());
		String orderIdStr = Long.toString(orderid);

		model.addAttribute("orderUpdateDTO", orderUpdateDTO);
		model.addAttribute("orderId", orderIdStr);

		return "editorder";

	}

	@GetMapping("/showallactiveorderforadditem")
	public String showAllActiveOrderForAddItem(Model model, HttpServletRequest request) throws Exception {

		List<OrderItemDetailDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrderItemDetails();
		model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
		
		return "showallactiveorderforadditem";
	}

	@GetMapping("/showeditorderitemsadditem/{orderId}")

	public String showeditorderitemsadditem(@PathVariable("orderId") long orderId, HttpServletResponse response,
			HttpServletRequest request, Model model) throws IOException {

		long orderid = orderId;

		updatePopulateDropDowns(model);

		List<Long> orderIDs = new ArrayList<Long>();
		orderIDs.add(Long.valueOf(orderId));
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIDs);
		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIDs);
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("orderTotal", orderMasterDTO.getTotal());
		model.addAttribute("profitMargin", orderMasterDTO.getProfitMargin());
		System.out.println("Order Details Size" + orderdetails.size());
		model.addAttribute("orderdetails", orderdetails);

		Order orderEntity = orderrepository.findById(orderid);
		ModelMapper modelMapper = new ModelMapper();
		OrderAddItemDTO orderAddItemDTO = new OrderAddItemDTO();
		orderAddItemDTO.setId(orderid);

		String orderIdStr = Long.toString(orderid);

		model.addAttribute("orderAddItemDTO", orderAddItemDTO);
		model.addAttribute("orderId", orderIdStr);

		return "editorderadditem";

	}

	@GetMapping("/showallactiveorderfordeleteitem")
	public String showAllActiveOrderForDeleteItem(Model model, HttpServletRequest request) throws Exception {


		List<OrderItemDetailDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrderItemDetails();
		model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
		return "showallactiveorderfordeleteitem";
	}

	@GetMapping("/showeditorderitemsdeleteitem/{orderId}")

	public String showeEitOrderItemsDeleteItem(@PathVariable("orderId") long orderId, HttpServletResponse response,
			HttpServletRequest request, Model model) throws IOException {
		long orderid = orderId;
		System.out.println("Printing Order Id from showeditorderdeleteitem" + orderId);

		List<Long> orderIds = new ArrayList<Long>();
		orderIds.add(Long.valueOf(orderid));
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIds);
		System.out.println("Order Details Size" + orderdetails.size());

		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIds);
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("orderTotal", orderMasterDTO.getTotal());
		model.addAttribute("profitMargin", orderMasterDTO.getProfitMargin());
			
		model.addAttribute("orderdetails", orderdetails);
		OrderItemIds orderItemIds = new OrderItemIds();
		orderItemIds.setOrderId(Long.toString(orderid));
		model.addAttribute("orderItemIds", orderItemIds);

		return "editorderdeleteitem";

	}

	@GetMapping("/showallactiveorderforcreateorderfromexistingorder")
	public String showAllActiveOrderForCreateOrderFromExistingOrder(Model model, HttpServletRequest request)
			throws Exception {

		List<OrderItemDetailDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrderItemDetails();
		model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
		return "showallactiveorderforcreateorderfromexistingorder";
	}

	@GetMapping("/showcreateorderfromexistingorder/{orderId}")

	public String showcreateorderfromexistingorder(@PathVariable("orderId") long orderId, HttpServletResponse response,
			HttpServletRequest request, Model model) throws IOException {

		String orderidStr = Long.toString(orderId);
		System.out.println("Printing Order Id from showeditorderdeleteitem" + orderId);
		long orderid = Long.parseLong(orderidStr);

		List<Long> orderIds = new ArrayList<Long>();
		orderIds.add(Long.valueOf(orderId));
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIds);
		System.out.println("Order Details Size" + orderdetails.size());

		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIds);
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("startDate", orderMasterDTO.getStartDate());
		model.addAttribute("endDate", orderMasterDTO.getEndDate());
		model.addAttribute("totalAmount", orderMasterDTO.getTotal());
		model.addAttribute("orderdetails", orderdetails);
		OrderItemIds orderItemIds = new OrderItemIds();
		orderItemIds.setOrderId(orderidStr);
		model.addAttribute("orderItemIds", orderItemIds);

		return "createorderfromexistingorder";

	}
	
	@GetMapping("/showallactiveorderfororderreport")
	public String showAllActiveOrderForOrderReport(Model model, HttpServletRequest request) throws Exception {

		List<OrderItemDetailDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrderItemDetails();
		model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
		return "showallactiveorderfororderreport";
	}
	

		@GetMapping("/showorderreport/{orderId}")

		public String showOrderReport(@PathVariable("orderId") long orderId, HttpServletResponse response,
				HttpServletRequest request, Model model) throws IOException {

	//	String orderId = orderSearchResultDTO.getOrderId();
		long orderid = orderId;
		List<Long> orderID = new ArrayList<Long>();
		orderID.add(Long.valueOf(orderId));

		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderID);
		System.out.println("Order Details Size" + orderdetails.size());
		model.addAttribute("orderdetails", orderdetails);
		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderID);
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("startDate", orderMasterDTO.getStartDate());
		model.addAttribute("endDate", orderMasterDTO.getEndDate());
		model.addAttribute("contactPersonName", orderMasterDTO.getContactPersonName());
		model.addAttribute("contactNumber", orderMasterDTO.getContactNumber());
		model.addAttribute("totalAmount", orderMasterDTO.getTotal());
		Map<String, Object> data = new HashMap<>();
		data.put("masterdetail", orderMasterDTO);
		data.put("itemdetails", orderdetails);

		request.getSession().setAttribute("orderdownload", data);
		request.getSession().setAttribute("orderdetail", orderdetails);
		
		return "showorderreport";

	}
		
		@GetMapping("/showallactiveorderforordercostreport")
		public String showallactiveorderforordercostreport(Model model, HttpServletRequest request) throws Exception {

			List<OrderItemDetailDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrderItemDetails();
			model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
			return "showallactiveorderforordercostreport";
		}
		
		@GetMapping("/showordercostreport/{orderId}")

		public String showOrderCostReport(@PathVariable("orderId") long orderId, HttpServletResponse response,
				HttpServletRequest request, Model model) throws IOException {
			

			//String orderId = orderSearchResultDTO.getOrderId();
			long orderid = orderId;
			List<Long> orderID = new ArrayList<Long>();
			List<Long> orderItemIDs = new ArrayList<Long>();
			orderID.add(Long.valueOf(orderId));

			List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderID);
			orderdetails.forEach(item -> {
				orderItemIDs.add(Long.parseLong(item.getOrderItemId()));
			});

			List<OrderItemPriceDTO> orderItemPriceDetails = populateOrderScreenService
					.findOrderItemPriceDetailByOrderItemId(orderItemIDs);
			System.out.println("Order Item Price Detail Size" + orderItemPriceDetails.size());
			model.addAttribute("orderdetails", orderdetails);
			model.addAttribute("orderitempricedetail", orderItemPriceDetails);
			List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderID);
			OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
			model.addAttribute("orderNo", orderMasterDTO.getOrderId());
			model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
			model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
			model.addAttribute("startDate", orderMasterDTO.getStartDate());
			model.addAttribute("endDate", orderMasterDTO.getEndDate());
			model.addAttribute("contactPersonName", orderMasterDTO.getContactPersonName());
			model.addAttribute("contactNumber", orderMasterDTO.getContactNumber());
			model.addAttribute("totalAmount", orderMasterDTO.getTotal());
			Map<String, Object> data = new HashMap<>();
			data.put("masterdetail", orderMasterDTO);
			data.put("itemdetails", orderdetails);
			data.put("orderitempricedetail", orderItemPriceDetails);

			request.getSession().setAttribute("orderpricedownload", data);
			request.getSession().setAttribute("orderdetail", orderdetails);

			// PDFThymeleafExampleModified thymeleaf2Pdf = new
			// PDFThymeleafExampleModified();
			// ByteArrayInputStream exportedData =
			// thymeleaf2Pdf.exportPdfFile("showorderreporttemplate", data);
			// response.setContentType("application/octet-stream");
			// response.setHeader("Content-Disposition", "attachment;
			// filename=receipt.pdf");
			/*
			 * PdfFileExporter pdfFileExporter = new PdfFileExporter(); String pdfFileName =
			 * "E:\\SimpleSolution\\order.pdf";
			 * pdfFileExporter.exportPdfFile("showorderreporttemplate", data, pdfFileName);
			 */

			// PDFThymeleafExampleModified thymeleaf2Pdf = new
			// PDFThymeleafExampleModified();
			// String pdfFileName = "E:\\SimpleSolution\\order.pdf";
			// thymeleaf2Pdf.exportPdfFile("showorderreporttemplate", data, pdfFileName);

			// String html = thymeleaf2Pdf.parseThymeleafTemplate();
			// thymeleaf2Pdf.generatePdfFromHtml(html);
			// return templateEngine.process("thymeleaf_template", context);
			return "showordercostreport";

		}


	@RequestMapping(value = { "/ordersearchfororderedit" }, method = RequestMethod.GET)
	public String showOrderSearchForOrderEdit(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchEditDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchEditDTO", orderSearchEditDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		return "ordersearchfororderedit";

	}

	@PostMapping("/showordersearchresultfororderedit")
	public String showOrderSearchResultForOrderEdit(
			@ModelAttribute("orderSearchEditDTO") OrderSearchDTO orderSearchEditDTO, BindingResult bindingResult,
			Model model, RedirectAttributes redirectAttributes) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String orderIdString = orderSearchEditDTO.getOrderId();
		if (!orderIdString.isEmpty()) {
			long orderId = Long.parseLong(orderSearchEditDTO.getOrderId());
			// long orderId = Long.parseLong(orderSearchDTO.getOrderId());
			OrderSearchDTO orderSearchResultDTO = new OrderSearchDTO();
			orderSearchResultDTO.setOrderId(orderIdString);
			redirectAttributes.addFlashAttribute("orderSearchResultDTO", orderSearchResultDTO);
			return "redirect:/showeditorderitemsforordersearch";
		} else {

			int institutitonId = Integer.parseInt(orderSearchEditDTO.getInstitutionId());
			int departmentId = Integer.parseInt(orderSearchEditDTO.getDepartmentId());
			List<OrderSearchDTO> orderSearchEditDTOList = populateOrderScreenService
					.findOrderByOrderIdorInstitutionIdorDepartmentId(orderSearchEditDTO);
			System.out.println("Showing Order List Size" + orderSearchEditDTOList.size());
			model.addAttribute("orderSearchEditDTOList", orderSearchEditDTOList);

			OrderSearchDTO orderSearchResultDTO = new OrderSearchDTO();
			model.addAttribute("orderSearchResultDTO", orderSearchResultDTO);

			return "ordersearchresultfororderedit";
		}
	}

	@GetMapping(value = {"/showeditorderitemsforordersearch"})
	// @PostMapping("/showeditorderitems")

	public String showEditOrderItemsForOrderSearch(@ModelAttribute("orderSearchResultDTO") OrderSearchDTO orderSearchResultDTO,
			BindingResult bindingResult, Model model) throws Exception {

		String orderId = orderSearchResultDTO.getOrderId();
		long orderid = Long.parseLong(orderId);

		updatePopulateDropDowns(model);

		Order orderEntity = orderrepository.findById(orderid);
		ModelMapper modelMapper = new ModelMapper();
		OrderUpdateDTO orderUpdateDTO = modelMapper.map(orderEntity, OrderUpdateDTO.class);
		System.out.println("Printing Order Id From showeditorderitems" + orderUpdateDTO.getId());
		String orderIdStr = Long.toString(orderid);

		model.addAttribute("orderUpdateDTO", orderUpdateDTO);
		model.addAttribute("orderId", orderIdStr);

		return "editorder";

	}
	
	@PostMapping(value = {"/showeditorderitems"})
	// @PostMapping("/showeditorderitems")

	public String showEditOrderItems(@ModelAttribute("orderSearchResultDTO") OrderSearchDTO orderSearchResultDTO,
			BindingResult bindingResult, Model model) throws Exception {

		String orderId = orderSearchResultDTO.getOrderId();
		long orderid = Long.parseLong(orderId);

		updatePopulateDropDowns(model);

		Order orderEntity = orderrepository.findById(orderid);
		ModelMapper modelMapper = new ModelMapper();
		OrderUpdateDTO orderUpdateDTO = modelMapper.map(orderEntity, OrderUpdateDTO.class);
		System.out.println("Printing Order Id From showeditorderitems" + orderUpdateDTO.getId());
		String orderIdStr = Long.toString(orderid);

		model.addAttribute("orderUpdateDTO", orderUpdateDTO);
		model.addAttribute("orderId", orderIdStr);

		return "editorder";

	}

	@PostMapping(value = "/saveeditorderitems", params = { "calculateprice" })
	public String calculatePrice(@ModelAttribute("orderUpdateDTO") OrderUpdateDTO orderUpdateDTO,
			BindingResult bindingResult, HttpServletRequest request, Model model,RedirectAttributes redirectAttributes) {
		long orderId = Integer.valueOf(request.getParameter("Id"));
		DecimalFormat df = new DecimalFormat("0.00");
		
		if (bindingResult.hasErrors()) {
			System.out.println("Inside error block");
			System.out.println("Error count" + bindingResult.getErrorCount());
			Map<String, Object> errorMessages = new HashMap();
			if (bindingResult.hasErrors()) {

				List<FieldError> fes = bindingResult.getFieldErrors();
				for (FieldError fe : fes) {
					errorMessages.put(fe.getField(), fe.getDefaultMessage());
				}

			}

			model.addAttribute("errorMessages", errorMessages);
			updatePopulateDropDowns(model);
			return "editorder";
		}
		
		
		Order orderFromDB = orderrepository.findById(orderId);
		
		List<OrderItem> orderItemListFromDB = orderFromDB.getOrderitems();

		List<OrderItemUpdateDTO> orderItemUpdateDTOList = orderUpdateDTO.getOrderitems();
		for (OrderItemUpdateDTO orderItemUpdateDTO : orderItemUpdateDTOList) {
			System.out.println("Item List Details from Front End" + "SelectedOrder Item ID" + orderItemUpdateDTO.getId()
					+ "Item Id" + orderItemUpdateDTO.getItemId() + "item Quantity" + orderItemUpdateDTO.getQuantity()
					+ "item Size" + orderItemUpdateDTO.getSizeId() + "Item Price " + orderItemUpdateDTO.getPrice());

		}

		
		int listSize = orderItemListFromDB.size();
		for (int i = 0; i < listSize; ++i) {

			System.out.println("printing i " + i);
			OrderItem orderItem = orderItemListFromDB.get(i);
			//
			System.out.println("Printing Order Item Id from DB" + orderItem.getId());

			System.out.println("DB Record" + orderItem.getQuantity() + orderItem.getPrice());
			OrderItemUpdateDTO orderItemUpdateDTO = orderItemUpdateDTOList.get(i);
			System.out.println("Printing Order Item Id from Front End" + orderItemUpdateDTO.getId());
			// if (orderItemUpdateDTO.getId()!= null) {
			System.out.println("From Front End " + orderItemUpdateDTO.getQuantity() + orderItemUpdateDTO.getPrice());
			orderItem.setItemId(orderItemUpdateDTO.getItemId());
			orderItem.setItemDescription(orderItemUpdateDTO.getItemDescription());
			orderItem.setSizeId(orderItemUpdateDTO.getSizeId());
			orderItem.setNote(orderItemUpdateDTO.getNote());
			orderItem.setUnitId(orderItemUpdateDTO.getUnitId());
			orderItem.setQuantity(orderItemUpdateDTO.getQuantity());
			orderItem.setPrice(orderItemUpdateDTO.getPrice());
			orderItem.setAmount(orderItemUpdateDTO.getAmount());
			System.out.println("Printing Order Item Status from DB" + orderItem.getItemStatusId());
			System.out.println("Printing Order Item Status from Front Emd" + orderItemUpdateDTO.getItemStatusId());

		


			int statusfromDB = orderItem.getItemStatusId();
			System.out.println("Printing Status from DB" + statusfromDB);
			System.out.println("Printing Status from frontend " + orderItemUpdateDTO.getItemStatusId());
			if (orderItem.getItemStatusId() == orderItemUpdateDTO.getItemStatusId()) {

				String currentComments = orderItemUpdateDTO.getComments().replaceAll("(?i)" + orderItem.getComments(), "");
				System.out.println("Status are Equal");
				orderItem.setComments(currentComments + orderItem.getComments());
			}

			if (orderItem.getItemStatusId() != orderItemUpdateDTO.getItemStatusId()) {
				System.out.println("Status are not Equal");
				ItemStatus itemStatus = itemStatusRepository.findByItemStatusId(orderItemUpdateDTO.getItemStatusId());
				Date date = new Date();
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				String strDate = formatter.format(date);
				String commentWithDate = " : " + strDate + " : " + itemStatus.getItemStatusName();
				String currentComments = orderItemUpdateDTO.getComments().replaceAll("(?i)" + orderItem.getComments(), "");
				orderItem.setComments(currentComments + commentWithDate + orderItem.getComments());
				System.out.println("Printing Comments from if Block" + orderItem.getComments() + commentWithDate);

			}
			orderItem.setItemStatusId(orderItemUpdateDTO.getItemStatusId());
			orderitemrepository.save(orderItem);
			System.out.println("DB Record after update" + orderItem.getQuantity() + orderItem.getPrice());
			// }
			
			orderFromDB.setInstitutionId(orderUpdateDTO.getInstitutionId());
			orderFromDB.setDepartmentId(orderUpdateDTO.getDepartmentId());
			orderFromDB.setContactPersonName(orderUpdateDTO.getContactPersonName());
			orderFromDB.setContactNumber(orderUpdateDTO.getContactNumber());
			
			orderFromDB.setProfitMargin(orderUpdateDTO.getProfitMargin());
			
			orderFromDB.setTotal(Double.parseDouble(df.format(orderUpdateDTO.getTotal())));
			
			
			/*
			System.out.println("Printing Order Total From DB" + orderFromDB.getTotal());
			Double orderTotal = 0.0;
			Double totalAmount = 0.0;
			System.out.println("Printing Profit Margin" + orderUpdateDTO.getProfitMargin());
			Double profit =0.0;
			if (orderUpdateDTO.getProfitMargin()!=null) {
				orderFromDB.setProfitMargin(orderUpdateDTO.getProfitMargin());
				profit = orderUpdateDTO.getProfitMargin()/100*orderUpdateDTO.getTotal();
				System.out.println("Printing Profit " + profit);
			}
			if (orderUpdateDTO.getTotal()!=null) {
			
			totalAmount = orderUpdateDTO.getTotal()+profit;
			}
			System.out.println("Printing Order Total Amount" + totalAmount);
			*/
			
			orderrepository.save(orderFromDB);
		}



		int selectedRow = Integer.valueOf(request.getParameter("calculateprice"));
		int selectedOrderItemRow = selectedRow - 1;
		System.out.println("Printing Selected Row Id" + selectedRow);

		Order orderEntity = orderrepository.findById(orderId);
		List<OrderItem> orderItems = orderEntity.getOrderitems();
		OrderItem orderItem = orderItems.get(selectedOrderItemRow);
		long orderItemId = orderItem.getId();
		Double orderItemPrice =0.0;
		Double orderItemAmount =0.0;
		Integer orderItemQuantity =0;
		
		 if (orderItem.getPrice()!=null) {
		 orderItemPrice = orderItem.getPrice();
		 }
		 if (orderItem.getAmount()!=null) {
		 orderItemAmount = orderItem.getAmount();
		 }
		if (orderItem.getQuantity()!=null) {
		 orderItemQuantity = orderItem.getQuantity();
	     }
		long itemId = orderItem.getItemId();
		Item itemEntity = itemRepository.findByItemId(itemId);
		String orderItemName = itemEntity.getItemName();
		String orderItemNameId = orderItem.getItemDescription();

		if (orderItem.getPrice() == null) {
			
			
		
			
			ItemPriceCalculation itemPriceCalculation = new ItemPriceCalculation();
			itemPriceCalculation.setOrderId(orderId);
		    itemPriceCalculation.setOrderItemId(orderItemId);
			itemPriceCalculation.setOrderItemName(orderItemName);
			itemPriceCalculation.setOrderItemQuantity(orderItemQuantity);
			List<ItemRate> ItemRateEntityList = itemRateRepository.findAll();
			
			
			
			ItemRateEntityList.forEach(item -> {
			//	String phaseName = item.getItemRatePhaseName();
				ItemPriceDTO itemPriceDTO = new ItemPriceDTO();
				itemPriceDTO.setItemRateIdDB(item.getItemRateId());
				itemPriceDTO.setPhaseIdDB(item.getItemRatePhaseId());
				itemPriceDTO.setItemNameDB(item.getItemRateName());
				itemPriceDTO.setItemRate(item.getItemRate());
				itemPriceCalculation.add(itemPriceDTO);
				//ItemPriceDTO itemPhaseName = new ItemPriceDTO();
		//		itemPhaseName.setItemNameDB(item.getItemRatePhaseName());
				
				

				

			}); 
			

			
			
			
			
			List<ItemRatePhaseDTO> itemRatePhaseList = populateOrderScreenService.findAllItemRatePhase();
		

			List<ItemPriceDTO> group1 = itemPriceCalculation.getItemPriceDTOs();
			int sizeOfItemPriceArray1 = group1.size();

			
			System.out.println("Printing Size of Item Price DTOs Array" + sizeOfItemPriceArray1);
		//	System.out.println("Printing Size of Item Price DTOs Array" + sizeOfItemPriceArray2);
			model.addAttribute("itemPriceCalculation", itemPriceCalculation);
			//model.addAttribute("itemRateList", itemRateList);
		//	model.addAttribute("ItemRateEntityList", ItemRateEntityList);
			model.addAttribute("itemRatePhaseList", itemRatePhaseList);
			

		
			return "calculateitempriceadd";

			
			
		} else {

			System.out.println(" Printing from Item Price Edit");

			
			List<ItemRateDTO> itemRateList = new ArrayList<ItemRateDTO>();
			List<ItemRate> ItemRateEntityList = itemRateRepository.findAll();

			ItemPriceCalculation itemPriceCalculation = new ItemPriceCalculation();
			itemPriceCalculation.setOrderId(orderId);
			itemPriceCalculation.setOrderItemId(orderItemId);
			itemPriceCalculation.setOrderItemName(orderItemName);
			itemPriceCalculation.setOrderItemQuantity(orderItemQuantity);
			itemPriceCalculation.setOrderItemPrice(orderItemPrice);
			itemPriceCalculation.setOrderItemTotal(orderItemAmount);

			List<OrderItemPrice> orderItemPriceEntityList = orderItem.getOrderItemPrices();
			List<OrderItemPriceDTO> OrderItemPriceDTOs = new ArrayList<OrderItemPriceDTO>();

			orderItemPriceEntityList.forEach(item -> {
				OrderItemPriceDTO orderItemPriceDTO = new OrderItemPriceDTO();
				orderItemPriceDTO.setId(Long.toString(item.getId()));
				System.out.println("Printing Order Item Price ID" + orderItemPriceDTO.getId());
				orderItemPriceDTO.setItemRateId(Long.toString(item.getItemRateId()));
				System.out.println("Printing Item Rate ID" + orderItemPriceDTO.getItemRateId());
				if (item.getItemRate()!=null) {
				orderItemPriceDTO.setItemRate(Double.toString(item.getItemRate()));
				}
				System.out.println("Printing Item Rate" + orderItemPriceDTO.getItemRate());
				orderItemPriceDTO.setNoOfItems(Integer.toString(item.getNoOfItems()));
				orderItemPriceDTO.setAmount(Double.toString(item.getAmount()));
				OrderItemPriceDTOs.add(orderItemPriceDTO);
			});

			

		
			List<ItemRate> ItemRatesEntityList = itemRateRepository.findAll();
			//List<ItemRateDTO> ItemRatesEntityList =populateOrderScreenService.findAllItemRates();
		
			ItemRatesEntityList.forEach(item -> {
			//	String phaseName = item.getItemRatePhaseName();
				ItemPriceDTO itemPriceDTO = new ItemPriceDTO();
				itemPriceDTO.setItemRateIdDB(item.getItemRateId());
			//	itemPriceDTO.setPhaseNameDB(item.getPhaseName());
				itemPriceDTO.setPhaseIdDB(item.getItemRatePhaseId());
				itemPriceDTO.setItemNameDB(item.getItemRateName());
				itemPriceDTO.setItemRate(item.getItemRate());
				itemPriceCalculation.add(itemPriceDTO);
			//	ItemPriceDTO itemPhaseName = new ItemPriceDTO();
				//itemPhaseName.setItemNameDB(item.getItemRatePhaseName());
				
			

				

			}); 
			

			
		
			
			

			List<ItemRatePhaseDTO> itemRatePhaseList = populateOrderScreenService.findAllItemRatePhase();

			


			//List<ItemPriceDTO> ItemPriceDTOs = itemPriceCalculation.getItemPriceDTOs();
			//int sizeOfItemPriceArray1 = ItemPriceDTOs.size();

			

			List<ItemPriceDTO> ItemPriceDTOs = itemPriceCalculation.getItemPriceDTOs();
			int i = 0;
			for (ItemPriceDTO itemPriceDTO : ItemPriceDTOs) {
				System.out.println("Printing index" + i);
				i = i + 1;
				System.out.println("Iterating through Bean Collection" + itemPriceDTO.getItemRateId() + "::::"
						+ itemPriceDTO.getItemRateIdDB() + ":::" + itemPriceDTO.getItemRate());

			}

			for (OrderItemPriceDTO orderItemPriceDTO : OrderItemPriceDTOs) {

				int selectedRateId = Integer.parseInt(orderItemPriceDTO.getItemRateId());
				System.out.println("Printing Selected Rate Id from DataBase" + selectedRateId);
				int tableIndex = 0;

				// ItemRateEntityList.forEach(item-> {
				for (ItemRate itemRate : ItemRateEntityList) {

					if (itemRate.getItemRateId() == selectedRateId) {
						break;

					}
					tableIndex = tableIndex + 1;

					System.out.println("Printing Item Rate Index" + tableIndex);
				}

				// });

				
				if (tableIndex >=0 && tableIndex < ItemRateEntityList.size()) {
				ItemPriceDTO itemPriceDTO = ItemPriceDTOs.get(tableIndex);

				System.out.println("Printing Corresponding Rate Id from Bean " + itemPriceDTO.getItemRateIdDB());
				System.out.println(
						"Printing Corresponding Rate Id from Bean Befroe updating " + itemPriceDTO.getItemRateId());
				itemPriceDTO.setItemRateId(Long.parseLong(orderItemPriceDTO.getItemRateId()));
				System.out.println(
						"Printing Corresponding Rate Id from Bean After updating " + itemPriceDTO.getItemRateId());
			
				itemPriceDTO.setItemRate(Double.parseDouble(orderItemPriceDTO.getItemRate()));
				itemPriceDTO.setNoOfItems(Integer.parseInt(orderItemPriceDTO.getNoOfItems()));
				itemPriceDTO.setAmount(Double.parseDouble(orderItemPriceDTO.getAmount()));
				}
			}
			
			
		

			// List <ItemPriceDTO> ItemPriceDTOs = itemPriceCalculation.getItemPriceDTOs();
			
		//	System.out.println("Printing Size of Item Price DTOs Array" + sizeOfItemPriceArray);
			model.addAttribute("itemPriceCalculation", itemPriceCalculation);
			
			model.addAttribute("ItemRatesEntityList", ItemRatesEntityList);
			
			model.addAttribute("itemRatePhaseList", itemRatePhaseList);
			

			return "calculateitempriceedit";
		}
	}

	@GetMapping(value = { "/showeditprice" })

	public String showEditPrice(HttpServletRequest request,Model model) {
	System.out.println(" Printing from Item Price Edit");

				
				List<ItemRateDTO> itemRateList = new ArrayList<ItemRateDTO>();
				List<ItemRate> ItemRateEntityList = itemRateRepository.findAll();
				long orderId = Long.parseLong(request.getParameter("orderId"));
				long orderItemId = Long.parseLong(request.getParameter("orderItemId"));
				Order orderFromDB = orderrepository.findById(orderId);
				List<OrderItem> orderItemListFromDB = orderFromDB.getOrderitems();
				
				OrderItem orderItem =null;
				for (OrderItem orderItemDB :orderItemListFromDB) {
					if (orderItemDB.getId() == orderItemId)
					{
						orderItem = orderItemDB;
						break;
					}
				}
				
				
				Double orderItemPrice =0.0;
				Double orderItemAmount =0.0;
				Integer orderItemQuantity =0;
				
				 if (orderItem.getPrice()!=null) {
					 orderItemPrice = orderItem.getPrice();
					 }
					 if (orderItem.getAmount()!=null) {
					 orderItemAmount = orderItem.getAmount();
					 }
					if (orderItem.getQuantity()!=null) {
					 orderItemQuantity = orderItem.getQuantity();
				     }
					long itemId = orderItem.getItemId();
					Item itemEntity = itemRepository.findByItemId(itemId);
					String orderItemName = itemEntity.getItemName();
					String orderItemNameId = orderItem.getItemDescription();
				
				ItemPriceCalculation itemPriceCalculation = new ItemPriceCalculation();
				itemPriceCalculation.setOrderId(orderId);
				itemPriceCalculation.setOrderItemId(orderItemId);
				itemPriceCalculation.setOrderItemName(orderItemName);
				itemPriceCalculation.setOrderItemQuantity(orderItemQuantity);
				itemPriceCalculation.setOrderItemPrice(orderItemPrice);
				itemPriceCalculation.setOrderItemTotal(orderItemAmount);
				
				List<OrderItemPrice> orderItemPriceEntityList = orderItem.getOrderItemPrices();
				List<OrderItemPriceDTO> OrderItemPriceDTOs = new ArrayList<OrderItemPriceDTO>();

				orderItemPriceEntityList.forEach(item -> {
					OrderItemPriceDTO orderItemPriceDTO = new OrderItemPriceDTO();
					orderItemPriceDTO.setId(Long.toString(item.getId()));
					System.out.println("Printing Order Item Price ID" + orderItemPriceDTO.getId());
					orderItemPriceDTO.setItemRateId(Long.toString(item.getItemRateId()));
					System.out.println("Printing Item Rate ID" + orderItemPriceDTO.getItemRateId());
					orderItemPriceDTO.setItemRate(Double.toString(item.getItemRate()));
					System.out.println("Printing Item Rate" + orderItemPriceDTO.getItemRate());
					orderItemPriceDTO.setNoOfItems(Integer.toString(item.getNoOfItems()));
					orderItemPriceDTO.setAmount(Double.toString(item.getAmount()));
					OrderItemPriceDTOs.add(orderItemPriceDTO);
				});

				ArrayList<String> phaseNameArrayList = new ArrayList<String>();

			
				List<ItemRate> ItemRatesEntityList = itemRateRepository.findAll();
				List<String> phaseNames = new ArrayList<String>();
				
				ItemRateEntityList.forEach(item -> {
					//String phaseName = item.getItemRatePhaseName();
					ItemPriceDTO itemPriceDTO = new ItemPriceDTO();
					itemPriceDTO.setItemRateIdDB(item.getItemRateId());
					itemPriceDTO.setPhaseIdDB(item.getItemRatePhaseId());
					itemPriceDTO.setItemNameDB(item.getItemRateName());
					itemPriceDTO.setItemRate(item.getItemRate());
					
					itemPriceCalculation.add(itemPriceDTO);
				

				}); 
				

				
				List<ItemRatePhaseDTO> itemRatePhaseList = populateOrderScreenService.findAllItemRatePhase();


				//List<ItemPriceDTO> ItemPriceDTOs = itemPriceCalculation.getItemPriceDTOs();
				//int sizeOfItemPriceArray1 = ItemPriceDTOs.size();

				

				List<ItemPriceDTO> ItemPriceDTOs = itemPriceCalculation.getItemPriceDTOs();
				int i = 0;
				for (ItemPriceDTO itemPriceDTO : ItemPriceDTOs) {
					System.out.println("Printing index" + i);
					i = i + 1;
					System.out.println("Iterating through Bean Collection" + itemPriceDTO.getItemRateId() + "::::"
							+ itemPriceDTO.getItemRateIdDB() + ":::" + itemPriceDTO.getItemRate());

				}

				for (OrderItemPriceDTO orderItemPriceDTO : OrderItemPriceDTOs) {

					int selectedRateId = Integer.parseInt(orderItemPriceDTO.getItemRateId());
					System.out.println("Printing Selected Rate Id from DataBase" + selectedRateId);
					int tableIndex = 0;

					// ItemRateEntityList.forEach(item-> {
					for (ItemRate itemRate : ItemRateEntityList) {

						if (itemRate.getItemRateId() == selectedRateId) {
							break;

						}
						tableIndex = tableIndex + 1;

						System.out.println("Printing Item Rate Index" + tableIndex);
					}

					// });

					
					if (tableIndex >=0 && tableIndex < ItemRateEntityList.size()) {
					ItemPriceDTO itemPriceDTO = ItemPriceDTOs.get(tableIndex);

					System.out.println("Printing Corresponding Rate Id from Bean " + itemPriceDTO.getItemRateIdDB());
					System.out.println(
							"Printing Corresponding Rate Id from Bean Befroe updating " + itemPriceDTO.getItemRateId());
					itemPriceDTO.setItemRateId(Long.parseLong(orderItemPriceDTO.getItemRateId()));
					System.out.println(
							"Printing Corresponding Rate Id from Bean After updating " + itemPriceDTO.getItemRateId());
				
					itemPriceDTO.setItemRate(Double.parseDouble(orderItemPriceDTO.getItemRate()));
					itemPriceDTO.setNoOfItems(Integer.parseInt(orderItemPriceDTO.getNoOfItems()));
					itemPriceDTO.setAmount(Double.parseDouble(orderItemPriceDTO.getAmount()));
					}
				}
				
				
			

				// List <ItemPriceDTO> ItemPriceDTOs = itemPriceCalculation.getItemPriceDTOs();
				
			//	System.out.println("Printing Size of Item Price DTOs Array" + sizeOfItemPriceArray);
				model.addAttribute("itemPriceCalculation", itemPriceCalculation);
				
				model.addAttribute("ItemRatesEntityList", ItemRatesEntityList);
				
				model.addAttribute("itemRatePhaseList", itemRatePhaseList);
				

				return "calculateitempriceedit";


	
		}
//	@RequestMapping(value = { "/saveorderitemprice" }, method = RequestMethod.GET)
	 @PostMapping("/saveorderitemprice")
	public String saveOrderItemPrice(@ModelAttribute("itemPriceCalculation") ItemPriceCalculation itemPriceCalculation,
			BindingResult bindingResult, HttpServletRequest request, Model model, RedirectAttributes redirectAttributes) {
		 
		
		 DecimalFormat df = new DecimalFormat("0.00");
		

		long orderId = itemPriceCalculation.getOrderId();
		long orderItemId = itemPriceCalculation.getOrderItemId();
		System.out.println("Printing Order Item ID from saveorderitemprice" + orderItemId);
		String orderItemName = itemPriceCalculation.getOrderItemName();

		System.out.println(
				"Printing Order Id and Order Item ID from saveorderitemprice" + orderId + ":::" + orderItemId + ":::");

		Order orderEntity = orderrepository.findById(orderId);
		OrderItem orderItemEntity = orderitemrepository.findById(orderItemId);
		int itemQuantity = orderItemEntity.getQuantity();
		List<OrderItemPrice> orderItemPricesEntityList = orderItemEntity.getOrderItemPrices();
		
		
		List<Long> priceItemIds = new ArrayList();
		orderItemPricesEntityList.forEach(item->{
			priceItemIds.add(item.getId());
			
		});
		
		for (Long priceitemid : priceItemIds) {
			populateOrderScreenService.deleteOrderItemPrice(priceitemid);
		}
		
		
		System.out.println("Printing Order Item Price List Size" + orderItemPricesEntityList.size());

		
	
		List<ItemPriceDTO> ItemPriceDTOList = itemPriceCalculation.getItemPriceDTOs();
		
		Double orderItemTotal = 0.0;
		Double orderItemPrice = 0.0;
		for (ItemPriceDTO itemPriceDTO : ItemPriceDTOList) {

			if (itemPriceDTO.getItemRateId() != 0) {
				System.out.println("Printing Rate Item Id" + itemPriceDTO.getItemRateId());
				OrderItemPrice orderItemPriceEntity = new OrderItemPrice();
				orderItemPriceEntity.setItemRateId(itemPriceDTO.getItemRateId());
				ItemRate itemRateEntity = itemRateRepository.findByItemRateId(itemPriceDTO.getItemRateId());

				Long phaseName = itemRateEntity.getItemRatePhaseId();
				double itemRate = itemPriceDTO.getItemRate();
			
				
				
				System.out.println("Printing Rate " + itemRate);
			
				System.out.println("Printing Phase Name " + phaseName);
				
				orderItemPriceEntity.setNoOfItems(itemPriceDTO.getNoOfItems());
				long noOfItems = itemPriceDTO.getNoOfItems();
				orderItemPriceEntity.setItemRate(itemPriceDTO.getItemRate());
				
							
				
				orderItemPriceEntity.setItemRate(Double.parseDouble(df.format(itemPriceDTO.getItemRate())));
				System.out.println("Printing No Of Items " + noOfItems);
				
				double itemAmount = 0.0;
				itemAmount = noOfItems * itemRate;
				System.out.println("Printing Amount " + itemAmount);
				orderItemPriceEntity.setAmount(Double.parseDouble(df.format(itemAmount)));
						
				orderItemPriceEntity.setOrderItem(orderItemEntity);
				orderItemPriceRepository.save(orderItemPriceEntity);
				orderItemTotal = orderItemTotal+itemAmount;
		
		}
		}

		
		
		
		
		orderItemPrice = orderItemTotal/itemQuantity;
		
		
	
		
		System.out.println("Printing  Order Item Total" + orderItemTotal);
		System.out.println("Printing Order Item Price" + orderItemPrice);
		orderItemEntity.setPrice(Double.parseDouble(df.format(orderItemPrice)));
		/*orderItemEntity.setOneTimeChargesTotal(oneTimeChargesTotal);
		orderItemEntity.setMultipleTimeChargesTotal(multipleTimeChargesTotal); */
		orderItemEntity.setAmount(Double.parseDouble(df.format(orderItemTotal)));
		orderitemrepository.save(orderItemEntity);
		
		
		
		
		orderitemrepository.save(orderItemEntity);
	
		List<OrderItem> orderItemList = orderEntity.getOrderitems();

		Double orderTotal = 0.0;
		for (OrderItem orderItem : orderItemList) {
		
			if (orderItem.getAmount() != null) {
				orderTotal = orderTotal + orderItem.getAmount();
				System.out.println("Inside Order Total Loop printing each item amount" + orderItem.getAmount());
			}

		}
		
		orderEntity.setTotal(Double.parseDouble(df.format(orderTotal)));
		
		
		orderrepository.save(orderEntity);
		int orderItemQuantityUpdated = orderItemEntity.getQuantity();
		Double orderItemPriceUpdated = orderItemEntity.getPrice();
		Double orderItemTotalUpdated = orderItemEntity.getAmount();

		List<Long> orderItemsIds = new ArrayList<Long>();
		orderItemsIds.add(Long.valueOf(orderItemId));
		List<OrderItemPriceDTO> orderItemPriceDetailByOrderItemId = populateOrderScreenService
				.findOrderItemPriceDetailByOrderItemId(orderItemsIds);
		model.addAttribute("orderId", orderId);
		model.addAttribute("orderItemId", orderItemId);
		model.addAttribute("orderItemName", orderItemName);
		model.addAttribute("orderItemQuantity", orderItemQuantityUpdated);
		model.addAttribute("orderItemPrice", orderItemPriceUpdated);
		model.addAttribute("orderItemTotal", orderItemTotalUpdated);

		model.addAttribute("orderItemPriceDetail", orderItemPriceDetailByOrderItemId);

		OrderSearchDTO orderSearchResultDTO = new OrderSearchDTO();
		orderSearchResultDTO.setOrderId(Long.toString(orderId));

		model.addAttribute("orderSearchResultDTO", orderSearchResultDTO);
		return "saveitempricesuccess";
	//}
	}
	// @PostMapping("/saveeditorderitems")
	
	
	
	@PostMapping(value = { "/saveeditorderitems"})
	public String saveeditorderitems(@Valid @ModelAttribute("orderUpdateDTO") OrderUpdateDTO orderUpdateDTO,
			BindingResult bindingResult, @RequestParam("Id") String orderId, Model model,
			RedirectAttributes redirectAttributes) {

		
		DecimalFormat df = new DecimalFormat("0.00");
		
		if (bindingResult.hasErrors()) {
			System.out.println("Inside error block");
			System.out.println("Error count" + bindingResult.getErrorCount());
			Map<String, Object> errorMessages = new HashMap();
			if (bindingResult.hasErrors()) {

				List<FieldError> fes = bindingResult.getFieldErrors();
				for (FieldError fe : fes) {
					errorMessages.put(fe.getField(), fe.getDefaultMessage());
				}

			}

			model.addAttribute("errorMessages", errorMessages);
			updatePopulateDropDowns(model);
			return "editorder";
		}

		System.out.println("Printing Order Id from Save method" + orderId);

		System.out.println("Printing from save method");

		long orderIdLong = Long.parseLong(orderId);

		Order orderFromDB = orderrepository.findById(orderIdLong);
		List<OrderItem> orderItemListFromDB = orderFromDB.getOrderitems();

		List<OrderItemUpdateDTO> orderItemUpdateDTOList = orderUpdateDTO.getOrderitems();
		for (OrderItemUpdateDTO orderItemUpdateDTO : orderItemUpdateDTOList) {
			System.out.println("Item List Details from Front End" + "SelectedOrder Item ID" + orderItemUpdateDTO.getId()
					+ "Item Id" + orderItemUpdateDTO.getItemId() + "item Quantity" + orderItemUpdateDTO.getQuantity()
					+ "item Size" + orderItemUpdateDTO.getSizeId() + "Item Price " + orderItemUpdateDTO.getPrice());

		}

	
		int listSize = orderItemListFromDB.size();
		for (int i = 0; i < listSize; ++i) {

			System.out.println("printing i " + i);
			OrderItem orderItem = orderItemListFromDB.get(i);
			//
			System.out.println("Printing Order Item Id from DB" + orderItem.getId());

			System.out.println("DB Record" + orderItem.getQuantity() + orderItem.getPrice());
			OrderItemUpdateDTO orderItemUpdateDTO = orderItemUpdateDTOList.get(i);
			System.out.println("Printing Order Item Id from Front End" + orderItemUpdateDTO.getId());
			// if (orderItemUpdateDTO.getId()!= null) {
			System.out.println("From Front End " + orderItemUpdateDTO.getQuantity() + orderItemUpdateDTO.getPrice());
			orderItem.setItemId(orderItemUpdateDTO.getItemId());
			orderItem.setItemDescription(orderItemUpdateDTO.getItemDescription());
			orderItem.setSizeId(orderItemUpdateDTO.getSizeId());
			orderItem.setNote(orderItemUpdateDTO.getNote());
			orderItem.setUnitId(orderItemUpdateDTO.getUnitId());
			orderItem.setQuantity(orderItemUpdateDTO.getQuantity());
			orderItem.setPrice(orderItemUpdateDTO.getPrice());
			orderItem.setAmount(orderItemUpdateDTO.getAmount());
			System.out.println("Printing Order Item Status from DB" + orderItem.getItemStatusId());
			System.out.println("Printing Order Item Status from Front Emd" + orderItemUpdateDTO.getItemStatusId());

			
		
			orderitemrepository.save(orderItem);
		
		
			

			int statusfromDB = orderItem.getItemStatusId();
			System.out.println("Printing Status from DB" + statusfromDB);
			System.out.println("Printing Status from frontend " + orderItemUpdateDTO.getItemStatusId());
			if (orderItem.getItemStatusId() == orderItemUpdateDTO.getItemStatusId()) {
				String currentComments = orderItemUpdateDTO.getComments().replaceAll("(?i)" + orderItem.getComments(), "");
				System.out.println("Status are Equal");
				orderItem.setComments(currentComments + orderItem.getComments());
			}

			if (orderItem.getItemStatusId() != orderItemUpdateDTO.getItemStatusId()) {
				System.out.println("Status are not Equal");
				ItemStatus itemStatus = itemStatusRepository.findByItemStatusId(orderItemUpdateDTO.getItemStatusId());
				Date date = new Date();
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				String strDate = formatter.format(date);
				String commentWithDate = " : " + strDate + " : " + itemStatus.getItemStatusName();
				String currentComments = orderItemUpdateDTO.getComments().replaceAll("(?i)" + orderItem.getComments(), "");
				orderItem.setComments(currentComments + commentWithDate + orderItem.getComments());
				System.out.println("Printing Comments from if Block" + orderItem.getComments() + commentWithDate);

			}
			orderItem.setItemStatusId(orderItemUpdateDTO.getItemStatusId());
			orderitemrepository.save(orderItem);
			System.out.println("DB Record after update" + orderItem.getQuantity() + orderItem.getPrice());
			// }

			orderFromDB.setInstitutionId(orderUpdateDTO.getInstitutionId());
			orderFromDB.setDepartmentId(orderUpdateDTO.getDepartmentId());
			orderFromDB.setContactPersonName(orderUpdateDTO.getContactPersonName());
			orderFromDB.setContactNumber(orderUpdateDTO.getContactNumber());
			orderFromDB.setProfitMargin(orderUpdateDTO.getProfitMargin());
			
			List<OrderItem> orderItemList = orderFromDB.getOrderitems();
			
			Double orderTotal = 0.0;
			for (OrderItem orderitem : orderItemList) {
				System.out.println("Printing Each Order Item Amount"+ orderitem.getAmount());
				if (orderitem.getAmount()!=null) {
				orderTotal = orderTotal+orderitem.getAmount();
				}
			};
			
		
			
			
			orderFromDB.setTotal(Double.parseDouble(df.format(orderTotal)));
			System.out.println("Printing Order Total From DB" + orderFromDB.getTotal());
			Double totalAmount = 0.0;
			System.out.println("Printing Profit Margin" + orderUpdateDTO.getProfitMargin());
			/*
			Double profit =0.0;
			if (orderUpdateDTO.getProfitMargin()!=null) {
				orderFromDB.setProfitMargin(orderUpdateDTO.getProfitMargin());
				profit = orderUpdateDTO.getProfitMargin()/100*orderTotal;
				System.out.println("Printing Profit " + profit);
			}
			
			totalAmount = orderTotal+profit;
			*/
			System.out.println("Printing Order Total Amount" + totalAmount);
			
			orderrepository.save(orderFromDB);
		}

		System.out.println("printing order id from saveeditorderitems" + orderId);
		List<Long> orderID = new ArrayList<Long>();
		orderID.add(Long.valueOf(orderId));
		System.out.println("Number of elements in Array" + orderID.size());
		System.out.println("Printing order ID" + orderId);
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderID);
		System.out.println("Order Details Size" + orderdetails.size());
		model.addAttribute("orderdetails", orderdetails);
		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderID);
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("contactPersonName", orderMasterDTO.getContactPersonName());
		model.addAttribute("contactNumber", orderMasterDTO.getContactNumber());
		model.addAttribute("orderTotal", orderMasterDTO.getTotal());
		model.addAttribute("profitMargin", orderMasterDTO.getProfitMargin());
		

		return "editordersuccess";
	}



	@RequestMapping(value = { "/ordersearchfororderreport" }, method = RequestMethod.GET)
	public String showOrderSearchForOrderReport(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchEditDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchEditDTO", orderSearchEditDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		return "ordersearchfororderreport";

	}

	@PostMapping("/showordersearchresultfororderreport")
	public String showOrderSearchResultForOrderReport(
			@ModelAttribute("orderSearchEditDTO") OrderSearchDTO orderSearchEditDTO, BindingResult bindingResult,
			Model model, RedirectAttributes redirectAttributes) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String orderIdString = orderSearchEditDTO.getOrderId();
		if (!orderIdString.isEmpty()) {
			long orderId = Long.parseLong(orderSearchEditDTO.getOrderId());
			// long orderId = Long.parseLong(orderSearchDTO.getOrderId());
			OrderSearchDTO orderSearchResultDTO = new OrderSearchDTO();
			orderSearchResultDTO.setOrderId(orderIdString);
			redirectAttributes.addFlashAttribute("orderSearchResultDTO", orderSearchResultDTO);
			return "redirect:/showorderreport";
		} else {

			int institutitonId = Integer.parseInt(orderSearchEditDTO.getInstitutionId());
			int departmentId = Integer.parseInt(orderSearchEditDTO.getDepartmentId());
			List<OrderSearchDTO> orderSearchEditDTOList = populateOrderScreenService
					.findOrderByOrderIdorInstitutionIdorDepartmentId(orderSearchEditDTO);
			System.out.println("Showing Order List Size" + orderSearchEditDTOList.size());
			model.addAttribute("orderSearchEditDTOList", orderSearchEditDTOList);

			OrderSearchDTO orderSearchResultDTO = new OrderSearchDTO();
			model.addAttribute("orderSearchResultDTO", orderSearchResultDTO);

			return "ordersearchresultfororderreport";
		}
	}

	@RequestMapping(value = { "/showorderreport" }, method = RequestMethod.GET)

	public String showorderReport(@ModelAttribute("orderSearchResultDTO") OrderSearchDTO orderSearchResultDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request) throws Exception {

		String orderId = orderSearchResultDTO.getOrderId();
		long orderid = Long.parseLong(orderId);
		List<Long> orderID = new ArrayList<Long>();
		orderID.add(Long.valueOf(orderId));

		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderID);
		System.out.println("Order Details Size" + orderdetails.size());
		model.addAttribute("orderdetails", orderdetails);
		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderID);
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("startDate", orderMasterDTO.getStartDate());
		model.addAttribute("endDate", orderMasterDTO.getEndDate());
		model.addAttribute("contactPersonName", orderMasterDTO.getContactPersonName());
		model.addAttribute("contactNumber", orderMasterDTO.getContactNumber());
		model.addAttribute("totalAmount", orderMasterDTO.getTotal());
		Map<String, Object> data = new HashMap<>();
		data.put("masterdetail", orderMasterDTO);
		data.put("itemdetails", orderdetails);

		request.getSession().setAttribute("orderdownload", data);
		request.getSession().setAttribute("orderdetail", orderdetails);
		
		return "showorderreport";

	}

	@RequestMapping(value = { "/ordersearchforordercostreport" }, method = RequestMethod.GET)
	public String showOrderSearchForOrderCostReport(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchEditDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchEditDTO", orderSearchEditDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		return "ordersearchforordercostreport";

	}

	@PostMapping("/showordersearchresultforordercostreport")
	public String showOrderSearchResultForOrderCostReport(
			@ModelAttribute("orderSearchEditDTO") OrderSearchDTO orderSearchEditDTO, BindingResult bindingResult,
			Model model, RedirectAttributes redirectAttributes) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String orderIdString = orderSearchEditDTO.getOrderId();
		if (!orderIdString.isEmpty()) {
			long orderId = Long.parseLong(orderSearchEditDTO.getOrderId());
			// long orderId = Long.parseLong(orderSearchDTO.getOrderId());
			OrderSearchDTO orderSearchResultDTO = new OrderSearchDTO();
			orderSearchResultDTO.setOrderId(orderIdString);
			redirectAttributes.addFlashAttribute("orderSearchResultDTO", orderSearchResultDTO);
			return "redirect:/showordercostreport";
		} else {

			int institutitonId = Integer.parseInt(orderSearchEditDTO.getInstitutionId());
			int departmentId = Integer.parseInt(orderSearchEditDTO.getDepartmentId());
			List<OrderSearchDTO> orderSearchEditDTOList = populateOrderScreenService
					.findOrderByOrderIdorInstitutionIdorDepartmentId(orderSearchEditDTO);
			System.out.println("Showing Order List Size" + orderSearchEditDTOList.size());
			model.addAttribute("orderSearchEditDTOList", orderSearchEditDTOList);

			OrderSearchDTO orderSearchResultDTO = new OrderSearchDTO();
			model.addAttribute("orderSearchResultDTO", orderSearchResultDTO);

			return "ordersearchresultforordercostreport";
		}
	}

	@RequestMapping(value = { "/showordercostreport" }, method = RequestMethod.GET)

	public String showorderCostReport(@ModelAttribute("orderSearchResultDTO") OrderSearchDTO orderSearchResultDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request) throws Exception {

		String orderId = orderSearchResultDTO.getOrderId();
		long orderid = Long.parseLong(orderId);
		List<Long> orderID = new ArrayList<Long>();
		List<Long> orderItemIDs = new ArrayList<Long>();
		orderID.add(Long.valueOf(orderId));

		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderID);
		orderdetails.forEach(item -> {
			orderItemIDs.add(Long.parseLong(item.getOrderItemId()));
		});

		List<OrderItemPriceDTO> orderItemPriceDetails = populateOrderScreenService
				.findOrderItemPriceDetailByOrderItemId(orderItemIDs);
		System.out.println("Order Item Price Detail Size" + orderItemPriceDetails.size());
		model.addAttribute("orderdetails", orderdetails);
		model.addAttribute("pricedetails", orderItemPriceDetails);
		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderID);
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("startDate", orderMasterDTO.getStartDate());
		model.addAttribute("endDate", orderMasterDTO.getEndDate());
		model.addAttribute("contactPersonName", orderMasterDTO.getContactPersonName());
		model.addAttribute("contactNumber", orderMasterDTO.getContactNumber());
		model.addAttribute("totalAmount", orderMasterDTO.getTotal());
		Map<String, Object> data = new HashMap<>();
		data.put("masterdetail", orderMasterDTO);
		data.put("itemdetails", orderdetails);
		data.put("orderitempricedetail", orderItemPriceDetails);

		request.getSession().setAttribute("orderpricedownload", data);
		request.getSession().setAttribute("orderdetail", orderdetails);

		// PDFThymeleafExampleModified thymeleaf2Pdf = new
		// PDFThymeleafExampleModified();
		// ByteArrayInputStream exportedData =
		// thymeleaf2Pdf.exportPdfFile("showorderreporttemplate", data);
		// response.setContentType("application/octet-stream");
		// response.setHeader("Content-Disposition", "attachment;
		// filename=receipt.pdf");
		/*
		 * PdfFileExporter pdfFileExporter = new PdfFileExporter(); String pdfFileName =
		 * "E:\\SimpleSolution\\order.pdf";
		 * pdfFileExporter.exportPdfFile("showorderreporttemplate", data, pdfFileName);
		 */

		// PDFThymeleafExampleModified thymeleaf2Pdf = new
		// PDFThymeleafExampleModified();
		// String pdfFileName = "E:\\SimpleSolution\\order.pdf";
		// thymeleaf2Pdf.exportPdfFile("showorderreporttemplate", data, pdfFileName);

		// String html = thymeleaf2Pdf.parseThymeleafTemplate();
		// thymeleaf2Pdf.generatePdfFromHtml(html);
		// return templateEngine.process("thymeleaf_template", context);
		return "showordercostreport";

	}

	@GetMapping("/downloadorderdetailsexcel")
	public void downloadOrderdetailsExcel(HttpServletResponse response, HttpServletRequest request) throws IOException {
		/*
		 * Map orderdownload = (Map) request.getSession().getAttribute("orderdownload");
		 * PDFThymeleafExampleModified thymeleaf2Pdf = new
		 * PDFThymeleafExampleModified(); ByteArrayInputStream exportedData =
		 * thymeleaf2Pdf.exportPdfFile("showorderreporttemplate", orderdownload);
		 * response.setContentType("application/octet-stream");
		 * response.setHeader("Content-Disposition",
		 * "attachment; filename=receipt.pdf"); IOUtils.copy(exportedData,
		 * response.getOutputStream());
		 */
		response.setContentType("application/octet-stream");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=orderdetail_" + currentDateTime + ".xlsx";
		response.setHeader(headerKey, headerValue);

		List<OrderItemDetailDTO> orderdetailsforexcel = (List) request.getSession().getAttribute("orderdetail");
		System.out.println("printing no of records" + orderdetailsforexcel.size());
		request.getSession().removeAttribute("orderdetail");
		ExcelGenerator generator = new ExcelGenerator(orderdetailsforexcel);

		generator.generateExcelFile(response);

	}

	@GetMapping("/downloadshortpendingorderreportexcel")
	public void downloadShortPendingOrderReportExcel(HttpServletResponse response, HttpServletRequest request)
			throws IOException {

		response.setContentType("application/octet-stream");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=orderdetail_" + currentDateTime + ".xlsx";
		response.setHeader(headerKey, headerValue);

		List<OrderMasterDTO> orderdetailsforexcel = (List) request.getSession().getAttribute("orderdetail");
		System.out.println("printing no of records" + orderdetailsforexcel.size());
		request.getSession().removeAttribute("orderdetail");
		ExcelGeneratorShortReport generator = new ExcelGeneratorShortReport(orderdetailsforexcel);

		generator.generateExcelFileForShortPendingOrderReport(response);

	}

	@GetMapping("/downloadbillreportforinstitutionexcel")
	public void downloadBillReportForInstitutionExcel(HttpServletResponse response, HttpServletRequest request)
			throws IOException {

		response.setContentType("application/octet-stream");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=BillReport_" + currentDateTime + ".xlsx";
		response.setHeader(headerKey, headerValue);

		List<BillDTO> billdetailsforexcel = (List) request.getSession().getAttribute("billReportListSession");
		System.out.println("printing no of records" + billdetailsforexcel.size());
		request.getSession().removeAttribute("billReportListSession");
		BillExcelGenerator generator = new BillExcelGenerator(billdetailsforexcel);

		generator.generateExcelFile(response);

	}

	@GetMapping("/downloadrevenuereportexcel")
	public void downloadRevenueReporteExcel(HttpServletResponse response, HttpServletRequest request)
			throws IOException {

		response.setContentType("application/octet-stream");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=BillReport_" + currentDateTime + ".xlsx";
		response.setHeader(headerKey, headerValue);

		List<BillDTO> billdetailsforexcel = (List) request.getSession().getAttribute("revenueReportListSession");
		// System.out.println("printing no of records"+ billdetailsforexcel.size());
		request.getSession().removeAttribute("revenueReportListSession");
		BillExcelGenerator generator = new BillExcelGenerator(billdetailsforexcel);

		generator.generateExcelFile(response);

	}

	@GetMapping("/downloadorderdetailspdf")
	public void downloadOrderdetailsPDF(HttpServletResponse response, HttpServletRequest request) throws IOException {
		Map orderdetailsforpdf = (Map) request.getSession().getAttribute("orderdownload");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());
		request.getSession().removeAttribute("orderdownload");
		PDFThymeleafExampleModified thymeleaf2Pdf = new PDFThymeleafExampleModified();
		ByteArrayInputStream exportedData = thymeleaf2Pdf.exportPdfFile("showorderreporttemplate", orderdetailsforpdf);
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=orderdetail_" + currentDateTime + ".pdf");
		IOUtils.copy(exportedData, response.getOutputStream());

	}

	@GetMapping("/downloadorderpricedetailspdf")
	public void downloadOrderPricedetailsPDF(HttpServletResponse response, HttpServletRequest request)
			throws IOException {
		Map orderpricedetailsforpdf = (Map) request.getSession().getAttribute("orderpricedownload");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());
		request.getSession().removeAttribute("orderdownload");
		PDFThymeleafExampleModified thymeleaf2Pdf = new PDFThymeleafExampleModified();
		ByteArrayInputStream exportedData = thymeleaf2Pdf.exportPdfFile("showorderpricereporttemplate",
				orderpricedetailsforpdf);
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=orderpricedetail_" + currentDateTime + ".pdf");
		IOUtils.copy(exportedData, response.getOutputStream());

	}

	@GetMapping("/downloadbilldraftpdf")
	public void downloadBillDraftPDF(HttpServletResponse response, HttpServletRequest request) throws IOException {
		List<OrderItemDetailDTO> orderdetailsforpdf = (List) request.getSession().getAttribute("orderdetailpdf");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());
		request.getSession().removeAttribute("orderdetailpdf");
		PDFThymeleaf thymeleaf2Pdf = new PDFThymeleaf();
		String html = thymeleaf2Pdf.parseThymeleafTemplate();
		thymeleaf2Pdf.generatePdfFromHtml(html);
		// PDFThymeleaf thymeleaf2Pdf = new PDFThymeleaf();
		// ByteArrayInputStream exportedData =
		// thymeleaf2Pdf.generatePdfFromHtml("thymeleaf_template", orderdetailsforpdf);
		// response.setContentType("application/octet-stream");
		// response.setHeader("Content-Disposition", "attachment; filename=BillDraft_" +
		// currentDateTime + ".pdf");
		// IOUtils.copy(exportedData, response.getOutputStream());

	}

	@RequestMapping(value = { "/ordersearchforordereditadditem" }, method = RequestMethod.GET)
	public String showOrderSearchForOrderEditAddItem(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchDTO", orderSearchDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		return "ordersearchforordereditadditem";

		//
	}

	@PostMapping("/showordersearchresultforordereditadditem")
	public String showOrderSearchResultForOrderEditAddItem(
			@ModelAttribute("orderSearchDTO") OrderSearchDTO orderSearchDTO, BindingResult bindingResult, Model model,
			RedirectAttributes redirectAttributes) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String orderIdString = orderSearchDTO.getOrderId();
		if (!orderIdString.isEmpty()) {
			long orderId = Long.parseLong(orderSearchDTO.getOrderId());
			OrderSearchDTO orderSearchAddItemDTO = new OrderSearchDTO();
			orderSearchAddItemDTO.setOrderId(orderIdString);
			redirectAttributes.addFlashAttribute("orderSearchAddItemDTO", orderSearchAddItemDTO);
			return "redirect:/showeditorderitemsadditem";
			// return "showeditorderitemsadditem";
		} else {

			int institutitonId = Integer.parseInt(orderSearchDTO.getInstitutionId());
			int departmentId = Integer.parseInt(orderSearchDTO.getDepartmentId());
			List<OrderSearchDTO> orderSearchDTOList = populateOrderScreenService
					.findOrderByOrderIdorInstitutionIdorDepartmentId(orderSearchDTO);
			System.out.println("Showing Order List Size" + orderSearchDTOList.size());
			model.addAttribute("orderSearchDTOList", orderSearchDTOList);

			OrderSearchDTO orderSearchAddItemDTO = new OrderSearchDTO();
			model.addAttribute("orderSearchAddItemDTO", orderSearchAddItemDTO);

			return "ordersearchresultforordereditadditem";
		}
	}

	@RequestMapping(value = { "/showeditorderitemsadditem" }, method = RequestMethod.GET)

	public String showeditorderitemsAddItem(@ModelAttribute("orderSearchAddItemDTO") OrderSearchDTO searchOrderDTO,
			BindingResult bindingResult, Model model) throws Exception {

		String orderId = searchOrderDTO.getOrderId();
		long orderid = Long.parseLong(orderId);

		updatePopulateDropDowns(model);

		List<Long> orderIDs = new ArrayList<Long>();
		orderIDs.add(Long.valueOf(orderId));
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIDs);
		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIDs);
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("orderTotal", orderMasterDTO.getTotal());
		model.addAttribute("profitMargin", orderMasterDTO.getProfitMargin());
		


		System.out.println("Order Details Size" + orderdetails.size());
		model.addAttribute("orderdetails", orderdetails);

		Order orderEntity = orderrepository.findById(orderid);
		ModelMapper modelMapper = new ModelMapper();
		OrderAddItemDTO orderAddItemDTO = new OrderAddItemDTO();
		orderAddItemDTO.setId(orderid);

		String orderIdStr = Long.toString(orderid);

		model.addAttribute("orderAddItemDTO", orderAddItemDTO);
		model.addAttribute("orderId", orderIdStr);

		return "editorderadditem";

	}

	@PostMapping(value = "/editorderadditem", params = { "addItem" })
	public String addItemToExistingEntity(OrderAddItemDTO orderAddItemDTO, BindingResult bindingResult, Model model) {

		orderAddItemDTO.getOrderitemsAddItems().add(new OrderItemAddItemDTO());
		List<Long> orderIDs = new ArrayList<Long>();
		orderIDs.add(Long.valueOf(orderAddItemDTO.getId()));
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIDs);
		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIDs);
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("orderTotal", orderMasterDTO.getTotal());
		model.addAttribute("profitMargin", orderMasterDTO.getProfitMargin());
		


		System.out.println("Order Details Size" + orderdetails.size());
		model.addAttribute("orderdetails", orderdetails);
		populateDropDowns(model);
		return "editorderadditem";
	}

	@PostMapping(value = "/editorderadditem", params = { "removeItem" })
	public String removeItemToExistingEntity(OrderAddItemDTO orderAddItemDTO, BindingResult bindingResult,
			HttpServletRequest request, Model model) {
		int itemId = Integer.valueOf(request.getParameter("removeItem"));
		orderAddItemDTO.getOrderitemsAddItems().remove(itemId);
		List<Long> orderIDs = new ArrayList<Long>();
		orderIDs.add(Long.valueOf(orderAddItemDTO.getId()));
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIDs);
		model.addAttribute("orderdetails", orderdetails);
		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIDs);
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("orderTotal", orderMasterDTO.getTotal());
		model.addAttribute("profitMargin", orderMasterDTO.getProfitMargin());
		


		populateDropDowns(model);
		return "editorderadditem";
	}

	@PostMapping(value = "/editorderadditem", params = { "save" })

	public String editOrderAddItemSave(@Valid @ModelAttribute("orderAddItemDTO") OrderAddItemDTO orderAddItemDTO,
			BindingResult bindingResult, @RequestParam("Id") String orderId, Model model,
			RedirectAttributes redirectAttributes) {

		if (bindingResult.hasErrors()) {
			System.out.println("Error block");
			System.out.println("printing error count" + bindingResult.getErrorCount());
			Map<String, Object> errorMessages = new HashMap();
			if (bindingResult.hasErrors()) {

				List<FieldError> fes = bindingResult.getFieldErrors();
				for (FieldError fe : fes) {
					errorMessages.put(fe.getField(), fe.getDefaultMessage());
				}

			}

			List<Long> orderIDs = new ArrayList<Long>();
			orderIDs.add(Long.valueOf(orderAddItemDTO.getId()));
			List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIDs);
			List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIDs);
			OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
			model.addAttribute("orderNo", orderMasterDTO.getOrderId());
			model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
			model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
			model.addAttribute("orderTotal", orderMasterDTO.getTotal());
			model.addAttribute("profitMargin", orderMasterDTO.getProfitMargin());
			


			model.addAttribute("orderdetails", orderdetails);
			System.out.println("Order Details Size" + orderdetails.size());
			model.addAttribute("orderdetails", orderdetails);
			model.addAttribute("errorMessages", errorMessages);
			updatePopulateDropDowns(model);
			return "editorderadditem";

		}
		Double newlyAddedtotalAmount = 0.0;
		long orderIdLong = Long.parseLong(orderId);
		Order orderEntity = orderrepository.findById(orderIdLong);
		Double initialTotal = orderEntity.getTotal();

		List<OrderItemAddItemDTO> orderItemsAddItemDTO = orderAddItemDTO.getOrderitemsAddItems();
		List<OrderItem> orderItemList = new ArrayList<OrderItem>();
		for (OrderItemAddItemDTO orderItemDTO : orderItemsAddItemDTO) {
			System.out.println("Item List Details from Front End" + orderItemDTO.getId() + orderItemDTO.getItemId()
					+ orderItemDTO.getQuantity() + orderItemDTO.getSizeId() + orderItemDTO.getPrice());
			OrderItem orderItem = new OrderItem();
			orderItem.setItemId(orderItemDTO.getItemId());
			orderItem.setItemDescription(orderItemDTO.getItemDescription());
			orderItem.setSizeId(orderItemDTO.getSizeId());
			orderItem.setNote(orderItemDTO.getNote());
			orderItem.setUnitId(orderItemDTO.getUnitId());
			orderItem.setQuantity(orderItemDTO.getQuantity());
			orderItem.setPrice(orderItemDTO.getPrice());
			orderItem.setItemStatusId(orderItemDTO.getItemStatusId());
			// double price = orderItemDTO.getPrice();

			if (orderItemDTO.getPrice() != null && orderItemDTO.getQuantity() != null) {
				Double amount = orderItemDTO.getPrice() * orderItemDTO.getQuantity();
				newlyAddedtotalAmount = newlyAddedtotalAmount + amount;
				orderItem.setAmount(amount);
			}
			// orderItem.setComments(orderItemDTO.getComments());

			System.out.println("Printing Status Id" + orderItemDTO.getItemStatusId());

			orderItem.setComments(orderItemDTO.getComments());

			System.out.println("Printing Status Id" + orderItemDTO.getItemStatusId());

			// orderItem.setComments(orderItemDTO.getComments());
			if (orderItemDTO.getItemStatusId() >= 1) {
				ItemStatus itemStatus = itemStatusRepository.findByItemStatusId(orderItemDTO.getItemStatusId());
				Date date = new Date();
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				String strDate = formatter.format(date);
				String commentWithDate = " : " + strDate + " : " + itemStatus.getItemStatusName();
				System.out.println("Printing Comments inside if block" + commentWithDate);
				orderItem.setComments(orderItemDTO.getComments() + commentWithDate);
			}

			orderItem.setOrder(orderEntity);
			orderitemrepository.save(orderItem);

		}
		Double finalTotalAmount = initialTotal + newlyAddedtotalAmount;

		//orderEntity.setTotalAmount(finalTotalAmount);

		orderrepository.save(orderEntity);

		List<Long> orderIDs = new ArrayList<Long>();
		orderIDs.add(Long.valueOf(orderAddItemDTO.getId()));
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIDs);
		System.out.println("Order Details Size" + orderdetails.size());
		model.addAttribute("orderdetails", orderdetails);
		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIDs);
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("orderTotal", orderMasterDTO.getTotal());
		model.addAttribute("profitMargin", orderMasterDTO.getProfitMargin());
		


		return "editorderadditemsuccess";
	}

	@RequestMapping(value = { "/ordersearchforordereditdeleteitem" }, method = RequestMethod.GET)
	public String showOrderSearchForOrderEditDeleteItem(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchDTO", orderSearchDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		return "ordersearchforordereditdeleteitem";

	}

	@PostMapping("/showordersearchresultforordereditdeleteitem")
	public String showOrderSearchResultForOrderEditDeleteItem(
			@ModelAttribute("orderSearchDTO") OrderSearchDTO orderSearchDTO, BindingResult bindingResult, Model model,
			RedirectAttributes redirectAttributes) throws Exception {

		System.out.println("In showOrderSearchResultForOrderDeleteItem method");
		String orderIdString = orderSearchDTO.getOrderId();
		if (!orderIdString.isEmpty()) {
			long orderId = Long.parseLong(orderSearchDTO.getOrderId());
			OrderSearchDTO orderSearchDeleteItemDTO = new OrderSearchDTO();
			orderSearchDeleteItemDTO.setOrderId(orderIdString);
			redirectAttributes.addFlashAttribute("orderSearchDeleteItemDTO", orderSearchDeleteItemDTO);
			return "redirect:/showeditorderdeleteitem";
		} else {

			int institutitonId = Integer.parseInt(orderSearchDTO.getInstitutionId());
			int departmentId = Integer.parseInt(orderSearchDTO.getDepartmentId());
			List<OrderSearchDTO> orderSearchDeleteDTOList = populateOrderScreenService
					.findOrderByOrderIdorInstitutionIdorDepartmentId(orderSearchDTO);
			System.out.println("Showing Order List Size" + orderSearchDeleteDTOList.size());
			model.addAttribute("orderSearchDeleteDTOList", orderSearchDeleteDTOList);

			OrderSearchDTO orderSearchDeleteItemDTO = new OrderSearchDTO();
			model.addAttribute("orderSearchDeleteItemDTO", orderSearchDeleteItemDTO);

			return "ordersearchresultforordereditdeleteitem";
		}
	}

	// @PostMapping("/showeditorderdeleteitem")
	@GetMapping("/showeditorderdeleteitem")

	public String showeditorderdeleteitem(
			@ModelAttribute("orderSearchDeleteItemDTO") OrderSearchDTO orderSearchDeleteItemDTO,
			BindingResult bindingResult, Model model) throws Exception {

		String orderId = orderSearchDeleteItemDTO.getOrderId();
		System.out.println("Printing Order Id from showeditorderdeleteitem" + orderId);
		long orderid = Long.parseLong(orderId);

		List<Long> orderIds = new ArrayList<Long>();
		orderIds.add(Long.valueOf(orderId));
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIds);
		System.out.println("Order Details Size" + orderdetails.size());

		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIds);
		
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		System.out.println("Printing Master Details"+ orderMasterDTO.getInstitutionName()); 
		
		//+ orderMasterDTO.getTotal()+orderMasterDTO.getProfitMargin()+orderMasterDTO.getTotalAmount());
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("orderTotal", orderMasterDTO.getTotal());
		model.addAttribute("profitMargin", orderMasterDTO.getProfitMargin());
		model.addAttribute("orderdetails", orderdetails);
		OrderItemIds orderItemIds = new OrderItemIds();
		orderItemIds.setOrderId(orderId);
		model.addAttribute("orderItemIds", orderItemIds);

		return "editorderdeleteitem";

	}

	@PostMapping("/saveeditorderdeleteitem")

	public String saveEditOrderDeleteItem(@ModelAttribute("orderItemIds") OrderItemIds orderItemIds,
			BindingResult bindingResult, @RequestParam("orderId") String orderID, Model model,
			RedirectAttributes redirectAttributes) throws Exception {

		try {
			
			DecimalFormat df = new DecimalFormat("0.00");

			String orderIdStr = orderID;
			System.out.println("Printing Order Id from Save method" + orderIdStr);
			Order orderFromDB = orderrepository.findById(Long.valueOf(orderIdStr));
			List<OrderItem> orderItemListFromDB = orderFromDB.getOrderitems();
			System.out.println("Printing no of items from DB" + orderItemListFromDB.size());
			String[] itemIds = orderItemIds.getOrderItemIds();
			System.out.println("Printing no of selected items to be deleted" + itemIds.length);
			int listSize = orderItemListFromDB.size();
			
			
			for (OrderItem item : orderItemListFromDB ) {
				List<Long> priceItemIds = new ArrayList();
				System.out.println("Printing Order Item Id" + item.getId());
				if (item.getPrice()!=null) {
					List<OrderItemPrice> orderItemPriceList = item.getOrderItemPrices();
					for (OrderItemPrice price : orderItemPriceList) {
						System.out.println("Printing Order Item Price Id" + price.getId());
						priceItemIds.add(price.getId());
					}
				/*	for (OrderItemPrice price : orderItemPriceList) {
						
						orderItemPriceRepository.delete(price);
						}
						*/
						
					}
				
				
				for (Long priceitemid : priceItemIds) {
					System.out.println("Printing Order Item Price Id in Delete" + priceitemid);
					
					populateOrderScreenService.deleteOrderItemPrice(priceitemid);
				}
				
				
			}
			
			
			System.out.println("Successfully deleted all price records");
			
			 for (String itemid : itemIds) {
				 
					System.out.println("Printing Order Item Id to be deleted " + itemid);
					
					Long orderItemId = Long.parseLong(itemid);
					
					populateOrderScreenService.deleteOrderItem(Long.parseLong(itemid));
					/*
					 * Optional<OrderItem> orderItem =
					 * orderitemrepository.findById(Long.valueOf(itemid));
					 * 
					 * orderFromDB.getOrderitems().remove(orderItem);
					 * orderrepository.save(orderFromDB);
					 * orderitemrepository.delete(orderItem.get());
					 */
					// orderitemrepository.deleteById(Long.valueOf(itemid));
					System.out.println("Deleted successfully" + itemid);

				}

	
			// refreshEntity(Long.valueOf(orderIdStr));
			 
			
			Order updatedOrderFromDB = orderrepository.findById(Long.valueOf(orderIdStr));
		
			
			System.out.println("Prinitng Order Id " + updatedOrderFromDB.getId());
			
			List<OrderItem> updatedorderItemListFromDB = updatedOrderFromDB.getOrderitems();
			
			List<Long> orderId = new ArrayList<Long>();
			orderId.add(Long.valueOf(orderIdStr));
			System.out.println("Number of elements in Array" + orderId.size());
			System.out.println("Printing order ID" + orderId);
			List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderId);
			System.out.println("Printing no of items " + orderdetails.size());
			
			//System.out.println("Prinitng Order Item Ids " + updatedorderItemListFromDB);
			
			System.out.println("Prinitng Order Total and Total Amount" + updatedOrderFromDB.getTotal());
			Double updatedOrderTotal = 0.0;
			Double updatedOrderTotalAmount = 0.0;
			for (OrderItemDetailDTO item : orderdetails)
			{
				System.out.println("Printing Item Price and Item Amount");
				if (item.getPrice()!=null && item.getAmount()!=null) {
				updatedOrderTotal = updatedOrderTotal + Double.parseDouble(item.getAmount());
				System.out.println("Printing Updated Order Total" + updatedOrderTotal);
				}
			}
			
			System.out.println("Printing Updated ToTal " + updatedOrderTotal);
			updatedOrderFromDB.setTotal(Double.parseDouble(df.format(updatedOrderTotal)));
			
		//	Double profit =0.0;
			if (updatedOrderFromDB.getProfitMargin()!=null) {
				updatedOrderFromDB.setProfitMargin(updatedOrderFromDB.getProfitMargin());
				//profit = updatedOrderFromDB.getProfitMargin()/100*updatedOrderFromDB.getTotal();
				//System.out.println("Printing Profit " + profit);
			}
			
			if (updatedOrderFromDB.getTotal()!=null) {
				
				//updatedOrderTotalAmount = updatedOrderFromDB.getTotal()+profit;
				}

			//System.out.println("Printing Updated ToTal Amount " + updatedOrderTotalAmount);
			System.out.println("Printing from save method");
			
			
			orderrepository.save(updatedOrderFromDB);
			System.out.println("Order Updated Successfully");

			// System.out.println("Printing order ids size" + itemIds.length);
			// System.out.println("Printing Order Ids" + itemIds);
			// System.out.println("printing order id from saveeditorderitems" + orderIdStr);
		//	List<Long> orderId = new ArrayList<Long>();
			orderId.add(Long.valueOf(orderIdStr));
			System.out.println("Number of elements in Array" + orderId.size());
			System.out.println("Printing order ID" + orderId);
		//	List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderId);
			System.out.println("Order Details Size" + orderdetails.size());
			model.addAttribute("orderdetails", orderdetails);
			List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderId);
			OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
			model.addAttribute("orderNo", orderMasterDTO.getOrderId());
			model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
			model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
			model.addAttribute("orderTotal", orderMasterDTO.getTotal());
			model.addAttribute("profitMargin", orderMasterDTO.getProfitMargin());
			//

		} catch (Exception e) {
			redirectAttributes.addAttribute("message", e.getMessage());
		}

		return "editorderdeleteitemsuccess";
	}

	@RequestMapping(value = { "/ordersearchforcreateorderfromexistingorder" }, method = RequestMethod.GET)
	public String showOrderSearchForCreateoOrderFromExistingOrder(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchDTO", orderSearchDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		return "ordersearchforcreateorderfromexistingorder";

	}

	@PostMapping("/showordersearchresultforcreateorderfromexistingorder")
	public String showOrderSearchResultForCreateoOrderFromExistingOrder(
			@ModelAttribute("orderSearchDTO") OrderSearchDTO orderSearchDTO, BindingResult bindingResult, Model model,
			RedirectAttributes redirectAttributes) throws Exception {

		System.out.println("In showOrderSearchResultForOrderDeleteItem method");
		String orderIdString = orderSearchDTO.getOrderId();
		if (!orderIdString.isEmpty()) {
			long orderId = Long.parseLong(orderSearchDTO.getOrderId());
			OrderSearchDTO orderSearchDeleteItemDTO = new OrderSearchDTO();
			orderSearchDeleteItemDTO.setOrderId(orderIdString);
			redirectAttributes.addFlashAttribute("orderSearchDeleteItemDTO", orderSearchDeleteItemDTO);
			return "redirect:/showcreateorderfromexistingorder";
		} else {

			int institutitonId = Integer.parseInt(orderSearchDTO.getInstitutionId());
			int departmentId = Integer.parseInt(orderSearchDTO.getDepartmentId());
			List<OrderSearchDTO> orderSearchDeleteDTOList = populateOrderScreenService
					.findOrderByOrderIdorInstitutionIdorDepartmentId(orderSearchDTO);
			System.out.println("Showing Order List Size" + orderSearchDeleteDTOList.size());
			model.addAttribute("orderSearchDeleteDTOList", orderSearchDeleteDTOList);

			OrderSearchDTO orderSearchDeleteItemDTO = new OrderSearchDTO();
			model.addAttribute("orderSearchDeleteItemDTO", orderSearchDeleteItemDTO);

			return "ordersearchresultforcreateorderfromexistingorder";
		}
	}

	// @PostMapping("/showeditorderdeleteitem")
	@GetMapping("/showcreateorderfromexistingorder")

	public String showCreateoOrderFromExistingOrder(
			@ModelAttribute("orderSearchDeleteItemDTO") OrderSearchDTO orderSearchDeleteItemDTO,
			BindingResult bindingResult, Model model) throws Exception {

		String orderId = orderSearchDeleteItemDTO.getOrderId();
		System.out.println("Printing Order Id from showeditorderdeleteitem" + orderId);
		long orderid = Long.parseLong(orderId);

		List<Long> orderIds = new ArrayList<Long>();
		orderIds.add(Long.valueOf(orderId));
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIds);
		System.out.println("Order Details Size" + orderdetails.size());

		List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIds);
		OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
		model.addAttribute("orderNo", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
		model.addAttribute("startDate", orderMasterDTO.getStartDate());
		model.addAttribute("endDate", orderMasterDTO.getEndDate());
		model.addAttribute("totalAmount", orderMasterDTO.getTotal());
		model.addAttribute("orderdetails", orderdetails);
		OrderItemIds orderItemIds = new OrderItemIds();
		orderItemIds.setOrderId(orderId);
		model.addAttribute("orderItemIds", orderItemIds);

		return "createorderfromexistingorder";

	}

	@PostMapping("/savecreateorderfromexistingorder")

	public String saveCreateoOrderFromExistingOrder(@ModelAttribute("orderItemIds") OrderItemIds orderItemIds,
			BindingResult bindingResult, @RequestParam("orderId") String orderID, Model model,
			RedirectAttributes redirectAttributes) throws Exception {

		try {

			String orderIdStr = orderID;
			System.out.println("Printing Order Id from Save method" + orderIdStr);
			Order orderFromDB = orderrepository.findById(Long.valueOf(orderIdStr));
			List<OrderItem> orderItemListFromDB = orderFromDB.getOrderitems();
			System.out.println("Printing no of items from DB" + orderItemListFromDB.size());
			String[] itemIds = orderItemIds.getOrderItemIds();
			List<Long> priceItemIds = new ArrayList();
			System.out.println("Printing no of selected items to be deleted" + itemIds.length);
			int listSize = orderItemListFromDB.size();

			Order order = new Order();
			order.setInstitutionId(orderFromDB.getInstitutionId());
			order.setDepartmentId(orderFromDB.getDepartmentId());
			order.setStartDate(new Date());
			// order.setEndDate();
			order.setContactPersonName(orderFromDB.getContactPersonName());
			order.setContactNumber(orderFromDB.getContactNumber());
			orderrepository.save(order);
			
			System.out.println("Printing Newly created Order Id" + order.getId());

			Double totalAmount = 0.0;
			for (int i = 0; i < listSize; ++i) {
				System.out.println("printing i " + i);
				OrderItem orderItem = orderItemListFromDB.get(i);
				long DBorderitemid = orderItem.getId();
				for (String itemid : itemIds) {
					long selectedOrderitemid = Long.parseLong(itemid);
					System.out.println("Printing OrderItem Id from DB" + DBorderitemid);
					System.out.println("Printing Selected  OrderItem Id from Front End " + selectedOrderitemid);
					if (DBorderitemid == selectedOrderitemid) {
						System.out.println("Deleteing Order Item from DB" + DBorderitemid);
						OrderItem neworderitem = new OrderItem();
						OrderItem ordeitemfromDB = orderFromDB.getOrderitems().get(i);
						
						neworderitem.setItemId(ordeitemfromDB.getItemId());
						System.out.println("Printing Order Item Id from DB" + ordeitemfromDB.getItemId());
						neworderitem.setItemDescription(ordeitemfromDB.getItemDescription());
						System.out.println(
								"Printing Order Item Description from DB" + ordeitemfromDB.getItemDescription());
						neworderitem.setSizeId(ordeitemfromDB.getSizeId());
						neworderitem.setNote(ordeitemfromDB.getNote());
						neworderitem.setUnitId(ordeitemfromDB.getUnitId());
						neworderitem.setQuantity(ordeitemfromDB.getQuantity());
						neworderitem.setPrice(ordeitemfromDB.getPrice());
						neworderitem.setItemStatusId(ordeitemfromDB.getItemStatusId());
						neworderitem.setComments(ordeitemfromDB.getComments());
						if (ordeitemfromDB.getPrice()!=null) {
						neworderitem.setAmount(ordeitemfromDB.getAmount());
						totalAmount = totalAmount + ordeitemfromDB.getAmount();
						}
						System.out.println("Printing Order Item Amount from DB" + ordeitemfromDB.getAmount());
					
						
						
						order.setTotal(totalAmount);
						neworderitem.setOrder(order);
						orderitemrepository.save(neworderitem);
						
						if (ordeitemfromDB.getPrice()!=null) {
						List<OrderItemPrice> orderItemPriceList = orderFromDB.getOrderitems().get(i).getOrderItemPrices();
						orderItemPriceList.forEach(item-> {
							priceItemIds.add(item.getId());
							OrderItemPrice orderItemPrice = new OrderItemPrice();
							orderItemPrice.setItemRateId(item.getItemRateId());
							orderItemPrice.setItemRate(item.getItemRate());
							orderItemPrice.setNoOfItems(item.getNoOfItems());
							orderItemPrice.setAmount(item.getAmount());
							orderItemPrice.setOrderItem(neworderitem);
							orderItemPriceRepository.save(orderItemPrice);
							
						});
						
						for (Long priceitemid : priceItemIds) {
							populateOrderScreenService.deleteOrderItemPrice(priceitemid);
						}
						
						}

						System.out.println("New Order created from Existing Order successfully" + DBorderitemid);

					}

					Long OrderId = order.getId();
					Order orderfromDB = orderrepository.findById(OrderId);
					System.out.println("Printing Newly created Order No" + OrderId + ":::::" + orderfromDB.getId());
					List<OrderItem> orderitemlist = orderfromDB.getOrderitems();
					System.out.println("Printing no of items from Order" + orderitemlist.size());
					
					orderrepository.save(orderfromDB);
				}
				System.out.println("DB Record ID" + orderItem.getId());

			}

			
			

			for (String itemid : itemIds) {
				populateOrderScreenService.deleteOrderItem(Long.parseLong(itemid));
				System.out.println("Deleted successfully" + itemid);

			}
			System.out.println("Printing from save method");

		
			List<Long> orderId = new ArrayList<Long>();
			orderId.add(Long.valueOf(orderIdStr));
			System.out.println("Number of elements in Array" + orderId.size());
			System.out.println("Printing order ID" + orderId);
			List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderId);
			System.out.println("Order Details Size" + orderdetails.size());
			model.addAttribute("orderdetails", orderdetails);
			List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderId);
			OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
			model.addAttribute("orderNo", orderMasterDTO.getOrderId());
			model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
			model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
			model.addAttribute("startDate", orderMasterDTO.getStartDate());
			model.addAttribute("endDate", orderMasterDTO.getEndDate());
			model.addAttribute("totalAmount", orderMasterDTO.getTotal());

		} catch (Exception e) {
			redirectAttributes.addAttribute("message", e.getMessage());
		}

		return "createorderfromexistingordersuccess";
	}

	@RequestMapping("/showpendingordersshortreport")

	public String showPendingOrdersShortReport(Model model, HttpServletRequest request) throws Exception {

		List<OrderMasterDTO> OrderMultipleItemDTOList = populateOrderScreenService.findAllActiveOrders();
		model.addAttribute("OrderMultipleItemDTOList", OrderMultipleItemDTOList);
		request.getSession().setAttribute("orderdetail", OrderMultipleItemDTOList);
		return "showpendingordersshortreport";
	}

	@RequestMapping("/showbillorderdetail")

	public String showBillOrderDetail(Model model, HttpServletRequest request) throws Exception {

		List<BillOrderDTO> billOrderDetailList = populateOrderScreenService.findBillOrderDetail();
		model.addAttribute("billOrderDetailList", billOrderDetailList);
		return "showbillorderdetail";
	}

	@RequestMapping("/showpendingordersdetailedreport")

	public String showPendingOrdersDetailedReport(Model model, HttpServletRequest request) throws Exception {

		List<OrderItemDetailDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrderItemDetails();
		System.out.println("Printing no of records" + OrderItemDTOActiveList.size());
		model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
		List<ItemStatusDTO> itemstatuslist = populateOrderScreenService.findAllItemStatus();
		model.addAttribute("itemstatus", itemstatuslist);
		ItemPriceDTO itemPriceDTO = new ItemPriceDTO();
		model.addAttribute("itemPriceDTO", itemPriceDTO);
		model.addAttribute("itemstatus", itemstatuslist);
		request.getSession().setAttribute("orderdetail", OrderItemDTOActiveList);
		return "showpendingordersdetailedreport";

	}

	@RequestMapping(value = { "/itemsearchfororderreportbyitemtype" }, method = RequestMethod.GET)
	public String showOrderReportByItemType(Model model, HttpServletRequest request) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<ItemDTO> itemlist = populateOrderScreenService.findAllItems();
		model.addAttribute("items", itemlist);

		return "itemsearchfororderreportbyitemtype";

	}

	@PostMapping("/showorderreportbyitemtype")
	public String showOrderReportByItemType(
			@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO, BindingResult bindingResult,
			Model model, HttpServletRequest request) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String itemIdString = orderSearchBillingDTO.getItemId();
		if (!itemIdString.isEmpty()) {
			long orderId = Long.parseLong(orderSearchBillingDTO.getItemId());
		}
		List<Integer> itemIds = new ArrayList<Integer>();
		itemIds.add(Integer.valueOf(itemIdString));

		List<OrderItemDetailDTO> orderreportbyitemtype = populateOrderScreenService.findAllOrdersByItemType(itemIds);
		request.getSession().setAttribute("orderdetail", orderreportbyitemtype);
		System.out.println("Showing Order List Size" + orderreportbyitemtype.size());
		model.addAttribute("orderreportbyitemtype", orderreportbyitemtype);

		return "showorderreportbyitemtype";
	}

	@RequestMapping(value = { "/showordersearchfordraftingbill" }, method = RequestMethod.GET)
	public String showOrderSearchForDraftingBill(Model model) {
		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		return "ordersearchfordraftingbill";
	}

	@PostMapping("/showordersearchresultfordraftingbill")

	public String showOrderSearchResultForDraftingBill(
			@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO, BindingResult bindingResult,
			Model model) throws Exception {
		String orderIdString = orderSearchBillingDTO.getOrderId();
		if (!orderIdString.isEmpty()) {
			long orderId = Long.parseLong(orderSearchBillingDTO.getOrderId());
		}

		int institutitonId = Integer.parseInt(orderSearchBillingDTO.getInstitutionId());
		int departmentId = Integer.parseInt(orderSearchBillingDTO.getDepartmentId());
		List<OrderSearchDTO> orderSearchBillingDTOList = populateOrderScreenService
				.findOrderByOrderIdorInstitutionIdorDepartmentId(orderSearchBillingDTO);
		System.out.println("Showing Order List Size" + orderSearchBillingDTOList.size());
		model.addAttribute("orderSearchBillingDTOList", orderSearchBillingDTOList);

		OrderIdsForBilling orderIdsForBilling = new OrderIdsForBilling();
		model.addAttribute("orderIdsForBilling", orderIdsForBilling);

		return "ordersearchresultfordraftingbill";
	}

	@GetMapping("/showdraftbill")

	public String showDraftBill(Model model) throws Exception {
		List<OrderSearchDTO> allOrderForBillDraftList = populateOrderScreenService.findAllOrderForBillDraft();
		OrderIdsForBilling orderIdsForBilling = new OrderIdsForBilling();
		model.addAttribute("orderIdsForBilling", orderIdsForBilling);
		model.addAttribute("allOrderForBillDraftList", allOrderForBillDraftList);
		return "showordersfordraftbill";
	}

	@PostMapping("/printbilldraft")
	public String printBillDraft(@ModelAttribute("orderIdsForBilling") OrderIdsForBilling orderIdsForBilling, HttpServletRequest request,
			HttpServletResponse response,Model model) throws IOException {
		System.out.println("Printing Some Data");
		System.out.println("Printing from previewbill method");
		String[] orderIds = orderIdsForBilling.getOrderIds();
		System.out.println("Printing Order Ids" + orderIds);
		System.out.println("Printing order ids size" + orderIds.length);
		String commaSeparatedString = String.join(",", orderIds);
	HashSet<String> orderIDs = new HashSet<String>();
		List<Long> orderids = new ArrayList<Long>();
		for (String orderno : orderIds) {
			Long orderid = Long.valueOf(orderno);
			orderids.add(orderid);
			orderIDs.add(orderno);
			System.out.println("Printing Order Ids" + orderno);

		}

		HashSet<String> institution = new HashSet<String>();
		HashSet<String> departments = new HashSet<String>();
		List<String> itemNames = new ArrayList<>();

		
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetailsforBilling(orderids);
		
		for (OrderItemDetailDTO orderdetail : orderdetails) {
			departments.add(orderdetail.getDepartmentName());
			institution.add(orderdetail.getInstitutionName());
			itemNames.add(orderdetail.getItemName() +" " + orderdetail.getItemDescription());
			
		}
		
		
		
		
     System.out.println("Printing All Order Items with Space in btween" + itemNames);

		Iterator it = institution.iterator();
		String institutionName = null;
		while (it.hasNext()) {
			institutionName = (String) it.next();
		}
		
		DecimalFormat df = new DecimalFormat("0.00");
		Bill bill = new Bill();
		Double billTotal = 0.0;
		for (Long orderno : orderids) {

			Order orderfromDB = orderrepository.findById(Long.valueOf(orderno));
			BillOrder billOrder = new BillOrder();
			billOrder.setOrderId(orderno);
			if (orderfromDB.getTotal()!=null) {
			billOrder.setOrderTotalAmount(orderfromDB.getTotal());
			bill.getBillOrders().add(billOrder);
			billTotal = billTotal + orderfromDB.getTotal();
			}
		}
		bill.setTransactionDate(new Date());
		bill.setTotalAmount(billTotal);
		billRepository.save(bill);
		long billid = bill.getBillId();
		System.out.println("Printing Bill Id" + billid);
		
		
 for (String orderno : orderIds) {
			Long orderid = Long.valueOf(orderno);

			Order orderFromDB = orderrepository.findById(Long.valueOf(orderid));
			orderFromDB.setBillDraft("yes");
			orderrepository.save(orderFromDB);
			System.out.println("Printing Order Ids" + orderno);

		} 
		

	    Bill DBBillFromDB = billRepository.findByBillId(billid);
	    Long billTotalRounded = Math.round(DBBillFromDB.getTotalAmount());
		long billtotallong = billTotalRounded.longValue();
		String amountinwords = "(Rupees in words  " + ConvertNumberToWords.numberToWords(billtotallong) + " only)";
		Date billDate = DBBillFromDB.getTransactionDate();
		int billDateYear = YearMonth.now().getYear();
		String billDateYearStr = Integer.toString(billDateYear);
		String lastTwoDigitsOfbillDateYear = billDateYearStr.substring(2, 4);
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		
		String strDate = formatter.format(billDate);
		int totalNoofRows = 12;
		int orderdetailsize = orderdetails.size();
		
				
		int totalItems =orderdetails.size();
		int totalPages = (int) Math.ceil((double) totalItems / ITEMS_PER_PAGE);
		
		 List<List<OrderItemDetailDTO>> orderItemPages = new ArrayList<>();
	        for (int i = 0; i < totalPages; i++) {
	            int start = i * ITEMS_PER_PAGE;
	            int end = Math.min(start + ITEMS_PER_PAGE, totalItems);
	            orderItemPages.add(orderdetails.subList(start, end));
	        }
	        
	        int sizeOFLastPage = 0;
	    
	        		List<OrderItemDetailDTO> orderItemPage = orderItemPages.get(orderItemPages.size()-1);
	        		sizeOFLastPage = orderItemPage.size();
	        
	        int noOfEmptySpacesToBeAdded = ITEMS_PER_PAGE - sizeOFLastPage;
		
	    model.addAttribute("orderItemPages", orderItemPages);
	    model.addAttribute("lastTwoDigitsOfbillDateYear",lastTwoDigitsOfbillDateYear);
		model.addAttribute("billId", billid);
		model.addAttribute("institution", institutionName);
		model.addAttribute("departments", departments);
		model.addAttribute("orderdetails", orderdetails);
		model.addAttribute("orderIds", commaSeparatedString);
		model.addAttribute("billTotal",df.format(billTotalRounded)); 
				
		model.addAttribute("amountinwords", amountinwords);
		model.addAttribute("noOfEmptySpacesToBeAdded", noOfEmptySpacesToBeAdded);
		model.addAttribute("date", strDate);
		model.addAttribute("pageSize", totalPages);
		model.addAttribute("itemperpage", ITEMS_PER_PAGE);
		request.getSession().setAttribute("orderdetailpdf", orderdetails);
		
		
		return "printbilldraft";
		
		
	

	}

	@GetMapping("/showbillprint")

	public String showdBillPrint(Model model) throws Exception {
		List<BillOrderDTO> billOrderList = populateOrderScreenService.findBillOrderDetail();
		System.out.println("Showing Bill List Size" + billOrderList.size());

		BillSearchDTO BillSearchDTOForPrinting = new BillSearchDTO();
		model.addAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
		model.addAttribute("billReportList", billOrderList);
		System.out.println("This is from showbillreportsearchresult method");

		return "showbillsforbillprint";
	}

	@GetMapping("/billprinting")
	public String billPrinting( HttpServletResponse response,
			HttpServletRequest request, Model model) throws IOException {
		System.out.println("Printing from printbill");
		long billId =Long.parseLong(request.getParameter("billId"));
		//long billid = billId;
		System.out.println("Printing Bill Id" + billId);

		List<BillOrderDTO> billOrderList = populateOrderScreenService.findBillOrderDetailByBillId(billId);

		// Bill bill = new Bill();
		int size = billOrderList.size();
		String[] orderIds = new String[size];
		for (int i = 0; i < size; i++) {
			BillOrderDTO BillOrderDTO = billOrderList.get(i);
			orderIds[i] = BillOrderDTO.getOrderId();
		}
		String commaSeparatedString = String.join(",", orderIds);

		List<Long> orderids = new ArrayList<Long>();
		for (BillOrderDTO billOrder : billOrderList) {
			Long orderid = Long.valueOf(billOrder.getOrderId());
			orderids.add(orderid);
			System.out.println("Printing Order Ids" + orderid);

		}

		
		for (Long orderno : orderids) {
			System.out.println("Inside Profit Margin");
			System.out.println("Printing Order Id" + orderno);
			Double orderTotal = 0.0;
			Order orderfromDB = orderrepository.findById(Long.valueOf(orderno));
			System.out.println("Printing Order Id" + orderfromDB.getId());
			List<OrderItem> orderItems = orderfromDB.getOrderitems();
			
			for (OrderItem orderItem : orderItems) {
				System.out.println("Printing Order Item Id" + orderItem.getId());
				DecimalFormat df = new DecimalFormat("0.00");
				Double profitMargin = orderfromDB.getProfitMargin();
				System.out.println("Printing Profit Margin" + profitMargin);
				Double totalItemProfit = 0.0;
				Double itemProfit = 0.0;
				if (orderItem.getAmount() != null && profitMargin != null) {
					totalItemProfit = profitMargin/100*orderItem.getAmount();
					System.out.println("Printing Total Item Profit " + totalItemProfit);
				}
				if (orderItem.getQuantity()!=null) {
					itemProfit = totalItemProfit/orderItem.getQuantity();
					System.out.println("Printing Item Profit " + itemProfit);
				}
				if (orderItem.getPrice()!=null ) {
					System.out.println("Printing Price Before Applying Profit Margin "+ orderItem.getPrice());
					orderItem.setPrice(Double.parseDouble(df.format(orderItem.getPrice()+itemProfit)));
					System.out.println("Printing Price After Applying Profit Margin "+ orderItem.getPrice());
				}
				/*orderItemEntity.setOneTimeChargesTotal(oneTimeChargesTotal);
				orderItemEntity.setMultipleTimeChargesTotal(multipleTimeChargesTotal); */
				if (orderItem.getAmount()!=null) {
					System.out.println("Printing Price Before Applying Profit Margin "+ orderItem.getPrice());
					orderItem.setAmount(Double.parseDouble(df.format(orderItem.getAmount()+totalItemProfit)));
					System.out.println("Printing Price Before Applying Profit Margin "+ orderItem.getPrice());
					orderTotal = orderTotal+orderItem.getAmount();
				}
				orderitemrepository.save(orderItem);
				
			}
			
			System.out.println("Printing Order Total  "+ orderTotal);
			orderfromDB.setTotal(orderTotal);
			orderrepository.save(orderfromDB);
			
		}

		HashSet<String> institution = new HashSet<String>();
		HashSet<String> departments = new HashSet<String>();

		// Double totalAmount = 0.0;
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetailsforBilling(orderids);
		for (OrderItemDetailDTO orderdetail : orderdetails) {
			departments.add(orderdetail.getDepartmentName());
			institution.add(orderdetail.getInstitutionName());
			// totalAmount = totalAmount + Double.parseDouble(orderdetail.getAmount());
		}

		Iterator it = institution.iterator();
		String institutionName = null;
		while (it.hasNext()) {
			institutionName = (String) it.next();
		}

		Bill billFromDB = billRepository.findByBillId(billId);
		System.out.println("Printing Bill ID" + billFromDB.getBillId());
		List<BillOrder> billOrderListFromDB = billFromDB.getBillOrders();
		int listSize = billOrderListFromDB.size();
		System.out.println("Printing Bill Order List Size" + listSize);
		for (int i = 0; i < listSize; ++i) {
			System.out.println("printing i " + i);
			BillOrder billOrder = billOrderListFromDB.get(i);
			long orderId = billOrder.getOrderId();
			System.out.println("Printing Order Id" + orderId);
			Order orderFromDB = orderrepository.findById(orderId);
			billOrder.setOrderTotalAmount(orderFromDB.getTotal());
		}

		Double billTotal = 0.0;
		for (Long orderno : orderids) {

			Order orderfromDB = orderrepository.findById(Long.valueOf(orderno));
			BillOrder billOrder = new BillOrder();
			billOrder.setOrderId(orderno);
			billOrder.setOrderTotalAmount(orderfromDB.getTotal());
			billTotal = billTotal + orderfromDB.getTotal();
			billOrderRepository.save(billOrder);
		}
		billFromDB.setTransactionDate(new Date());
		billFromDB.setTotalAmount(billTotal);
		billRepository.save(billFromDB);
		double total = 0;
		// List<OrderItemDetailDTO> OrderItemDetailDTOList =
		// populateOrderScreenService.findOrderItemDetails(orderids);
		/*
		 * for (OrderItemDetailDTO OrderItemDetailDTO : orderdetails) {
		 * System.out.println("Printing order id and total amount" +
		 * OrderItemDetailDTO.getOrderId() + OrderItemDetailDTO.getAmount());
		 * 
		 * total = total + Double.parseDouble(OrderItemDetailDTO.getAmount()); }
		 */

		System.out.println("Printing Total " + total);

		System.out.println("Printing Bill Id" + billId);
		for (Long orderno : orderids) {

			System.out.println("Printing Order Id from Bill Table" + orderno);
			Order orderFromDB = orderrepository.findById(Long.valueOf(orderno));
			System.out.println("Printing order id from order table" + orderFromDB.getId());
			orderFromDB.setEndDate(new Date());
			orderFromDB.setStatus("complete");
			orderrepository.save(orderFromDB);
			System.out.println("Printing Order Id" + orderno);

		}
		Bill DBBillFromDB = billRepository.findByBillId(billId);
		// long billtotallong = billTotal.longValue();
		//long billtotallong = (long) Math.round(DBBillFromDB.getTotalAmount());
		  Long billTotalRounded = Math.round(DBBillFromDB.getTotalAmount());
			long billtotallong = billTotalRounded.longValue();
			//String amountinwords = "(Rupees in words  " + ConvertNumberToWords.numberToWords(billtotallong) + " only)";
		String amountinwords = "(Rupees in words  " + ConvertNumberToWords.numberToWords(billtotallong) + " only)";
		int billDateYear = YearMonth.now().getYear();
		String billDateYearStr = Integer.toString(billDateYear);
		String lastTwoDigitsOfbillDateYear = billDateYearStr.substring(2, 4);

		Date today = DBBillFromDB.getTransactionDate();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate = formatter.format(today);
		int totalNoofRows = 12;
		int orderdetailsize = orderdetails.size();
	//	int noOfEmptySpacesToBeAdded = totalNoofRows - orderdetailsize;
		
		
		int totalItems =orderdetails.size();
		int totalPages = (int) Math.ceil((double) totalItems / ITEMS_PER_PAGE);
		
		 List<List<OrderItemDetailDTO>> orderItemPages = new ArrayList<>();
	        for (int i = 0; i < totalPages; i++) {
	            int start = i * ITEMS_PER_PAGE;
	            int end = Math.min(start + ITEMS_PER_PAGE, totalItems);
	            orderItemPages.add(orderdetails.subList(start, end));
	        }
	        
	        int sizeOFLastPage = 0;
	        List<OrderItemDetailDTO> orderItemPage = orderItemPages.get(orderItemPages.size()-1);
    		sizeOFLastPage = orderItemPage.size();
	        int noOfEmptySpacesToBeAdded = ITEMS_PER_PAGE - sizeOFLastPage;
	        DecimalFormat df = new DecimalFormat("0.00");
	        model.addAttribute("lastTwoDigitsOfbillDateYear",lastTwoDigitsOfbillDateYear);
	        model.addAttribute("orderItemPages", orderItemPages);
		    
			model.addAttribute("billId", billId);
			model.addAttribute("institution", institutionName);
			model.addAttribute("departments", departments);
			model.addAttribute("orderdetails", orderdetails);
			model.addAttribute("orderIds", commaSeparatedString);
			model.addAttribute("billTotal",df.format(billTotalRounded)); 
			model.addAttribute("amountinwords", amountinwords);
			model.addAttribute("noOfEmptySpacesToBeAdded", noOfEmptySpacesToBeAdded);
			model.addAttribute("date", strDate);
			model.addAttribute("pageSize", totalPages);
			model.addAttribute("itemperpage", ITEMS_PER_PAGE);
		return "printbill";
		// return "printbillportrait";
		// return "printbill";
	//	return "printbilldrafttesting";
		// return "printbilltableborderless";

	}
	
	
	@GetMapping("/showduplicatebilldraftprint")

	public String showDuplicateBillDraftPrint(Model model) throws Exception {
	//	List<BillOrderDTO> billOrderList = populateOrderScreenService.findBillOrderDetail();
		List<BillOrderDTO> billOrderList = populateOrderScreenService.findBillOrderDetailForDuplicateBill();
		
		System.out.println("Showing Bill List Size" + billOrderList.size());

		BillSearchDTO BillSearchDTOForPrinting = new BillSearchDTO();
		model.addAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
		model.addAttribute("billReportList", billOrderList);
		System.out.println("This is from showbillreportsearchresult method");

		return "showduplicatebilldraftprint";
	}
	
	
	@GetMapping("/printduplicatebilldraftforall/{billId}")
	public String printDuplicateBillDraftForALL( @PathVariable("billId") long billId, HttpServletResponse response,
			HttpServletRequest request, Model model) throws IOException {
		System.out.println("Printing from printduplicatebilldraft");
		
		long billid = billId;
		System.out.println("Printing Bill Id" + billId);

		List<BillOrderDTO> billOrderList = populateOrderScreenService.findBillOrderDetailByBillId(billid);
		System.out.println("Printing no of items in Order list" + billOrderList.size());

		// Bill bill = new Bill();
		int size = billOrderList.size();
		String[] orderIds = new String[size];
		for (int i = 0; i < size; i++) {
			BillOrderDTO BillOrderDTO = billOrderList.get(i);
			orderIds[i] = BillOrderDTO.getOrderId();
		}
		String commaSeparatedString = String.join(",", orderIds);

		List<Long> orderids = new ArrayList<Long>();
		for (BillOrderDTO billOrder : billOrderList) {
			Long orderid = Long.valueOf(billOrder.getOrderId());
			orderids.add(orderid);
			System.out.println("Printing Order Ids" + orderid);

		}

		HashSet<String> institution = new HashSet<String>();
		HashSet<String> departments = new HashSet<String>();

		// Double totalAmount = 0.0;
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService
				.findOrderItemDetailsForDuplicateBill(orderids);
		for (OrderItemDetailDTO orderdetail : orderdetails) {
			departments.add(orderdetail.getDepartmentName());
			institution.add(orderdetail.getInstitutionName());
			// totalAmount = totalAmount + Double.parseDouble(orderdetail.getAmount());
		}

		Iterator it = institution.iterator();
		String institutionName = null;
		while (it.hasNext()) {
			institutionName = (String) it.next();
		}

		System.out.println("Printing Bill Id" + billId);

		Bill billFromDB = billRepository.findByBillId(billId);
		Double billTotal = billFromDB.getTotalAmount();
		System.out.println("Printing bill total from DB" + billTotal);
		 Long billTotalRounded = Math.round(billTotal);
		 System.out.println("Printing bill total After Round Off" + billTotalRounded);
		  long billtotallong = billTotalRounded.longValue();
		  System.out.println("Printing bill total After converting to long value" + billTotalRounded);
		//long billtotallong = (long) billFromDB.getTotalAmount();
		String amountinwords = "(in words) Rupees " + ConvertNumberToWords.numberToWords(billtotallong) + " Only";
		System.out.println("Printing bill total in words" + amountinwords);
		int billDateYear = YearMonth.now().getYear();
		String billDateYearStr = Integer.toString(billDateYear);
		String lastTwoDigitsOfbillDateYear = billDateYearStr.substring(2, 4);


		Date today = billFromDB.getTransactionDate();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate = formatter.format(today);
		int totalNoofRows = 12;
		int orderdetailsize = orderdetails.size();
		//int noOfEmptySpacesToBeAdded = totalNoofRows - orderdetailsize;

		int totalItems =orderdetails.size();
		int totalPages = (int) Math.ceil((double) totalItems / ITEMS_PER_PAGE);
		
		 List<List<OrderItemDetailDTO>> orderItemPages = new ArrayList<>();
	        for (int i = 0; i < totalPages; i++) {
	            int start = i * ITEMS_PER_PAGE;
	            int end = Math.min(start + ITEMS_PER_PAGE, totalItems);
	            orderItemPages.add(orderdetails.subList(start, end));
	        }
	        
	        int sizeOFLastPage = 0;
	        List<OrderItemDetailDTO> orderItemPage = orderItemPages.get(orderItemPages.size()-1);
    		sizeOFLastPage = orderItemPage.size();
	        int noOfEmptySpacesToBeAdded = ITEMS_PER_PAGE - sizeOFLastPage;
	        DecimalFormat df = new DecimalFormat("0.00");

	        model.addAttribute("lastTwoDigitsOfbillDateYear",lastTwoDigitsOfbillDateYear);


	        model.addAttribute("orderItemPages", orderItemPages);
		    
			model.addAttribute("billId", billId);
			model.addAttribute("institution", institutionName);
			model.addAttribute("departments", departments);
			model.addAttribute("orderdetails", orderdetails);
			model.addAttribute("orderIds", commaSeparatedString);
			model.addAttribute("billTotal",df.format(billTotalRounded)); 
			model.addAttribute("amountinwords", amountinwords);
			model.addAttribute("noOfEmptySpacesToBeAdded", noOfEmptySpacesToBeAdded);
			model.addAttribute("date", strDate);
			model.addAttribute("pageSize", totalPages);
			model.addAttribute("itemperpage", ITEMS_PER_PAGE);
		
		
		return "printbilldraftduplicate";

	}
	
	@GetMapping("/showduplicatebillprint")
	public String showDuplicateBillPrint(Model model) throws Exception {
		List<BillOrderDTO> billOrderList = populateOrderScreenService.findBillOrderDetailForDuplicateBill();
		System.out.println("Showing Bill List Size" + billOrderList.size());

		BillSearchDTO BillSearchDTOForPrinting = new BillSearchDTO();
		model.addAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
		model.addAttribute("billReportList", billOrderList);
		System.out.println("This is from showbillreportsearchresult method");

		return "showduplicatebillprint";
	}

	@GetMapping("/printduplicatebill/{billId}")
	public String printDuplicateBillForSome(HttpServletResponse response,
				HttpServletRequest request, Model model) throws IOException {
			System.out.println("Printing from printduplicatebilldraft");
			String billid =request.getParameter("billId");
			long billId = Long.parseLong(billid);
			System.out.println("Printing Bill Id" + billId);

			List<BillOrderDTO> billOrderList = populateOrderScreenService.findBillOrderDetailByBillId(billId);
			System.out.println("Printing no of items in Order list" + billOrderList.size());

			// Bill bill = new Bill();
			int size = billOrderList.size();
			String[] orderIds = new String[size];
			for (int i = 0; i < size; i++) {
				BillOrderDTO BillOrderDTO = billOrderList.get(i);
				orderIds[i] = BillOrderDTO.getOrderId();
			}
			String commaSeparatedString = String.join(",", orderIds);

			List<Long> orderids = new ArrayList<Long>();
			for (BillOrderDTO billOrder : billOrderList) {
				Long orderid = Long.valueOf(billOrder.getOrderId());
				orderids.add(orderid);
				System.out.println("Printing Order Ids" + orderid);

			}

			HashSet<String> institution = new HashSet<String>();
			HashSet<String> departments = new HashSet<String>();

			// Double totalAmount = 0.0;
			List<OrderItemDetailDTO> orderdetails = populateOrderScreenService
					.findOrderItemDetailsForDuplicateBill(orderids);
			for (OrderItemDetailDTO orderdetail : orderdetails) {
				departments.add(orderdetail.getDepartmentName());
				institution.add(orderdetail.getInstitutionName());
				// totalAmount = totalAmount + Double.parseDouble(orderdetail.getAmount());
			}

			Iterator it = institution.iterator();
			String institutionName = null;
			while (it.hasNext()) {
				institutionName = (String) it.next();
			}

			System.out.println("Printing Bill Id" + billId);

			Bill billFromDB = billRepository.findByBillId(billId);
			Double billTotal = billFromDB.getTotalAmount();
			System.out.println("Printing bill total from DB" + billTotal);
			 Long billTotalRounded = Math.round(billTotal);
			 System.out.println("Printing bill total After Round Off" + billTotalRounded);
			  long billtotallong = billTotalRounded.longValue();
			  System.out.println("Printing bill total After converting to long value" + billTotalRounded);
			//long billtotallong = (long) billFromDB.getTotalAmount();
			String amountinwords = "(in words) Rupees " + ConvertNumberToWords.numberToWords(billtotallong) + " Only";
			int billDateYear = YearMonth.now().getYear();
			String billDateYearStr = Integer.toString(billDateYear);
			String lastTwoDigitsOfbillDateYear = billDateYearStr.substring(2, 4);

			Date today = billFromDB.getTransactionDate();
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			String strDate = formatter.format(today);
			int totalNoofRows = 12;
			int orderdetailsize = orderdetails.size();
		//	int noOfEmptySpacesToBeAdded = totalNoofRows - orderdetailsize;

			int totalItems =orderdetails.size();
			int totalPages = (int) Math.ceil((double) totalItems / ITEMS_PER_PAGE);
			
			 List<List<OrderItemDetailDTO>> orderItemPages = new ArrayList<>();
		        for (int i = 0; i < totalPages; i++) {
		            int start = i * ITEMS_PER_PAGE;
		            int end = Math.min(start + ITEMS_PER_PAGE, totalItems);
		            orderItemPages.add(orderdetails.subList(start, end));
		        }
		        
		        int sizeOFLastPage = 0;
		        List<OrderItemDetailDTO> orderItemPage = orderItemPages.get(orderItemPages.size()-1);
        		sizeOFLastPage = orderItemPage.size();
		        int noOfEmptySpacesToBeAdded = ITEMS_PER_PAGE - sizeOFLastPage;
		        
		        DecimalFormat df = new DecimalFormat("0.00");
		        model.addAttribute("lastTwoDigitsOfbillDateYear",lastTwoDigitsOfbillDateYear);
		        model.addAttribute("orderItemPages", orderItemPages);
			    
				model.addAttribute("billId", billId);
				model.addAttribute("institution", institutionName);
				model.addAttribute("departments", departments);
				model.addAttribute("orderdetails", orderdetails);
				model.addAttribute("orderIds", commaSeparatedString);
				model.addAttribute("billTotal",df.format(billTotalRounded)); 
				model.addAttribute("amountinwords", amountinwords);
				model.addAttribute("noOfEmptySpacesToBeAdded", noOfEmptySpacesToBeAdded);
				model.addAttribute("date", strDate);
				model.addAttribute("pageSize", totalPages);
				model.addAttribute("itemperpage", ITEMS_PER_PAGE);
			return "printbillduplicate";

		}
	
	
	@GetMapping("/showallactiveorderforquote")
	public String showAllActiveOrderForQuote(Model model, HttpServletRequest request) throws Exception {

		List<OrderItemDetailDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrderItemDetails();
		model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
		
		return "showallactiveorderforquote";
	}
	
	@GetMapping("/showdorderquote/{orderId}")
	public String showorderquote(@PathVariable("orderId") long orderId, HttpServletResponse response,
			HttpServletRequest request, Model model) throws IOException {
		System.out.println("Printing from previewbill method");
		/*
		
		System.out.println("Printing Order Ids" + orderIds);
		System.out.println("Printing order ids size" + orderIds.length);
		String commaSeparatedString = String.join(",", orderIds);
		HashSet<String> orderIDs = new HashSet<String>();
		List<Long> orderids = new ArrayList<Long>();
		for (String orderno : orderIds) {
			Long orderid = Long.valueOf(orderno);
			orderids.add(orderid);
			orderIDs.add(orderno);
			System.out.println("Printing Order Ids" + orderno);

		}
		*/

		List<Long> orderIds = new ArrayList<Long>();
		orderIds.add(orderId);
		HashSet<String> institution = new HashSet<String>();
		HashSet<String> departments = new HashSet<String>();

		// Double totalAmount = 0.0;
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetailsforBilling(orderIds);
		for (OrderItemDetailDTO orderdetail : orderdetails) {
			departments.add(orderdetail.getDepartmentName());
			institution.add(orderdetail.getInstitutionName());
			// totalAmount = totalAmount + Double.parseDouble(orderdetail.getAmount());
		}

		Iterator it = institution.iterator();
		String institutionName = null;
		while (it.hasNext()) {
			institutionName = (String) it.next();
		}
	
		Order orderEntity = orderrepository.findById(Long.valueOf(orderId));
		long orderTotal = orderEntity.getTotal().longValue();
		
		String amountinwords = "(in words) Rupees " + ConvertNumberToWords.numberToWords(orderTotal) + " Only";
		Date billDate = orderEntity.getStartDate();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate = formatter.format(billDate);
		int totalNoofRows = 12;
		int orderdetailsize = orderdetails.size();
		
		
		int totalItems =orderdetails.size();
		int totalPages = (int) Math.ceil((double) totalItems / ITEMS_PER_PAGE);
		
		 List<List<OrderItemDetailDTO>> orderItemPages = new ArrayList<>();
	        for (int i = 0; i < totalPages; i++) {
	            int start = i * ITEMS_PER_PAGE;
	            int end = Math.min(start + ITEMS_PER_PAGE, totalItems);
	            orderItemPages.add(orderdetails.subList(start, end));
	        }
	        
	        int sizeOFLastPage = 0;
	        List<OrderItemDetailDTO> orderItemPage = orderItemPages.get(orderItemPages.size()-1);
    		sizeOFLastPage = orderItemPage.size();
	        int noOfEmptySpacesToBeAdded = ITEMS_PER_PAGE - sizeOFLastPage;
	        DecimalFormat df = new DecimalFormat("0.00");
	    model.addAttribute("orderItemPages", orderItemPages);
	    
		model.addAttribute("orderId", orderId);
		model.addAttribute("institution", institutionName);
		model.addAttribute("departments", departments);
		model.addAttribute("orderdetails", orderdetails);
	//	model.addAttribute("orderIds", commaSeparatedString);
		model.addAttribute("billTotal", df.format(orderTotal));
		model.addAttribute("amountinwords", amountinwords);
		model.addAttribute("noOfEmptySpacesToBeAdded", noOfEmptySpacesToBeAdded);
		model.addAttribute("date", strDate);
		model.addAttribute("pageSize", totalPages);
		model.addAttribute("itemperpage", ITEMS_PER_PAGE);
		return "printquote";
		//return "printbilldraft";
		
	}



	@RequestMapping(value = { "/showbillsearchforduplicatebilldraftprinting" }, method = RequestMethod.GET)
	public String showBillSearchForDuplicateBillDraftPrinting(Model model) {
		System.out.println("Printing from showbillsearchforduplicatebilldraftprinting");
		// OrderIdsDTO orderIdsDTO = new OrderIdsDTO();
		// model.addAttribute("orderIdsDTO", orderIdsDTO);
		BillSearchDTO billSearchDTO = new BillSearchDTO();
		model.addAttribute("billSearchDTO", billSearchDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		return "billsearchforduplicatebilldraftprinting";
	}

	@GetMapping(value = { "/showbillsearchresultfordupilcatebilldraftprinting" })
	// public String showRevenueReportSearchResult() throws Exception {
	public String showBillSearchrResultfForDupilcateBillDraftPrinting(
			@Valid @ModelAttribute("billSearchDTO") BillSearchDTO billSearchDTO, BindingResult bindingResult,
			Model model, RedirectAttributes redirectAttributes, HttpServletRequest request) throws Exception {

		if (bindingResult.hasErrors()) {
			// return "redirect:/test25";
			return "showbillsearchforduplicatebilldraftprinting";
		}

		System.out.println(
				"Printing Bill ID from showbillsearchresultfordupilcatebilldraftprinting" + billSearchDTO.getBillId());

		if (!billSearchDTO.getBillId().isEmpty()) {
			long billId = Long.parseLong(billSearchDTO.getBillId());
			BillSearchDTO BillSearchDTOForPrinting = new BillSearchDTO();
			BillSearchDTOForPrinting.setBillId(billSearchDTO.getBillId());
			// model.addAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
			redirectAttributes.addFlashAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
			return "redirect:/printduplicatebilldraft";
		} else {
			// List<BillDTO> billOrderList =
			// populateOrderScreenService.findBillByInstitutionOrBillId(billSearchDTO);
			List<BillDTO> billOrderList = populateOrderScreenService
					.findBillByInstitutionOrBillIdForDuplicateBill(billSearchDTO);
			System.out.println("Showing Bill List Size" + billOrderList.size());

			request.getSession().setAttribute("billReportListSession", billOrderList);
			BillSearchDTO BillSearchDTOForPrinting = new BillSearchDTO();
			model.addAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
			model.addAttribute("billReportList", billOrderList);
			System.out.println("This is from showbillreportsearchresult method");
			return "showbillsearchresultforduplicatebilldraftprinting";
		}
	}

	@RequestMapping("/printduplicatebilldraft")
	// @RequestMapping(value = { "/generatebill" }, params = { "savebill" })
	public String printDuplicateBillDraft(Model model,
			@ModelAttribute("BillSearchDTOForPrinting") BillSearchDTO BillSearchDTOForPrinting) {
		System.out.println("Printing from printduplicatebilldraft");
		long billId = Long.parseLong(BillSearchDTOForPrinting.getBillId());
		System.out.println("Printing Bill Id" + billId);

		List<BillOrderDTO> billOrderList = populateOrderScreenService.findBillOrderDetailByBillId(billId);
		System.out.println("Printing no of items in Order list" + billOrderList.size());

		// Bill bill = new Bill();
		int size = billOrderList.size();
		String[] orderIds = new String[size];
		for (int i = 0; i < size; i++) {
			BillOrderDTO BillOrderDTO = billOrderList.get(i);
			orderIds[i] = BillOrderDTO.getOrderId();
		}
		String commaSeparatedString = String.join(",", orderIds);

		List<Long> orderids = new ArrayList<Long>();
		for (BillOrderDTO billOrder : billOrderList) {
			Long orderid = Long.valueOf(billOrder.getOrderId());
			orderids.add(orderid);
			System.out.println("Printing Order Ids" + orderid);

		}

		HashSet<String> institution = new HashSet<String>();
		HashSet<String> departments = new HashSet<String>();

		// Double totalAmount = 0.0;
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService
				.findOrderItemDetailsForDuplicateBill(orderids);
		for (OrderItemDetailDTO orderdetail : orderdetails) {
			departments.add(orderdetail.getDepartmentName());
			institution.add(orderdetail.getInstitutionName());
			// totalAmount = totalAmount + Double.parseDouble(orderdetail.getAmount());
		}

		Iterator it = institution.iterator();
		String institutionName = null;
		while (it.hasNext()) {
			institutionName = (String) it.next();
		}

		System.out.println("Printing Bill Id" + billId);

		Bill billFromDB = billRepository.findByBillId(billId);
		Double billTotal = billFromDB.getTotalAmount();
		long billtotallong = (long) billFromDB.getTotalAmount();
		String amountinwords = "(in words) Rupees " + ConvertNumberToWords.numberToWords(billtotallong) + " Only";
		int billDateYear = YearMonth.now().getYear();
		String billDateYearStr = Integer.toString(billDateYear);
		String lastTwoDigitsOfbillDateYear = billDateYearStr.substring(2, 4);


		Date today = billFromDB.getTransactionDate();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate = formatter.format(today);
		int totalNoofRows = 12;
		int orderdetailsize = orderdetails.size();
		//int noOfEmptySpacesToBeAdded = totalNoofRows - orderdetailsize;

		int totalItems =orderdetails.size();
		int totalPages = (int) Math.ceil((double) totalItems / ITEMS_PER_PAGE);
		
		 List<List<OrderItemDetailDTO>> orderItemPages = new ArrayList<>();
	        for (int i = 0; i < totalPages; i++) {
	            int start = i * ITEMS_PER_PAGE;
	            int end = Math.min(start + ITEMS_PER_PAGE, totalItems);
	            orderItemPages.add(orderdetails.subList(start, end));
	        }
	        
	        int sizeOFLastPage = 0;
	        List<OrderItemDetailDTO> orderItemPage = orderItemPages.get(orderItemPages.size()-1);
    		sizeOFLastPage = orderItemPage.size();
	        int noOfEmptySpacesToBeAdded = ITEMS_PER_PAGE - sizeOFLastPage;
	        DecimalFormat df = new DecimalFormat("0.00");

	        model.addAttribute("lastTwoDigitsOfbillDateYear",lastTwoDigitsOfbillDateYear);


	        model.addAttribute("orderItemPages", orderItemPages);
		    
			model.addAttribute("billId", billId);
			model.addAttribute("institution", institutionName);
			model.addAttribute("departments", departments);
			model.addAttribute("orderdetails", orderdetails);
			model.addAttribute("orderIds", commaSeparatedString);
			model.addAttribute("billTotal",df.format(Math.round(billTotal))); 
			model.addAttribute("amountinwords", amountinwords);
			model.addAttribute("noOfEmptySpacesToBeAdded", noOfEmptySpacesToBeAdded);
			model.addAttribute("date", strDate);
			model.addAttribute("pageSize", totalPages);
			model.addAttribute("itemperpage", ITEMS_PER_PAGE);
		
		
		return "printbilldraftduplicate";

	}

	@RequestMapping(value = { "/showbillsearchforduplicatebillprinting" }, method = RequestMethod.GET)
	public String showBillSearchForDuplicateBillPrinting(Model model) {
		System.out.println("Printing from showbillsearchforduplicatebilldraftprinting");
		// OrderIdsDTO orderIdsDTO = new OrderIdsDTO();
		// model.addAttribute("orderIdsDTO", orderIdsDTO);
		BillSearchDTO billSearchDTO = new BillSearchDTO();
		model.addAttribute("billSearchDTO", billSearchDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		return "billsearchforduplicatebillprinting";
	}

	@GetMapping(value = { "/showbillsearchresultfordupilcatebillprinting" })
//public String showRevenueReportSearchResult() throws Exception {
	public String showBillSearchrResultfForDupilcateBillPrinting(
			@Valid @ModelAttribute("billSearchDTO") BillSearchDTO billSearchDTO, BindingResult bindingResult,
			Model model, RedirectAttributes redirectAttributes, HttpServletRequest request) throws Exception {

		if (bindingResult.hasErrors()) {
			// return "redirect:/test25";
			return "showbillsearchforduplicatebillprinting";
		}

		System.out.println(
				"Printing Bill ID from showbillsearchresultfordupilcatebilldraftprinting" + billSearchDTO.getBillId());

		if (!billSearchDTO.getBillId().isEmpty()) {
			long billId = Long.parseLong(billSearchDTO.getBillId());
			BillSearchDTO BillSearchDTOForPrinting = new BillSearchDTO();
			BillSearchDTOForPrinting.setBillId(billSearchDTO.getBillId());
			// model.addAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
			redirectAttributes.addFlashAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
			return "redirect:/printduplicatebill";
		} else {
			// List<BillDTO> billOrderList =
			// populateOrderScreenService.findBillByInstitutionOrBillId(billSearchDTO);
			List<BillDTO> billOrderList = populateOrderScreenService
					.findBillByInstitutionOrBillIdForDuplicateBill(billSearchDTO);
			System.out.println("Showing Bill List Size" + billOrderList.size());

			request.getSession().setAttribute("billReportListSession", billOrderList);
			BillSearchDTO BillSearchDTOForPrinting = new BillSearchDTO();
			model.addAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
			model.addAttribute("billReportList", billOrderList);
			System.out.println("This is from showbillreportsearchresult method");
			return "showbillsearchresultforduplicatebillprinting";
		}
	}

	@RequestMapping("/printduplicatebill")
//@RequestMapping(value = { "/generatebill" }, params = { "savebill" })
	public String printDuplicateBill(Model model,
			@ModelAttribute("BillSearchDTOForPrinting") BillSearchDTO BillSearchDTOForPrinting) {
		System.out.println("Printing from printduplicatebilldraft");
		long billId = Long.parseLong(BillSearchDTOForPrinting.getBillId());
		System.out.println("Printing Bill Id" + billId);

		List<BillOrderDTO> billOrderList = populateOrderScreenService.findBillOrderDetailByBillId(billId);
		System.out.println("Printing no of items in Order list" + billOrderList.size());

		// Bill bill = new Bill();
		int size = billOrderList.size();
		String[] orderIds = new String[size];
		for (int i = 0; i < size; i++) {
			BillOrderDTO BillOrderDTO = billOrderList.get(i);
			orderIds[i] = BillOrderDTO.getOrderId();
		}
		String commaSeparatedString = String.join(",", orderIds);

		List<Long> orderids = new ArrayList<Long>();
		for (BillOrderDTO billOrder : billOrderList) {
			Long orderid = Long.valueOf(billOrder.getOrderId());
			orderids.add(orderid);
			System.out.println("Printing Order Ids" + orderid);

		}

		HashSet<String> institution = new HashSet<String>();
		HashSet<String> departments = new HashSet<String>();

		// Double totalAmount = 0.0;
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService
				.findOrderItemDetailsForDuplicateBill(orderids);
		for (OrderItemDetailDTO orderdetail : orderdetails) {
			departments.add(orderdetail.getDepartmentName());
			institution.add(orderdetail.getInstitutionName());
			// totalAmount = totalAmount + Double.parseDouble(orderdetail.getAmount());
		}

		Iterator it = institution.iterator();
		String institutionName = null;
		while (it.hasNext()) {
			institutionName = (String) it.next();
		}

		System.out.println("Printing Bill Id" + billId);

		Bill billFromDB = billRepository.findByBillId(billId);
		Double billTotal = billFromDB.getTotalAmount();
		long billtotallong = (long) billFromDB.getTotalAmount();
		String amountinwords = "(in words) Rupees " + ConvertNumberToWords.numberToWords(billtotallong) + " Only";
		int billDateYear = YearMonth.now().getYear();
		String billDateYearStr = Integer.toString(billDateYear);
		String lastTwoDigitsOfbillDateYear = billDateYearStr.substring(2, 4);

		Date today = billFromDB.getTransactionDate();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate = formatter.format(today);
		int totalNoofRows = 12;
		int orderdetailsize = orderdetails.size();
	//	int noOfEmptySpacesToBeAdded = totalNoofRows - orderdetailsize;

		int totalItems =orderdetails.size();
		int totalPages = (int) Math.ceil((double) totalItems / ITEMS_PER_PAGE);
		
		 List<List<OrderItemDetailDTO>> orderItemPages = new ArrayList<>();
	        for (int i = 0; i < totalPages; i++) {
	            int start = i * ITEMS_PER_PAGE;
	            int end = Math.min(start + ITEMS_PER_PAGE, totalItems);
	            orderItemPages.add(orderdetails.subList(start, end));
	        }
	        
	        int sizeOFLastPage = 0;
	        List<OrderItemDetailDTO> orderItemPage = orderItemPages.get(orderItemPages.size()-1);
    		sizeOFLastPage = orderItemPage.size();
	        int noOfEmptySpacesToBeAdded = ITEMS_PER_PAGE - sizeOFLastPage;
	        
	        DecimalFormat df = new DecimalFormat("0.00");
	        model.addAttribute("lastTwoDigitsOfbillDateYear",lastTwoDigitsOfbillDateYear);
	        model.addAttribute("orderItemPages", orderItemPages);
		    
			model.addAttribute("billId", billId);
			model.addAttribute("institution", institutionName);
			model.addAttribute("departments", departments);
			model.addAttribute("orderdetails", orderdetails);
			model.addAttribute("orderIds", commaSeparatedString);
			model.addAttribute("billTotal",df.format(Math.round(billTotal))); 
			model.addAttribute("amountinwords", amountinwords);
			model.addAttribute("noOfEmptySpacesToBeAdded", noOfEmptySpacesToBeAdded);
			model.addAttribute("date", strDate);
			model.addAttribute("pageSize", totalPages);
			model.addAttribute("itemperpage", ITEMS_PER_PAGE);
		return "printbillduplicate";

	}


	@RequestMapping(value = { "/showordersearchforquotationgeneration" }, method = RequestMethod.GET)
	public String showOrderSearchForQuotationGeneration(Model model) {
		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		return "ordersearchforquotationgeneration";
	}

	@PostMapping("/showordersearchresultforquotationgeneration")

	public String showOrderSearchResultForQuotationGeneration(
			@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO, BindingResult bindingResult,
			Model model) throws Exception {
		String orderIdString = orderSearchBillingDTO.getOrderId();
		if (!orderIdString.isEmpty()) {
			long orderId = Long.parseLong(orderSearchBillingDTO.getOrderId());
		}

		int institutitonId = Integer.parseInt(orderSearchBillingDTO.getInstitutionId());
		int departmentId = Integer.parseInt(orderSearchBillingDTO.getDepartmentId());
		List<OrderSearchDTO> orderSearchBillingDTOList = populateOrderScreenService
				.findOrderByOrderIdorInstitutionIdorDepartmentId(orderSearchBillingDTO);
		System.out.println("Showing Order List Size" + orderSearchBillingDTOList.size());
		model.addAttribute("orderSearchBillingDTOList", orderSearchBillingDTOList);

		OrderIdsForBilling orderIdsForBilling = new OrderIdsForBilling();
		model.addAttribute("orderIdsForBilling", orderIdsForBilling);

		return "ordersearchresultforquotationgeneration";
	}

	// @RequestMapping(value = { "/createquotation" }, method = RequestMethod.GET)
	@PostMapping("/createquotation")

	public String showquotation(@ModelAttribute("orderIdsForBilling") OrderIdsForBilling orderIdsForBilling,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		String[] orderIds = orderIdsForBilling.getOrderIds();
		List<Long> orderids = new ArrayList<Long>();
		for (String orderno : orderIds) {
			Long orderid = Long.valueOf(orderno);
			orderids.add(orderid);

			System.out.println("Printing Order Ids" + orderno);

		}

		request.getSession().setAttribute("quotationorderids", orderids);

		Quotation quotation = new Quotation();
		quotation.setTransactionDate(new Date());
		quotationRepository.save(quotation);
		long quoationId = quotation.getId();
		request.getSession().setAttribute("quotationid", quoationId);

		QuotationDTO quotationDTO = new QuotationDTO();
		quotationDTO.setQuotationId(quoationId);
		quotationDTO.setTransactionDate(new Date());

		HashSet<String> institution = new HashSet<String>();
		HashSet<String> departments = new HashSet<String>();
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderids);
		for (OrderItemDetailDTO orderdetail : orderdetails) {
			departments.add(orderdetail.getDepartmentName());
			institution.add(orderdetail.getInstitutionName());
		}

		request.getSession().setAttribute("institution", institution);
		request.getSession().setAttribute("departments", departments);
		Double totalAmount = 0.0;
		for (OrderItemDetailDTO orderdetail : orderdetails) {
			QuotationOrderItem quotationOrderItem = new QuotationOrderItem();
			quotationOrderItem.setItemId(Integer.parseInt(orderdetail.getItemId()));
			quotationOrderItem.setPrice(Double.parseDouble(orderdetail.getPrice()));
			quotationOrderItem.setQuantity(Integer.valueOf(orderdetail.getQuantity()));
			if (orderdetail.getPrice() != null && orderdetail.getQuantity() != null) {
				Double amount = Double.parseDouble(orderdetail.getPrice())
						* Integer.parseInt(orderdetail.getQuantity());
				totalAmount = totalAmount + amount;
				quotationOrderItem.setAmount(amount);
			}
			quotationOrderItem.setOrderId(Double.valueOf(orderdetail.getOrderId()));
			quotationOrderItem.setQuotation(quotation);
			quotationOrderItemRepository.save(quotationOrderItem);

			QuotationOrderItemDTO quotationOrderItemDTO = new QuotationOrderItemDTO();
			quotationOrderItemDTO.setItemId(Integer.parseInt(orderdetail.getItemId()));
			quotationOrderItemDTO.setPrice(Double.parseDouble(orderdetail.getPrice()));
			quotationOrderItemDTO.setAmount(Double.parseDouble(orderdetail.getAmount()));
			quotationOrderItemDTO.setQuantity(Integer.valueOf(orderdetail.getQuantity()));
			quotationOrderItemDTO.setOrderId(Double.valueOf(orderdetail.getOrderId()));
			quotationOrderItemDTO.setQuotationDTO(quotationDTO);
			quotationDTO.add(quotationOrderItemDTO);
		}
		// long orderid = orderids.get(0);

		Quotation quotationEntity = quotationRepository.findById(quoationId);
		System.out.println("Printing quotation Id" + quotationEntity.getId());
		List<QuotationOrderItem> QuotationOrderItems = quotationEntity.getQuotationOrderItems();
		System.out.println("Printing QuotationOrderItems Size" + QuotationOrderItems.size());
		for (QuotationOrderItem QuotationOrderItem : QuotationOrderItems) {
			System.out.println("Printing Item List items " + QuotationOrderItem.getId() + QuotationOrderItem.getItemId()
					+ QuotationOrderItem.getPrice() + QuotationOrderItem.getQuantity());
		}

		System.out.println("printing QuotationList Size" + QuotationOrderItems.size());
		ModelMapper modelMapper = new ModelMapper();
		// QuotationDTO quotationDTO = modelMapper.map(quotationEntity,
		// QuotationDTO.class);
		System.out.println("printing Quaotation ID" + quotationDTO.getQuotationId());
		List<QuotationOrderItemDTO> quotationOrderItemDTOs = quotationDTO.getQuotationOrderItemsDTO();
		System.out.println("printing List size" + quotationOrderItemDTOs.size());
		// QuotationOrderItemDTO quotationOrderItemDTO = quotationOrderItemDTOs.get(0);
		// System.out.println("Printing Items" +
		// quotationOrderItemDTO.getId()+quotationOrderItemDTO.getItemId()+quotationOrderItemDTO.getSizeId()+quotationOrderItemDTO.getPrice());
		System.out.println("Printing Order Id From showeditorderitems" + quotationDTO.getQuotationId());
		// String orderIdStr = Long.toString(orderid);

		updatePopulateDropDowns(model);

		Iterator it = institution.iterator();
		String institutionName = null;
		while (it.hasNext()) {
			institutionName = (String) it.next();
		}

		model.addAttribute("quotationDTO", quotationDTO);
		model.addAttribute("quotationId", quoationId);
		model.addAttribute("institution", institutionName);
		model.addAttribute("departments", departments);

		return "createquotation";

	}

	// @PostMapping("/saveeditorderitems")
	@RequestMapping(value = { "/savequoatation" }, method = RequestMethod.GET)

	public String saveQuoatation(@Valid @ModelAttribute("quotationDTO") QuotationDTO quotationDTO,
			BindingResult bindingResult, Model model, RedirectAttributes redirectAttributes, HttpServletRequest request,
			HttpSession session) {

		if (bindingResult.hasErrors()) {
			System.out.println("Inside error block");
			System.out.println("Error count" + bindingResult.getErrorCount());
			Map<String, Object> errorMessages = new HashMap();
			if (bindingResult.hasErrors()) {

				List<FieldError> fes = bindingResult.getFieldErrors();
				for (FieldError fe : fes) {
					errorMessages.put(fe.getField(), fe.getDefaultMessage());
				}

			}

			model.addAttribute("errorMessages", errorMessages);
			updatePopulateDropDowns(model);
			return "editorder";
		}

		Long quotationid = (Long) request.getSession().getAttribute("quotationid");
		System.out.println("Priting Quotation Id" + quotationid);
		List<Long> quotationorderids = (List<Long>) request.getSession().getAttribute("quotationorderids");
		HashSet<String> institution = (HashSet<String>) request.getSession().getAttribute("institution");
		HashSet<String> departments = (HashSet<String>) request.getSession().getAttribute("departments");

		Quotation quotationFromDB = quotationRepository.findById(quotationid);
		List<QuotationOrderItem> quotationOrderItems = quotationFromDB.getQuotationOrderItems();
		List<QuotationOrderItemDTO> quotationOrderItemsDTO = quotationDTO.getQuotationOrderItemsDTO();
		System.out.println("No of items in Quoatation List" + quotationOrderItems.size());

		int listSize = quotationOrderItems.size();
		Double totalAmount = 0.0;
		for (int i = 0; i < listSize; ++i) {
			QuotationOrderItem quotationOrderItem = quotationOrderItems.get(i);
			QuotationOrderItemDTO quotationOrderItemDTO = quotationOrderItemsDTO.get(i);
			quotationOrderItem.setQuantity(quotationOrderItemDTO.getQuantity());
			quotationOrderItem.setPrice(quotationOrderItemDTO.getPrice());
			Double amount = quotationOrderItemDTO.getPrice() * quotationOrderItemDTO.getQuantity();
			totalAmount = totalAmount + amount;
			quotationOrderItem.setAmount(amount);
			quotationOrderItemRepository.save(quotationOrderItem);

		}

		/*
		 * List<QuotationOrderItemDTO> QuotationOrderItemDTOList =
		 * quotationDTO.getQuotationOrderItemsDTO(); for (QuotationOrderItemDTO
		 * quotationOrderItemDTO : QuotationOrderItemDTOList) {
		 * System.out.println("Printing quotation id and other details" +
		 * quotationOrderItemDTO.getId()+quotationOrderItemDTO.getQuantity()+
		 * quotationOrderItemDTO.getPrice()); Double amount =
		 * quotationOrderItemDTO.getQuantity() * quotationOrderItemDTO.getPrice();
		 * populateOrderScreenService.updateQuoatationItems(quotationid,
		 * quotationOrderItemDTO.getQuantity(),quotationOrderItemDTO.getPrice(),amount);
		 * 
		 * }
		 */

		List<OrderItemDetailDTO> quotationItemDetails = populateOrderScreenService
				.findQuotationOrderItemDetails(quotationorderids, quotationid);
		double total = 0;

		for (OrderItemDetailDTO quotationdetail : quotationItemDetails) {
			total = total + Double.parseDouble(quotationdetail.getAmount());
		}

		quotationFromDB.setTotal(totalAmount);
		quotationRepository.save(quotationFromDB);

		Iterator it = institution.iterator();
		String institutionName = null;
		while (it.hasNext()) {
			institutionName = (String) it.next();
		}

		/*
		 * double total = 0;
		 * 
		 * 
		 * List<QuotationSubTotalDTO> quotationSubTotalDTOList =
		 * populateOrderScreenService.findSubTotalForQuotation(quotationid); for
		 * (QuotationSubTotalDTO quotationSubTotalDTO : quotationSubTotalDTOList) {
		 * total = total + quotationSubTotalDTO.getQuotationPrice(); }
		 */

		model.addAttribute("quotationId", quotationid);
		model.addAttribute("institution", institutionName);
		model.addAttribute("departments", departments);
		model.addAttribute("quotationdetails", quotationItemDetails);
		model.addAttribute("total", totalAmount);

		return "savequotation";
	}

	@RequestMapping(value = { "/showrevenuereportsearch" }, method = RequestMethod.GET)
	public String showRevenueReportSearch(Model model) {
		System.out.println("Printing from welcome");
		// OrderIdsDTO orderIdsDTO = new OrderIdsDTO();
		// model.addAttribute("orderIdsDTO", orderIdsDTO);
		BillSearchDTO billSearchDTO = new BillSearchDTO();
		model.addAttribute("billSearchDTO", billSearchDTO);
		return "revenuereportsearch";
	}

	@GetMapping(value = { "/showrevenuereportsearchresult" })
	// public String showRevenueReportSearchResult() throws Exception {
	public String showRevenueReportSearchResult(@Valid @ModelAttribute("billSearchDTO") BillSearchDTO billSearchDTO,
			BindingResult bindingResult, Model model, RedirectAttributes redirectAttributes, HttpServletRequest request)
			throws Exception {

		if (bindingResult.hasErrors()) {
			// return "redirect:/test25";
			return "revenuereportsearch";
		}

		// int orderId = orderIdsDTO.getOrderId();
		Date startDate = billSearchDTO.getStartDate();
		Date endDate = billSearchDTO.getEndDate();
		System.out.println("Printing Start Date" + startDate);
		System.out.println("Printing Start Date" + endDate);

		// if (!orderIdString.isEmpty()) {
		// long orderId = Long.parseLong(orderSearchBillingDTO.getOrderId());
		// }

		// int institutitonId =
		// Integer.parseInt(orderSearchBillingDTO.getInstitutionId());
		// int departmentId = Integer.parseInt(orderSearchBillingDTO.getDepartmentId());
		List<BillDTO> revenueReportList = populateOrderScreenService.findRevenueDetails(startDate, endDate);

		Double total = 0.0;
		for (BillDTO billDTO : revenueReportList) {
			total = total + billDTO.getTotalAmount();
			System.out.println("total amount" + total);
		}
		System.out.println("Showing Order List Size" + revenueReportList.size());
		model.addAttribute("revenueReportList", revenueReportList);
		model.addAttribute("total", total);
		System.out.println("total amount" + total);
		request.getSession().setAttribute("revenueReportListSession", revenueReportList);
		// model.addAttribute("revenueReportListSession", revenueReportList);

		System.out.println("This is from showrevenuereportsearchresult method");
		return "showrevenuereport";
	}

	@RequestMapping(value = { "/showbillreportsearch" }, method = RequestMethod.GET)
	public String showBillReportSearch(Model model) {
		System.out.println("Printing from welcome");
		// OrderIdsDTO orderIdsDTO = new OrderIdsDTO();
		// model.addAttribute("orderIdsDTO", orderIdsDTO);
		BillSearchDTO billSearchDTO = new BillSearchDTO();
		model.addAttribute("billSearchDTO", billSearchDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		return "billreportsearch";
	}

	@GetMapping(value = { "/showbillreportsearchresult" })
	// public String showRevenueReportSearchResult() throws Exception {
	public String showBillReportSearchResult(@Valid @ModelAttribute("billSearchDTO") BillSearchDTO billSearchDTO,
			BindingResult bindingResult, Model model, RedirectAttributes redirectAttributes, HttpServletRequest request)
			throws Exception {

		if (bindingResult.hasErrors()) {
			// return "redirect:/test25";
			return "billreportsearch";
		}

		// int orderId = orderIdsDTO.getOrderId();
		Date startDate = billSearchDTO.getStartDate();
		Date endDate = billSearchDTO.getEndDate();
		long institutionId = Long.parseLong(billSearchDTO.getInstitutionId());
		System.out.println("Printing Start Date" + startDate);
		System.out.println("Printing Start Date" + endDate);

		// if (!orderIdString.isEmpty()) {
		// long orderId = Long.parseLong(orderSearchBillingDTO.getOrderId());
		// }

		// int institutitonId =
		// Integer.parseInt(orderSearchBillingDTO.getInstitutionId());
		// int departmentId = Integer.parseInt(orderSearchBillingDTO.getDepartmentId());
		List<BillDTO> billReportList = populateOrderScreenService.findBillByInstitution(startDate, endDate,
				institutionId);
		System.out.println("Showing Bill List Size" + billReportList.size());

		request.getSession().setAttribute("billReportListSession", billReportList);
		model.addAttribute("billReportList", billReportList);
		System.out.println("This is from showbillreportsearchresult method");
		return "showbillreport";
	}

	@RequestMapping(value = { "/showbillsearchforbillprinting" }, method = RequestMethod.GET)
	public String showBillSearchForBillPrinting(Model model) {
		System.out.println("Printing from welcome");
		// OrderIdsDTO orderIdsDTO = new OrderIdsDTO();
		// model.addAttribute("orderIdsDTO", orderIdsDTO);
		BillSearchDTO billSearchDTO = new BillSearchDTO();
		model.addAttribute("billSearchDTO", billSearchDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		return "billsearchforbillprinting";
	}

	@GetMapping(value = { "/showbillsearchresultforbillprinting" })
	// public String showRevenueReportSearchResult() throws Exception {
	public String showBillSearchrResultfForBillPrinting(
			@Valid @ModelAttribute("billSearchDTO") BillSearchDTO billSearchDTO, BindingResult bindingResult,
			Model model, RedirectAttributes redirectAttributes, HttpServletRequest request) throws Exception {

		if (bindingResult.hasErrors()) {
			// return "redirect:/test25";
			return "billsearchforbillprinting";
		}

		System.out.println("Printing Bill ID" + billSearchDTO.getBillId());

		if (!billSearchDTO.getBillId().isEmpty()) {
			long billId = Long.parseLong(billSearchDTO.getBillId());
			BillSearchDTO BillSearchDTOForPrinting = new BillSearchDTO();
			BillSearchDTOForPrinting.setBillId(billSearchDTO.getBillId());
			// model.addAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
			redirectAttributes.addFlashAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
			return "redirect:/printbill";
		} else {
			List<BillDTO> billOrderList = populateOrderScreenService.findBillByInstitutionOrBillId(billSearchDTO);
			System.out.println("Showing Bill List Size" + billOrderList.size());

			request.getSession().setAttribute("billReportListSession", billOrderList);
			BillSearchDTO BillSearchDTOForPrinting = new BillSearchDTO();
			model.addAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
			model.addAttribute("billReportList", billOrderList);
			System.out.println("This is from showbillreportsearchresult method");
			return "showbillsearchresultforbillprinting";
		}
	}

	@RequestMapping("/printbill")
	// @RequestMapping(value = { "/generatebill" }, params = { "savebill" })
	public String printBill(Model model,
			@ModelAttribute("BillSearchDTOForPrinting") BillSearchDTO BillSearchDTOForPrinting) {
		System.out.println("Printing from printbill");
		long billId = Long.parseLong(BillSearchDTOForPrinting.getBillId());
		System.out.println("Printing Bill Id" + billId);

		List<BillOrderDTO> billOrderList = populateOrderScreenService.findBillOrderDetailByBillId(billId);

		// Bill bill = new Bill();
		int size = billOrderList.size();
		String[] orderIds = new String[size];
		for (int i = 0; i < size; i++) {
			BillOrderDTO BillOrderDTO = billOrderList.get(i);
			orderIds[i] = BillOrderDTO.getOrderId();
		}
		String commaSeparatedString = String.join(",", orderIds);

		List<Long> orderids = new ArrayList<Long>();
		for (BillOrderDTO billOrder : billOrderList) {
			Long orderid = Long.valueOf(billOrder.getOrderId());
			orderids.add(orderid);
			System.out.println("Printing Order Ids" + orderid);

		}

		HashSet<String> institution = new HashSet<String>();
		HashSet<String> departments = new HashSet<String>();

		// Double totalAmount = 0.0;
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderids);
		for (OrderItemDetailDTO orderdetail : orderdetails) {
			departments.add(orderdetail.getDepartmentName());
			institution.add(orderdetail.getInstitutionName());
			// totalAmount = totalAmount + Double.parseDouble(orderdetail.getAmount());
		}
		
		for (Long orderno : orderids) {
			System.out.println("Inside Profit Margin");
			System.out.println("Printing Order Id" + orderno);
			Double orderTotal = 0.0;
			Order orderfromDB = orderrepository.findById(Long.valueOf(orderno));
			System.out.println("Printing Order Id" + orderfromDB.getId());
			List<OrderItem> orderItems = orderfromDB.getOrderitems();
			
			for (OrderItem orderItem : orderItems) {
				System.out.println("Printing Order Item Id" + orderItem.getId());
				DecimalFormat df = new DecimalFormat("0.00");
				Double profitMargin = orderfromDB.getProfitMargin();
				System.out.println("Printing Profit Margin" + profitMargin);
				Double totalItemProfit = 0.0;
				Double itemProfit = 0.0;
				if (orderItem.getAmount() != null && profitMargin != null) {
					totalItemProfit = profitMargin/100*orderItem.getAmount();
					System.out.println("Printing Total Item Profit " + totalItemProfit);
				}
				if (orderItem.getQuantity()!=null) {
					itemProfit = totalItemProfit/orderItem.getQuantity();
					System.out.println("Printing Item Profit " + itemProfit);
				}
				if (orderItem.getPrice()!=null ) {
					System.out.println("Printing Price Before Applying Profit Margin "+ orderItem.getPrice());
					orderItem.setPrice(Double.parseDouble(df.format(orderItem.getPrice()+itemProfit)));
					System.out.println("Printing Price After Applying Profit Margin "+ orderItem.getPrice());
				}
				/*orderItemEntity.setOneTimeChargesTotal(oneTimeChargesTotal);
				orderItemEntity.setMultipleTimeChargesTotal(multipleTimeChargesTotal); */
				if (orderItem.getAmount()!=null) {
					System.out.println("Printing Price Before Applying Profit Margin "+ orderItem.getPrice());
					orderItem.setAmount(Double.parseDouble(df.format(orderItem.getAmount()+totalItemProfit)));
					System.out.println("Printing Price Before Applying Profit Margin "+ orderItem.getPrice());
					orderTotal = orderTotal+orderItem.getAmount();
				}
				orderitemrepository.save(orderItem);
				
			}
			
			System.out.println("Printing Order Total  "+ orderTotal);
			orderfromDB.setTotal(orderTotal);
			orderrepository.save(orderfromDB);
			
		}

		Iterator it = institution.iterator();
		String institutionName = null;
		while (it.hasNext()) {
			institutionName = (String) it.next();
		}

		Bill billFromDB = billRepository.findByBillId(billId);
		System.out.println("Printing Bill ID" + billFromDB.getBillId());
		List<BillOrder> billOrderListFromDB = billFromDB.getBillOrders();
		int listSize = billOrderListFromDB.size();
		System.out.println("Printing Bill Order List Size" + listSize);
		for (int i = 0; i < listSize; ++i) {
			System.out.println("printing i " + i);
			BillOrder billOrder = billOrderListFromDB.get(i);
			long orderId = billOrder.getOrderId();
			System.out.println("Printing Order Id" + orderId);
			Order orderFromDB = orderrepository.findById(orderId);
			billOrder.setOrderTotalAmount(orderFromDB.getTotal());
		}

		Double billTotal = 0.0;
		for (Long orderno : orderids) {

			Order orderfromDB = orderrepository.findById(Long.valueOf(orderno));
			BillOrder billOrder = new BillOrder();
			billOrder.setOrderId(orderno);
			billOrder.setOrderTotalAmount(orderfromDB.getTotal());
			billTotal = billTotal + orderfromDB.getTotal();
			billOrderRepository.save(billOrder);
		}
		billFromDB.setTransactionDate(new Date());
		billFromDB.setTotalAmount(billTotal);
		billRepository.save(billFromDB);
		double total = 0;
		// List<OrderItemDetailDTO> OrderItemDetailDTOList =
		// populateOrderScreenService.findOrderItemDetails(orderids);
		/*
		 * for (OrderItemDetailDTO OrderItemDetailDTO : orderdetails) {
		 * System.out.println("Printing order id and total amount" +
		 * OrderItemDetailDTO.getOrderId() + OrderItemDetailDTO.getAmount());
		 * 
		 * total = total + Double.parseDouble(OrderItemDetailDTO.getAmount()); }
		 */

		System.out.println("Printing Total " + total);

		System.out.println("Printing Bill Id" + billId);
		for (Long orderno : orderids) {

			System.out.println("Printing Order Id from Bill Table" + orderno);
			Order orderFromDB = orderrepository.findById(Long.valueOf(orderno));
			System.out.println("Printing order id from order table" + orderFromDB.getId());
			orderFromDB.setEndDate(new Date());
			orderFromDB.setStatus("complete");
			orderrepository.save(orderFromDB);
			System.out.println("Printing Order Id" + orderno);

		}
		Bill DBBillFromDB = billRepository.findByBillId(billId);
		// long billtotallong = billTotal.longValue();
		long billtotallong = (long) DBBillFromDB.getTotalAmount();
		String amountinwords = "(in words) Rupees " + ConvertNumberToWords.numberToWords(billtotallong) + " Only";
		Date today = DBBillFromDB.getTransactionDate();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate = formatter.format(today);
		int totalNoofRows = 12;
		int orderdetailsize = orderdetails.size();
		int noOfEmptySpacesToBeAdded = totalNoofRows - orderdetailsize;

		model.addAttribute("billId", billId);
		model.addAttribute("institution", institutionName);
		model.addAttribute("departments", departments);
		model.addAttribute("orderIds", commaSeparatedString);
		model.addAttribute("orderdetails", orderdetails);
		model.addAttribute("billTotal", billTotal);
		model.addAttribute("amountinwords", amountinwords);
		model.addAttribute("date", strDate);
		model.addAttribute("noOfEmptySpacesToBeAdded", noOfEmptySpacesToBeAdded);
		return "printbill";
		// return "printbillportrait";
		// return "printbill";
		// return "printbilltableborderless";

	}


	@RequestMapping(value = { "/showbillsearchforfuturebillprinting" }, method = RequestMethod.GET)
	public String showBillSearchForFeatureBillPrinting(Model model) {
		System.out.println("Printing from welcome");
		// OrderIdsDTO orderIdsDTO = new OrderIdsDTO();
		// model.addAttribute("orderIdsDTO", orderIdsDTO);
		BillSearchDTO billSearchDTO = new BillSearchDTO();
		model.addAttribute("billSearchDTO", billSearchDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		return "billsearchforfuturebillprinting";
	}

	@GetMapping(value = { "/showbillsearchresultforfuturebillprinting" })
	// public String showRevenueReportSearchResult() throws Exception {
	public String showBillSearchrResultfForFeatureBillPrinting(
			@Valid @ModelAttribute("billSearchDTO") BillSearchDTO billSearchDTO, BindingResult bindingResult,
			Model model, RedirectAttributes redirectAttributes, HttpServletRequest request) throws Exception {

		if (bindingResult.hasErrors()) {
			// return "redirect:/test25";
			return "billsearchforfuturebillprinting";
		}

		System.out.println("Printing Bill ID" + billSearchDTO.getBillId());

		if (!billSearchDTO.getBillId().isEmpty()) {
			long billId = Long.parseLong(billSearchDTO.getBillId());
			BillSearchDTO BillSearchDTOForPrinting = new BillSearchDTO();
			BillSearchDTOForPrinting.setBillId(billSearchDTO.getBillId());
			BillSearchDTOForPrinting.setStartDate(billSearchDTO.getStartDate());
			// model.addAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
			redirectAttributes.addFlashAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
			return "redirect:/printfuturebill";
		} else {
			List<BillDTO> billOrderList = populateOrderScreenService.findBillByInstitutionOrBillId(billSearchDTO);
			System.out.println("Showing Bill List Size" + billOrderList.size());

			request.getSession().setAttribute("billReportListSession", billOrderList);
			BillSearchDTO BillSearchDTOForPrinting = new BillSearchDTO();
			model.addAttribute("BillSearchDTOForPrinting", BillSearchDTOForPrinting);
			model.addAttribute("billReportList", billOrderList);
			System.out.println("This is from showbillreportsearchresult method");
			return "showbillsearchresultforfuturebillprinting";
		}
	}

	@RequestMapping("/printfuturebill")
	// @RequestMapping(value = { "/generatebill" }, params = { "savebill" })
	public String printFeatureBill(Model model,
			@ModelAttribute("BillSearchDTOForPrinting") BillSearchDTO BillSearchDTOForPrinting) {
		System.out.println("Printing from printbill");
		long billId = Long.parseLong(BillSearchDTOForPrinting.getBillId());
		System.out.println("Printing Bill Id" + billId);

		List<BillOrderDTO> billOrderList = populateOrderScreenService.findBillOrderDetailByBillId(billId);

		// Bill bill = new Bill();
		int size = billOrderList.size();
		String[] orderIds = new String[size];
		for (int i = 0; i < size; i++) {
			BillOrderDTO BillOrderDTO = billOrderList.get(i);
			orderIds[i] = BillOrderDTO.getOrderId();
		}
		String commaSeparatedString = String.join(",", orderIds);

		List<Long> orderids = new ArrayList<Long>();
		for (BillOrderDTO billOrder : billOrderList) {
			Long orderid = Long.valueOf(billOrder.getOrderId());
			orderids.add(orderid);
			System.out.println("Printing Order Ids" + orderid);

		}

		HashSet<String> institution = new HashSet<String>();
		HashSet<String> departments = new HashSet<String>();

		// Double totalAmount = 0.0;
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderids);
		for (OrderItemDetailDTO orderdetail : orderdetails) {
			departments.add(orderdetail.getDepartmentName());
			institution.add(orderdetail.getInstitutionName());
			// totalAmount = totalAmount + Double.parseDouble(orderdetail.getAmount());
		}

		Iterator it = institution.iterator();
		String institutionName = null;
		while (it.hasNext()) {
			institutionName = (String) it.next();
		}

		Bill billFromDB = billRepository.findByBillId(billId);
		System.out.println("Printing Bill ID" + billFromDB.getBillId());
		List<BillOrder> billOrderListFromDB = billFromDB.getBillOrders();
		int listSize = billOrderListFromDB.size();
		System.out.println("Printing Bill Order List Size" + listSize);
		for (int i = 0; i < listSize; ++i) {
			System.out.println("printing i " + i);
			BillOrder billOrder = billOrderListFromDB.get(i);
			long orderId = billOrder.getOrderId();
			System.out.println("Printing Order Id" + orderId);
			Order orderFromDB = orderrepository.findById(orderId);
			billOrder.setOrderTotalAmount(orderFromDB.getTotal());
		}

		Double billTotal = 0.0;
		for (Long orderno : orderids) {

			Order orderfromDB = orderrepository.findById(Long.valueOf(orderno));
			BillOrder billOrder = new BillOrder();
			billOrder.setOrderId(orderno);
			billOrder.setOrderTotalAmount(orderfromDB.getTotal());
			billTotal = billTotal + orderfromDB.getTotal();
			billOrderRepository.save(billOrder);
		}
		billFromDB.setTransactionDate(new Date());
		billFromDB.setTotalAmount(billTotal);
		billRepository.save(billFromDB);
		double total = 0;
		// List<OrderItemDetailDTO> OrderItemDetailDTOList =
		// populateOrderScreenService.findOrderItemDetails(orderids);
		/*
		 * for (OrderItemDetailDTO OrderItemDetailDTO : orderdetails) {
		 * System.out.println("Printing order id and total amount" +
		 * OrderItemDetailDTO.getOrderId() + OrderItemDetailDTO.getAmount());
		 * 
		 * total = total + Double.parseDouble(OrderItemDetailDTO.getAmount()); }
		 */

		System.out.println("Printing Total " + total);

		System.out.println("Printing Bill Id" + billId);
		for (Long orderno : orderids) {

			System.out.println("Printing Order Id from Bill Table" + orderno);
			Order orderFromDB = orderrepository.findById(Long.valueOf(orderno));
			System.out.println("Printing order id from order table" + orderFromDB.getId());
			orderFromDB.setEndDate(new Date());
			orderFromDB.setStatus("complete");
			orderrepository.save(orderFromDB);
			System.out.println("Printing Order Id" + orderno);

		}
		Bill DBBillFromDB = billRepository.findByBillId(billId);
		// long billtotallong = billTotal.longValue();
		long billtotallong = (long) DBBillFromDB.getTotalAmount();
		String amountinwords = "(in words) Rupees " + ConvertNumberToWords.numberToWords(billtotallong) + " Only";
		Date today = DBBillFromDB.getTransactionDate();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate = formatter.format(today);
		int totalNoofRows = 12;
		int orderdetailsize = orderdetails.size();
		int noOfEmptySpacesToBeAdded = totalNoofRows - orderdetailsize;

		model.addAttribute("billId", billId);
		model.addAttribute("institution", institutionName);
		model.addAttribute("departments", departments);
		model.addAttribute("orderIds", commaSeparatedString);
		model.addAttribute("orderdetails", orderdetails);
		model.addAttribute("billTotal", billTotal);
		model.addAttribute("amountinwords", amountinwords);
		model.addAttribute("date", strDate);
		model.addAttribute("noOfEmptySpacesToBeAdded", noOfEmptySpacesToBeAdded);
		// return "printbill";
		// return "printbillportrait";
		return "printfuturebill";

	}

	private void populateDropDowns(Model model) {
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		List<ItemDTO> itemlist = populateOrderScreenService.findAllItems();
		model.addAttribute("items", itemlist);
		List<SizeDTO> sizelist = populateOrderScreenService.findAllSizes();
		model.addAttribute("sizes", sizelist);
		List<UnitDTO> unitlist = populateOrderScreenService.findAllUnits();
		model.addAttribute("units", unitlist);
		List<ItemStatusDTO> itemstatuslist = populateOrderScreenService.findAllItemStatus();
		model.addAttribute("itemstatus", itemstatuslist);

	}

	private void updatePopulateDropDowns(Model model) {
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		List<ItemDTO> itemlist = populateOrderScreenService.findAllItems();
		model.addAttribute("items", itemlist);
		List<SizeDTO> sizelist = populateOrderScreenService.findAllSizes();
		model.addAttribute("sizes", sizelist);
		List<UnitDTO> unitlist = populateOrderScreenService.findAllUnits();
		model.addAttribute("units", unitlist);
		List<ItemStatusDTO> itemstatuslist = populateOrderScreenService.findAllItemStatus();
		model.addAttribute("itemstatus", itemstatuslist);

	}

	@RequestMapping(value = { "/showcreateinstitution" }, method = RequestMethod.GET)
	public String showCreateInstituion(Model model) {
		InstitutionDTO institutionDTO = new InstitutionDTO();
		model.addAttribute("institutionDTO", institutionDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		return "createinstitution";
	}

	@PostMapping("/createinstitution")
	public String createInstitution(@Valid @ModelAttribute("institutionDTO") InstitutionDTO institutionDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String institutionName = institutionDTO.getInstitutionName();

		if (bindingResult.hasErrors()) {

			return "createinstitution";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			Institution institution = modelMapper.map(institutionDTO, Institution.class);
			 try {

			institutionRepository.save(institution);
			model.addAttribute("institutionName", institutionName);
			return "createinstitutionsuccess";
			 }catch (DataIntegrityViolationException e) {
		            model.addAttribute("error", "Institution Name must be unique.");
		            redirectAttributes.addFlashAttribute("error", "Institution Name must be unique.");
					redirectAttributes.addFlashAttribute("institution", institution);

		            return "redirect:/showcreateinstitution"; // Return to form with error message
		        }


		}
	}

	@RequestMapping(value = { "/showeditinstitution" }, method = RequestMethod.GET)
	public String showEditinstitution(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<InstitutionDTO> institutionlist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionlist);

		return "showeditinstitution";

	}

	@RequestMapping(value = "/editinstitution", params = { "updateinstitution" })

	public String updateinstitution(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String institutionIdString = orderSearchBillingDTO.getInstitutionId();
		Integer institutionId = 0;
		if (!institutionIdString.isEmpty()) {
			institutionId = Integer.parseInt(orderSearchBillingDTO.getInstitutionId());
		}
		Institution institutionfromDB = institutionRepository.findByInstitutionId(institutionId);
		String institutionName = institutionfromDB.getInstitutionName();
		InstitutionDTO institutionDTO = new InstitutionDTO();
		institutionDTO.setInstitutionName(institutionName);
		request.getSession().setAttribute("institutionId", institutionId);
		model.addAttribute("institutionDTO", institutionDTO);

		return "editinstitution";
	}

	@RequestMapping(value = { "/saveinstitution" }, method = RequestMethod.GET)
	public String saveinstitution(@ModelAttribute("institutionDTO") InstitutionDTO institutionDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer institutionId = (Integer) request.getSession().getAttribute("institutionId");
		Institution institutionfromDB = institutionRepository.findByInstitutionId(institutionId);
		institutionfromDB.setInstitutionName(institutionDTO.getInstitutionName());
		 try {
		institutionRepository.save(institutionfromDB);
		model.addAttribute("updatedinstitutionName", institutionDTO.getInstitutionName());
		return "editinstitutionupdatesuccess";
		 }
		catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Institution Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Institution Name must be unique.");
			

            return "redirect:/showeditinstitution"; // Return to form with error message
        }
		
	}

	@RequestMapping(value = "/editinstitution", params = { "deleteinstitution" })

	public String deleteInstitution(@ModelAttribute("institutionDTO") InstitutionDTO institutionDTO,
			BindingResult bindingResult, Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long institutionId = institutionDTO.getInstitutionId();
		Institution institutionfromDB = institutionRepository.findByInstitutionId(institutionId);
		String institutionName = institutionfromDB.getInstitutionName();
		institutionRepository.delete(institutionfromDB);
		model.addAttribute("deletedInstitutioneName", institutionName);

		return "editinstitutiondeletesuccess";
	}

	@RequestMapping(value = { "/showcreatedepartment" }, method = RequestMethod.GET)
	public String showCreateDepartment(Model model) {
		DepartmentDTO departmentDTO = new DepartmentDTO();
		model.addAttribute("departmentDTO", departmentDTO);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		return "createdepartment";
	}

	@PostMapping("/createdepartment")
	public String createDepartment(@Valid @ModelAttribute("departmentDTO") DepartmentDTO departmentDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String departmentName = departmentDTO.getDepartmentName();

		if (bindingResult.hasErrors()) {

			return "createdepartment";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			Department department = modelMapper.map(departmentDTO, Department.class);

			try {
			departmentRepository.save(department);
			model.addAttribute("departmentName", departmentName);
			return "createdepartmentsuccess";
			}catch (DataIntegrityViolationException e) {
	            model.addAttribute("error", "Department Name must be unique.");
	            redirectAttributes.addFlashAttribute("error", "Department Name must be unique.");
				

	            return "redirect:/showcreateitemratephase"; // Return to form with error message
	        }


		}
	}

	@RequestMapping(value = { "/showeditdepartment" }, method = RequestMethod.GET)
	public String showEditDepartment(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);

		return "showeditdepartment";

	}

	@RequestMapping(value = "/editdepartment", params = { "updatedepartment" })

	public String updatedepartment(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String departmentIdString = orderSearchBillingDTO.getDepartmentId();
		Integer departmentId = 0;
		if (!departmentIdString.isEmpty()) {
			departmentId = Integer.parseInt(orderSearchBillingDTO.getDepartmentId());
		}
		Department departmentfromDB = departmentRepository.findByDepartmentId(departmentId);
		String departmentName = departmentfromDB.getDepartmentName();
		DepartmentDTO departmentDTO = new DepartmentDTO();
		departmentDTO.setDepartmentName(departmentName);
		request.getSession().setAttribute("departmentId", departmentId);
		model.addAttribute("departmentDTO", departmentDTO);

		return "editdepartment";
	}

	@RequestMapping(value = { "/savedepartment" }, method = RequestMethod.GET)
	public String saveinstitution(@ModelAttribute("departmentDTO") DepartmentDTO departmentDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer departmentId = (Integer) request.getSession().getAttribute("departmentId");
		Department departmentfromDB = departmentRepository.findByDepartmentId(departmentId);
		departmentfromDB.setDepartmentName(departmentDTO.getDepartmentName());
		 try {

		departmentRepository.save(departmentfromDB);
		model.addAttribute("updateddepartmentName", departmentDTO.getDepartmentName());

		return "editdepartmentupdatesuccess";
		 }catch (DataIntegrityViolationException e) {
	            model.addAttribute("error", "Department Name must be unique.");
	            redirectAttributes.addFlashAttribute("error", "Department Name must be unique.");
				

	            return "redirect:/showeditdepartment"; // Return to form with error message
	        }

	}

	@RequestMapping(value = "/editdepartment", params = { "deletedepartment" })

	public String deleteDepartment(@ModelAttribute("departmentDTO") DepartmentDTO departmentDTO,
			BindingResult bindingResult, Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long departmentId = departmentDTO.getDepartmentId();
		Department departmentfromDB = departmentRepository.findByDepartmentId(departmentId);
		String departmentName = departmentfromDB.getDepartmentName();
		departmentRepository.delete(departmentfromDB);
		model.addAttribute("deletedDepartmentName", departmentName);

		return "editdepartmentdeletesuccess";
	}

	@RequestMapping(value = { "/showcreateitem" }, method = RequestMethod.GET)
	public String showCreateItem(Model model) {
		ItemDTO itemDTO = new ItemDTO();
		model.addAttribute("itemDTO", itemDTO);
		List<ItemDTO> itemlist = populateOrderScreenService.findAllItems();
		model.addAttribute("items", itemlist);
		return "createitem";
	}

	@PostMapping("/createitem")
	public String createInstitution(@Valid @ModelAttribute("itemDTO") ItemDTO itemDTO, BindingResult bindingResult,
			Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String itemName = itemDTO.getItemName();

		if (bindingResult.hasErrors()) {

			return "createitem";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			Item item = modelMapper.map(itemDTO, Item.class);
			 try {


			itemRepository.save(item);
			model.addAttribute("itemName", itemName);
			return "createitemsuccess";

		}catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Item Rate Phase Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Item Rate Phase Name must be unique.");
			

            return "redirect:/showcreateitem"; // Return to form with error message
        }

	}
	}

	@RequestMapping(value = { "/showedititem" }, method = RequestMethod.GET)
	public String showEditItemType(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<ItemDTO> itemlist = populateOrderScreenService.findAllItems();
		model.addAttribute("items", itemlist);

		return "showedititem";

	}

	@RequestMapping(value = "/edititem", params = { "updateitem" })

	public String updateItemType(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String itemIdString = orderSearchBillingDTO.getItemId();
		Integer itemId = 0;
		if (!itemIdString.isEmpty()) {
			itemId = Integer.parseInt(orderSearchBillingDTO.getItemId());
		}
		Item itemfromDB = itemRepository.findByItemId(itemId);
		String itemName = itemfromDB.getItemName();
		ItemDTO editItemTypeDTO = new ItemDTO();
		editItemTypeDTO.setItemName(itemName);
		request.getSession().setAttribute("itemId", itemId);
		model.addAttribute("editItemTypeDTO", editItemTypeDTO);

		return "edititem";
	}

	@RequestMapping(value = { "/saveitem" }, method = RequestMethod.GET)
	public String saveItemtType(@ModelAttribute("editItemTypeDTO") ItemDTO editItemTypeDTO, BindingResult bindingResult,
			Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer itemId = (Integer) request.getSession().getAttribute("itemId");
		Item itemfromDB = itemRepository.findByItemId(itemId);
		itemfromDB.setItemName(editItemTypeDTO.getItemName());
		 try {

		itemRepository.save(itemfromDB);
		model.addAttribute("updatedItemTypeName", editItemTypeDTO.getItemName());

		return "edititemupdatesuccess";
		 }
		catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Item Rate Phase Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Item Rate Phase Name must be unique.");
			

            return "redirect:/showedititem"; // Return to form with error message
        }

	
	}

	@RequestMapping(value = "/edititem", params = { "deleteitem" })

	public String deleteItemType(@ModelAttribute("editItemTypeDTO") ItemDTO editItemTypeDTO,
			BindingResult bindingResult, Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long itemId = editItemTypeDTO.getItemId();
		Item itemfromDB = itemRepository.findByItemId(itemId);
		String itemtypename = itemfromDB.getItemName();
		itemRepository.delete(itemfromDB);
		model.addAttribute("deletedItemTypeName", itemtypename);

		return "edititemdeletesuccess";
	}

	@RequestMapping(value = { "/showcreatesize" }, method = RequestMethod.GET)
	public String showCreateSize(Model model) {
		SizeDTO sizeDTO = new SizeDTO();
		model.addAttribute("sizeDTO", sizeDTO);
		List<SizeDTO> sizelist = populateOrderScreenService.findAllSizes();
		model.addAttribute("sizes", sizelist);
		return "createsize";
	}

	@PostMapping("/createsize")
	public String createInstitution(@Valid @ModelAttribute("sizeDTO") SizeDTO sizeDTO, BindingResult bindingResult,
			Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String sizeName = sizeDTO.getSizeName();

		if (bindingResult.hasErrors()) {

			return "createsize";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			Size size = modelMapper.map(sizeDTO, Size.class);
			 try {

			sizeRepository.save(size);
			model.addAttribute("sizeName", sizeName);
			return "createsizesuccess";

		}catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Size Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Size Name must be unique.");
			

            return "redirect:/showcreatesize"; // Return to form with error message
        }

	}
	}

	@RequestMapping(value = { "/showeditsize" }, method = RequestMethod.GET)
	public String showEditSize(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<SizeDTO> sizelist = populateOrderScreenService.findAllSizes();
		model.addAttribute("sizes", sizelist);

		return "showeditsize";

	}

	@RequestMapping(value = "/editsize", params = { "updatesize" })

	public String updateSize(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String sizeIdString = orderSearchBillingDTO.getSizeId();
		Integer sizeId = 0;
		if (!sizeIdString.isEmpty()) {
			sizeId = Integer.parseInt(orderSearchBillingDTO.getSizeId());
		}
		Size sizefromDB = sizeRepository.findBySizeId(sizeId);
		String sizeName = sizefromDB.getSizeName();
		SizeDTO sizeDTO = new SizeDTO();
		sizeDTO.setSizeName(sizeName);
		request.getSession().setAttribute("sizeId", sizeId);
		model.addAttribute("sizeDTO", sizeDTO);

		return "editsize";
	}

	@RequestMapping(value = { "/savesize" }, method = RequestMethod.GET)
	public String saveinstitution(@ModelAttribute("sizeDTO") SizeDTO sizeDTO, BindingResult bindingResult, Model model,
			HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer sizeId = (Integer) request.getSession().getAttribute("sizeId");
		Size sizefromDB = sizeRepository.findBySizeId(sizeId);
		sizefromDB.setSizeName(sizeDTO.getSizeName());
		 try {
		sizeRepository.save(sizefromDB);
		model.addAttribute("updatedsizeName", sizeDTO.getSizeName());

		return "editsizeupdatesuccess";
	}catch (DataIntegrityViolationException e) {
        model.addAttribute("error", "Size Name must be unique.");
        redirectAttributes.addFlashAttribute("error", "Size Name must be unique.");
		

        return "redirect:/showeditsize"; // Return to form with error message
    }
}


	@RequestMapping(value = "/editsize", params = { "deletesize" })

	public String deleteSize(@ModelAttribute("sizeDTO") SizeDTO sizeDTO, BindingResult bindingResult, Model model)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long sizeId = sizeDTO.getSizeId();
		Size sizefromDB = sizeRepository.findBySizeId(sizeId);
		String sizeName = sizefromDB.getSizeName();
		sizeRepository.delete(sizefromDB);
		model.addAttribute("deletedSizeName", sizeName);

		return "editsizedeletesuccess";
	}

	@RequestMapping(value = { "/showcreateunit" }, method = RequestMethod.GET)
	public String showCreateUnit(Model model) {
		UnitDTO unitDTO = new UnitDTO();
		model.addAttribute("unitDTO", unitDTO);
		List<UnitDTO> unitlist = populateOrderScreenService.findAllUnits();
		model.addAttribute("units", unitlist);
		return "createunit";
	}

	@PostMapping("/createunit")
	public String createUnit(@Valid @ModelAttribute("unitDTO") UnitDTO unitDTO, BindingResult bindingResult,
			Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String unitName = unitDTO.getUnitName();

		if (bindingResult.hasErrors()) {

			return "createunit";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			Unit unit = modelMapper.map(unitDTO, Unit.class);
			 try {
			unitRepository.save(unit);
			model.addAttribute("unitName", unitName);
			return "createunitsuccess";

		}catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Unit Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Unit Name must be unique.");
			

            return "redirect:/showcreateunit"; // Return to form with error message
        }

	}
	}

	@RequestMapping(value = { "/showeditunit" }, method = RequestMethod.GET)
	public String showEditUnit(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<UnitDTO> unitlist = populateOrderScreenService.findAllUnits();
		model.addAttribute("units", unitlist);

		return "showeditunit";

	}

	@RequestMapping(value = "/editunit", params = { "updateunit" })

	public String updateUnit(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String unitIdString = orderSearchBillingDTO.getUnitId();
		Integer unitId = 0;
		if (!unitIdString.isEmpty()) {
			unitId = Integer.parseInt(orderSearchBillingDTO.getUnitId());
		}
		Unit unitfromDB = unitRepository.findByUnitId(unitId);
		String unitName = unitfromDB.getUnitName();
		UnitDTO unitDTO = new UnitDTO();
		unitDTO.setUnitName(unitName);
		request.getSession().setAttribute("unitId", unitId);
		model.addAttribute("unitDTO", unitDTO);

		return "editunit";
	}

	@RequestMapping(value = { "/saveunit" }, method = RequestMethod.GET)
	public String saveUnit(@ModelAttribute("unitDTO") UnitDTO unitDTO, BindingResult bindingResult, Model model,
			HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer unitId = (Integer) request.getSession().getAttribute("unitId");
		Unit unitfromDB = unitRepository.findByUnitId(unitId);
		unitfromDB.setUnitName(unitDTO.getUnitName());
		 try {
		unitRepository.save(unitfromDB);
		model.addAttribute("updatedunitName", unitDTO.getUnitName());

		return "editunitupdatesuccess";
	}catch (DataIntegrityViolationException e) {
        model.addAttribute("error", "Unit Name must be unique.");
        redirectAttributes.addFlashAttribute("error", "Unit Name must be unique.");
		

        return "redirect:/showeditunit"; // Return to form with error message
    }
}



	@RequestMapping(value = "/editunit", params = { "deleteunit" })

	public String deleteUnit(@ModelAttribute("unitDTO") UnitDTO unitDTO, BindingResult bindingResult, Model model)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long unitId = unitDTO.getUnitId();
		Unit unitfromDB = unitRepository.findByUnitId(unitId);
		String unitName = unitfromDB.getUnitName();
		unitRepository.delete(unitfromDB);
		model.addAttribute("deletedUnitName", unitName);

		return "editunitdeletesuccess";
	}

	@RequestMapping(value = { "/showcreateitemstatus" }, method = RequestMethod.GET)
	public String showCreateItemStatus(Model model) {
		ItemStatusDTO itemstatusDTO = new ItemStatusDTO();
		model.addAttribute("itemstatusDTO", itemstatusDTO);
		List<ItemStatusDTO> itemstatusList = populateOrderScreenService.findAllItemStatus();
		model.addAttribute("itemstatuslist", itemstatusList);
		return "createitemstatus";
	}

	@PostMapping("/createitemstatus")
	public String createItemStatus(@Valid @ModelAttribute("itemstatusDTO") ItemStatusDTO itemstatusDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String itemstatusName = itemstatusDTO.getItemStatusName();

		if (bindingResult.hasErrors()) {

			return "createitemstatus";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			ItemStatus itemStatus = modelMapper.map(itemstatusDTO, ItemStatus.class);
			 try {
			itemStatusRepository.save(itemStatus);
			model.addAttribute("itemStatus", itemStatus);
			return "createitemstatussuccess";

		}catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Item Status Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Item Status Name must be unique.");
			

            return "redirect:/showcreateitemstatus"; // Return to form with error message
        }
	}

	}

	@RequestMapping(value = { "/showedititemstatus" }, method = RequestMethod.GET)
	public String showEditItemStatus(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<ItemStatusDTO> itemstatuslist = populateOrderScreenService.findAllItemStatus();
		model.addAttribute("itemstatus", itemstatuslist);

		return "showedititemstatus";

	}

	@RequestMapping(value = "/edititemstatus", params = { "updateitemstatus" })

	public String updateItemStatus(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String itemstatusIdString = orderSearchBillingDTO.getItemStatusId();
		Integer itemstatusId = 0;
		if (!itemstatusIdString.isEmpty()) {
			itemstatusId = Integer.parseInt(orderSearchBillingDTO.getItemStatusId());
		}
		ItemStatus itemstatusfromDB = itemStatusRepository.findByItemStatusId(itemstatusId);
		String itemstatusName = itemstatusfromDB.getItemStatusName();
		ItemStatusDTO itemStatusDTO = new ItemStatusDTO();
		itemStatusDTO.setItemStatusName(itemstatusName);
		request.getSession().setAttribute("itemstatusId", itemstatusId);
		model.addAttribute("itemStatusDTO", itemStatusDTO);

		return "edititemstatus";
	}

	@RequestMapping(value = { "/saveitemstatus" }, method = RequestMethod.GET)
	public String saveItemStatus(@ModelAttribute("itemStatusDTO") ItemStatusDTO itemStatusDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer itemstatusId = (Integer) request.getSession().getAttribute("itemstatusId");
		ItemStatus itemstatusfromDB = itemStatusRepository.findByItemStatusId(itemstatusId);
		itemstatusfromDB.setItemStatusName(itemStatusDTO.getItemStatusName());
		 try {

		itemStatusRepository.save(itemstatusfromDB);
		model.addAttribute("updateditemstatusName", itemStatusDTO.getItemStatusName());

		return "edititemstatusupdatesuccess";
	}catch (DataIntegrityViolationException e) {
        model.addAttribute("error", "Item Status Name must be unique.");
        redirectAttributes.addFlashAttribute("error", "Item Status Name must be unique.");
		

        return "redirect:/showedititemstatus"; // Return to form with error message
    }
}


	@RequestMapping(value = "/edititemstatus", params = { "deleteitemstatus" })

	public String deleteUnit(@ModelAttribute("itemStatusDTO") ItemStatusDTO itemStatusDTO, BindingResult bindingResult,
			Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long itemstatusId = itemStatusDTO.getItemStatusId();
		ItemStatus itemstatusfromDB = itemStatusRepository.findByItemStatusId(itemstatusId);
		String itemstatus = itemstatusfromDB.getItemStatusName();
		itemStatusRepository.delete(itemstatusfromDB);
		model.addAttribute("deletedItemStatusName", itemstatus);

		return "edititemstatusdeletesuccess";
	}

	@RequestMapping(value = { "/showcreateitemrate" }, method = RequestMethod.GET)
	public String showCreateItemrate(Model model) {
		ItemRateDTO itemRateDTO = new ItemRateDTO();
		model.addAttribute("itemRateDTO", itemRateDTO);
		List<ItemRatePhaseDTO> itemRatePhaseList = populateOrderScreenService.findAllItemRatePhase();
		System.out.println("Printing Size of Phase List"+ itemRatePhaseList.size());
		model.addAttribute("itemratephases", itemRatePhaseList);
		List<ItemRateDTO> itemratelist = populateOrderScreenService.findAllItemRates();
		model.addAttribute("itemrates", itemratelist);
		return "createitemrate";
	}

	@PostMapping("/createitemrate")
	public String createItemRate(@Valid @ModelAttribute("itemRateDTO") ItemRateDTO itemRateDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String itemRateName = itemRateDTO.getItemRateName();

		if (bindingResult.hasErrors()) {

			return "createitemrate";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			ItemRate itemRate = modelMapper.map(itemRateDTO, ItemRate.class);
			 try {
			itemRateRepository.save(itemRate);
			model.addAttribute("itemRateName", itemRateName);
			return "createitemratesuccess";

		}catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Item Rate Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Item Rate Name must be unique.");
			

            return "redirect:/showcreateitemrate"; // Return to form with error message
        }
	}

	}

	@RequestMapping(value = { "/showedititemrate" }, method = RequestMethod.GET)
	public String showEditItemRate(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<ItemRateDTO> itemRatelist = populateOrderScreenService.findAllItemRates();
		model.addAttribute("itemrates", itemRatelist);

		return "showedititemrate";

	}

	@RequestMapping(value = "/edititemrate", params = { "updateitemrate" })

	public String editItemRate(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String itemIdString = orderSearchBillingDTO.getItemRateId();
		Integer itemRateId = 0;
		if (!itemIdString.isEmpty()) {
			itemRateId = Integer.parseInt(orderSearchBillingDTO.getItemRateId());
		}
		ItemRate itemRateFromDB = itemRateRepository.findByItemRateId(itemRateId);
		Long phaseId = itemRateFromDB.getItemRatePhaseId();
		String itemRateName = itemRateFromDB.getItemRateName();
		Double itemRate = itemRateFromDB.getItemRate();
		ItemRateDTO editItemRateDTO = new ItemRateDTO();
		editItemRateDTO.setPhaseId(phaseId);
		editItemRateDTO.setItemRateName(itemRateName);
		editItemRateDTO.setItemRate(itemRate);
		List<ItemRatePhaseDTO> itemRatePhaseList = populateOrderScreenService.findAllItemRatePhase();
		model.addAttribute("itemratephases", itemRatePhaseList);
		request.getSession().setAttribute("itemRateId", itemRateId);
		model.addAttribute("editItemRateDTO", editItemRateDTO);

		return "edititemrate";
	}

	@RequestMapping(value = { "/saveitemrate" }, method = RequestMethod.GET)
	public String saveItemRate(@ModelAttribute("editItemRateDTO") ItemRateDTO editItemRateDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer itemRateId = (Integer) request.getSession().getAttribute("itemRateId");
		ItemRate itemRateIdFromDB = itemRateRepository.findByItemRateId(itemRateId);
		itemRateIdFromDB.setItemRatePhaseId(editItemRateDTO.getPhaseId());
		itemRateIdFromDB.setItemRateName(editItemRateDTO.getItemRateName());
		itemRateIdFromDB.setItemRate(editItemRateDTO.getItemRate());
		 try {
		itemRateRepository.save(itemRateIdFromDB);
		model.addAttribute("updatedItemRateName", editItemRateDTO.getItemRateName());

		return "edititemrateupdatesuccess";
	}catch (DataIntegrityViolationException e) {
        model.addAttribute("error", "Item Rate Name must be unique.");
        redirectAttributes.addFlashAttribute("error", "Item Rate Name must be unique.");
		

        return "redirect:/showedititemrate"; // Return to form with error message
    }
}


	@RequestMapping(value = "/edititemrate", params = { "deleteitemrate" })

	public String editItemRate(@ModelAttribute("editItemRateDTO") ItemRateDTO editItemRateDTO,
			BindingResult bindingResult, Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long itemRateId = editItemRateDTO.getItemRateId();
		ItemRate itemRateIdFromDB = itemRateRepository.findByItemRateId(itemRateId);
		String itemRateName = itemRateIdFromDB.getItemRateName();
		itemRateRepository.delete(itemRateIdFromDB);
		model.addAttribute("deletedItemRateName", itemRateName);

		return "edititemratedeletesuccess";
	}

	@RequestMapping(value = { "/showitemratebatchupdate" }, method = RequestMethod.GET)
	public String showItemRateBatchUpdate(Model model) {
		System.out.println("Printing from welcome");
		// String orderId = orderSearchResultDTO.getOrderId();
		// long orderid = Long.parseLong(orderId);
		//List<ItemRateDTO> findAllItemRates = populateOrderScreenService.findAllItemRates();
		List<ItemRate> itemRateEntity = itemRateRepository.findAll();
//		 List<ItemRateDTO> itemRatelist=new ArrayList<ItemRateDTO>();
		ItemRateBatchDTO itemRateBatchDTO = new ItemRateBatchDTO();
		itemRateEntity.forEach(item -> {
			ItemRateDTO itemRateDTO = new ItemRateDTO();
			itemRateDTO.setItemRateId(item.getItemRateId());
			itemRateDTO.setPhaseId(item.getItemRatePhaseId());
		//    itemRateDTO.setPhaseName(item.getPhaseName());
			itemRateDTO.setItemRateName(item.getItemRateName());
			itemRateDTO.setItemRate(item.getItemRate());
			itemRateBatchDTO.add(itemRateDTO);
		});
		List<ItemRatePhaseDTO> itemRatePhaseList = populateOrderScreenService.findAllItemRatePhase();
		model.addAttribute("itemratephases", itemRatePhaseList);

		model.addAttribute("itemRateBatchDTO", itemRateBatchDTO);
		// model.addAttribute("itemRatelist", itemRatelist);

		return "showitemratebatchupdate";
	}

	@RequestMapping(value = { "/saveitemratebatchupdate" }, method = RequestMethod.POST)
	public String saveItemRateBatchUpdate(@ModelAttribute("itemRateBatchDTO") ItemRateBatchDTO itemRateBatchDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		List<ItemRateDTO> itemRates = itemRateBatchDTO.getItemRates();
		System.out.println("Printing no of items from Rates list"+itemRates.size());
		 try {
	           batchUpdate(itemRateBatchDTO);
	           List<ItemRateDTO> itemRatePhaseList = populateOrderScreenService.findAllItemRates();
	       	List<ItemRate> itemRatesFromDB = itemRateRepository.findAll();
			List<ItemRateDTO> itemRatesDTOs = new ArrayList<ItemRateDTO>();
			itemRatePhaseList.forEach(item -> {
				ItemRateDTO itemRateDTO = new ItemRateDTO();
				itemRateDTO.setItemRateId(item.getItemRateId());
				itemRateDTO.setPhaseId(item.getPhaseId());
				itemRateDTO.setPhaseName(item.getPhaseName());
				itemRateDTO.setItemRateName(item.getItemRateName());
				itemRateDTO.setItemRate(item.getItemRate());
				itemRatesDTOs.add(itemRateDTO);
			});
			model.addAttribute("itemratelist", itemRatesDTOs);
			return "showitemratebatchupdatesuccess";
	          //  return "redirect:/batchUpdate";  // On success, redirect back to the same page
	        } catch (DataIntegrityViolationException e) {
	            // On duplicate exception, add an error message to the redirect attributes
	            redirectAttributes.addFlashAttribute("error", e.getMessage());
	            return "redirect:/showitemratebatchupdate";  // Redirect to the batchUpdate page with error message
	        }
		

	
	}
	
	 @Transactional
	    public void batchUpdate(ItemRateBatchDTO itemRateBatchDTO) throws DataIntegrityViolationException {
		 List<ItemRateDTO> itemRates = itemRateBatchDTO.getItemRates();
		 System.out.println("Printing item rates list size"+ itemRates);
	        for (ItemRateDTO item : itemRates) {
	        	if (item.getItemRateId() != null) {
	        		ItemRate itemRateIdFromDB = itemRateRepository.findByItemRateId(item.getItemRateId());
					itemRateIdFromDB.setItemRatePhaseId(item.getPhaseId());
					itemRateIdFromDB.setItemRateName(item.getItemRateName());
					itemRateIdFromDB.setItemRate(item.getItemRate());
					  try {
			            	itemRateRepository.save(itemRateIdFromDB);
			            } catch (DataIntegrityViolationException e) {
			                // Propagate the exception to be handled in the controller
			                throw new DataIntegrityViolationException("A duplicate entry was found.");
			            }
	        	}
	          
	        }
	    }
	
	
	
	@RequestMapping(value = { "/showcreateitemratephase" }, method = RequestMethod.GET)
	public String showCreateItemRatePhase(Model model) {
		ItemRatePhaseDTO itemRatePhaseDTO = new ItemRatePhaseDTO();
		model.addAttribute("itemRatePhaseDTO", itemRatePhaseDTO);
		List<ItemRatePhaseDTO> itemratephaselist = populateOrderScreenService.findAllItemRatePhase();
		model.addAttribute("itemratephases", itemratephaselist);
		return "createitemratephase";
	}

	@PostMapping("/createitemratephase")
	public String createItemRatePhase(@Valid @ModelAttribute("ItemRatePhaseDTO") ItemRatePhaseDTO itemRatePhaseDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String itemRatePhaseName = itemRatePhaseDTO.getItemRatePhaseName();

		if (bindingResult.hasErrors()) {

			return "createitemratephase";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			ItemRatePhase itemRatePhase = modelMapper.map(itemRatePhaseDTO, ItemRatePhase.class);
			 try {

			itemRatePhaseRepository.save(itemRatePhase);
			model.addAttribute("itemRatePhaseName", itemRatePhaseName);
			return "createitemratephasesuccess";

		}catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Item Rate Phase Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Item Rate Phase Name must be unique.");
			redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.itemRatePhase",
					bindingResult);
			redirectAttributes.addFlashAttribute("itemRatePhase", itemRatePhase);

            return "redirect:/showcreateitemratephase"; // Return to form with error message
        }
	}
	}
	
	
	

	@RequestMapping(value = { "/showedititemratephase" }, method = RequestMethod.GET)
	public String showEditItemRatePhase(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<ItemRatePhaseDTO> itemratephaselist = populateOrderScreenService.findAllItemRatePhase();
		model.addAttribute("itemratephases", itemratephaselist);

		return "showedititemratephase";

	}



	
	
	@RequestMapping(value = "/edititemratephase", params = { "updateitemratephase" })

	public String editItemRatePhase(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String itemRatePhaseIdString = orderSearchBillingDTO.getItemRatePhaseId();
		Integer itemRatePhaseId = 0;
		if (!itemRatePhaseIdString.isEmpty()) {
			itemRatePhaseId = Integer.parseInt(orderSearchBillingDTO.getItemRatePhaseId());
		}
		ItemRatePhase itemRatePhasefromDB = itemRatePhaseRepository.findByItemRatePhaseId(itemRatePhaseId);
		String itemRatePhaseName = itemRatePhasefromDB.getItemRatePhaseName();
		ItemRatePhaseDTO itemRatePhaseDTO = new ItemRatePhaseDTO();
		itemRatePhaseDTO.setItemRatePhaseName(itemRatePhaseName);
		request.getSession().setAttribute("itemRatePhaseId", itemRatePhaseId);
		model.addAttribute("itemRatePhaseDTO", itemRatePhaseDTO);

		return "edititemratephase";
	}
	
	@RequestMapping(value = { "/saveitemratephase" }, method = RequestMethod.GET)
	public String saveItemRatePhase(@ModelAttribute("itemRatePhaseDTO") ItemRatePhaseDTO itemRatePhaseDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer itemRatePhaseId = (Integer) request.getSession().getAttribute("itemRatePhaseId");
		ItemRatePhase itemRatePhasefromDB = itemRatePhaseRepository.findByItemRatePhaseId(itemRatePhaseId);
		itemRatePhasefromDB.setItemRatePhaseName(itemRatePhaseDTO.getItemRatePhaseName());
		 try {

		itemRatePhaseRepository.save(itemRatePhasefromDB);
		model.addAttribute("updateditemPhaseName", itemRatePhasefromDB.getItemRatePhaseName());

		return "edititemratephaseupdatesuccess";
	}catch (DataIntegrityViolationException e) {
        model.addAttribute("error", "Item Rate Phase Name must be unique.");
        redirectAttributes.addFlashAttribute("error", "Item Rate Phase Name must be unique.");
		

        return "redirect:/showedititemratephase"; // Return to form with error message
    }
}


	@RequestMapping(value = "/edititemratephase", params = { "deleteitemratephase" })

	public String editItemRatePhase(@ModelAttribute("itemRatePhaseDTO") ItemRatePhaseDTO itemRatePhaseDTO,
			BindingResult bindingResult, Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long itemRatePhaseId = itemRatePhaseDTO.getItemRatePhaseId();
		ItemRatePhase itemRatePhasefromDB = itemRatePhaseRepository.findByItemRatePhaseId(itemRatePhaseId);
		String itemRatePhaseName = itemRatePhasefromDB.getItemRatePhaseName();
		itemRatePhaseRepository.delete(itemRatePhasefromDB);
		model.addAttribute("deletedItemPhaseName", itemRatePhaseName);

		return "edititemphasenamedeletesuccess";
	}
	
	@Transactional
public void refreshEntity(Long entityId) {
	Order entity = orderrepository.findById(entityId);
	System.out.println("printing Order Id " + entity.getId());
	if (entity!=null)
	{
	 entityManager.refresh(entity);
	}
	
}

}
