package com.printing.frontend.constraint;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
/* import com.printing.frontend.constraint.*;
import java.util.Calendar;
import java.util.Date;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.lang.Object; */
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.printing.frontend.controller.*;
/* import java.text.SimpleDateFormat;  
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.text.ParseException;
import java.text.SimpleDateFormat; 
*/

@Component

public class OrderFormValidator implements Validator {

	// private static final SimpleDateFormat sdf = new
	// SimpleDateFormat("dd/MM/YYYY");
	// which objects can be validated by this validator
	@Override
	public boolean supports(Class<?> clazz) {
		return OrderForm.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		OrderForm orderform = (OrderForm) obj;
		int institutionName = Integer.parseInt(orderform.getInstitutionId());
		int departmentName = Integer.parseInt(orderform.getDepartmentId());
		int itemName = Integer.parseInt(orderform.getItemId());
		int size = Integer.parseInt(orderform.getSizeId());
		int unit = Integer.parseInt(orderform.getUnitId());
		int quantity = Integer.parseInt(orderform.getQuantity());
		// double price = Integer.parseInt(orderform.getPrice());
		// Date transactionDate = orderform.getTransactionDate();

		/*
		 * if (orderform.getTransactionDate()!= null) { transactionDate =
		 * orderform.getTransactionDate().toString(); }
		 */

		// System.out.println("Printing Values in validate method" + institutionName +
		// departmentName + itemName + size + unit + quantity + price +
		// transactionDate);
		// System.out.println("Printing Values in validate method" + institutionName +
		// departmentName + itemName + size + unit + quantity + price );
		/*
		 * if (institutionName.equalsIgnoreCase("Select Institution")) {
		 * System.out.println("printing inside equalsIgnoreCase " + institutionName +
		 * "Select Institution" ); errors.rejectValue("institutionId",
		 * "InCorrect Institution", "Please Select Institution"); }
		 * 
		 * /* if (departmentName.equalsIgnoreCase("Select Department")) {
		 * errors.rejectValue("departmentId", "InCorrect Institution",
		 * "Please Select Department"); }
		 */
		/*
		 * if (size.equalsIgnoreCase("Select Size")) { errors.rejectValue("sizeId",
		 * "InCorrect Size", "Please Select Size"); }
		 * 
		 * if (itemName.equalsIgnoreCase("Select Item")) { errors.rejectValue("itemId",
		 * "InCorrect Item", "Please Select Item"); } if
		 * (itemName.equalsIgnoreCase("Select Unit")) { errors.rejectValue("unitId",
		 * "InCorrect Unit", "Please Select Unit"); }
		 */

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "quantity", "", "Quantity is Required");
		// ValidationUtils.rejectIfEmptyOrWhitespace(errors,"price","", "Price is
		// Required");
		// ValidationUtils.rejectIfEmptyOrWhitespace(errors,"transactionDate","","Transaction
		// Date is Required");

		/*
		 * boolean isPriceNumeric = isNumeric(price);
		 * 
		 * if (!isPriceNumeric) { errors.rejectValue("price", "InCorrect Price",
		 * "Please Enter Price in correct format"); }
		 */

		/*
		 * if (StringUtils.isEmpty(transactionDate) == false &&
		 * (StringUtils.isBlank(transactionDate)) == false) { boolean
		 * isTransactionDateValid = isValidDate(transactionDate);
		 * 
		 * if (!isTransactionDateValid) { errors.rejectValue("transactionDate",
		 * "InCorrect Date", "Please Enter Transaction Date in dd/MM/YYYY"); }
		 * 
		 * }
		 */

	}

	private boolean isNumeric(String price) {
		try {
			double pricetemp = Double.parseDouble(price);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}

	/*
	 * public static boolean isValidDate(final String date) {
	 * 
	 * boolean valid = false;
	 * 
	 * try { // why 2008-02-2x, 20-11-02, 12012-04-05 are valid date?
	 * sdf.parse(date); // strict mode - check 30 or 31 days, leap year
	 * sdf.setLenient(false); System.out.println("Transaction Date Inside Validator"
	 * + date ); valid = true;
	 * 
	 * } catch (ParseException e) { e.printStackTrace(); valid = false; }
	 * 
	 * return valid; }
	 */

}
