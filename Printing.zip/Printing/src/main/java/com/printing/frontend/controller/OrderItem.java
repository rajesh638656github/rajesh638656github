package com.printing.frontend.controller;

public class OrderItem {
	private String orderId;
	private String itemid;
	private String sizeId;
	private String unitId;
	private String quantity;
	private String price;

}
