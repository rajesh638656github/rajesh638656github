package com.printing.registrationlogin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.printing.registrationlogin.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);
}
