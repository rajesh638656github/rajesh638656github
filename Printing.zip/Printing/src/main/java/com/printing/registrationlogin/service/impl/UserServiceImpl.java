package com.printing.registrationlogin.service.impl;

import com.printing.registrationlogin.dto.UserDto;
import com.printing.registrationlogin.entity.Role;
import com.printing.registrationlogin.entity.User;
import com.printing.registrationlogin.repository.RoleRepository;
import com.printing.registrationlogin.repository.UserRepository;
import com.printing.registrationlogin.service.UserService;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;
    private RoleRepository roleRepository;
    private PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository,
                           RoleRepository roleRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void saveUser(UserDto userDto) {
        User user = new User();
        user.setName(userDto.getFirstName() + " " + userDto.getLastName());
        user.setEmail(userDto.getEmail());

        //encrypt the password once we integrate spring security
        //user.setPassword(userDto.getPassword());
        user.setPassword(passwordEncoder.encode(userDto.getPassword()));
        Role role = roleRepository.findByName("ROLE_ADMIN");
        if(role == null){
            role = checkRoleExist();
        }
        user.setRoles(Arrays.asList(role));
        userRepository.save(user);
    }
    
    @Override
    public void updatePassword(UserDto userDto) {
    	User existing = userRepository.findByEmail(userDto.getEmail());
    	System.out.println("Printing existing user id" + existing.getEmail());
    	System.out.println("Printing existing Password" + existing.getPassword());
       	existing.setPassword(passwordEncoder.encode(userDto.getPassword()));
        userRepository.save(existing);
    }

    @Override
    public User findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Override
    public List<UserDto> findAllUsers() {
        List<User> users = userRepository.findAll();
        return users.stream().map((user) -> convertEntityToDto(user))
                .collect(Collectors.toList());
    }

    private UserDto convertEntityToDto(User user){
        UserDto userDto = new UserDto();
        String[] name = user.getName().split(" ");
        userDto.setFirstName(name[0]);
        userDto.setLastName(name[1]);
        userDto.setEmail(user.getEmail());
        List<Role> roles =user.getRoles();
        Role role = roles.get(0);
        String roleName = role.getName();
        userDto.setRole(roleName);
        return userDto;
    }

    private Role checkRoleExist() {
        Role role = new Role();
        role.setName("ROLE_ADMIN");
        return roleRepository.save(role);
    }
}
