package com.printing.registrationlogin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.printing.registrationlogin.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {
    Role findByName(String name);
    
    
}
