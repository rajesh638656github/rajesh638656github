package com.printing.registrationlogin.service;

import com.printing.registrationlogin.dto.UserDto;
import com.printing.registrationlogin.entity.User;

import java.util.List;

public interface UserService {
    void saveUser(UserDto userDto);
    
    void updatePassword(UserDto userDto);

    User findByEmail(String email);

    List<UserDto> findAllUsers();
}
