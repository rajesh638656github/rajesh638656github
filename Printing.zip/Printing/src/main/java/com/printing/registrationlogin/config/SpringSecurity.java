package com.printing.registrationlogin.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;

@Configuration
@EnableWebSecurity
public class SpringSecurity {

    @Autowired
    private UserDetailsService userDetailsService;

    @Bean
    public static PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
      //  http.csrf().disable()
    	http.csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests((authorize) ->
                authorize.requestMatchers("/register/**", "/update-password").permitAll()
                        
                    //    .requestMatchers("/emailentry").permitAll()
                     //   .requestMatchers("/savenewpassword").permitAll()
                        
                        .requestMatchers("/images/**").permitAll()
                        //.requestMatchers("/images/spring-logo.svg").permitAll()
                              .requestMatchers("/webjars/**").permitAll()
                               .requestMatchers("/favicon.ico").permitAll()
                               .requestMatchers("/webjars/font-awesome/4.7.0/css/font-awesome.min.css").permitAll()
                               .requestMatchers("/webjars/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js").permitAll()
                                .requestMatchers("/index").permitAll()
                               .requestMatchers("/webjars/bootstrap/5.3.0/js/bootstrap.bundle.min.js").permitAll()
                               .requestMatchers("/webjars/jquery-ui/1.12.0/jquery-ui.min.js").permitAll()
                                .requestMatchers("/testing").authenticated()
                                .requestMatchers("/welcome").authenticated()
                                .requestMatchers("/downloadorderdetailsexcel").authenticated()
                                .requestMatchers("/downloadshortpendingorderreportexcel").authenticated()
                                .requestMatchers("/downloadbillreportforinstitutionexcel").authenticated()
                                .requestMatchers("/downloadorderpricedetailspdf").authenticated()
                                .requestMatchers("/previewbill").authenticated()
                                .requestMatchers("/downloadorderdetailspdf").authenticated()
                                .requestMatchers("/showdraftbill").authenticated()
                                .requestMatchers("/showordersfordraftbill").authenticated()
                                .requestMatchers("/showbillprint").authenticated()
                                .requestMatchers("/ordermanager").authenticated()
                                .requestMatchers("/showeditorderitemsfromshortreport/**").authenticated()
                                .requestMatchers("/showitempricecalculation").authenticated()
                                .requestMatchers("/showitemratebatchupdate").authenticated()
                                .requestMatchers("/saveitemratebatchupdate").authenticated()
                                .requestMatchers("/saveorderitemprice").authenticated()
                                .requestMatchers("/showeditprice").authenticated()
                                .requestMatchers("/saveitempricesuccess").authenticated()
                                .requestMatchers("/showcreateinstitution").authenticated()
                                .requestMatchers("/createinstitution").authenticated()
                                .requestMatchers("/showeditinstitution").authenticated()
                                .requestMatchers("/editinstitution").authenticated()
                                .requestMatchers("/saveinstitution").authenticated()
                                .requestMatchers("/showcreatedepartment").authenticated()
                                .requestMatchers("/createdepartment").authenticated()
                                .requestMatchers("/showeditdepartment").authenticated()
                                .requestMatchers("/editdepartment").authenticated()
                                .requestMatchers("/savedepartment").authenticated()
                                .requestMatchers("/showcreateitem").authenticated()
                                .requestMatchers("/createitem").authenticated()
                                .requestMatchers("/showedititemtype").authenticated()
                                .requestMatchers("/edititemtype").authenticated()
                                .requestMatchers("/saveitemtype").authenticated()
                                .requestMatchers("/showcreatesize").authenticated()
                                .requestMatchers("/createsize").authenticated()
                                .requestMatchers("/showeditsize").authenticated()
                                .requestMatchers("/editsize").authenticated()
                                .requestMatchers("/savesize").authenticated()
                                .requestMatchers("/showcreateunit").authenticated()
                                .requestMatchers("/createunit").authenticated()
                                .requestMatchers("/showeditunit").authenticated()
                                .requestMatchers("/editunit").authenticated()
                                .requestMatchers("/saveunit").authenticated()
                                .requestMatchers("/showcreateitemstatus").authenticated()
                                .requestMatchers("/createitemstatus").authenticated()
                                .requestMatchers("/showedititemstatus").authenticated()
                                .requestMatchers("/edititemstatus").authenticated()
                                .requestMatchers("/saveitemstatus").authenticated()
                                .requestMatchers("/showcreateitemrate").authenticated()
                                .requestMatchers("/createitemrate").authenticated()
                                .requestMatchers("/showedititemrate").authenticated()
                                .requestMatchers("/edititemrate").authenticated()
                                .requestMatchers("/saveitemrate").authenticated()
                                .requestMatchers("/showcreateitemratephase").authenticated()
                                .requestMatchers("/createitemratephase").authenticated()
                                .requestMatchers("/showedititemratephase").authenticated()
                                .requestMatchers("/edititemratephase").authenticated()
                                .requestMatchers("/saveitemratephase").authenticated()
                                .requestMatchers("/showallactiveorderforquote").authenticated()
                                .requestMatchers("/showdorderquote/**").authenticated()
                                .requestMatchers("/showduplicatebilldraftprint").authenticated()
                                .requestMatchers("/printduplicatebilldraftforall/**").authenticated()
                                .requestMatchers("/showduplicatebillprint").authenticated()
                                .requestMatchers("/printduplicatebill/**").authenticated()
                                .requestMatchers("/showallactiveorderfororderreport").authenticated()
                                .requestMatchers("/showorderreport/**").authenticated()
                                .requestMatchers("/showallactiveorderforordercostreport").authenticated()
                                .requestMatchers("/showordercostreport/**").authenticated()
                                .requestMatchers("/showallactiveorderforedit").authenticated()
                                .requestMatchers("/showallactiveorderforadditem").authenticated()
                                .requestMatchers("/showallactiveorderfordeleteitem").authenticated()
                                .requestMatchers("/showallactiveorderforcreateorderfromexistingorder").authenticated()
                                .requestMatchers("/showdeditorder/**").authenticated()
                                .requestMatchers("/showeditorderitemsadditem/**").authenticated()
                                .requestMatchers("/showeditorderitemsdeleteitem/**").authenticated()
                                .requestMatchers("/showcreateorderfromexistingorder/**").authenticated()
                                .requestMatchers("/ordersearchfororderreport").authenticated()
                                .requestMatchers("/showordersearchresultfororderreport").authenticated()
                                .requestMatchers("/showorderreport").authenticated()
                                .requestMatchers("/ordersearchforordercostreport").authenticated()
                                .requestMatchers("/showordersearchresultforordercostreport").authenticated()
                                .requestMatchers("/showordercostreport").authenticated()
                                .requestMatchers("/ordersearchfororderedit").authenticated()
                                .requestMatchers("/showordersearchresultfororderedit").authenticated()
                                .requestMatchers("/showeditorderitems").authenticated()
                                .requestMatchers("/saveeditorderitems").authenticated()
                                .requestMatchers("/ordersearchforordereditadditem").authenticated()
                                .requestMatchers("/showordersearchresultforordereditadditem").authenticated()
                                .requestMatchers("/showeditorderitemsadditem").authenticated()
                                .requestMatchers("/editorderadditem").authenticated()
                                .requestMatchers("/ordersearchforordereditdeleteitem").authenticated()
                                .requestMatchers("/showordersearchresultforordereditdeleteitem").authenticated()
                                .requestMatchers("/showeditorderdeleteitem").authenticated()
                                .requestMatchers("/saveeditorderdeleteitem").authenticated()
                                .requestMatchers("/ordersearchforcreateorderfromexistingorder").authenticated()
                                .requestMatchers("/showordersearchresultforcreateorderfromexistingorder").authenticated()
                                .requestMatchers("/showcreateorderfromexistingorder").authenticated()
                                .requestMatchers("/savecreateorderfromexistingorder").authenticated()
                                .requestMatchers("/showbillorderdetail").authenticated()
                                .requestMatchers("/showpendingordersshortreport").authenticated()
                                .requestMatchers("/showpendingordersdetailedreport").authenticated()
                                .requestMatchers("/itemsearchfororderreportbyitemtype").authenticated()
                                .requestMatchers("/showorderreportbyitemtype").authenticated()
                                .requestMatchers("/showordersearchfordraftingbill").authenticated()
                                .requestMatchers("/showordersearchresultfordraftingbill").authenticated()
                                .requestMatchers("/printbilldraft").authenticated()
                                .requestMatchers("/showrevenuereportsearch").authenticated()
                                .requestMatchers("/showrevenuereportsearchresult").authenticated()
                                .requestMatchers("/downloadrevenuereportexcel").authenticated()
                                .requestMatchers("/showbillreportsearch").authenticated()
                                .requestMatchers("/showbillreportsearchresult").authenticated()
                                .requestMatchers("/showbillsearchforbillprinting").authenticated()
                                .requestMatchers("/printbill").authenticated()
                                .requestMatchers("/billprinting").authenticated()
                                .requestMatchers("/printbillforall").authenticated()
                                .requestMatchers("/showbillsearchforfuturebillprinting").authenticated()
                                .requestMatchers("/printfuturebill").authenticated()
                                .requestMatchers("/downloadbilldraftpdf").authenticated()
                                .requestMatchers("/showbillsearchresultforbillprinting").authenticated()
                                .requestMatchers("/showordersearchforquotationgeneration").authenticated()
                                .requestMatchers("/showordersearchresultforquotationgeneration").authenticated()
                                .requestMatchers("/createquotation").authenticated()
                                .requestMatchers("/savequoatation").authenticated()
                                .requestMatchers("/showbillsearchforduplicatebilldraftprinting").authenticated()
                                .requestMatchers("/showbillsearchresultfordupilcatebilldraftprinting").authenticated()
                                .requestMatchers("/printduplicatebilldraft").authenticated()
                                .requestMatchers("/showbillsearchforduplicatebillprinting").authenticated()
                                .requestMatchers("/showbillsearchresultfordupilcatebillprinting").authenticated()
                                .requestMatchers("/printduplicatebill").authenticated()
                                

                                .requestMatchers("/users").hasRole("ADMIN")
                ).formLogin(
                        form -> form
                                .loginPage("/login")
                                .loginProcessingUrl("/login")
                               // .defaultSuccessUrl("/users")
                                .defaultSuccessUrl("/welcome",true)
                                .permitAll()
                ).logout(
                        logout -> logout
                               .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                               .logoutSuccessUrl("/login")
                               .invalidateHttpSession(true)        // set invalidation state when logout
                               .deleteCookies("JSESSIONID")  
                                .permitAll()
                      //  .logoutSuccessUrl("/login")
                );
        return http.build();
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth
                .userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder());
    }
}
