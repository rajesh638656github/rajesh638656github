package com.printing.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.printing.entity.Size;

@Repository
public interface SizeRepository extends JpaRepository<Size, Integer> {
	Size findBySizeId(long sizeId);
}
