package com.printing.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.printing.entity.ItemRate;

@Repository

public interface ItemRateRepository  extends JpaRepository<ItemRate, Long> {
	ItemRate findByItemRateId(long itemId);
	List<ItemRate> findAllByOrderByItemRatePhaseId();
	//List<ItemRate> findByItemRatePhaseNameIn(List<String> itemRatePhaseName);
}

