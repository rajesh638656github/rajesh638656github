package com.printing.repository;
import com.printing.entity.QuotationOrderItem;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface QuotationOrderItemRepository extends JpaRepository<QuotationOrderItem, Long> {

}
