package com.printing.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.printing.entity.OrderItemPrice;

@Repository
public interface OrderItemPriceRepository extends JpaRepository<OrderItemPrice, Integer> {

}
