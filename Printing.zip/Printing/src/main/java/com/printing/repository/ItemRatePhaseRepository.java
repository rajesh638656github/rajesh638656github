package com.printing.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.printing.entity.ItemRatePhase;

@Repository
public interface ItemRatePhaseRepository  extends JpaRepository<ItemRatePhase, Integer> {
	ItemRatePhase findByItemRatePhaseId(long itemRatePhaseId);
}