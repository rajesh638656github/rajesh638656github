package com.printing.repository;

import com.printing.entity.Bill;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BillRepository extends JpaRepository<Bill, Integer> {
	Bill findByBillId(long billId);
}
