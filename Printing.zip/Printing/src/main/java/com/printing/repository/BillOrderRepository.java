package com.printing.repository;

import com.printing.entity.BillOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository

public interface BillOrderRepository extends JpaRepository<BillOrder, Integer> {
	BillOrder findByBillOrderId(long billOrderId);
}
