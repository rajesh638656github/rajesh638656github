package com.printing.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.printing.entity.Item;
import com.printing.entity.ItemStatus;

public interface ItemStatusRepository extends JpaRepository<ItemStatus, Integer> {
	ItemStatus findByItemStatusId(long itemStatusId);
}
