package com.printing.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.printing.entity.Unit;

@Repository
public interface UnitRepository extends JpaRepository<Unit, Integer> {
	Unit findByUnitId(long unitId);
}
