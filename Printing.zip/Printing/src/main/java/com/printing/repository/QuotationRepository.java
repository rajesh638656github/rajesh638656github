package com.printing.repository;
import java.util.List;


import com.printing.entity.Quotation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface QuotationRepository  extends JpaRepository<Quotation, Integer> {
	Quotation findById(long quotationId);
}

