package com.printing.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.printing.entity.Item;
import com.printing.entity.ItemStatus;

@Repository

public interface ItemRepository extends JpaRepository<Item, Integer> {
	Item findByItemId(long itemId);
}
