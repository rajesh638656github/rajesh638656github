package com.printing.repository;

import java.util.List;
import com.printing.entity.Order;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {
	Order findById(long orderId);
}
