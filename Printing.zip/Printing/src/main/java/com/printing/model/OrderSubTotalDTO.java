package com.printing.model;

public class OrderSubTotalDTO {
	private long orderId;
	private double orderPrice;

	public OrderSubTotalDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderSubTotalDTO(int orderId, double orderPrice) {
		super();
		this.orderId = orderId;
		this.orderPrice = orderPrice;
	}

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public double getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(double orderPrice) {
		this.orderPrice = orderPrice;
	}

	@Override
	public String toString() {
		return "OrderSubTotalDTO [orderId=" + orderId + ", orderPrice=" + orderPrice + "]";
	}

}
