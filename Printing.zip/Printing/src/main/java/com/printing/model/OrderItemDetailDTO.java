package com.printing.model;

public class OrderItemDetailDTO {
	private String rownum;
	private String orderId;
	private String institutionId;
	private String departmentId;
	private String orderItemId;
	private String itemDescription;
	private String status;
	private String billDraft;
	private String itemId;
	private String sizeId;
	private String note;
	private String unitId;
	private String itemstatusId;
	private String institutionName;
	private String departmentName;
	private String contactPersonName;
	private String contactNumber;
	private String total;
	private String profitMargin;
	private String totalAmount;
	private String itemName;
	private String sizeName;
	private String unitName;
	private String quantity;
	private String price;
	private String amount;
	private String billingItemRate;
	private String itemStatus;
	private String comments;
	private String startDate;
	private String endDate;

	public OrderItemDetailDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderItemDetailDTO(String orderId, String institutionId, String departmentId,String status,String billDraft,String total,String profitMargin,String totalAmount,String orderItemId, String itemId, String itemDescription, String sizeId,
			String note,String unitId,String itemstatusId, String institutionName, String departmentName, String contactPersonName,String contactNumber,String itemName, String sizeName,
			String unitName, String quantity, String price, String amount,String itemStatus,String comments, String startDate, String endDate) {
		super();
		this.orderId = orderId;
		this.institutionId = institutionId;
		this.departmentId = departmentId;
		this.contactPersonName = contactPersonName;
		this.contactNumber = contactNumber;
		this.total = total;
		this.profitMargin = profitMargin;
		this.totalAmount = totalAmount;
		this.status = status;
		this.billDraft = billDraft;
		this.orderItemId = orderItemId;
		this.itemId = itemId;
		this.itemDescription = itemDescription;
		this.sizeId = sizeId;
		this.note = note; 
		this.unitId = unitId;
		this.itemstatusId = itemstatusId;
		this.institutionName = institutionName;
		this.departmentName = departmentName;
		this.itemName = itemName;
		this.sizeName = sizeName;
		this.unitName = unitName;
		this.quantity = quantity;
		this.price = price;
		this.amount = amount;
		this.itemStatus = itemStatus;
		this.comments = comments;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	

	public String getRownum() {
		return rownum;
	}

	public void setRownum(String rownum) {
		this.rownum = rownum;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}
	
	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public String getBillDraft() {
		return billDraft;
	}

	public void setBillDraft(String billDraft) {
		this.billDraft = billDraft;
	}
	
	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public String getProfitMargin() {
		return profitMargin;
	}

	public void setProfitMargin(String profitMargin) {
		this.profitMargin = profitMargin;
	}

	public String getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(String orderItemId) {
		this.orderItemId = orderItemId;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getSizeId() {
		return sizeId;
	}

	public void setSizeId(String sizeId) {
		this.sizeId = sizeId;
	}
	

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}
	public String getItemstatusId() {
		return itemstatusId;
	}

	public void setItemstatusId(String itemstatusId) {
		this.itemstatusId = itemstatusId;
	}

	public String getInstitutionName() {
		return institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	
	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getSizeName() {
		return sizeName;
	}

	public void setSizeName(String sizeName) {
		this.sizeName = sizeName;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	
	public String getBillingItemRate() {
		return billingItemRate;
	}

	public void setBillingItemRate(String billingItemRate) {
		this.billingItemRate = billingItemRate;
	}

	public String getItemStatus() {
		return itemStatus;
	}

	public void setItemStatus(String itemStatus) {
		this.itemStatus = itemStatus;
	}
	
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "OrderMultipleItemDTO [orderId=" + orderId + ", institutionId=" + institutionId + ", departmentId="
				+ departmentId + ", itemId=" + itemId + ", sizeId=" + sizeId + ", unitId=" + unitId
				+ ", institutionName=" + institutionName + ", departmentName=" + departmentName + ", itemName="
				+ itemName + ", sizeName=" + sizeName + ", unitName=" + unitName + ", quantity=" + quantity + ", price="
				+ price + ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}

}
