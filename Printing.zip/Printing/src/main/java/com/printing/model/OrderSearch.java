package com.printing.model;

public class OrderSearch {
	private String orderId;

	public OrderSearch() {

		// TODO Auto-generated constructor stub
	}

	public OrderSearch(String orderId) {
		super();
		this.orderId = orderId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	@Override
	public String toString() {
		return "SearchOrder [orderId=" + orderId + "]";
	}

}
