package com.printing.model;

public class OrderItemIds {
	String orderId;
	String[] orderItemIds;

	public OrderItemIds() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderItemIds(String orderId,String[] orderItemIds) {
		super();
		this.orderId = orderId;
		this.orderItemIds = orderItemIds;
	}

	public String[] getOrderItemIds() {
		return orderItemIds;
	}

	public void setOrderItemIds(String[] orderItemIds) {
		this.orderItemIds = orderItemIds;
	}
	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	

}
