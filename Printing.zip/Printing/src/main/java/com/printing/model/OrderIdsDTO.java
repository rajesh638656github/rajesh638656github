package com.printing.model;

public class OrderIdsDTO {
	private int orderId;

	public OrderIdsDTO() {

		// TODO Auto-generated constructor stub
	}

	public OrderIdsDTO(int orderId) {
		super();
		this.orderId = orderId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	@Override
	public String toString() {
		return "OrderIdDTO [orderId=" + orderId + "]";
	}

}
