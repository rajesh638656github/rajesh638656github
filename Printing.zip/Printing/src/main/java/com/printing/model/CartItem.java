package com.printing.model;

public class CartItem {
	private int institutionId;
	private int departmentId;
	private int itemId;
	private int sizeId;
	private int unitId;

	public CartItem() {

	}

	public CartItem(int institutionId, int departmentId, int itemId, int sizeId, int unitId) {
		super();
		this.institutionId = institutionId;
		this.departmentId = departmentId;
		this.itemId = itemId;
		this.sizeId = sizeId;
		this.unitId = unitId;
	}

	public int getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(int institutionId) {
		this.institutionId = institutionId;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getSizeId() {
		return sizeId;
	}

	public void setSizeId(int sizeId) {
		this.sizeId = sizeId;
	}

	public int getUnitId() {
		return unitId;
	}

	public void setUnitId(int unitId) {
		this.unitId = unitId;
	}

	@Override
	public String toString() {
		return "CartItem [institutionId=" + institutionId + ", departmentId=" + departmentId + ", itemId=" + itemId
				+ ", sizeId=" + sizeId + ", unitId=" + unitId + "]";
	}

}
