package com.printing.model;

import com.printing.model.*;
import com.printing.frontend.controller.*;
import java.util.List;
import java.util.ArrayList;

public class OrdersFormCreationDTO {
	public List<OrderForm> ordersForms;

	public OrdersFormCreationDTO() {

		this.ordersForms = new ArrayList<>();
		// TODO Auto-generated constructor stub
	}

	public OrdersFormCreationDTO(List<OrderForm> ordersForms) {
		super();
		this.ordersForms = ordersForms;
	}

	public List<OrderForm> getOrdersForms() {
		return ordersForms;
	}

	public void setOrdersForms(List<OrderForm> ordersForms) {
		this.ordersForms = ordersForms;
	}

	public void addOrdersForm(OrderForm orderForm) {
		this.ordersForms.add(orderForm);
	}

}
