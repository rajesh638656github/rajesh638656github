package com.printing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//@EntityScan({"com.printing.entity.Item","com.printing.entity.Order"})
public class PrintingApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrintingApplication.class, args);
	}

}
