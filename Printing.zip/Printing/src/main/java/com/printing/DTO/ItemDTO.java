package com.printing.DTO;

public class ItemDTO {
	private long itemId;
	String itemName;

	public ItemDTO() {

	}

	public ItemDTO(long itemId, String itemName) {

		this.itemId = itemId;
		this.itemName = itemName;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", itemName=" + itemName + "]";
	}

}
