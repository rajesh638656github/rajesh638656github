package com.printing.DTO;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

public class BillDTO {
	
	private int billId;
	private String transactionDate;
	private String institutionName;
	private double subTotal;
	private double taxAmount;
	private double totalAmount;
	public BillDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getBillId() {
		return billId;
	}
	public void setBillId(int billId) {
		this.billId = billId;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getInstitutionName() {
		return institutionName;
	}
	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}
	public double getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}
	public double getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	@Override
	public String toString() {
		return "BillDTO [billId=" + billId + ", transactionDate=" + transactionDate + ", subTotal=" + subTotal
				+ ", taxAmount=" + taxAmount + ", totalAmount=" + totalAmount + "]";
	}
	
	

}
