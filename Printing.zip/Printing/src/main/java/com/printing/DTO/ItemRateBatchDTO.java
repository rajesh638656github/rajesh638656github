package com.printing.DTO;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.printing.entity.OrderItem;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import jakarta.validation.Valid;
//import jakarta.persistence.*;

//import com.printing.entity.OrderItem;

import lombok.*;
import java.util.HashSet;
import java.util.Set;
public class ItemRateBatchDTO {
	private List<ItemRateDTO> itemRates;
	private String selectAll;

	public ItemRateBatchDTO() {
		itemRates = new ArrayList<ItemRateDTO>();
		//super();
		// TODO Auto-generated constructor stub
	}
	
	

	public String getSelectAll() {
		return selectAll;
	}



	public void setSelectAll(String selectAll) {
		this.selectAll = selectAll;
	}



	public List<ItemRateDTO> getItemRates() {
		return itemRates;
	}

	public void setItemRates(List<ItemRateDTO> itemRates) {
		this.itemRates = itemRates;
	}
	
	public void add(ItemRateDTO item) {

        if (item != null) {
            if (itemRates == null) {
            	itemRates = new ArrayList<>();
            }

            itemRates.add(item);
           // item.setOrder(this);
        }
    }

}
