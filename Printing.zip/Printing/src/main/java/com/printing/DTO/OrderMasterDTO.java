package com.printing.DTO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import com.printing.model.OrderItemDetailDTO;

public class OrderMasterDTO {
	private String orderId;
	private String institutionId;
	private String departmentId;
	private String institutionName;
	private String departmentName;
	private String contactPersonName;
	private String contactNumber;
	private String total;
	private String profitMargin;
	private String totalAmount;
	private String startDate;
	private String endDate;
	public OrderMasterDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderMasterDTO(String orderId, String institutionId, String departmentId, String institutionName,
			String departmentName, String startDate, String endDate,String contactPersonName,String contactNumber) {
		super();
		this.orderId = orderId;
		this.institutionId = institutionId;
		this.departmentId = departmentId;
		this.institutionName = institutionName;
		this.departmentName = departmentName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.contactPersonName = contactPersonName;
		this.contactNumber = contactNumber;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getInstitutionId() {
		return institutionId;
	}
	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}
	public String getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}
	public String getInstitutionName() {
		return institutionName;
	}
	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getProfitMargin() {
		return profitMargin;
	}
	public void setProfitMargin(String profitMargin) {
		this.profitMargin = profitMargin;
	}
	
	
	
		

}


