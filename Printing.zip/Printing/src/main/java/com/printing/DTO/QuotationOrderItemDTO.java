package com.printing.DTO;

import com.printing.entity.Quotation;

import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

public class QuotationOrderItemDTO { 

private long id;
private int itemId;
private Integer quantity;
private Double price;
private Double amount;
private Double orderId;

private QuotationDTO quotationDTO;


public QuotationOrderItemDTO() {
	// super();
	// TODO Auto-generated constructor stub
}



public QuotationOrderItemDTO(int itemId, Integer quantity, Double price,Double amount,Double orderId) {
	super();
	this.itemId = itemId;
	this.quantity = quantity;
	this.price = price;
	this.amount = amount;
	this.orderId = orderId;
}



public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public int getItemId() {
	return itemId;
}

public void setItemId(int itemId) {
	this.itemId = itemId;
}

public Integer getQuantity() {
	return quantity;
}

public void setQuantity(Integer quantity) {
	this.quantity = quantity;
}

public Double getPrice() {
	return price;
}

public Double getAmount() {
	return amount;
}



public void setAmount(Double amount) {
	this.amount = amount;
}



public void setPrice(Double price) {
	this.price = price;
}
public Double getOrderId() {
	return orderId;
}
public void setOrderId(Double orderId) {
	this.orderId = orderId;
}
public QuotationDTO getQuotationDTO() {
	return quotationDTO;
}



public void setQuotationDTO(QuotationDTO quotationDTO) {
	this.quotationDTO = quotationDTO;
}


/*
 * public long getOrderId() { return orderId; } public void setOrderId(long
 * orderId) { this.orderId = orderId; }
 */


}


