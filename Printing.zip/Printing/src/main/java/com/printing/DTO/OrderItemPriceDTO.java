package com.printing.DTO;

import jakarta.persistence.Column;

public class OrderItemPriceDTO {
	private String id;
	private String orderItemId;
	private String orderItemName; 
	private String orderItemPriceId;
	private String itemRateId;
	private String phaseId;
	private String phaseName;
	private String itemRateName;
	private String itemRate;
	private String noOfItems;
	private String amount;
	public OrderItemPriceDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getOrderItemId() {
		return orderItemId;
	}
	public void setOrderItemId(String orderItemId) {
		this.orderItemId = orderItemId;
	}
	public String getItemRateId() {
		return itemRateId;
	}
	public void setItemRateId(String itemRateId) {
		this.itemRateId = itemRateId;
	}
	
	
	public String getOrderItemName() {
		return orderItemName;
	}
	public void setOrderItemName(String orderItemName) {
		this.orderItemName = orderItemName;
	}
	
	
	public String getOrderItemPriceId() {
		return orderItemPriceId;
	}
	public void setOrderItemPriceId(String orderItemPriceId) {
		this.orderItemPriceId = orderItemPriceId;
	}
	public String getPhaseName() {
		return phaseName;
	}
	public void setPhaseName(String phaseName) {
		this.phaseName = phaseName;
	}
	public String getPhaseId() {
		return phaseId;
	}
	public void setPhaseId(String phaseId) {
		this.phaseId = phaseId;
	}
	public String getItemRateName() {
		return itemRateName;
	}
	public void setItemRateName(String itemRateName) {
		this.itemRateName = itemRateName;
	}
	
	public String getItemRate() {
		return itemRate;
	}
	public void setItemRate(String itemRate) {
		this.itemRate = itemRate;
	}
	
	public String getNoOfItems() {
		return noOfItems;
	}
	public void setNoOfItems(String noOfItems) {
		this.noOfItems = noOfItems;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}


}
