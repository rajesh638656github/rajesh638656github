package com.printing.DTO;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.printing.entity.QuotationOrderItem;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
public class QuotationDTO {
	
private long quotationId;
private Date transactionDate = new Date();
private double subTotal;
private double taxAmount;
private double totalAmount;



private List<QuotationOrderItemDTO> quotationOrderItemsDTO;

public QuotationDTO() {
	quotationOrderItemsDTO = new ArrayList<>();
}

public QuotationDTO(Date transactionDate, double subTotal, double taxAmount, double totalAmount) {

	this.transactionDate = transactionDate;
	this.subTotal = subTotal;
	this.taxAmount = taxAmount;
	this.totalAmount = totalAmount;
}

public long getQuotationId() {
	return quotationId;
}

public void setQuotationId(long quotationId) {
	this.quotationId = quotationId;
}

public Date getTransactionDate() {
	return transactionDate;
}

public void setTransactionDate(Date transactionDate) {
	this.transactionDate = transactionDate;
}

public double getSubTotal() {
	return subTotal;
}

public void setSubTotal(double subTotal) {
	this.subTotal = subTotal;
}

public double getTaxAmount() {
	return taxAmount;
}

public void setTaxAmount(double taxAmount) {
	this.taxAmount = taxAmount;
}

public double getTotalAmount() {
	return totalAmount;
}

public void setTotalAmount(double totalAmount) {
	this.totalAmount = totalAmount;
}

public List<QuotationOrderItemDTO> getQuotationOrderItemsDTO() {
	return quotationOrderItemsDTO;
}

public void setQuotationOrderItemsDTO(List<QuotationOrderItemDTO> quotationOrderItemsDTO) {
	this.quotationOrderItemsDTO = quotationOrderItemsDTO;
}

public void add(QuotationOrderItemDTO item) {

    if (item != null) {
        if (quotationOrderItemsDTO == null) {
        	quotationOrderItemsDTO = new ArrayList<>();
        }

        quotationOrderItemsDTO.add(item);
      item.setQuotationDTO(this);
    }
}

public void remove(QuotationOrderItemDTO item) {
   
	quotationOrderItemsDTO.remove(item);
       item.setQuotationDTO(null);
   
}

}

