package com.printing.DTO;

/*import javax.validation.*;
import javax.validation.constraints.Min;*/
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

public class OrderItemUpdateDTO {

	private Long id;
	//@Min(value = 1, message = "Please Select Item")
	private int itemId;
	//@Min(value = 1, message = "Please Select Size")
	private String itemDescription;
	private int sizeId;
	private String note;

	//@NotNull(message = "Quantity cannot be empty.")
	//@Min(value = 1, message = "Please enter valid Quantity")
	//@Range(min = 1)
	private Integer quantity;
	//@Min(value = 1, message = "Please Select Unit")
	private int unitId;
	//@NotNull(message = "Price cannot be empty.")
	//@Min(value = 1, message = "Please enter valid Price")
	//@Digits(integer = 10, fraction = 2, message = "Please enter valid Price")
	private Double price;
	private Double amount;
	

	private int itemStatusId;
	private String comments;
	
	

	public OrderItemUpdateDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public int getSizeId() {
		return sizeId;
	}

	public void setSizeId(int sizeId) {
		this.sizeId = sizeId;
	}
	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public int getUnitId() {
		return unitId;
	}

	public void setUnitId(int unitId) {
		this.unitId = unitId;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public int getItemStatusId() {
		return itemStatusId;
	}


	public void setItemStatusId(int itemStatusId) {
		this.itemStatusId = itemStatusId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	@Override
	public String toString() {
		return "OrderItemDTO [id=" + id + ", itemId=" + itemId + ", sizeId=" + sizeId + ", quantity=" + quantity
				+ ", unitId=" + unitId + ", price=" + price + "]";
	}

}
