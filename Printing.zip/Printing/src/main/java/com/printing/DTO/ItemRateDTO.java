package com.printing.DTO;

import jakarta.persistence.Column;

public class ItemRateDTO {
	private Long itemRateId;
	private Long phaseId;
	private String phaseName;
	private String itemRateName;
	private Double itemRate;
	
	public ItemRateDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getItemRateId() {
		return itemRateId;
	}

	public void setItemRateId(Long itemRateId) {
		this.itemRateId = itemRateId;
	}

	
	
	public Long getPhaseId() {
		return phaseId;
	}

	public void setPhaseId(Long phaseId) {
		this.phaseId = phaseId;
	}

	public String getItemRateName() {
		return itemRateName;
	}

	public void setItemRateName(String itemRateName) {
		this.itemRateName = itemRateName;
	}

	public Double getItemRate() {
		return itemRate;
	}

	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}

	public String getPhaseName() {
		return phaseName;
	}

	public void setPhaseName(String phaseName) {
		this.phaseName = phaseName;
	}

	
	
	
}
