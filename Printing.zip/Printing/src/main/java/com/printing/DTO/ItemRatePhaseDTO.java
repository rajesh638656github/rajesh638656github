package com.printing.DTO;

import jakarta.persistence.Column;

public class ItemRatePhaseDTO {
	private long itemRatePhaseId;
	private String itemRatePhaseName;
	public ItemRatePhaseDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getItemRatePhaseId() {
		return itemRatePhaseId;
	}
	public void setItemRatePhaseId(long itemRatePhaseId) {
		this.itemRatePhaseId = itemRatePhaseId;
	}
	public String getItemRatePhaseName() {
		return itemRatePhaseName;
	}
	public void setItemRatePhaseName(String itemRatePhaseName) {
		this.itemRatePhaseName = itemRatePhaseName;
	}
	
	
	

}
