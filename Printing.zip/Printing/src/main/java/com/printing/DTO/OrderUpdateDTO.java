package com.printing.DTO;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import jakarta.validation.Valid;
//import jakarta.persistence.*;

//import com.printing.entity.OrderItem;

import lombok.*;
import java.util.HashSet;
import java.util.Set;
/*import javax.validation.*;
//import javax.validation.constraints.Min;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;*/

public class OrderUpdateDTO {

	private long id;
	private Date startDate;
	private Date endDate;
	//@Min(0)
	//@Min(value = 1, message = "Please Select Institution")
	//@Min(value = 1, message = "Institution can not be empty")
	private int institutionId;
	private int departmentId;
	private String contactPersonName;
	private String contactNumber;
	private Double total;
	@DecimalMin(value = "0", message = "Profit Margin should be Numeric Value")
	private Double profitMargin;
	private Double totalAmount;

	@NotEmpty(message = "Order Item list cannot be empty.")
    @Valid
	private List<OrderItemUpdateDTO> orderitems;
	
	

	
	public OrderUpdateDTO() {
		orderitems = new ArrayList<>();
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public int getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(int institutionId) {
		this.institutionId = institutionId;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	
	public Double getTotal() {
		return total;
	}

	public void setTotal(Double total) {
		this.total = total;
	}

	public Double getProfitMargin() {
		return profitMargin;
	}

	public void setProfitMargin(Double profitMargin) {
		this.profitMargin = profitMargin;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}


	public List<OrderItemUpdateDTO> getOrderitems() {
		return orderitems;
	}

	public void setOrderitems(List<OrderItemUpdateDTO> orderitems) {
		this.orderitems = orderitems;
	}

	@Override
	public String toString() {
		return "OrderDTO [id=" + id + ", startDate=" + startDate + ", endDate=" + endDate + ", institutionId="
				+ institutionId + ", departmentId=" + departmentId + ", orderitems=" + orderitems + "]";
	}

}
