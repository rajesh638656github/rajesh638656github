package com.printing.DTO;

public class UnitDTO {

	private long unitId;
	private String unitName;

	public UnitDTO() {

	}

	public UnitDTO(long unitId, String unitName) {
		super();
		this.unitId = unitId;
		this.unitName = unitName;
	}

	public long getUnitId() {
		return unitId;
	}

	public void setUnitId(long unitId) {
		this.unitId = unitId;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	@Override
	public String toString() {
		return "Unit [unitId=" + unitId + ", unitName=" + unitName + "]";
	}

}
