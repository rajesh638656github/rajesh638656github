package com.printing.DTO;

import jakarta.persistence.Column;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;

public class ItemPriceDTO {
    private long id;
	private long itemRateId;
	
	@Min(value = 0, message = "Quantity should be Numeric Value")
	private int noOfItems;
	private double amount;
	private long itemRateIdDB;
	private long phaseIdDB;
	private String phaseNameDB;
	private String itemNameDB;
	@DecimalMin(value = "0", message = "Item Rate should be Numeric Value")
	private double itemRate;
	
	private OrderItemDTO orderItemDTO;
	
	
	public ItemPriceDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getItemRateId() {
		return itemRateId;
	}
	public void setItemRateId(long itemRateId) {
		this.itemRateId = itemRateId;
	}
	

	public int getNoOfItems() {
		return noOfItems;
	}


	public void setNoOfItems(int noOfItems) {
		this.noOfItems = noOfItems;
	}


	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public OrderItemDTO getOrderItemDTO() {
		return orderItemDTO;
	}
	public void setOrderItemDTO(OrderItemDTO orderItemDTO) {
		this.orderItemDTO = orderItemDTO;
	}


	public long getItemRateIdDB() {
		return itemRateIdDB;
	}


	public void setItemRateIdDB(long itemRateIdDB) {
		this.itemRateIdDB = itemRateIdDB;
	}

	


	public String getPhaseNameDB() {
		return phaseNameDB;
	}


	public void setPhaseNameDB(String phaseNameDB) {
		this.phaseNameDB = phaseNameDB;
	}


	public long getPhaseIdDB() {
		return phaseIdDB;
	}


	public void setPhaseIdDB(long phaseIdDB) {
		this.phaseIdDB = phaseIdDB;
	}


	public String getItemNameDB() {
		return itemNameDB;
	}


	public void setItemNameDB(String itemNameDB) {
		this.itemNameDB = itemNameDB;
	}


	public double getItemRate() {
		return itemRate;
	}


	public void setItemRate(double itemRateDB) {
		this.itemRate = itemRateDB;
	}
	
	
	
	
}
