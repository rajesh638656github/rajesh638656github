package com.printing.DTO;

public class PhaseNameDTO {
	private int itemRateId;
	private String phaseName;
	public PhaseNameDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PhaseNameDTO(int itemRateId, String phaseName) {
		super();
		this.itemRateId = itemRateId;
		this.phaseName = phaseName;
	}
	public int getItemRateId() {
		return itemRateId;
	}
	public void setItemRateId(int itemRateId) {
		this.itemRateId = itemRateId;
	}
	public String getPhaseName() {
		return phaseName;
	}
	public void setPhaseName(String phaseName) {
		this.phaseName = phaseName;
	}
	
}
