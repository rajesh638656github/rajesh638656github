package com.printing.dao;

import com.printing.DTO.SizeDTO;
import com.printing.model.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class SizeMapper implements RowMapper<SizeDTO> {
	public SizeDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		SizeDTO sizeDTO = new SizeDTO();
		sizeDTO.setSizeId(rs.getLong("SIZE_ID"));
		// System.out.println("Printitng Institution Id" + rs.getLong("SIZE_ID"));
		sizeDTO.setSizeName(rs.getString("SIZE_NAME"));
		// System.out.println("Printitng Institution Name" + rs.getString("SIZE_NAME"));
		return sizeDTO;
	}
}
