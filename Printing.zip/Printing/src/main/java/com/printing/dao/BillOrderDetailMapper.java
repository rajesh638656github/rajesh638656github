package com.printing.dao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;

import com.printing.DTO.BillDTO;
import com.printing.DTO.BillOrderDTO;
public class BillOrderDetailMapper implements RowMapper<BillOrderDTO> {
	public BillOrderDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		BillOrderDTO billOrderDTO = new BillOrderDTO();
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		//int orderid;
				long billId = rs.getLong("bill_id");
				long id = rs.getLong("order_id");
				int orderid = (int) id;
				int orderid1 = Long.valueOf(id).intValue();
				billOrderDTO.setOrderId(Integer.toString(orderid1));
				int intBillIdTemp = (int) billId;
				int intBillId = Long.valueOf(intBillIdTemp).intValue();
			
				billOrderDTO.setBillId(intBillId);
				//billOrderDTO.setTotalAmount(rs.getDouble("total_amount"));
				
				billOrderDTO.setInstitutionName(rs.getString("institution_name"));
			
				//BillDTO.setTaxAmount(rs.getDouble("tax_amount"));
			
				
			
				//BillDTO.setTotalAmount(rs.getDouble("total_amount"));
				
		/* if (rs.getDate("transaction_date") != null) {
			billOrderDTO.setTransactionDate(dateformate.format(rs.getDate("transaction_date")));
		} */
	
		return billOrderDTO;
	}

}
