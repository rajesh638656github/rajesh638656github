package com.printing.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;

import com.printing.DTO.BillDTO;

public class BillDetailMapper implements RowMapper<BillDTO> {
	public BillDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		BillDTO BillDTO = new BillDTO();
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		//int orderid;
				long billId = rs.getLong("bill_id");
				int intBillIdTemp = (int) billId;
				int intBillId = Long.valueOf(intBillIdTemp).intValue();
			
				BillDTO.setBillId(intBillId);
				BillDTO.setTotalAmount(rs.getDouble("total_amount"));
			
				//BillDTO.setTaxAmount(rs.getDouble("tax_amount"));
			
				
			
				//BillDTO.setTotalAmount(rs.getDouble("total_amount"));
				
		if (rs.getDate("transaction_date") != null) {
			BillDTO.setTransactionDate(dateformate.format(rs.getDate("transaction_date")));
		}
	
		return BillDTO;
	}

}
