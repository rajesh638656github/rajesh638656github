package com.printing.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


import com.printing.model.QuotationSubTotalDTO;
public class QuotationSubTotalMapper implements RowMapper<QuotationSubTotalDTO> {
	public QuotationSubTotalDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		QuotationSubTotalDTO quotationSubTotalDTO = new QuotationSubTotalDTO();

		quotationSubTotalDTO.setQuotationId((rs.getInt("Quotation_ID")));
		quotationSubTotalDTO.setQuotationPrice(rs.getDouble("SUBTOTAL"));
		System.out.println("Printitng ORDER ID from OrderIdsMapper()" + rs.getInt("Quotation_ID"));

		return quotationSubTotalDTO;
	}
}


