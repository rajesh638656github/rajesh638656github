package com.printing.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.printing.DTO.InstitutionDTO;
import com.printing.model.Order1;
import com.printing.model.OrderIdsDTO;
import java.text.*;
import java.util.*;

public class OrderIdsMapper implements RowMapper<OrderIdsDTO> {
	public OrderIdsDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		OrderIdsDTO orderIdsDTO = new OrderIdsDTO();

		orderIdsDTO.setOrderId((rs.getInt("ORDER_ID")));
		// System.out.println("Printitng ORDER ID from OrderIdsMapper()" +
		// rs.getInt("ORDER_ID"));

		return orderIdsDTO;
	}
}
