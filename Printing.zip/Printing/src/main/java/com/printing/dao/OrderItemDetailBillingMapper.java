package com.printing.dao;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.printing.DTO.InstitutionDTO;
import com.printing.model.Order1;
import com.printing.model.OrderItemDetailDTO;
import java.text.*;
import java.util.*;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.math.BigDecimal;

public class OrderItemDetailBillingMapper implements RowMapper<OrderItemDetailDTO> {
	public OrderItemDetailDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		OrderItemDetailDTO orderItemDetailDTO = new OrderItemDetailDTO();
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		 DecimalFormat df = new DecimalFormat("#.##");
		//int orderid;
				long id = rs.getLong("ID");
				int orderid = (int) id;
				int orderid1 = Long.valueOf(id).intValue();
				long order_itemid = rs.getLong("order_item_id");
				int orderitemid = Long.valueOf(order_itemid).intValue();
		System.out.println("OrderItemDetailMapper");
		orderItemDetailDTO.setRownum(rs.getString("num_row"));
		System.out.println("Order ID" + orderItemDetailDTO.getOrderId());
		orderItemDetailDTO.setOrderId(Integer.toString(orderid1));
		orderItemDetailDTO.setInstitutionId(Integer.toString(rs.getInt("INSTITUTION_ID")));

		orderItemDetailDTO.setDepartmentId(Integer.toString(rs.getInt("DEPARTMENT_ID")));
		orderItemDetailDTO.setContactPersonName(rs.getString("contact_person_name"));
		orderItemDetailDTO.setContactNumber(rs.getString("contact_number"));
		
		System.out.println("Printing Total befoew Formating" + rs.getDouble("total"));
		//orderItemDetailDTO.setTotal(df.format(rs.getDouble("total")));
		System.out.println("Printing Total befoew Formating" + df.format(rs.getDouble("total")));
		orderItemDetailDTO.setProfitMargin(rs.getString("profit_margin"));
	//	orderItemDetailDTO.setTotalAmount(df.format(rs.getDouble("total_amount")));
		System.out.println("Department Name" + orderItemDetailDTO.getDepartmentName());
		orderItemDetailDTO.setOrderItemId(Integer.toString(orderitemid));
		orderItemDetailDTO.setItemId(Integer.toString(rs.getInt("ITEM_ID")));
		orderItemDetailDTO.setItemDescription(rs.getString("item_description"));
		orderItemDetailDTO.setSizeId(Integer.toString(rs.getInt("SIZE_ID")));
		orderItemDetailDTO.setNote(rs.getString("note"));
		orderItemDetailDTO.setUnitId(Integer.toString(rs.getInt("UNIT_ID")));
		orderItemDetailDTO.setItemstatusId(Integer.toString(rs.getInt("item_status_id")));
		// System.out.println("Printitng ORDER ID " + rs.getInt("ORDER_ID"));
		orderItemDetailDTO.setInstitutionName(rs.getString("INSTITUTION_NAME"));
		orderItemDetailDTO.setDepartmentName(rs.getString("DEPARTMENT_NAME"));
		orderItemDetailDTO.setItemName(rs.getString("ITEM_NAME"));
		orderItemDetailDTO.setSizeName(rs.getString("SIZE_NAME"));
		orderItemDetailDTO.setUnitName(rs.getString("UNIT_NAME"));
		orderItemDetailDTO.setItemStatus(rs.getString("item_status_name"));
		orderItemDetailDTO.setQuantity(Integer.toString(rs.getInt("QUANTITY")));
		
		   // Round values consistently
	    int decimalPlaces = 2;
	    BigDecimal rate = BigDecimal.valueOf(rs.getDouble("PRICE")).setScale(decimalPlaces, RoundingMode.HALF_UP);
	    BigDecimal amount = BigDecimal.valueOf(rs.getDouble("amount")).setScale(decimalPlaces, RoundingMode.HALF_UP);
	    BigDecimal total = BigDecimal.valueOf(rs.getDouble("total")).setScale(decimalPlaces, RoundingMode.HALF_UP);
	    // Verify the calculation
	    BigDecimal calculatedAmount = rate.multiply(BigDecimal.valueOf(rs.getInt("QUANTITY")))
	                                     .setScale(decimalPlaces, RoundingMode.HALF_UP);
	    
	    if (!calculatedAmount.equals(amount)) {
	        // Adjust either rate or amount to maintain consistency
	        amount = calculatedAmount;
	    }
		System.out.println("Printing Total befoew Formating" + rs.getDouble("PRICE"));
		orderItemDetailDTO.setPrice(String.format("%.2f",rate.doubleValue()));
		System.out.println("Printing Total befoew Formating" + df.format(rs.getDouble("PRICE")));
		orderItemDetailDTO.setAmount(String.format("%.2f",amount.doubleValue()));
		orderItemDetailDTO.setTotal(Double.toString(total.doubleValue()));
		orderItemDetailDTO.setComments(rs.getString("comments"));
		// orderDTO.setTransactionDate(rs.getDate("TRANSACTION_DATE"));
		if (rs.getDate("start_date") != null) {
			orderItemDetailDTO.setStartDate(dateformate.format(rs.getDate("start_date")));
		}
		if (rs.getDate("end_date") != null) {
			orderItemDetailDTO.setEndDate(dateformate.format(rs.getDate("end_date")));
		}
		// ordermultipleDTO.setStartDate(dateformate.format(rs.getDate("start_date")));

		return orderItemDetailDTO;
	}

}
