package com.printing.dao;
import com.printing.DTO.ItemRateDTO;
import com.printing.DTO.ItemDTO;
import com.printing.model.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class ItemRateMapper implements RowMapper<ItemRateDTO> {
	
	public ItemRateDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		ItemRateDTO itemRateDTO = new ItemRateDTO();
		itemRateDTO.setPhaseName(rs.getString("item_rate_phase_name"));
		itemRateDTO.setItemRateId(rs.getLong("ITEM_RATE_ID"));
		// System.out.println("Printitng Institution Id" + rs.getLong("ITEM_ID"));
		itemRateDTO.setItemRateName(rs.getString("ITEM_RATE_NAME"));
		itemRateDTO.setItemRate(rs.getDouble("ITEM_RATE"));
		// System.out.println("Printitng Institution Name" + rs.getString("ITEM_NAME"));
		return itemRateDTO;
	}

}
