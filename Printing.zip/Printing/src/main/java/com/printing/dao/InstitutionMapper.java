package com.printing.dao;

import com.printing.DTO.InstitutionDTO;
import com.printing.model.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class InstitutionMapper implements RowMapper<InstitutionDTO> {
	public InstitutionDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		InstitutionDTO institutionDTO = new InstitutionDTO();
		institutionDTO.setInstitutionId(rs.getInt("INSTITUTION_ID"));
		// System.out.println("Printitng Institution Id" +
		// rs.getLong("INSTITUTION_ID"));
		institutionDTO.setInstitutionName(rs.getString("INSTITUTION_NAME"));
		// System.out.println("Printitng Institution Name" +
		// rs.getString("INSTITUTION_NAME"));
		return institutionDTO;
	}
}