package com.printing.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;

import com.printing.DTO.OrderMasterDTO;

public class OrderMasterDetailMapper implements RowMapper<OrderMasterDTO> {
	public OrderMasterDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		OrderMasterDTO OrderMasterDTO = new OrderMasterDTO();
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		//int orderid;
				long id = rs.getLong("ID");
				int orderid = (int) id;
				int orderid1 = Long.valueOf(id).intValue();
			
				OrderMasterDTO.setOrderId(Integer.toString(orderid1));
				OrderMasterDTO.setInstitutionId(Integer.toString(rs.getInt("INSTITUTION_ID")));
				OrderMasterDTO.setDepartmentId(Integer.toString(rs.getInt("DEPARTMENT_ID")));
				OrderMasterDTO.setInstitutionName(rs.getString("INSTITUTION_NAME"));
				OrderMasterDTO.setDepartmentName(rs.getString("DEPARTMENT_NAME"));
				OrderMasterDTO.setContactPersonName(rs.getString("contact_person_name"));
				OrderMasterDTO.setContactNumber(rs.getString("contact_number"));
				OrderMasterDTO.setTotal(Double.toString(rs.getDouble("total")));
						
				OrderMasterDTO.setProfitMargin(Double.toString(rs.getDouble("profit_margin")));
			//	OrderMasterDTO.setTotalAmount(Double.toString(rs.getDouble("total_amount")));
				
				System.out.println("total" + OrderMasterDTO.getTotal());
				System.out.println("profit margin" + OrderMasterDTO.getProfitMargin());
			//	System.out.println("total amount" + OrderMasterDTO.getTotalAmount());
				
				
		if (rs.getDate("start_date") != null) {
			OrderMasterDTO.setStartDate(dateformate.format(rs.getDate("start_date")));
		}
		if (rs.getDate("end_date") != null) {
			OrderMasterDTO.setEndDate(dateformate.format(rs.getDate("end_date")));
		}
		// ordermultipleDTO.setStartDate(dateformate.format(rs.getDate("start_date")));

		return OrderMasterDTO;
	}

}
