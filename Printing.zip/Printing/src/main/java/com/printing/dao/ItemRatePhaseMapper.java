package com.printing.dao;

import com.printing.DTO.ItemRatePhaseDTO;
import com.printing.model.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
public class ItemRatePhaseMapper implements RowMapper<ItemRatePhaseDTO>{
	public ItemRatePhaseDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		ItemRatePhaseDTO itemRatePhaseDTO = new ItemRatePhaseDTO();
		itemRatePhaseDTO.setItemRatePhaseId(rs.getInt("item_rate_Phase_id"));
		// System.out.println("Printitng Institution Id" +
		// rs.getLong("INSTITUTION_ID"));
		itemRatePhaseDTO.setItemRatePhaseName(rs.getString("item_rate_phase_name"));
		// System.out.println("Printitng Institution Name" +
		// rs.getString("INSTITUTION_NAME"));
		return itemRatePhaseDTO;
	}

}
