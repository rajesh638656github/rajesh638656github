package com.printing.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.printing.model.OrderSubTotalDTO;

public class OrderSubTotalMapper implements RowMapper<OrderSubTotalDTO> {
	public OrderSubTotalDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		OrderSubTotalDTO orderSubTotalDTO = new OrderSubTotalDTO();

		orderSubTotalDTO.setOrderId((rs.getInt("ORDER_ID")));
		orderSubTotalDTO.setOrderPrice(rs.getDouble("SUBTOTAL"));
		System.out.println("Printitng ORDER ID from OrderIdsMapper()" + rs.getInt("ORDER_ID"));

		return orderSubTotalDTO;
	}
}
