package com.printing.dao;

import com.printing.DTO.ItemDTO;
import com.printing.model.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class ItemMapper implements RowMapper<ItemDTO> {
	public ItemDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		ItemDTO itemDTO = new ItemDTO();
		itemDTO.setItemId(rs.getLong("ITEM_ID"));
		// System.out.println("Printitng Institution Id" + rs.getLong("ITEM_ID"));
		itemDTO.setItemName(rs.getString("ITEM_NAME"));
		// System.out.println("Printitng Institution Name" + rs.getString("ITEM_NAME"));
		return itemDTO;
	}
}
