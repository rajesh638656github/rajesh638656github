package com.printing.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.*;
import java.sql.Types;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementCallback;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.printing.DTO.DepartmentDTO;
import com.printing.DTO.OrderMasterDTO;
import com.printing.DTO.InstitutionDTO;
import com.printing.DTO.ItemDTO;
import com.printing.DTO.ItemStatusDTO;
import com.printing.DTO.BillDTO;
import com.printing.DTO.BillOrderDTO;
import com.printing.dao.BillOrderDetailMapper;
import com.printing.DTO.SizeDTO;
import com.printing.DTO.UnitDTO;
import com.printing.DTO.ItemRateDTO;
import com.printing.DTO.ItemRatePhaseDTO;
import com.printing.dao.InstitutionMapper;
import com.printing.DTO.OrderItemPriceDTO;
import com.printing.dao.OrderItemPriceDetailMapper;
import com.printing.model.*;
import com.printing.entity.OrderItem;
import com.printing.entity.Order;

@Component
public class PopulateOrderScreenServiceDAO {

	// @Autowired
	// PreparedStatement ps;
	@Autowired
	JdbcTemplate jdbc;
	@Autowired
	NamedParameterJdbcTemplate namedjdbcTemplateObject;

	public List<InstitutionDTO> findAllInstitutions() throws Exception {
		try {

			return jdbc.query("SELECT INSTITUTION_ID,INSTITUTION_NAME from INSTITUTION ORDER BY INSTITUTION_NAME", new InstitutionMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	public List<DepartmentDTO> findAllDepartments() throws Exception {
		try {

			
			return jdbc.query("SELECT DEPARTMENT_ID,DEPARTMENT_NAME from DEPARTMENT ORDER BY DEPARTMENT_NAME ", new DepartmentMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	
	
	public List<ItemDTO> findAllItems() throws Exception {
		try {

			
			return jdbc.query("SELECT ITEM_ID, ITEM_NAME from ITEM ORDER BY ITEM_NAME", new ItemMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}


	public List<SizeDTO> findAllSizes() throws Exception {
		try {

			
			return jdbc.query("SELECT SIZE_ID,SIZE_NAME from SIZE ORDER BY SIZE_NAME", new SizeMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	public List<UnitDTO> findAllUnits() throws Exception {
		try {

			
			return jdbc.query("SELECT UNIT_ID,UNIT_NAME from UNIT ORDER BY UNIT_NAME", new UnitMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	public List<ItemStatusDTO> findAllItemStatus() throws Exception {
		try {

			
			return jdbc.query("SELECT ITEM_STATUS_ID, ITEM_STATUS_NAME from ITEM_STATUS ORDER BY ITEM_STATUS_NAME", new ItemStatusMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	public List<ItemRateDTO> findAllItemRates() throws Exception {
		try {

			
			return jdbc.query("SELECT IT.ITEM_RATE_ID, IT.item_rate_phase_id, IT.ITEM_RATE_NAME,IT.ITEM_RATE,IRPN.ITEM_RATE_PHASE_NAME from ITEM_RATE IT "
					+ "JOIN ITEM_RATE_PHASE IRPN ON IRPN.item_rate_phase_id = IT.item_rate_phase_id ORDER BY IT.item_rate_phase_id", new ItemRateMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	public List<ItemRatePhaseDTO> findAllItemRatePhase() throws Exception {
		try {

			
			return jdbc.query("SELECT ITEM_RATE_PHASE_ID, item_rate_phase_name from ITEM_RATE_PHASE ORDER BY ITEM_RATE_PHASE_ID", new ItemRatePhaseMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}


	public List<OrderItemDetailDTO> findQuotationOrderItemDetails(List<Long> orderIds,Long quotationId) throws Exception {
		try {

			
			SqlParameterSource parameters1 = new MapSqlParameterSource().addValue("orderIds", orderIds).addValue("quotationId", quotationId);
		
		//	SqlParameterSource parameters1 = new MapSqlParameterSource("orderIds", orderIds);
			//SqlParameterSource parameters2 = new MapSqlParameterSource("quotationId", quotationId);
			
			String selectQuery = "SELECT o.id,o.INSTITUTION_ID,o.DEPARTMENT_ID,o.contact_person_name,o.contact_number,o.total_amount,oi.id as order_item_id,oi.ITEM_ID,oi.amount,I.INSTITUTION_NAME, D.DEPARTMENT_NAME,IT.ITEM_NAME,oi.QUANTITY,oi.PRICE,o.start_date,o.end_date "
					+ "FROM orders o " + "JOIN quotation_order_items oi " + "ON oi.order_id = o.id "
					+ "JOIN INSTITUTION I " + "ON o.INSTITUTION_ID = I.INSTITUTION_ID " + "JOIN DEPARTMENT D "
					+ "ON o.DEPARTMENT_ID = d.DEPARTMENT_ID " + "JOIN ITEM IT " + "ON oi.ITEM_ID = IT.ITEM_ID "
				//	+ "JOIN SIZE S " + "ON oi.SIZE_ID = S.SIZE_ID " + "JOIN UNIT U "
				//	+ "ON oi.UNIT_ID = U.UNIT_ID " 
					//+ "JOIN item_status its " + "ON oi.item_status_id = its.item_status_id "
					+ "WHERE o.id IN (:orderIds) and oi.quotation_id in (:quotationId)";

			return namedjdbcTemplateObject.query(selectQuery,parameters1, new QuotationOrderItemDetailMapper());

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	public List<OrderItemDetailDTO> findOrderItemDetails(List<Long> orderIds) throws Exception {
		try {

			SqlParameterSource parameters = new MapSqlParameterSource("orderIds", orderIds);

			return namedjdbcTemplateObject.query(
					"SELECT  ROW_NUMBER() OVER() AS num_row,o.id,o.INSTITUTION_ID,o.DEPARTMENT_ID,o.contact_person_name,o.contact_number,o.total,o.profit_margin,o.total_amount,oi.id as order_item_id,oi.ITEM_ID,oi.item_description,oi.SIZE_ID,oi.note,oi.UNIT_ID,oi.item_status_id,its.item_status_name ,I.INSTITUTION_NAME, D.DEPARTMENT_NAME,IT.ITEM_NAME,S.SIZE_NAME,U.UNIT_NAME,oi.QUANTITY,oi.PRICE,oi.AMOUNT,oi.COMMENTS,o.start_date,o.end_date "
							+ "FROM orders o " + "JOIN order_items oi " + "ON oi.order_id = o.id "
							+ "JOIN INSTITUTION I " + "ON o.INSTITUTION_ID = I.INSTITUTION_ID " + "JOIN DEPARTMENT D "
							+ "ON o.DEPARTMENT_ID = d.DEPARTMENT_ID " + "JOIN ITEM IT " + "ON oi.ITEM_ID = IT.ITEM_ID "
							+ "JOIN SIZE S " + "ON oi.SIZE_ID = S.SIZE_ID " + "JOIN UNIT U "
							+ "ON oi.UNIT_ID = U.UNIT_ID " 
							+ "JOIN item_status its " + "ON oi.item_status_id = its.item_status_id "
							+ "WHERE o.id IN (:orderIds) AND status IN ('active') ORDER BY ORDER_ID",
					parameters, new OrderItemDetailMapper());

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	public List<OrderItemDetailDTO> findOrderItemDetailsforBilling(List<Long> orderIds) throws Exception {
		try {

			SqlParameterSource parameters = new MapSqlParameterSource("orderIds", orderIds);

			return namedjdbcTemplateObject.query(
					"SELECT  ROW_NUMBER() OVER() AS num_row,o.id,o.INSTITUTION_ID,o.DEPARTMENT_ID,o.contact_person_name,o.contact_number,o.total,o.profit_margin,o.total_amount,oi.id as order_item_id,oi.ITEM_ID,oi.item_description,oi.SIZE_ID,oi.note,oi.UNIT_ID,oi.item_status_id,its.item_status_name ,I.INSTITUTION_NAME, D.DEPARTMENT_NAME,IT.ITEM_NAME,S.SIZE_NAME,U.UNIT_NAME,oi.QUANTITY,oi.PRICE,oi.AMOUNT,oi.COMMENTS,o.start_date,o.end_date "
							+ "FROM orders o " + "JOIN order_items oi " + "ON oi.order_id = o.id "
							+ "JOIN INSTITUTION I " + "ON o.INSTITUTION_ID = I.INSTITUTION_ID " + "JOIN DEPARTMENT D "
							+ "ON o.DEPARTMENT_ID = d.DEPARTMENT_ID " + "JOIN ITEM IT " + "ON oi.ITEM_ID = IT.ITEM_ID "
							+ "JOIN SIZE S " + "ON oi.SIZE_ID = S.SIZE_ID " + "JOIN UNIT U "
							+ "ON oi.UNIT_ID = U.UNIT_ID " 
							+ "JOIN item_status its " + "ON oi.item_status_id = its.item_status_id "
							+ "WHERE o.id IN (:orderIds) AND status IN ('active') ORDER BY ORDER_ID",
					parameters, new OrderItemDetailBillingMapper());

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	public List<OrderItemDetailDTO> findOrderItemDetailsForDuplicateBill(List<Long> orderIds) throws Exception {
		try {

			SqlParameterSource parameters = new MapSqlParameterSource("orderIds", orderIds);

			return namedjdbcTemplateObject.query(
					"SELECT ROW_NUMBER() OVER() AS num_row,o.id,o.INSTITUTION_ID,o.DEPARTMENT_ID,o.contact_person_name,o.contact_number,o.total,o.profit_margin,o.total_amount,oi.id as order_item_id,oi.ITEM_ID,oi.item_description,oi.SIZE_ID,oi.note,oi.UNIT_ID,oi.item_status_id,its.item_status_name ,I.INSTITUTION_NAME, D.DEPARTMENT_NAME,IT.ITEM_NAME,S.SIZE_NAME,U.UNIT_NAME,oi.QUANTITY,oi.PRICE,oi.AMOUNT,oi.COMMENTS,o.start_date,o.end_date "
							+ "FROM orders o " + "JOIN order_items oi " + "ON oi.order_id = o.id "
							+ "JOIN INSTITUTION I " + "ON o.INSTITUTION_ID = I.INSTITUTION_ID " + "JOIN DEPARTMENT D "
							+ "ON o.DEPARTMENT_ID = d.DEPARTMENT_ID " + "JOIN ITEM IT " + "ON oi.ITEM_ID = IT.ITEM_ID "
							+ "JOIN SIZE S " + "ON oi.SIZE_ID = S.SIZE_ID " + "JOIN UNIT U "
							+ "ON oi.UNIT_ID = U.UNIT_ID " 
							+ "JOIN item_status its " + "ON oi.item_status_id = its.item_status_id "
							//+ "WHERE o.id IN (:orderIds) AND status IN ('active') ORDER BY ORDER_ID",
							+ "WHERE o.id IN (:orderIds) ORDER BY ORDER_ID",
					parameters, new OrderItemDetailBillingMapper());

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	

	public List<OrderItemDetailDTO> findAllActiveOrderItemDetails() throws Exception {
		try {

		//	SqlParameterSource parameters = new MapSqlParameterSource("orderIds", orderIds);
			
			String sql= "SELECT ROW_NUMBER() OVER() AS num_row,o.id,o.INSTITUTION_ID,o.DEPARTMENT_ID,o.contact_person_name,o.contact_number,o.total,o.profit_margin,o.total_amount,oi.id as order_item_id,oi.ITEM_ID,oi.item_description,oi.SIZE_ID,oi.note,oi.UNIT_ID,oi.item_status_id,its.item_status_name ,I.INSTITUTION_NAME, D.DEPARTMENT_NAME,IT.ITEM_NAME,S.SIZE_NAME,U.UNIT_NAME,oi.QUANTITY,oi.PRICE,oi.AMOUNT,oi.AMOUNT/oi.QUANTITY as billing_item_rate,oi.COMMENTS,o.start_date,o.end_date "
					+ "FROM orders o " + "JOIN order_items oi " + "ON oi.order_id = o.id "
					+ "JOIN INSTITUTION I " + "ON o.INSTITUTION_ID = I.INSTITUTION_ID " + "JOIN DEPARTMENT D "
					+ "ON o.DEPARTMENT_ID = d.DEPARTMENT_ID " + "JOIN ITEM IT " + "ON oi.ITEM_ID = IT.ITEM_ID "
					+ "JOIN SIZE S " + "ON oi.SIZE_ID = S.SIZE_ID " + "JOIN UNIT U "
					+ "ON oi.UNIT_ID = U.UNIT_ID " 
					+ "JOIN item_status its " + "ON oi.item_status_id = its.item_status_id "
					+ "WHERE status IN ('active') ORDER BY ORDER_ID";
			
			System.out.println("printing findAllActiveOrderItemDetails Query" + sql);

			return jdbc.query(
					sql, new OrderItemDetailMapper());

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	
	public List<BillDTO> findRevenueDetails(Date startDate,Date endDate) throws Exception {
		try {

			//SqlParameterSource parameters = new MapSqlParameterSource("orderIds", orderIds);
			
		java.sql.Date sqlSatrtDate =  new java.sql.Date(startDate.getTime());
		java.sql.Date sqlEndDate =  new java.sql.Date(endDate.getTime());

			return jdbc.query(
					
					"SELECT b.bill_id,b.transaction_date,b.total_amount "
							+ "FROM bill b "
							+ "WHERE (b.transaction_date between ? and ? )",
					 new BillDetailMapper(),sqlSatrtDate,sqlEndDate);


		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	public List<BillDTO> findBillByInstitution(Date startDate,Date endDate,long institutionId) throws Exception {
		try {

			//SqlParameterSource parameters = new MapSqlParameterSource("orderIds", orderIds);
		if 	(startDate != null) {
		java.sql.Date sqlSatrtDate =  new java.sql.Date(startDate.getTime());
		}
		if (endDate != null) {
		java.sql.Date sqlEndDate =  new java.sql.Date(endDate.getTime());
		}
	/*	String selectStatement = "SELECT * FROM bill b "
				+ "JOIN bill_order bo on b.bill_id = bo.bill_id "
				+ "jOIN orders o on bo.order_id = o.id "
				+ "JOIN institution i  on o.institution_id = i.institution_id "
				+ "WHERE i.institution_id = ? AND (b.transaction_date between ? and ? ) "; */

			return jdbc.query(
					
					"SELECT distinct i.institution_name,b.bill_id,b.transaction_date,b.total_amount FROM bill b "
					+ "JOIN bill_order bo on b.bill_id = bo.bill_id "
					+ "jOIN orders o on bo.order_id = o.id "
					+ "JOIN institution i  on o.institution_id = i.institution_id "
				//	+ "WHERE i.institution_id = ? AND (b.transaction_date between ? and ? )",
					+ "WHERE i.institution_id = ? ",
					 new BillReportMapper(),institutionId);
					 //new BillReportMapper(),institutionId,sqlSatrtDate,sqlEndDate);


		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	public List<BillDTO> findBillByInstitutionOrBillId(BillSearchDTO billSearchDTO) throws Exception {
		try {

			String billIdString = billSearchDTO.getBillId();
			String institutitonIdStr = billSearchDTO.getInstitutionId();
			
			String finalsqlquery = null;
			long billId = 0;
			int institutionId = 0;
			int departmentId = 0;
			List<BillDTO> orderSearchBillingDTOList = null;

			if (!billSearchDTO.getBillId().isEmpty()) {
				billId = Long.parseLong(billSearchDTO.getBillId());
			}
			if (!billSearchDTO.getInstitutionId().isEmpty()) {
				institutionId = Integer.parseInt(billSearchDTO.getInstitutionId());
			}
			
			String selectStatement = "SELECT distinct b.bill_id,i.institution_name,b.total_amount FROM bill b "
					+ "JOIN bill_order bo on b.bill_id = bo.bill_id "
					+ "jOIN orders o on bo.order_id = o.id "
					+ "JOIN institution i  on o.institution_id = i.institution_id ";
			
			String whereStatement = null;
			if (!billSearchDTO.getBillId().isEmpty()) {
				whereStatement = "WHERE b.bill_id = ? AND o.bill_draft= 'no'";
				System.out.println("Printing Order Id" + billId);
				System.out.println("Printing Sql Query in Order Id Block" + whereStatement);
				finalsqlquery = selectStatement.concat(whereStatement);
				System.out.println("Printing Sql Query in Order Id Block" + finalsqlquery);
				return orderSearchBillingDTOList = jdbc.query(finalsqlquery, new BillReportMapper(),billId);

			}
			
			if (billSearchDTO.getBillId().isEmpty()
					&& !billSearchDTO.getInstitutionId().equalsIgnoreCase("0")
					) {
				whereStatement = "WHERE o.institution_id = ? AND o.bill_draft= 'no'";
				System.out.println("Printing institutiton Id " + institutionId);
				finalsqlquery = selectStatement.concat(whereStatement);
				System.out.println("Printing Sql Query in Order Id Block" + finalsqlquery);
				return orderSearchBillingDTOList = jdbc.query(finalsqlquery, new BillReportMapper(),institutionId);
			}

		/*	return jdbc.query(
					
					"SELECT distinct i.institution_name,b.bill_id,b.transaction_date,b.total_amount,bo.order_id FROM bill b "
					+ "JOIN bill_order bo on b.bill_id = bo.bill_id "
					+ "jOIN orders o on bo.order_id = o.id "
					+ "JOIN institution i  on o.institution_id = i.institution_id "
				//	+ "WHERE i.institution_id = ? AND (b.transaction_date between ? and ? )",
					+ "WHERE i.institution_id = ? ",
					 new BillOrderDetailMapper(),billId);*/
					 //new BillReportMapper(),institutionId,sqlSatrtDate,sqlEndDate);
			return orderSearchBillingDTOList;



		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	
	
	public List<BillDTO> findBillByInstitutionOrBillIdForDuplicateBill(BillSearchDTO billSearchDTO) throws Exception {
		try {

			String billIdString = billSearchDTO.getBillId();
			String institutitonIdStr = billSearchDTO.getInstitutionId();
			
			String finalsqlquery = null;
			long billId = 0;
			int institutionId = 0;
			int departmentId = 0;
			List<BillDTO> orderSearchBillingDTOList = null;

			if (!billSearchDTO.getBillId().isEmpty()) {
				billId = Long.parseLong(billSearchDTO.getBillId());
			}
			if (!billSearchDTO.getInstitutionId().isEmpty()) {
				institutionId = Integer.parseInt(billSearchDTO.getInstitutionId());
			}
			
			String selectStatement = "SELECT distinct b.bill_id,i.institution_name,b.total_amount FROM bill b "
					+ "JOIN bill_order bo on b.bill_id = bo.bill_id "
					+ "jOIN orders o on bo.order_id = o.id "
					+ "JOIN institution i  on o.institution_id = i.institution_id ";
			
			String whereStatement = null;
			if (!billSearchDTO.getBillId().isEmpty()) {
				//whereStatement = "WHERE b.bill_id = ? AND o.bill_draft= 'no'";
				whereStatement = "WHERE b.bill_id = ? ";
				System.out.println("Printing Order Id" + billId);
				System.out.println("Printing Sql Query in Order Id Block" + whereStatement);
				finalsqlquery = selectStatement.concat(whereStatement);
				System.out.println("Printing Sql Query in Order Id Block" + finalsqlquery);
				return orderSearchBillingDTOList = jdbc.query(finalsqlquery, new BillReportMapper(),billId);

			}
			
			if (billSearchDTO.getBillId().isEmpty()
					&& !billSearchDTO.getInstitutionId().equalsIgnoreCase("0")
					) {
				//whereStatement = "WHERE o.institution_id = ? AND o.bill_draft= 'no'";
				whereStatement = "WHERE o.institution_id = ? ";
				System.out.println("Printing institutiton Id " + institutionId);
				finalsqlquery = selectStatement.concat(whereStatement);
				System.out.println("Printing Sql Query in Order Id Block" + finalsqlquery);
				return orderSearchBillingDTOList = jdbc.query(finalsqlquery, new BillReportMapper(),institutionId);
			}

		/*	return jdbc.query(
					
					"SELECT distinct i.institution_name,b.bill_id,b.transaction_date,b.total_amount,bo.order_id FROM bill b "
					+ "JOIN bill_order bo on b.bill_id = bo.bill_id "
					+ "jOIN orders o on bo.order_id = o.id "
					+ "JOIN institution i  on o.institution_id = i.institution_id "
				//	+ "WHERE i.institution_id = ? AND (b.transaction_date between ? and ? )",
					+ "WHERE i.institution_id = ? ",
					 new BillOrderDetailMapper(),billId);*/
					 //new BillReportMapper(),institutionId,sqlSatrtDate,sqlEndDate);
			return orderSearchBillingDTOList;



		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	public List<BillOrderDTO> findBillOrderDetailByBillId(long billId)  throws Exception {
		try {

			
			
			String selectStatement = "SELECT distinct b.bill_id,i.institution_name,bo.order_id FROM bill b "
					+ "JOIN bill_order bo on b.bill_id = bo.bill_id "
					+ "jOIN orders o on bo.order_id = o.id "
					+ "JOIN institution i  on o.institution_id = i.institution_id "
			        + "WHERE b.bill_id = ? ";
			System.out.println("Printing Bill Order Detail By Bill ID Query" + selectStatement);
			
			return jdbc.query(selectStatement, new BillOrderDetailMapper(),billId);


		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	public List<OrderItemPriceDTO> findOrderItemPriceDetailByOrderItemId(List<Long> orderItemIds)  throws Exception {
		try {

			SqlParameterSource parameters = new MapSqlParameterSource("orderItemIds", orderItemIds);
			
			return namedjdbcTemplateObject.query("SELECT oip.order_item_id,it.item_name,oip.id,oip.item_rate_id,oip.no_of_items,oip.amount,ir.item_rate_phase_id,IRPN.item_rate_phase_name,ir.item_rate_name,oip.item_rate FROM order_item_price oip "
					+ "JOIN item_rate ir on oip.item_rate_id = ir.item_rate_id "
					+ "JOIN order_items oi on oip.order_item_id = oi.id "
					+ "JOIN item it ON oi.item_id = it.item_id "
					+ "JOIN ITEM_RATE_PHASE IRPN ON IRPN.item_rate_phase_id = ir.item_rate_phase_id "
					+ "where oip.order_item_id IN (:orderItemIds) ",parameters,new OrderItemPriceDetailMapper());
			//System.out.println("Printing Order Item Price Detail Query" + selectStatement);
			
			//return jdbc.query(selectStatement, new OrderItemPriceDetailMapper(),orderItemId);


		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	
	public List<BillOrderDTO> findBillOrderDetail()  throws Exception {
		try {

			
			
			String selectStatement = "SELECT distinct b.bill_id,i.institution_name,bo.order_id FROM bill b "
					+ "JOIN bill_order bo on b.bill_id = bo.bill_id "
					+ "jOIN orders o on bo.order_id = o.id "
					+ "JOIN institution i  on o.institution_id = i.institution_id where bill_draft='yes' and status='active'";
			       
			
			return jdbc.query(selectStatement, new BillOrderDetailMapper());


		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	
	public List<OrderMasterDTO> findAllActiveOrders() throws Exception {
		try {

		
			return jdbc.query(
					//"SELECT o.id,o.INSTITUTION_ID,o.DEPARTMENT_ID,oi.id as order_item_id,oi.ITEM_ID,oi.SIZE_ID,oi.UNIT_ID,I.INSTITUTION_NAME, D.DEPARTMENT_NAME,IT.ITEM_NAME,S.SIZE_NAME,U.UNIT_NAME,oi.QUANTITY,oi.PRICE,oi.COMMENTS,o.start_date,o.end_date "
					"SELECT o.id,o.INSTITUTION_ID,o.DEPARTMENT_ID,I.INSTITUTION_NAME, D.DEPARTMENT_NAME,o.start_date,o.end_date,o.contact_person_name,o.contact_number,o.total,o.profit_margin,o.total_amount "
							+ "FROM orders o "
							//+ "JOIN order_items oi " + "ON oi.order_id = o.id "
							+ "JOIN INSTITUTION I " + "ON o.INSTITUTION_ID = I.INSTITUTION_ID " + "JOIN DEPARTMENT D "
							+ "ON o.DEPARTMENT_ID = d.DEPARTMENT_ID "
							//+ "JOIN ITEM IT " + "ON oi.ITEM_ID = IT.ITEM_ID "
							//+ "JOIN SIZE S " + "ON oi.SIZE_ID = S.SIZE_ID " 
							//+ "JOIN UNIT U " + "ON oi.UNIT_ID = U.UNIT_ID " 
							+ "WHERE status IN ('active') ORDER BY ID",
					 new OrderMasterDetailMapper());

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	public List<OrderItemDetailDTO> findAllOrdersByItemType(List<Integer> itemIds) throws Exception {
		try {

			SqlParameterSource parameters = new MapSqlParameterSource("itemIds", itemIds);

			
			return namedjdbcTemplateObject.query(
					"SELECT o.id,o.INSTITUTION_ID,o.DEPARTMENT_ID,oi.id as order_item_id,oi.ITEM_ID,oi.item_description,oi.SIZE_ID,oi.note,oi.UNIT_ID,I.INSTITUTION_NAME, D.DEPARTMENT_NAME,IT.ITEM_NAME,S.SIZE_NAME,U.UNIT_NAME,oi.QUANTITY,oi.PRICE,oi.AMOUNT,oi.COMMENTS,oi.item_status_id,its.item_status_name,o.start_date,o.end_date,o.contact_person_name,o.contact_number,o.total_amount,o.total,o.profit_margin "
							+ "FROM orders o " + "JOIN order_items oi " + "ON oi.order_id = o.id "
							+ "JOIN INSTITUTION I " + "ON o.INSTITUTION_ID = I.INSTITUTION_ID " + "JOIN DEPARTMENT D "
							+ "ON o.DEPARTMENT_ID = d.DEPARTMENT_ID " + "JOIN ITEM IT " + "ON oi.ITEM_ID = IT.ITEM_ID "
							+ "JOIN SIZE S " + "ON oi.SIZE_ID = S.SIZE_ID " + "JOIN UNIT U "
							+ "ON oi.UNIT_ID = U.UNIT_ID "
							+ "JOIN item_status its " + "ON oi.item_status_id = its.item_status_id "
							+ "WHERE oi.ITEM_ID IN (:itemIds) ORDER BY ORDER_ID",
					parameters, new OrderItemDetailMapper());

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	public List<OrderMasterDTO> findOrderMasterDetails(List<Long> orderIds) throws Exception {
		try {

			SqlParameterSource parameters = new MapSqlParameterSource("orderIds", orderIds);

			
			return namedjdbcTemplateObject.query(
					"SELECT o.id,o.INSTITUTION_ID,o.DEPARTMENT_ID,I.INSTITUTION_NAME, D.DEPARTMENT_NAME,o.contact_person_name,o.contact_number,o.start_date,o.end_date,o.total_amount,o.total,o.profit_margin "
							+ "FROM orders o "
							+ "JOIN INSTITUTION I " + "ON o.INSTITUTION_ID = I.INSTITUTION_ID " + "JOIN DEPARTMENT D "
							+ "ON o.DEPARTMENT_ID = d.DEPARTMENT_ID "
						    + "WHERE o.id IN (:orderIds) ORDER BY ID",
					parameters, new OrderMasterDetailMapper());

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	public List<OrderSearchDTO> findOrderByOrderIdorInstitutionIdorDepartmentId(OrderSearchDTO orderSearchBillingDTO)
			throws Exception {
		try {
			
			String orderIdString = orderSearchBillingDTO.getOrderId();
			String institutitonIdStr = orderSearchBillingDTO.getInstitutionId();
			String departmentIdStr = orderSearchBillingDTO.getDepartmentId();
			String finalsqlquery = null;
			long orderId = 0;
			int institutionId = 0;
			int departmentId = 0;
			List<OrderSearchDTO> orderSearchBillingDTOList = null;

			if (!orderSearchBillingDTO.getOrderId().isEmpty()) {
				orderId = Long.parseLong(orderSearchBillingDTO.getOrderId());
			}
			if (!orderSearchBillingDTO.getInstitutionId().isEmpty()) {
				institutionId = Integer.parseInt(orderSearchBillingDTO.getInstitutionId());
			}
			if (!orderSearchBillingDTO.getDepartmentId().isEmpty()) {
				departmentId = Integer.parseInt(orderSearchBillingDTO.getDepartmentId());
			}
			
			String selectStatement = "SELECT o.id,o.INSTITUTION_ID,o.DEPARTMENT_ID,I.INSTITUTION_NAME, D.DEPARTMENT_NAME,o.start_date,o.end_date "
					+ "FROM orders o " + "JOIN INSTITUTION I " + "ON o.INSTITUTION_ID = I.INSTITUTION_ID "
					+ "JOIN DEPARTMENT D " + "ON o.DEPARTMENT_ID = d.DEPARTMENT_ID ";

			String whereStatement = null;

			

			if (!orderSearchBillingDTO.getOrderId().isEmpty()) {
				whereStatement = "WHERE o.id = ? and o.status='active' and o.bill_draft='no'" + "ORDER BY id ";
				System.out.println("Printing Order Id" + orderId);
				System.out.println("Printing Sql Query in Order Id Block" + whereStatement);
				finalsqlquery = selectStatement.concat(whereStatement);
				System.out.println("Printing Sql Query in Order Id Block" + finalsqlquery);
				return orderSearchBillingDTOList = jdbc.query(finalsqlquery, new OrderSearchForBillingMapper(),
						orderId);

			}

			if (orderSearchBillingDTO.getOrderId().isEmpty()
					&& !orderSearchBillingDTO.getInstitutionId().equalsIgnoreCase("0")
					&& !orderSearchBillingDTO.getDepartmentId().equalsIgnoreCase("1")) {
				whereStatement = "WHERE o.institution_id = ? and o.department_id = ? and o.status='active' and o.bill_draft='no'" + "ORDER BY id ";
				System.out.println("Printing institutiton Id and department id" + institutionId + departmentId);
				finalsqlquery = selectStatement.concat(whereStatement);
				System.out.println("Printing Sql Query in Order Id Block" + finalsqlquery);
				return orderSearchBillingDTOList = jdbc.query(finalsqlquery, new OrderSearchForBillingMapper(),
						institutionId, departmentId);
			}

			if (orderSearchBillingDTO.getOrderId().isEmpty()
					&& orderSearchBillingDTO.getDepartmentId().equalsIgnoreCase("1")
					&& !orderSearchBillingDTO.getInstitutionId().isEmpty()) {
				whereStatement = "WHERE o.institution_id = ? and o.status='active' and o.bill_draft='no'" + "ORDER BY id ";
				System.out.println("Printing institutiton Id " + institutionId);
				finalsqlquery = selectStatement.concat(whereStatement);
				System.out.println("Printing Sql Query in Order Id Block" + finalsqlquery);
				return orderSearchBillingDTOList = jdbc.query(finalsqlquery, new OrderSearchForBillingMapper(),
						institutionId);
			}

			if (orderSearchBillingDTO.getOrderId().isEmpty()
					&& orderSearchBillingDTO.getInstitutionId().equalsIgnoreCase("0")
					&& !orderSearchBillingDTO.getDepartmentId().isEmpty()) {
				whereStatement = "WHERE o.department_id = ? and o.status='active' and o.bill_draft='no'" + "ORDER BY id ";
				System.out.println("Printing department Id " + departmentId);
				finalsqlquery = selectStatement.concat(whereStatement);
				System.out.println("Printing Sql Query in Order Id Block" + finalsqlquery);
				return orderSearchBillingDTOList = jdbc.query(finalsqlquery, new OrderSearchForBillingMapper(),
						departmentId);
			}

			System.out.println("getOrderMultipleItemDetails" + selectStatement);
			return orderSearchBillingDTOList;

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	public List<OrderSearchDTO> findAllOrderForBillDraft()
			throws Exception {
		try {
			
			
			
			String selectStatement = "SELECT o.id,o.INSTITUTION_ID,o.DEPARTMENT_ID,I.INSTITUTION_NAME, D.DEPARTMENT_NAME,o.start_date,o.end_date "
					+ "FROM orders o " + "JOIN INSTITUTION I " + "ON o.INSTITUTION_ID = I.INSTITUTION_ID "
					+ "JOIN DEPARTMENT D " + "ON o.DEPARTMENT_ID = d.DEPARTMENT_ID "
					+ "WHERE o.status='active' and o.bill_draft='no' and o.total_amount!=0";

			String whereStatement = null;
			
			return jdbc.query(selectStatement, new OrderSearchForBillingMapper());

			

			
			
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}



	public List<OrderSubTotalDTO> findSubTotalforEachOrderId() throws Exception {
		try {

			System.out.println("Inside getTempOrderIds() method");
			// String inSql = String.join(",", Collections.nCopies(orderIds.size(), "?"));
			// NamedParameterJdbcTemplate jdbcTemplateObject = new
			// NamedParameterJdbcTemplate();

			// SqlParameterSource parameters = new MapSqlParameterSource("orderIds",
			// orderIds);

			// System.out.println("Inside getOrderDetails() method");
			// return jdbc.query("SELECT
			// ORDER_ID,INSTITUTION_ID,DEPARTMENT_ID,ITEM_ID,SIZE_ID,UNIT_ID,PRICE FROM
			// ORDERS_DETAILS where ORDER_ID = ?", new OrderDetailMapper(),orderID);
			return jdbc.query("SELECT ORDER_ID,SUM(PRICE) AS SUBTOTAL FROM TEMP_ORDERS_DETAILS GROUP BY ORDER_ID",
					new OrderSubTotalMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	
	public void deleteOrderItem(long orderItemId) throws Exception {
    	try {
          	 
       		System.out.println("Inside delete Item method");
       		
       		System.out.println("printing values " + orderItemId);
       		//java.sql.Date transactionDateSQL = new java.sql.Date(transactionDate.getTime());
       	 
      String SQL = "DELETE FROM order_items WHERE id = ?";
      	       
      jdbc.update(SQL,orderItemId);
       	  
		               		
          	}
          	catch (InvalidResultSetAccessException e) 
          	{
          		System.out.println(e);
          	    throw new RuntimeException(e);
          	} 
          	catch (DataAccessException e)
          	{
          		System.out.println(e);
          		throw new Exception("A problem occurred while retrieving my data", e);
          	}
          	
             
       	
       }
	
	public void deleteOrderItemPrice(long orderPriceItemId) throws Exception {
    	try {
          	 
       		System.out.println("Inside delete Item method");
       		
       		System.out.println("printing values " + orderPriceItemId);
       		//java.sql.Date transactionDateSQL = new java.sql.Date(transactionDate.getTime());
       	 
      String SQL = "DELETE FROM order_item_price WHERE id = ?";
      
      System.out.println("Printing Sql and order price item id" + SQL + ":::::" + orderPriceItemId);
      	       
      int i= jdbc.update(SQL,orderPriceItemId);
      System.out.println("Printing no of Rows affected" + i);
      
      
       	  
		               		
          	}
          	catch (InvalidResultSetAccessException e) 
          	{
          		System.out.println(e);
          	    throw new RuntimeException(e);
          	} 
          	catch (DataAccessException e)
          	{
          		System.out.println(e);
          		throw new Exception("A problem occurred while retrieving my data", e);
          	}
          	
             
       	
       }
	
	
	
	public void updateQuoatationItems(long quotationId,int quantity,double price,double amount) throws Exception {
    	try {
          	 
       		System.out.println("Inside delete Item method");
       		
       		//System.out.println("printing values " + orderItemId);
       		//java.sql.Date transactionDateSQL = new java.sql.Date(transactionDate.getTime());
       		
       	 
      String SQL = "UPDATE quotation_order_items SET QUANTITY = ?, PRICE = ?, AMOUNT = ? WHERE quotation_id = ?";
      	       
      jdbc.update(SQL,quantity,price,amount,quotationId);
       	  
		               		
          	}
          	catch (InvalidResultSetAccessException e) 
          	{
          		System.out.println(e);
          	    throw new RuntimeException(e);
          	} 
          	catch (DataAccessException e)
          	{
          		System.out.println(e);
          		throw new Exception("A problem occurred while retrieving my data", e);
          	}
          	
             
       	
       }

	public List<OrderSubTotalDTO> findSubTotalForBilling(List<Long> orderIds) throws Exception {
		try {

			System.out.println("Inside getSubTotalForBilling() method");
			SqlParameterSource parameters = new MapSqlParameterSource("orderIds", orderIds);
			
			return namedjdbcTemplateObject.query(
					"SELECT ORDER_ID,SUM(PRICE) AS SUBTOTAL FROM ORDER_ITEMS WHERE ORDER_ID IN (:orderIds) GROUP BY ORDER_ID",
					parameters, new OrderSubTotalMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	public List<QuotationSubTotalDTO> findSubTotalForQuotation(Long quotationId) throws Exception {
		try {

			System.out.println("Inside getSubTotalForBilling() method");
			SqlParameterSource parameters = new MapSqlParameterSource("quotationId", quotationId);
			
			return namedjdbcTemplateObject.query(
					"SELECT quotation_id,SUM(PRICE) AS SUBTOTAL FROM quotation_order_items WHERE quotation_id IN (:quotationId) GROUP BY quotation_id",
					parameters, new QuotationSubTotalMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	public int findMaxOrderID() {
		
		int orderId;

		orderId = jdbc.query("SELECT IFNULL(MAX(ORDER_ID),1) FROM ORDERS_DETAILS;", rs -> {
			if (rs.next()) {
				return rs.getInt(1);
			} else {
				throw new SQLException("Unable to retrieve value from sequence chessgame_seq.");
			}
		});
		return orderId;
	}

	public int createInstitution(String institutionName) throws Exception {
		try {

			int orderdetailstatus = jdbc.update("INSERT INTO INSTITUTION (INSTITUTION_NAME) values(?)",
					institutionName);

			return orderdetailstatus;

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	public int createDepartment(String departmentName) throws Exception {
		try {

			int departmentCreateStatus = jdbc.update("INSERT INTO DEPARTMENT (DEPARTMENT_NAME) values(?)",
					departmentName);

			return departmentCreateStatus;

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	public int createItem(String itemName) throws Exception {
		try {

			int itemCreateStatus = jdbc.update("INSERT INTO ITEM (ITEM_NAME) values(?)", itemName);

			return itemCreateStatus;

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	public int createSize(String sizeName) throws Exception {
		try {

			int sizeCreateStatus = jdbc.update("INSERT INTO SIZE (SIZE_NAME) values(?)", sizeName);

			return sizeCreateStatus;

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	public int createUnit(String unitName) throws Exception {
		try {

			int sizeCreateStatus = jdbc.update("INSERT INTO UNIT (UNIT_NAME) values(?)", unitName);

			return sizeCreateStatus;

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	public int createCostItem(String costItemName) throws Exception {
		try {

			int costItemCreateStatus = jdbc.update("INSERT INTO COST_ITEM (COST_ITEM_NAME) values(?)", costItemName);

			return costItemCreateStatus;

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
}
