var dis;
var tal;
var vill;
$(document).ready(function () {
	document.write('Hello World');
$.ajax({
	type: "GET",
	url: "http://localhost:8080/listInstituion",
	data: "json",
	contentType: "application/json",
	success: function (data) {
		let obj = $.parseJSON(data);
		$.each(obj, function (key, value) {
			$('#districtlist').append('<option value="' + value.districtcode + '">' + value.districtcode + '--' + value.districtname + '</option>');
		});
	},

	error: function (data) {
		$('#districtlist').append('<option>District Unavailable</option>');
	},
});


});
