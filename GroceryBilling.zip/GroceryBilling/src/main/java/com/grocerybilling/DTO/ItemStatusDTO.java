package com.grocerybilling.DTO;

public class ItemStatusDTO {
	private long itemStatusId;
	private String itemStatusName;
	public ItemStatusDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ItemStatusDTO(long itemStatusId, String itemStatusName) {
		super();
		this.itemStatusId = itemStatusId;
		this.itemStatusName = itemStatusName;
	}
	public long getItemStatusId() {
		return itemStatusId;
	}
	public void setItemStatusId(long itemStatusId) {
		this.itemStatusId = itemStatusId;
	}
	public String getItemStatusName() {
		return itemStatusName;
	}
	public void setItemStatusName(String itemStatusName) {
		this.itemStatusName = itemStatusName;
	}
	@Override
	public String toString() {
		return "ItemStatusDTO [itemStatusId=" + itemStatusId + ", itemStatusName=" + itemStatusName + "]";
	}
	
}
