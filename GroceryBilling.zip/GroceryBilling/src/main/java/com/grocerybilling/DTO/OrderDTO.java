package com.grocerybilling.DTO;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.grocerybilling.entity.OrderItem;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import jakarta.validation.Valid;
//import jakarta.persistence.*;

//import com.printing.entity.OrderItem;

import lombok.*;
import java.util.HashSet;
import java.util.Set;
/*import javax.validation.*;
//import javax.validation.constraints.Min;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;*/

public class OrderDTO {

	private Long id;
	private String startDate;
	private Date endDate;
	//@Min(0)
	//@Min(value = 1, message = "Please Select Institution")
	//@Min(value = 1, message = "Institution can not be Empty")
	private Integer institutionId;
	private String monthOfPurchase;
	private String installmentNumber;
	private String contactPersonName;
	private String contactNumber;
	private String status;
	private Double total;
	@DecimalMin(value = "0", message = "Profit Margin should be Numeric Value")
	private Double profitMargin;
	private Double totalAmount;
	private String itemPhase;
	
	
	@NotEmpty(message = "Item List must contain at least 1 Item.")
	 @Size(min = 1, message = "Item List must contain at least 1 item")
    @Valid
	private List<OrderItemDTO> OrderItemDTOs;
		

	
	public OrderDTO() {
		OrderItemDTOs = new ArrayList<>();
		
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getStartDate() {
		return startDate;
	}



	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}



	public Date getEndDate() {
		return endDate;
	}



	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}



	public String getMonthOfPurchase() {
		return monthOfPurchase;
	}



	public void setMonthOfPurchase(String monthOfPurchase) {
		this.monthOfPurchase = monthOfPurchase;
	}



	public Integer getInstitutionId() {
		return institutionId;
	}



	public void setInstitutionId(Integer institutionId) {
		this.institutionId = institutionId;
	}



	public String getInstallmentNumber() {
		return installmentNumber;
	}



	public void setInstallmentNumber(String installmentNumber) {
		this.installmentNumber = installmentNumber;
	}



	



	public String getContactPersonName() {
		return contactPersonName;
	}



	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}



	public String getContactNumber() {
		return contactNumber;
	}



	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public Double getTotal() {
		return total;
	}



	public void setTotal(Double total) {
		this.total = total;
	}



	public Double getProfitMargin() {
		return profitMargin;
	}



	public void setProfitMargin(Double profitMargin) {
		this.profitMargin = profitMargin;
	}



	public Double getTotalAmount() {
		return totalAmount;
	}



	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}



	public String getItemPhase() {
		return itemPhase;
	}



	public void setItemPhase(String itemPhase) {
		this.itemPhase = itemPhase;
	}



	public List<OrderItemDTO> getOrderItemDTOs() {
		return OrderItemDTOs;
	}



	public void setOrderItemDTOs(List<OrderItemDTO> orderItemDTOs) {
		OrderItemDTOs = orderItemDTOs;
	}



	public void add(OrderItemDTO item) {

        if (item != null) {
            if (OrderItemDTOs == null) {
            	OrderItemDTOs = new ArrayList<>();
            }

            OrderItemDTOs.add(item);
           // item.setOrder(this);
        }
    }
	
	

}
