package com.grocerybilling.DTO;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.grocerybilling.entity.OrderItem;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import jakarta.validation.Valid;
//import jakarta.persistence.*;

//import com.printing.entity.OrderItem;

import lombok.*;
import java.util.HashSet;
import java.util.Set;
public class ItemBatchDTO {
	private List<ItemDTO> items;
	private String selectAll;

	public ItemBatchDTO() {
		items = new ArrayList<ItemDTO>();
		//super();
		// TODO Auto-generated constructor stub
	}
	
	

	public String getSelectAll() {
		return selectAll;
	}



	public void setSelectAll(String selectAll) {
		this.selectAll = selectAll;
	}




	public List<ItemDTO> getItems() {
		return items;
	}



	public void setItems(List<ItemDTO> items) {
		this.items = items;
	}



	public void add(ItemDTO item) {

        if (item != null) {
            if (items == null) {
            	items = new ArrayList<>();
            }

            items.add(item);
           // item.setOrder(this);
        }
    }

}
