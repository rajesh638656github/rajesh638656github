package com.grocerybilling.DTO;

import com.grocerybilling.entity.QuotationOrder;

public class QuotationOrderItemDTO {
	private Long rownum;
	private Long purchaseOrderId;
	private Long quotationId;
	
		
	private Long purchaseOrderItemId;
	private Long itemId;
	private String itemName;
	

	private Long itemPhaseId;
	private String itemPhaseName;
	private Double itemRate;
	
	private Long unitId;
	private Double quantity;
	
	private Double amount;
	
	private Long departmentId;
	private String departmentName;
	
	private Long itemIdDB;
	private Long phaseIdDB;
	private String phaseNameDB;
	private String itemNameDB;
	
	
	private QuotationOrder quotationOrder;


	public QuotationOrderItemDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public QuotationOrderItemDTO(Long rownum, Long purchaseOrderId, Long purchaseOrderItemId, Long itemId,
			String itemName, Long itemPhaseId, String itemPhaseName, Double itemRate, Double quantity, Double amount,
			Long departmentId, String departmentName, Long itemIdDB, Long phaseIdDB, String phaseNameDB,
			String itemNameDB, QuotationOrder quotationOrder) {
		super();
		this.rownum = rownum;
		this.purchaseOrderId = purchaseOrderId;
		this.purchaseOrderItemId = purchaseOrderItemId;
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPhaseId = itemPhaseId;
		this.itemPhaseName = itemPhaseName;
		this.itemRate = itemRate;
		this.quantity = quantity;
		this.amount = amount;
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.itemIdDB = itemIdDB;
		this.phaseIdDB = phaseIdDB;
		this.phaseNameDB = phaseNameDB;
		this.itemNameDB = itemNameDB;
		this.quotationOrder = quotationOrder;
	}


	public Long getRownum() {
		return rownum;
	}


	public void setRownum(Long rownum) {
		this.rownum = rownum;
	}

	public Long getQuotationId() {
		return quotationId;
	}


	public void setQuotationId(Long quotationId) {
		this.quotationId = quotationId;
	}


	public Long getPurchaseOrderId() {
		return purchaseOrderId;
	}


	public void setPurchaseOrderId(Long purchaseOrderId) {
		this.purchaseOrderId = purchaseOrderId;
	}


	public Long getPurchaseOrderItemId() {
		return purchaseOrderItemId;
	}


	public void setPurchaseOrderItemId(Long purchaseOrderItemId) {
		this.purchaseOrderItemId = purchaseOrderItemId;
	}


	public Long getItemId() {
		return itemId;
	}


	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public Long getItemPhaseId() {
		return itemPhaseId;
	}


	public void setItemPhaseId(Long itemPhaseId) {
		this.itemPhaseId = itemPhaseId;
	}


	public String getItemPhaseName() {
		return itemPhaseName;
	}


	public void setItemPhaseName(String itemPhaseName) {
		this.itemPhaseName = itemPhaseName;
	}


	public Double getItemRate() {
		return itemRate;
	}


	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}


	public Double getQuantity() {
		return quantity;
	}


	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public Long getDepartmentId() {
		return departmentId;
	}


	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}


	public String getDepartmentName() {
		return departmentName;
	}


	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}


	public Long getItemIdDB() {
		return itemIdDB;
	}


	public void setItemIdDB(Long itemIdDB) {
		this.itemIdDB = itemIdDB;
	}


	public Long getPhaseIdDB() {
		return phaseIdDB;
	}


	public void setPhaseIdDB(Long phaseIdDB) {
		this.phaseIdDB = phaseIdDB;
	}


	public String getPhaseNameDB() {
		return phaseNameDB;
	}


	public void setPhaseNameDB(String phaseNameDB) {
		this.phaseNameDB = phaseNameDB;
	}


	public String getItemNameDB() {
		return itemNameDB;
	}


	public void setItemNameDB(String itemNameDB) {
		this.itemNameDB = itemNameDB;
	}


	public QuotationOrder getQuotationOrder() {
		return quotationOrder;
	}


	public void setQuotationOrder(QuotationOrder quotationOrder) {
		this.quotationOrder = quotationOrder;
	}


	public Long getUnitId() {
		return unitId;
	}


	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}
	
	

}
