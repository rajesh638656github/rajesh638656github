package com.grocerybilling.DTO;

public class ItemUnitDTO {
	
	private Long id;
	private Long itemId;
	private long unitId;
	private String unitName;
	public ItemUnitDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ItemUnitDTO(Long id, Long itemId, long unitId) {
		super();
		this.id = id;
		this.itemId = itemId;
		this.unitId = unitId;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getItemId() {
		return itemId;
	}
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	public long getUnitId() {
		return unitId;
	}
	public void setUnitId(long unitId) {
		this.unitId = unitId;
	}
	public String getUnitName() {
		return unitName;
	}
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	
	
}
