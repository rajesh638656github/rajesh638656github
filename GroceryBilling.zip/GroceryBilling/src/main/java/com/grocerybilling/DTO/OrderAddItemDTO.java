package com.grocerybilling.DTO;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import jakarta.validation.Valid;
//import jakarta.persistence.*;

//import com.printing.entity.OrderItem;

import lombok.*;
import java.util.HashSet;
import java.util.Set;
/*import javax.validation.*;
//import javax.validation.constraints.Min;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;*/

public class OrderAddItemDTO {

	private long id;
	private Date startDate;
	private Date endDate;
	//@Min(0)
	//@Min(value = 1, message = "Please Select Institution")
	//@Min(value = 1, message = "Institution can not be empty")
	private int institutionId;
	private int departmentId;
	@NotEmpty(message = "Order Item list cannot be empty.")
    @Valid
	private List<OrderItemAddItemDTO> orderitemsAddItems;
	
	

	
	public OrderAddItemDTO() {
		orderitemsAddItems = new ArrayList<>();
		// TODO Auto-generated constructor stub
	}




	public long getId() {
		return id;
	}




	public void setId(long id) {
		this.id = id;
	}




	public Date getStartDate() {
		return startDate;
	}




	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}




	public Date getEndDate() {
		return endDate;
	}




	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}




	public int getInstitutionId() {
		return institutionId;
	}




	public void setInstitutionId(int institutionId) {
		this.institutionId = institutionId;
	}




	public int getDepartmentId() {
		return departmentId;
	}




	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}




	public List<OrderItemAddItemDTO> getOrderitemsAddItems() {
		return orderitemsAddItems;
	}




	public void setOrderitemsAddItems(List<OrderItemAddItemDTO> orderitemsAddItems) {
		this.orderitemsAddItems = orderitemsAddItems;
	}

	
}
