package com.grocerybilling.DTO;

import jakarta.persistence.Column;

public class ItemPhaseDTO {
	private long itemPhaseId;
	private String itemPhaseName;
	public ItemPhaseDTO() {
		super();
		// TODO Auto-generated constructor stub

}
	public long getItemPhaseId() {
		return itemPhaseId;
	}
	public void setItemPhaseId(long itemPhaseId) {
		this.itemPhaseId = itemPhaseId;
	}
	public String getItemPhaseName() {
		return itemPhaseName;
	}
	public void setItemPhaseName(String itemPhaseName) {
		this.itemPhaseName = itemPhaseName;
	}
}
