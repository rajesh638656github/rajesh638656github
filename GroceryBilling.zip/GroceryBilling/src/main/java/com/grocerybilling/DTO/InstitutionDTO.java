package com.grocerybilling.DTO;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;

public class InstitutionDTO {
	private int institutionId;
	private String institutionName;
	
	  @NotEmpty
	    private String firstName;
	    @NotEmpty
	    private String lastName;
	 //   private Integer institutionId;
	    @NotEmpty(message = "Email should not be empty")
	    @Email
	    private String email;
	    @NotEmpty(message = "Password should not be empty")
	    private String password;
	    private String userName;
		
		// @Size(min = 1, message = "Role List must contain at least 1 Role")
	   // @NotEmpty(message = "Role List must contain at least 1 Role.")
		// @Valid
	  //  private List<RoleDto> roles;
	    private String roles;

	public InstitutionDTO() {
	}

	public InstitutionDTO(int institutionId, String institutionName) {
		super();
		this.institutionId = institutionId;
		this.institutionName = institutionName;
	}

	public int getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(int institutionId) {
		this.institutionId = institutionId;
	}

	public String getInstitutionName() {
		return institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}

	@Override
	public String toString() {
		return "Institution [institutionId=" + institutionId + ", institutionName=" + institutionName + "]";
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	
	
	
}
