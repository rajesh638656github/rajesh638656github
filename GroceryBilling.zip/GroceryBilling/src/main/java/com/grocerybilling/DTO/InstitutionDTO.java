package com.grocerybilling.DTO;

public class InstitutionDTO {
	private int institutionId;
	private String institutionName;

	public InstitutionDTO() {
	}

	public InstitutionDTO(int institutionId, String institutionName) {
		super();
		this.institutionId = institutionId;
		this.institutionName = institutionName;
	}

	public int getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(int institutionId) {
		this.institutionId = institutionId;
	}

	public String getInstitutionName() {
		return institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}

	@Override
	public String toString() {
		return "Institution [institutionId=" + institutionId + ", institutionName=" + institutionName + "]";
	}

}
