package com.grocerybilling.DTO;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;

public class DepartmentDTO {

	private Long departmentId;
	private String departmentName;
	private String firstContactPersonName;
	private String firstContactPersonContactNumber;
	private String secondContactPersonName;
	private String secondContactPersonContactNumber;
	   

	public DepartmentDTO() {

	}

	public DepartmentDTO(Long departmentId, String departmentName) {

		this.departmentId = departmentId;
		this.departmentName = departmentName;
	}

	public Long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	@Override
	public String toString() {
		return "Department [departmentId=" + departmentId + ", departmentName=" + departmentName + "]";
	}

	public String getFirstContactPersonName() {
		return firstContactPersonName;
	}

	public void setFirstContactPersonName(String firstContactPersonName) {
		this.firstContactPersonName = firstContactPersonName;
	}

	public String getFirstContactPersonContactNumber() {
		return firstContactPersonContactNumber;
	}

	public void setFirstContactPersonContactNumber(String firstContactPersonContactNumber) {
		this.firstContactPersonContactNumber = firstContactPersonContactNumber;
	}

	public String getSecondContactPersonName() {
		return secondContactPersonName;
	}

	public void setSecondContactPersonName(String secondContactPersonName) {
		this.secondContactPersonName = secondContactPersonName;
	}

	public String getSecondContactPersonContactNumber() {
		return secondContactPersonContactNumber;
	}

	public void setSecondContactPersonContactNumber(String secondContactPersonContactNumber) {
		this.secondContactPersonContactNumber = secondContactPersonContactNumber;
	}

	
	
	

}
