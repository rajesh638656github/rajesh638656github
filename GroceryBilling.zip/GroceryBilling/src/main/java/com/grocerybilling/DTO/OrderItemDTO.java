package com.grocerybilling.DTO;

import com.grocerybilling.entity.Order;

/*import javax.validation.*;
import javax.validation.constraints.Min;*/
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

public class OrderItemDTO {

	private long orderId;
	private long orderItemId;
	private long itemId;
	private Double itemRate;
	private int quantity;
	private double amount;
	private long itemIdDB;
	private long phaseIdDB;
	private String phaseNameDB;
	private String itemNameDB;
	private OrderDTO orderDTO;
	public OrderItemDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderItemDTO(long orderId, long orderItemId, long itemId, Double itemRate, int quantity, double amount,
			long itemIdDB, long phaseIdDB, String phaseNameDB, String itemNameDB, OrderDTO orderDTO) {
		super();
		this.orderId = orderId;
		this.orderItemId = orderItemId;
		this.itemId = itemId;
		this.itemRate = itemRate;
		this.quantity = quantity;
		this.amount = amount;
		this.itemIdDB = itemIdDB;
		this.phaseIdDB = phaseIdDB;
		this.phaseNameDB = phaseNameDB;
		this.itemNameDB = itemNameDB;
		this.orderDTO = orderDTO;
	}
	public long getOrderId() {
		return orderId;
	}
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	public long getOrderItemId() {
		return orderItemId;
	}
	public void setOrderItemId(long orderItemId) {
		this.orderItemId = orderItemId;
	}
	public long getItemId() {
		return itemId;
	}
	public void setItemId(long itemId) {
		this.itemId = itemId;
	}
	public Double getItemRate() {
		return itemRate;
	}
	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public long getItemIdDB() {
		return itemIdDB;
	}
	public void setItemIdDB(long itemIdDB) {
		this.itemIdDB = itemIdDB;
	}
	public long getPhaseIdDB() {
		return phaseIdDB;
	}
	public void setPhaseIdDB(long phaseIdDB) {
		this.phaseIdDB = phaseIdDB;
	}
	public String getPhaseNameDB() {
		return phaseNameDB;
	}
	public void setPhaseNameDB(String phaseNameDB) {
		this.phaseNameDB = phaseNameDB;
	}
	public String getItemNameDB() {
		return itemNameDB;
	}
	public void setItemNameDB(String itemNameDB) {
		this.itemNameDB = itemNameDB;
	}
	public OrderDTO getOrderDTO() {
		return orderDTO;
	}
	public void setOrderDTO(OrderDTO orderDTO) {
		this.orderDTO = orderDTO;
	}
	
	
	
	
}
