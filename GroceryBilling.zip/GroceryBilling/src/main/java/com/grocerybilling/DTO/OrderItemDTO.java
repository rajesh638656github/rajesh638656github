package com.grocerybilling.DTO;

import com.grocerybilling.entity.Order;

/*import javax.validation.*;
import javax.validation.constraints.Min;*/
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import com.grocerybilling.constraint.*;


//@ValidQuantityUnit
@ValidOrderItem
public class OrderItemDTO {

	private Long orderId;
	private Long orderItemId;
	private Long itemId;
	private Double itemRate;
	//@NotNull(message = "Quantity cannot be Null")
    @DecimalMin(value = "0.01", message = "Quantity must be greater than 0")
    @DecimalMax(value = "10000.00", message = "Quantity cannot be greater than 10000")
   // @NumericValue(message = "Value must be a valid numeric value")
	private Double quantity;
//	@Min(value = 1, message = "Unit can not be Empty")
//@NotNull(message = "Unit is required when Quantity is entered")

	private Long unitId;
	private Double amount;
	private String comments;
	private Long itemIdDB;
	private Long phaseIdDB;
	private String phaseNameDB;
	private String itemNameDB;
	@Transient
    private String invalidQuantity; // Stores invalid input but does not persist in DB


	private OrderDTO orderDTO;
	public OrderItemDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderItemDTO(Long orderId, Long orderItemId, Long itemId, Double itemRate, Double quantity, Double amount, Long unitId,
			Long itemIdDB, Long phaseIdDB, String phaseNameDB, String itemNameDB, OrderDTO orderDTO) {
		super();
		this.orderId = orderId;
		this.orderItemId = orderItemId;
		this.itemId = itemId;
		this.itemRate = itemRate;
		this.quantity = quantity;
		this.amount = amount;
		this.unitId = unitId;
		this.itemIdDB = itemIdDB;
		this.phaseIdDB = phaseIdDB;
		this.phaseNameDB = phaseNameDB;
		this.itemNameDB = itemNameDB;
		this.orderDTO = orderDTO;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Long getOrderItemId() {
		return orderItemId;
	}
	public void setOrderItemId(Long orderItemId) {
		this.orderItemId = orderItemId;
	}
	public Long getItemId() {
		return itemId;
	}
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	public Double getItemRate() {
		return itemRate;
	}
	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	public Long getUnitId() {
		return unitId;
	}

	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}

	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Long getItemIdDB() {
		return itemIdDB;
	}
	public void setItemIdDB(Long itemIdDB) {
		this.itemIdDB = itemIdDB;
	}
	public Long getPhaseIdDB() {
		return phaseIdDB;
	}
	public void setPhaseIdDB(Long phaseIdDB) {
		this.phaseIdDB = phaseIdDB;
	}
	public String getPhaseNameDB() {
		return phaseNameDB;
	}
	public void setPhaseNameDB(String phaseNameDB) {
		this.phaseNameDB = phaseNameDB;
	}
	public String getItemNameDB() {
		return itemNameDB;
	}
	public void setItemNameDB(String itemNameDB) {
		this.itemNameDB = itemNameDB;
	}
	public OrderDTO getOrderDTO() {
		return orderDTO;
	}
	public void setOrderDTO(OrderDTO orderDTO) {
		this.orderDTO = orderDTO;
	}
	public String getInvalidQuantity() {
		return invalidQuantity;
	}
	public void setInvalidQuantity(String invalidQuantity) {
		this.invalidQuantity = invalidQuantity;
	}
	
	
	
	
}
