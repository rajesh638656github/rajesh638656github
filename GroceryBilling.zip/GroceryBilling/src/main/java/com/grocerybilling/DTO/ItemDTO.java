package com.grocerybilling.DTO;

import jakarta.persistence.Column;

public class ItemDTO {
	private Long itemId;
	private Long phaseId;
	private String phaseName;
	private String itemName;
	private Double itemRate;
	private long itemIdDB;
	private long phaseIdDB;
	private String itemNameDB;
	private long departmentId;
	private String departmentName;
	
	public ItemDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	
	

	public long getItemIdDB() {
		return itemIdDB;
	}

	public void setItemIdDB(long itemIdDB) {
		this.itemIdDB = itemIdDB;
	}

	public Long getPhaseId() {
		return phaseId;
	}

	public void setPhaseId(Long phaseId) {
		this.phaseId = phaseId;
	}

	public String getPhaseName() {
		return phaseName;
	}

	public void setPhaseName(String phaseName) {
		this.phaseName = phaseName;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Double getItemRate() {
		return itemRate;
	}

	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}

	public long getPhaseIdDB() {
		return phaseIdDB;
	}

	public void setPhaseIdDB(long phaseIdDB) {
		this.phaseIdDB = phaseIdDB;
	}

	public String getItemNameDB() {
		return itemNameDB;
	}

	public void setItemNameDB(String itemNameDB) {
		this.itemNameDB = itemNameDB;
	}

	public long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(long departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	
	
	
	
}
