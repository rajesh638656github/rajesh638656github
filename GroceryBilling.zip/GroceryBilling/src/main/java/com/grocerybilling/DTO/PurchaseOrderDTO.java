package com.grocerybilling.DTO;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.grocerybilling.entity.OrderItem;
import com.grocerybilling.entity.PurchaseOrderItem;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;
import jakarta.validation.Valid;

public class PurchaseOrderDTO {
	private Long id;
	private LocalDate startDate;

	private LocalDate endDate;

	private String contactPersonName;

	private String contactNumber;

	private String status;
	
	private String monthOfPurchase;
	
	private String installmentNumber;

	private String billDraft;

	private Double total;

	private Double profitMargin;

	private Double totalAmount;
	
	private String itemPhase;
	
	private String institutionName;
    @Valid
	private List<PurchaseOrderItemDTO> purchaseOrderItemDTOs;

	public PurchaseOrderDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PurchaseOrderDTO(Long id, LocalDate startDate, LocalDate endDate, String contactPersonName, String contactNumber,
			String status, String billDraft, Double total, Double profitMargin, Double totalAmount,
			List<PurchaseOrderItemDTO> purchaseOrderItemDTOs) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
		this.contactPersonName = contactPersonName;
		this.contactNumber = contactNumber;
		this.status = status;
		this.billDraft = billDraft;
		this.total = total;
		this.profitMargin = profitMargin;
		this.totalAmount = totalAmount;
		this.purchaseOrderItemDTOs = purchaseOrderItemDTOs;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	
	

	public String getItemPhase() {
		return itemPhase;
	}

	public void setItemPhase(String itemPhase) {
		this.itemPhase = itemPhase;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBillDraft() {
		return billDraft;
	}

	public void setBillDraft(String billDraft) {
		this.billDraft = billDraft;
	}

	public Double getTotal() {
		return total;
	}

	public void setTotal(Double total) {
		this.total = total;
	}

	public Double getProfitMargin() {
		return profitMargin;
	}

	public void setProfitMargin(Double profitMargin) {
		this.profitMargin = profitMargin;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	
		public String getInstallmentNumber() {
		return installmentNumber;
	}

	public void setInstallmentNumber(String installmentNumber) {
		this.installmentNumber = installmentNumber;
	}

	public List<PurchaseOrderItemDTO> getPurchaseOrderItemDTOs() {
		return purchaseOrderItemDTOs;
	}

	public void setPurchaseOrderItemDTOs(List<PurchaseOrderItemDTO> purchaseOrderItemDTOs) {
		this.purchaseOrderItemDTOs = purchaseOrderItemDTOs;
	}
	
	public String getMonthOfPurchase() {
		return monthOfPurchase;
	}

	public void setMonthOfPurchase(String monthOfPurchase) {
		this.monthOfPurchase = monthOfPurchase;
	}
	
	

	public String getInstitutionName() {
		return institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}

	public void add(PurchaseOrderItemDTO item) {

        if (item != null) {
            if (purchaseOrderItemDTOs == null) {
            	purchaseOrderItemDTOs = new ArrayList<>();
            }

            purchaseOrderItemDTOs.add(item);
           // item.setOrder(this);
        }
    }
	
	public void remove(PurchaseOrderItemDTO item) {
	       
		purchaseOrderItemDTOs.remove(item);
       item.setPurchaseOrder(null);
   
}

}
