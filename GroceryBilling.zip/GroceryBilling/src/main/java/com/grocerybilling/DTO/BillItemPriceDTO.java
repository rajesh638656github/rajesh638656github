package com.grocerybilling.DTO;

public class BillItemPriceDTO {
	private String billId;
	private String itemRateId;
	private String phaseId;
	private String phaseName;
	private String itemRateName;
	private String itemRate;
	private String noOfItems;
	private String amount;
	public String getBillId() {
		return billId;
	}
	public void setBillId(String billId) {
		this.billId = billId;
	}
	public String getItemRateId() {
		return itemRateId;
	}
	public void setItemRateId(String itemRateId) {
		this.itemRateId = itemRateId;
	}
	public String getPhaseId() {
		return phaseId;
	}
	public void setPhaseId(String phaseId) {
		this.phaseId = phaseId;
	}
	public String getPhaseName() {
		return phaseName;
	}
	public void setPhaseName(String phaseName) {
		this.phaseName = phaseName;
	}
	public String getItemRateName() {
		return itemRateName;
	}
	public void setItemRateName(String itemRateName) {
		this.itemRateName = itemRateName;
	}
	public String getItemRate() {
		return itemRate;
	}
	public void setItemRate(String itemRate) {
		this.itemRate = itemRate;
	}
	public String getNoOfItems() {
		return noOfItems;
	}
	public void setNoOfItems(String noOfItems) {
		this.noOfItems = noOfItems;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	

}
