package com.grocerybilling.DTO;

import com.grocerybilling.entity.PurchaseOrder;

import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import java.util.Date;
import com.grocerybilling.constraint.*;

@ValidOrderItem
public class PurchaseOrderItemDTO {
	
	private Long rownum;
	private Long purchaseOrderId;
	
		
	private Long purchaseOrderItemId;
	private Long institutionId;
	private Long itemId;
	private String itemName;
	

	private Long itemPhaseId;
	private String itemPhaseName;
	private Double itemRate;
	
	  @DecimalMin(value = "0.01", message = "Quantity must be greater than 0")
	    @DecimalMax(value = "10000.00", message = "Quantity cannot be greater than 10000")
	   // @NumericValue(message = "Value must be a valid numeric value")
	private Double quantity;
	  @NotNull(message = "Unit is required when Quantity is entered")
	private Long unitId;
	private String unitName;
	
	private Double amount;
	
	private Long departmentId;
	private String departmentName;
	
	private Long itemIdDB;
	private Long phaseIdDB;
	private String phaseNameDB;
	private String itemNameDB;
	
	
	private PurchaseOrder purchaseOrder;


	public PurchaseOrderItemDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public PurchaseOrderItemDTO(Long rownum, Long purchaseOrderId, Long purchaseOrderItemId, Long institutionId,Long itemId,
			String itemName, Long itemPhaseId, String itemPhaseName, Double itemRate, Double quantity, String unit,Double amount,
			Long departmentId, String departmentName, Long itemIdDB, Long phaseIdDB, String phaseNameDB,
			String itemNameDB, PurchaseOrder purchaseOrder) {
		super();
		this.rownum = rownum;
		this.purchaseOrderId = purchaseOrderId;
		this.purchaseOrderItemId = purchaseOrderItemId;
		this.institutionId = institutionId;
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPhaseId = itemPhaseId;
		this.itemPhaseName = itemPhaseName;
		this.itemRate = itemRate;
		this.quantity = quantity;
		this.unitId = unitId;
		this.amount = amount;
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.itemIdDB = itemIdDB;
		this.phaseIdDB = phaseIdDB;
		this.phaseNameDB = phaseNameDB;
		this.itemNameDB = itemNameDB;
		this.purchaseOrder = purchaseOrder;
	}


	public Long getRownum() {
		return rownum;
	}


	public void setRownum(Long rownum) {
		this.rownum = rownum;
	}


	public Long getPurchaseOrderId() {
		return purchaseOrderId;
	}


	public void setPurchaseOrderId(Long purchaseOrderId) {
		this.purchaseOrderId = purchaseOrderId;
	}


	public Long getPurchaseOrderItemId() {
		return purchaseOrderItemId;
	}


	public void setPurchaseOrderItemId(Long purchaseOrderItemId) {
		this.purchaseOrderItemId = purchaseOrderItemId;
	}

	public Long getInstitutionId() {
		return institutionId;
	}


	public void setInstitutionId(Long institutionId) {
		this.institutionId = institutionId;
	}


	public Long getItemId() {
		return itemId;
	}


	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public Long getItemPhaseId() {
		return itemPhaseId;
	}


	public void setItemPhaseId(Long itemPhaseId) {
		this.itemPhaseId = itemPhaseId;
	}


	public String getItemPhaseName() {
		return itemPhaseName;
	}


	public void setItemPhaseName(String itemPhaseName) {
		this.itemPhaseName = itemPhaseName;
	}


	public Double getItemRate() {
		return itemRate;
	}


	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}


	public Double getQuantity() {
		return quantity;
	}


	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	

	public Long getUnitId() {
		return unitId;
	}


	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public Long getDepartmentId() {
		return departmentId;
	}


	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}


	public String getDepartmentName() {
		return departmentName;
	}


	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}


	public Long getItemIdDB() {
		return itemIdDB;
	}


	public void setItemIdDB(Long itemIdDB) {
		this.itemIdDB = itemIdDB;
	}


	public Long getPhaseIdDB() {
		return phaseIdDB;
	}


	public void setPhaseIdDB(Long phaseIdDB) {
		this.phaseIdDB = phaseIdDB;
	}


	public String getPhaseNameDB() {
		return phaseNameDB;
	}


	public void setPhaseNameDB(String phaseNameDB) {
		this.phaseNameDB = phaseNameDB;
	}


	public String getItemNameDB() {
		return itemNameDB;
	}


	public void setItemNameDB(String itemNameDB) {
		this.itemNameDB = itemNameDB;
	}


	public PurchaseOrder getPurchaseOrder() {
		return purchaseOrder;
	}


	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}


	public String getUnitName() {
		return unitName;
	}


	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}


	

}
