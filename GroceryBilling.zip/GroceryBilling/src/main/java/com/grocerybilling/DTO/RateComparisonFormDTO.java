package com.grocerybilling.DTO;

import java.util.HashMap;
import java.util.Map;

import com.grocerybilling.model.ItemSupplierRateDTO;

public class RateComparisonFormDTO {
	
	 Map<String, ItemSupplierRateDTO> reportMap = new HashMap<>();

	public Map<String, ItemSupplierRateDTO> getReportMap() {
		return reportMap;
	}

	public void setReportMap(Map<String, ItemSupplierRateDTO> reportMap) {
		this.reportMap = reportMap;
	}
	 
	 

}
