package com.grocerybilling.DTO;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.grocerybilling.entity.OrderItem;
import com.grocerybilling.entity.QuotationOrderItem;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;

public class QuotationOrderDTO {
	private Long id;
	private Date startDate;

	private Date endDate;

	private String contactPersonName;

	private String contactNumber;

	private String status;
	
	private Integer installmentNumber;

	private String billDraft;

	private Double total;

	private Double profitMargin;

	private Double totalAmount;
	
	private String itemPhase;

	private List<QuotationOrderItemDTO> quotationOrderItemDTOs;

	public QuotationOrderDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public QuotationOrderDTO(Long id, Date startDate, Date endDate, String contactPersonName, String contactNumber,
			String status, Integer installmentNumber, String billDraft, Double total, Double profitMargin,
			Double totalAmount, String itemPhase, List<QuotationOrderItemDTO> quotationOrderItemDTOs) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
		this.contactPersonName = contactPersonName;
		this.contactNumber = contactNumber;
		this.status = status;
		this.installmentNumber = installmentNumber;
		this.billDraft = billDraft;
		this.total = total;
		this.profitMargin = profitMargin;
		this.totalAmount = totalAmount;
		this.itemPhase = itemPhase;
		this.quotationOrderItemDTOs = quotationOrderItemDTOs;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getInstallmentNumber() {
		return installmentNumber;
	}

	public void setInstallmentNumber(Integer installmentNumber) {
		this.installmentNumber = installmentNumber;
	}

	public String getBillDraft() {
		return billDraft;
	}

	public void setBillDraft(String billDraft) {
		this.billDraft = billDraft;
	}

	public Double getTotal() {
		return total;
	}

	public void setTotal(Double total) {
		this.total = total;
	}

	public Double getProfitMargin() {
		return profitMargin;
	}

	public void setProfitMargin(Double profitMargin) {
		this.profitMargin = profitMargin;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getItemPhase() {
		return itemPhase;
	}

	public void setItemPhase(String itemPhase) {
		this.itemPhase = itemPhase;
	}

	public List<QuotationOrderItemDTO> getQuotationOrderItemDTOs() {
		return quotationOrderItemDTOs;
	}

	public void setQuotationOrderItemDTOs(List<QuotationOrderItemDTO> quotationOrderItemDTOs) {
		this.quotationOrderItemDTOs = quotationOrderItemDTOs;
	}
	
	

}
