package com.grocerybilling.constraint;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
@Constraint(validatedBy = QuantityUnitValidator.class)
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidQuantityUnit {
	String message() default "Unit is required when quantity is entered";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};

}
