package com.grocerybilling.constraint;
import jakarta.validation.Constraint;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
public class NumericValueValidator implements ConstraintValidator<NumericValue, Double> {
    @Override
    public void initialize(NumericValue constraintAnnotation) {}

    @Override
    public boolean isValid(Double value, ConstraintValidatorContext context) {
        if (value == null) {
            return false;
        }
        // Return true if value is a valid number
        return value instanceof Double;
    }
}
