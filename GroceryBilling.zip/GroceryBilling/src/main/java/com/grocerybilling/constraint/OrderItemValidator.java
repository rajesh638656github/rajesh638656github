package com.grocerybilling.constraint;
import com.grocerybilling.DTO.*;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
public class OrderItemValidator implements ConstraintValidator<ValidOrderItem, OrderItemDTO> {

    @Override
    public boolean isValid(OrderItemDTO item, ConstraintValidatorContext context) {
        boolean isValid = true;

        // If quantity is -1.0 (set by @InitBinder for invalid input), show an error
        if (item.getQuantity() != null && item.getQuantity() == -1.0) {
            addConstraintViolation(context, "Quantity must be a numeric value.", "quantity");
            item.setQuantity(null);
            isValid = false;
        }
        
        
        // Ensure Unit is required when Quantity is entered
        if (item.getQuantity() != null && item.getQuantity() > 0 && (item.getUnitId() == null || item.getUnitId() <= 0)) {
            addConstraintViolation(context, "Unit is required when quantity is entered.", "unitId");
            isValid = false;
        }
        
        
       
        
        if (item.getUnitId() != null && item.getUnitId() > 0 && (item.getQuantity() == null || item.getQuantity() <= 0)) {
            addConstraintViolation(context, "Quantity is required when unit is selected.", "quantity");
            isValid = false;
        }
        
        return isValid;
    }

    private void addConstraintViolation(ConstraintValidatorContext context, String message, String field) {
        context.disableDefaultConstraintViolation();
        context.buildConstraintViolationWithTemplate(message)
                .addPropertyNode(field)
                .addConstraintViolation();
    }
}