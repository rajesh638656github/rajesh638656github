package com.grocerybilling.constraint;
import jakarta.validation.Constraint;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = NumericValueValidator.class)

public @interface NumericValue {
	 String message() default "Invalid numeric value";
	    Class<?>[] groups() default {};
	    Class<? extends Payload>[] payload() default {};

}
