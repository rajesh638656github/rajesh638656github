package com.grocerybilling.constraint;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = OrderItemValidator.class)
@Target({ElementType.TYPE})  // Apply to the class level
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidOrderItem {
	 String message() default "Invalid order item details";
	    Class<?>[] groups() default {};
	    Class<? extends Payload>[] payload() default {};

}
