package com.grocerybilling.constraint;
import com.grocerybilling.DTO.*;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
public class QuantityUnitValidator implements ConstraintValidator<ValidQuantityUnit, OrderItemDTO> {
    @Override
    public boolean isValid(OrderItemDTO item, ConstraintValidatorContext context) {
        if (item.getQuantity() != null && item.getQuantity() > 0 && (item.getUnitId() == null || item.getUnitId() <= 0)) {
        	
            return false; // Validation fails
        }
        return true;
    }
}