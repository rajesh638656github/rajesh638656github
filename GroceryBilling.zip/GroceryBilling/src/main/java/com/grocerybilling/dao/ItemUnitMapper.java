package com.grocerybilling.dao;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.grocerybilling.DTO.ItemDTO;
import com.grocerybilling.DTO.ItemUnitDTO;

public class ItemUnitMapper implements RowMapper<ItemUnitDTO> {
	public ItemUnitDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		ItemUnitDTO itemUnitDTO = new ItemUnitDTO();
		itemUnitDTO.setItemId(rs.getLong("ITEM_ID"));
		itemUnitDTO.setUnitId(rs.getLong("UNIT_ID"));
		itemUnitDTO.setUnitName(rs.getString("unit_name"));
		return itemUnitDTO;
	}
}
