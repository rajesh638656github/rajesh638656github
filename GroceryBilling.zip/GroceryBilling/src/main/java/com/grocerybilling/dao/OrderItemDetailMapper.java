package com.grocerybilling.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.grocerybilling.DTO.InstitutionDTO;
import com.grocerybilling.model.Order1;
import com.grocerybilling.model.OrderItemDetailDTO;

import java.text.*;
import java.util.*;
import java.math.BigInteger;

public class OrderItemDetailMapper implements RowMapper<OrderItemDetailDTO> {
	public OrderItemDetailDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		OrderItemDetailDTO orderItemDetailDTO = new OrderItemDetailDTO();
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		//int orderid;
				long id = rs.getLong("id");
				int orderid = (int) id;
				int orderid1 = Long.valueOf(id).intValue();
				long order_itemid = rs.getLong("order_item_id");
				int orderitemid = Long.valueOf(order_itemid).intValue();
		System.out.println("OrderItemDetailMapper");
		orderItemDetailDTO.setRownum(rs.getString("num_row"));
		System.out.println("Order ID" + orderItemDetailDTO.getOrderId());
		orderItemDetailDTO.setOrderId(Integer.toString(orderid1));
		orderItemDetailDTO.setInstitutionId(rs.getLong("INSTITUTION_ID"));
		orderItemDetailDTO.setInstitutionName(rs.getString("INSTITUTION_NAME"));
	//	orderItemDetailDTO.setDepartmentId(Integer.toString(rs.getInt("DEPARTMENT_ID")));
		orderItemDetailDTO.setContactPersonName(rs.getString("contact_person_name"));
		orderItemDetailDTO.setContactNumber(rs.getString("contact_number"));
		orderItemDetailDTO.setTotal(rs.getString("total"));
		
		if (rs.getString("installment_number") != null) {
		orderItemDetailDTO.setInstallmentNumber(rs.getString("installment_number"));
		}
		
		orderItemDetailDTO.setProfitMargin(rs.getString("profit_margin"));
		if (rs.getString("month_of_purchase") != null) {
		orderItemDetailDTO.setMonthOfPurchase(rs.getString("month_of_purchase"));
		}
		orderItemDetailDTO.setTotalAmount(rs.getString("total_amount"));
		System.out.println("Department Name" + orderItemDetailDTO.getDepartmentName());
		orderItemDetailDTO.setOrderItemId(Integer.toString(orderitemid));
		
		orderItemDetailDTO.setItemId(rs.getLong("item_id"));
		orderItemDetailDTO.setItemPhaseId(rs.getString("item_phase_id"));
		orderItemDetailDTO.setItemPhaseName(rs.getString("item_phase_name"));
		orderItemDetailDTO.setItemName(rs.getString("item_name"));
		orderItemDetailDTO.setUnitId(rs.getLong("unit_id"));
		orderItemDetailDTO.setUnitName(rs.getString(("unit_name")));
		orderItemDetailDTO.setItemRate(rs.getDouble("item_rate"));
		
		orderItemDetailDTO.setQuantity(rs.getDouble(("quantity")));
				
		orderItemDetailDTO.setAmount(Double.toString(rs.getDouble("amount")));
		orderItemDetailDTO.setComments(rs.getString("comments"));
				
	
		// orderDTO.setTransactionDate(rs.getDate("TRANSACTION_DATE"));
		if (rs.getDate("start_date") != null) {
			orderItemDetailDTO.setStartDate(dateformate.format(rs.getDate("start_date")));
		}
		if (rs.getDate("end_date") != null) {
			orderItemDetailDTO.setEndDate(dateformate.format(rs.getDate("end_date")));
		}
		// ordermultipleDTO.setStartDate(dateformate.format(rs.getDate("start_date")));

		return orderItemDetailDTO;
	}

}
