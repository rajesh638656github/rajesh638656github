package com.grocerybilling.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;

import com.grocerybilling.DTO.OrderItemPriceDTO;


public class OrderItemPriceDetailMapper implements RowMapper<OrderItemPriceDTO> {
	public OrderItemPriceDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		
		OrderItemPriceDTO orderItemPriceDTO = new OrderItemPriceDTO();
		//int orderid;
		orderItemPriceDTO.setOrderItemId(Long.toString(rs.getLong("order_item_id")));
		System.out.println("Printing From OrderItemPriceDetailMapper and Priting Order Item Id " + orderItemPriceDTO.getOrderItemId());
		orderItemPriceDTO.setOrderItemName(rs.getString("item_name"));
		System.out.println("Printing From OrderItemPriceDetailMapper and Priting Order Item Name " + orderItemPriceDTO.getOrderItemName());
		orderItemPriceDTO.setId(Long.toString(rs.getLong("id")));
		System.out.println("Printing From OrderItemPriceDetailMapper and Priting Order Item Price Id" + orderItemPriceDTO.getId());
		orderItemPriceDTO.setItemRateId(Long.toString(rs.getLong("item_rate_id")));
		System.out.println("Printing From OrderItemPriceDetailMapper and Priting Order Item Rate Id" + orderItemPriceDTO.getItemRateId());
		orderItemPriceDTO.setPhaseId(Long.toString(rs.getLong("item_rate_phase_id")));
		orderItemPriceDTO.setPhaseName(rs.getString("item_rate_phase_name"));
		System.out.println("Printing From OrderItemPriceDetailMapper and Priting Rate Phase Name" + orderItemPriceDTO.getPhaseId());
		orderItemPriceDTO.setItemRateName(rs.getString("item_rate_name"));
		System.out.println("Printing From OrderItemPriceDetailMapper and Priting Rate Name" + orderItemPriceDTO.getItemRateName());
		orderItemPriceDTO.setItemRate(Double.toString(rs.getDouble("item_rate")));
	
		System.out.println("Printing From OrderItemPriceDetailMapper and Priting Item Rate " + orderItemPriceDTO.getItemRate());
		orderItemPriceDTO.setNoOfItems(Long.toString(rs.getInt("no_of_items")));
		System.out.println("Printing From OrderItemPriceDetailMapper and Priting  No of Items " + orderItemPriceDTO.getNoOfItems());
		orderItemPriceDTO.setAmount(Double.toString(rs.getDouble("amount")));
		System.out.println("Printing From OrderItemPriceDetailMapper and Priting  Amount" + orderItemPriceDTO.getAmount());
		return orderItemPriceDTO;
	}

}
