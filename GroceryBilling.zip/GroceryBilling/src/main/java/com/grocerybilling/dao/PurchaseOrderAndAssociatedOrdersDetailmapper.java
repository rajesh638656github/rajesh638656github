package com.grocerybilling.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;

import com.grocerybilling.model.PurchaseOrderItemDetailDTO;
import com.grocerybilling.model.PurchaseOrderAndAssociatedOrderDTO;


public class PurchaseOrderAndAssociatedOrdersDetailmapper implements RowMapper<PurchaseOrderAndAssociatedOrderDTO> {
	public PurchaseOrderAndAssociatedOrderDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		PurchaseOrderAndAssociatedOrderDTO purchaseOrderAndAssociatedOrderDTO = new PurchaseOrderAndAssociatedOrderDTO();
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		//int orderid;
				long id = rs.getLong("id");
				int orderid = (int) id;
				int orderid1 = Long.valueOf(id).intValue();
				long order_itemid = rs.getLong("order_id");
				int orderitemid = Long.valueOf(order_itemid).intValue();
		System.out.println("PurchaseOrderItemDetailMapper");
		purchaseOrderAndAssociatedOrderDTO.setRownum(rs.getLong("num_row"));
		//System.out.println("Printing Purchase Order Id" + purchaseOrderOrderDeatilDTO.getPurchaseOrderId());
		purchaseOrderAndAssociatedOrderDTO.setPurchaseOrderId(id);
		System.out.println("Printing Purchase Order Id" + purchaseOrderAndAssociatedOrderDTO.getPurchaseOrderId());
		//orderItemDetailDTO.setInstitutionId(Integer.toString(rs.getInt("INSTITUTION_ID")));

	//	orderItemDetailDTO.setDepartmentId(Integer.toString(rs.getInt("DEPARTMENT_ID")));
		purchaseOrderAndAssociatedOrderDTO.setContactPersonName(rs.getString("contact_person_name"));
		purchaseOrderAndAssociatedOrderDTO.setContactNumber(rs.getString("contact_number"));
		purchaseOrderAndAssociatedOrderDTO.setTotal(rs.getDouble("total"));
		purchaseOrderAndAssociatedOrderDTO.setProfitMargin(rs.getDouble("profit_margin"));
		purchaseOrderAndAssociatedOrderDTO.setTotalAmount(rs.getDouble("total_amount"));
		purchaseOrderAndAssociatedOrderDTO.setPurchaseOrderOrderId(order_itemid);
		purchaseOrderAndAssociatedOrderDTO.setInstitutionName(rs.getString("INSTITUTION_NAME"));
		purchaseOrderAndAssociatedOrderDTO.setInstallmentNumber(rs.getString("installment_number"));
		purchaseOrderAndAssociatedOrderDTO.setMonthOfPurchase(rs.getString("month_of_purchase"));
		
		if (rs.getDate("start_date") != null) {
			purchaseOrderAndAssociatedOrderDTO.setStartDate(dateformate.format(rs.getDate("start_date")));
		}
		System.out.println("Printing Order Id" + purchaseOrderAndAssociatedOrderDTO.getPurchaseOrderOrderId());
		return purchaseOrderAndAssociatedOrderDTO;
	}

}
