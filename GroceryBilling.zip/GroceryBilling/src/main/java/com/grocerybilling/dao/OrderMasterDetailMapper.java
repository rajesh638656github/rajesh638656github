package com.grocerybilling.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;

import com.grocerybilling.DTO.OrderMasterDTO;

public class OrderMasterDetailMapper implements RowMapper<OrderMasterDTO> {
	public OrderMasterDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		OrderMasterDTO OrderMasterDTO = new OrderMasterDTO();
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		//int orderid;
				long id = rs.getLong("ID");
				int orderid = (int) id;
				int orderid1 = Long.valueOf(id).intValue();
			
				OrderMasterDTO.setOrderId(Integer.toString(orderid1));
				OrderMasterDTO.setInstitutionId(Integer.toString(rs.getInt("INSTITUTION_ID")));
			//	if (Integer.toString(rs.getInt("DEPARTMENT_ID")) != null) {
				//OrderMasterDTO.setDepartmentId(Integer.toString(rs.getInt("DEPARTMENT_ID")));
			//	}
				//OrderMasterDTO.setDepartmentName(rs.getString("DEPARTMENT_name"));
				OrderMasterDTO.setMonthOfPurchase(rs.getString("month_of_purchase"));
				OrderMasterDTO.setInstitutionName(rs.getString("INSTITUTION_NAME"));
				OrderMasterDTO.setInstallmentNumber(rs.getString("installment_number"));
				OrderMasterDTO.setContactPersonName(rs.getString("contact_person_name"));
				OrderMasterDTO.setContactNumber(rs.getString("contact_number"));
				OrderMasterDTO.setTotal(rs.getString("total"));
				OrderMasterDTO.setTotalAmount(rs.getString("total_amount"));
				
		if (rs.getDate("start_date") != null) {
			OrderMasterDTO.setStartDate(dateformate.format(rs.getDate("start_date")));
		}
		if (rs.getDate("end_date") != null) {
			OrderMasterDTO.setEndDate(dateformate.format(rs.getDate("end_date")));
		}
		// ordermultipleDTO.setStartDate(dateformate.format(rs.getDate("start_date")));

		return OrderMasterDTO;
	}

}
