package com.grocerybilling.dao;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


import com.grocerybilling.model.QuotationOrderItemDetailDTO;
import com.grocerybilling.DTO.QuotationOrderItemDTO;

import java.text.*;
import java.util.*;
import java.math.BigInteger;

public class QuotationOrderItemDetailMapper implements RowMapper<QuotationOrderItemDetailDTO>{
	public QuotationOrderItemDetailDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		QuotationOrderItemDetailDTO quotationOrderItemDetailDTO = new QuotationOrderItemDetailDTO();
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		//int orderid;
				long id = rs.getLong("id");
				int orderid = (int) id;
				int orderid1 = Long.valueOf(id).intValue();
				long order_itemid = rs.getLong("quotation_order_item_id");
				int orderitemid = Long.valueOf(order_itemid).intValue();
		System.out.println("QuotationOrderItemDetailMapper");
		quotationOrderItemDetailDTO.setRownum(rs.getLong("num_row"));
		System.out.println(" Quotation Order ID" + quotationOrderItemDetailDTO.getQuotationOrderId());
		quotationOrderItemDetailDTO.setQuotationOrderId(id);
		//orderItemDetailDTO.setInstitutionId(Integer.toString(rs.getInt("INSTITUTION_ID")));

	//	orderItemDetailDTO.setDepartmentId(Integer.toString(rs.getInt("DEPARTMENT_ID")));
		quotationOrderItemDetailDTO.setContactPersonName(rs.getString("contact_person_name"));
		quotationOrderItemDetailDTO.setContactNumber(rs.getString("contact_number"));
		System.out.println("Printing Supplier id and name " + rs.getLong("supplier_id") +  "...." + rs.getString("supplier_name"));
		quotationOrderItemDetailDTO.setSupplierId(rs.getLong("supplier_id"));
		quotationOrderItemDetailDTO.setSupplierName(rs.getString("supplier_name"));
		quotationOrderItemDetailDTO.setTotal(rs.getDouble("total"));
		quotationOrderItemDetailDTO.setMonthOfPurchase(rs.getString("month_of_purchase"));
		//	OrderMasterDTO.setInstitutionName(rs.getString("INSTITUTION_NAME"));
		quotationOrderItemDetailDTO.setInstallmentNumber(rs.getString("installment_number"));
		quotationOrderItemDetailDTO.setProfitMargin(rs.getDouble("profit_margin"));
		quotationOrderItemDetailDTO.setTotalAmount(rs.getDouble("total_amount"));
		System.out.println("Department Name" + quotationOrderItemDetailDTO.getDepartmentName());
		quotationOrderItemDetailDTO.setQuotationOrderItemId(order_itemid);
		System.out.println(" Quotation Order Item ID" + quotationOrderItemDetailDTO.getQuotationOrderItemId());
		
		quotationOrderItemDetailDTO.setItemId(rs.getLong("item_id"));
		quotationOrderItemDetailDTO.setItemPhaseId(rs.getLong("item_phase_id"));
		quotationOrderItemDetailDTO.setItemPhaseName(rs.getString("item_phase_name"));
		quotationOrderItemDetailDTO.setItemName(rs.getString("item_name"));
		quotationOrderItemDetailDTO.setItemRate(rs.getDouble("item_rate"));
		quotationOrderItemDetailDTO.setQuantity(rs.getInt(("quantity")));
		quotationOrderItemDetailDTO.setUnitId(rs.getLong("unit_id"));
		quotationOrderItemDetailDTO.setUnitName(rs.getString("unit_name"));
		quotationOrderItemDetailDTO.setAmount(rs.getDouble("amount"));
		quotationOrderItemDetailDTO.setDepartmentId(rs.getLong("department_id"));
		quotationOrderItemDetailDTO.setDepartmentName(rs.getString("department_name"));
				
				
	
		// orderDTO.setTransactionDate(rs.getDate("TRANSACTION_DATE"));
		if (rs.getDate("start_date") != null) {
			quotationOrderItemDetailDTO.setStartDate(dateformate.format(rs.getDate("start_date")));
		}
		if (rs.getDate("end_date") != null) {
			quotationOrderItemDetailDTO.setEndDate(dateformate.format(rs.getDate("end_date")));
		}
		// ordermultipleDTO.setStartDate(dateformate.format(rs.getDate("start_date")));

		return quotationOrderItemDetailDTO;
	}

}
