package com.grocerybilling.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.grocerybilling.DTO.InstitutionDTO;
import com.grocerybilling.model.Order1;
import com.grocerybilling.model.OrderSearchDTO;

import java.text.*;
import java.util.*;

public class OrderSearchForBillingMapper implements RowMapper<OrderSearchDTO> {
	public OrderSearchDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		OrderSearchDTO orderSearchDTO = new OrderSearchDTO();
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		int orderid;
		long id = rs.getLong("ID");
		orderid = (int) id;
		int orderid1 = Long.valueOf(id).intValue();
		System.out.println("Printing Id Initial value" + id);
		System.out.println("Printing Id after Conversion" + orderid);
		System.out.println("Printing Id after Conversion" + orderid1);
		orderSearchDTO.setOrderId(String.valueOf(orderid1));
		System.out.println("OrderItemDetailMapper");
		System.out.println("Order ID" + orderSearchDTO.getOrderId());

		orderSearchDTO.setInstitutionId(Integer.toString(rs.getInt("INSTITUTION_ID")));
		orderSearchDTO.setDepartmentId(Integer.toString(rs.getInt("DEPARTMENT_ID")));
		orderSearchDTO.setInstitutionName(rs.getString("INSTITUTION_NAME"));
		orderSearchDTO.setDepartmentName(rs.getString("DEPARTMENT_NAME"));

		if (rs.getDate("start_date") != null) {
			orderSearchDTO.setStartDate(dateformate.format(rs.getDate("start_date")));
			// orderSearchBillingDTO.setStartDate(rs.getDate("start_date"));
		}
		if (rs.getDate("end_date") != null) {
			orderSearchDTO.setEndDate(dateformate.format(rs.getDate("end_date")));
		}

		return orderSearchDTO;
	}

}
