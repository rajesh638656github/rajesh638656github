package com.grocerybilling.dao;

import com.grocerybilling.DTO.DepartmentDTO;
import com.grocerybilling.model.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;;

public class DepartmentMapper implements RowMapper<DepartmentDTO> {
	public DepartmentDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		DepartmentDTO departmentDTO = new DepartmentDTO();
		departmentDTO.setDepartmentId((rs.getLong("DEPARTMENT_ID")));
		departmentDTO.setDepartmentName(rs.getString("DEPARTMENT_NAME"));
		departmentDTO.setFirstContactPersonName(rs.getString("first_contact_person_name"));
		departmentDTO.setFirstContactPersonContactNumber(rs.getString("first_contact_person_contact_number"));
		departmentDTO.setSecondContactPersonName(rs.getString("second_contact_person_name"));
		departmentDTO.setSecondContactPersonContactNumber(rs.getString("second_contact_person_contact_number"));
		// System.out.println("Printitng Department Name" +
		// rs.getString("DEPARTMENT_NAME"));
		return departmentDTO;
	}
}
