package com.grocerybilling.dao;

import com.grocerybilling.DTO.DepartmentDTO;
import com.grocerybilling.model.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;;

public class DepartmentMapper implements RowMapper<DepartmentDTO> {
	public DepartmentDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		DepartmentDTO departmentDTO = new DepartmentDTO();
		departmentDTO.setDepartmentId((rs.getInt("DEPARTMENT_ID")));
		departmentDTO.setDepartmentName(rs.getString("DEPARTMENT_NAME"));
		// System.out.println("Printitng Department Name" +
		// rs.getString("DEPARTMENT_NAME"));
		return departmentDTO;
	}
}
