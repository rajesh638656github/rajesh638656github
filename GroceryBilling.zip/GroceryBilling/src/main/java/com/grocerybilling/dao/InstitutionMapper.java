package com.grocerybilling.dao;

import com.grocerybilling.DTO.InstitutionDTO;
import com.grocerybilling.model.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class InstitutionMapper implements RowMapper<InstitutionDTO> {
	public InstitutionDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		InstitutionDTO institutionDTO = new InstitutionDTO();
		institutionDTO.setInstitutionId(rs.getInt("INSTITUTION_ID"));
		// System.out.println("Printitng Institution Id" +
		// rs.getLong("INSTITUTION_ID"));
		institutionDTO.setInstitutionName(rs.getString("INSTITUTION_NAME"));
		institutionDTO.setUserName(rs.getString("name"));
		institutionDTO.setEmail(rs.getString("email"));
		// System.out.println("Printitng Institution Name" +
		// rs.getString("INSTITUTION_NAME"));
		return institutionDTO;
	}
}