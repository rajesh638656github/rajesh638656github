package com.grocerybilling.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.grocerybilling.DTO.ItemStatusDTO;
public class ItemStatusMapper implements RowMapper<ItemStatusDTO> {
	public ItemStatusDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		ItemStatusDTO itemStatusDTO = new ItemStatusDTO();
		itemStatusDTO.setItemStatusId(rs.getLong("ITEM_STATUS_ID"));
		// System.out.println("Printitng Institution Id" + rs.getLong("ITEM_ID"));
		itemStatusDTO.setItemStatusName(rs.getString("ITEM_STATUS_NAME"));
		// System.out.println("Printitng Institution Name" + rs.getString("ITEM_NAME"));
		return itemStatusDTO;
	}
}
