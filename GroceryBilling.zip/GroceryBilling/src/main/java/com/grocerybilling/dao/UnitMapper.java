package com.grocerybilling.dao;

import com.grocerybilling.DTO.UnitDTO;
import com.grocerybilling.model.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class UnitMapper implements RowMapper<UnitDTO> {
	public UnitDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		UnitDTO unitDTO = new UnitDTO();
		unitDTO.setUnitId(rs.getLong("UNIT_ID"));
		// System.out.println("Printitng Institution Id" + rs.getLong("UNIT_ID"));
		unitDTO.setUnitName(rs.getString("UNIT_NAME"));
		// System.out.println("Printitng Institution Name" + rs.getString("UNIT_NAME"));
		return unitDTO;
	}
}
