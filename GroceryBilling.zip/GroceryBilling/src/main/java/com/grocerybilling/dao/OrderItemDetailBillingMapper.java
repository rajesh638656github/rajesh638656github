package com.grocerybilling.dao;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.grocerybilling.DTO.InstitutionDTO;
import com.grocerybilling.model.Order1;
import com.grocerybilling.model.OrderItemDetailDTO;

import java.text.*;
import java.util.*;
import java.math.BigInteger;

public class OrderItemDetailBillingMapper implements RowMapper<OrderItemDetailDTO> {
	public OrderItemDetailDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		OrderItemDetailDTO orderItemDetailDTO = new OrderItemDetailDTO();
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		 DecimalFormat df = new DecimalFormat("0.00");
		//int orderid;
				long id = rs.getLong("ID");
				int orderid = (int) id;
				int orderid1 = Long.valueOf(id).intValue();
				long order_itemid = rs.getLong("order_item_id");
				int orderitemid = Long.valueOf(order_itemid).intValue();
		System.out.println("OrderItemDetailMapper");
		orderItemDetailDTO.setRownum(rs.getString("num_row"));
		System.out.println("Order ID" + orderItemDetailDTO.getOrderId());
		orderItemDetailDTO.setOrderId(Integer.toString(orderid1));
		orderItemDetailDTO.setInstitutionId(rs.getLong("INSTITUTION_ID"));

		orderItemDetailDTO.setDepartmentId(Integer.toString(rs.getInt("DEPARTMENT_ID")));
		orderItemDetailDTO.setContactPersonName(rs.getString("contact_person_name"));
		orderItemDetailDTO.setContactNumber(rs.getString("contact_number"));
		
		System.out.println("Printing Total befoew Formating" + rs.getDouble("total"));
		orderItemDetailDTO.setTotal(df.format(rs.getDouble("total")));
		System.out.println("Printing Total befoew Formating" + df.format(rs.getDouble("total")));
		orderItemDetailDTO.setProfitMargin(rs.getString("profit_margin"));
		orderItemDetailDTO.setTotalAmount(df.format(rs.getDouble("total_amount")));
		System.out.println("Department Name" + orderItemDetailDTO.getDepartmentName());
		orderItemDetailDTO.setOrderItemId(Integer.toString(orderitemid));
	/*	orderItemDetailDTO.setItemId(Integer.toString(rs.getInt("ITEM_ID")));
		orderItemDetailDTO.setItemDescription(rs.getString("item_description"));
		orderItemDetailDTO.setSizeId(Integer.toString(rs.getInt("SIZE_ID")));
		orderItemDetailDTO.setNote(rs.getString("note"));
		orderItemDetailDTO.setUnitId(Integer.toString(rs.getInt("UNIT_ID")));
		orderItemDetailDTO.setItemstatusId(Integer.toString(rs.getInt("item_status_id")));
		// System.out.println("Printitng ORDER ID " + rs.getInt("ORDER_ID"));
		orderItemDetailDTO.setInstitutionName(rs.getString("INSTITUTION_NAME"));
		orderItemDetailDTO.setDepartmentName(rs.getString("DEPARTMENT_NAME"));
		orderItemDetailDTO.setItemName(rs.getString("ITEM_NAME"));
		orderItemDetailDTO.setSizeName(rs.getString("SIZE_NAME"));
		orderItemDetailDTO.setUnitName(rs.getString("UNIT_NAME"));
		orderItemDetailDTO.setItemStatus(rs.getString("item_status_name"));
		orderItemDetailDTO.setQuantity(Integer.toString(rs.getInt("QUANTITY")));
		System.out.println("Printing Total befoew Formating" + rs.getDouble("PRICE"));
		orderItemDetailDTO.setPrice(df.format(rs.getDouble("PRICE")));
		System.out.println("Printing Total befoew Formating" + df.format(rs.getDouble("PRICE")));
		orderItemDetailDTO.setAmount(df.format(rs.getDouble("amount")));
		orderItemDetailDTO.setComments(rs.getString("comments"));*/
		// orderDTO.setTransactionDate(rs.getDate("TRANSACTION_DATE"));
		if (rs.getDate("start_date") != null) {
			orderItemDetailDTO.setStartDate(dateformate.format(rs.getDate("start_date")));
		}
		if (rs.getDate("end_date") != null) {
			orderItemDetailDTO.setEndDate(dateformate.format(rs.getDate("end_date")));
		}
		// ordermultipleDTO.setStartDate(dateformate.format(rs.getDate("start_date")));

		return orderItemDetailDTO;
	}

}
