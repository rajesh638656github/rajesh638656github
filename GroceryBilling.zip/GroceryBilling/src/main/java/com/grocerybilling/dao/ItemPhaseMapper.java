package com.grocerybilling.dao;

import com.grocerybilling.DTO.ItemPhaseDTO;
import com.grocerybilling.model.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
public class ItemPhaseMapper implements RowMapper<ItemPhaseDTO>{
	public ItemPhaseDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		ItemPhaseDTO itemPhaseDTO = new ItemPhaseDTO();
		itemPhaseDTO.setItemPhaseId(rs.getInt("item_Phase_id"));
		// System.out.println("Printitng Institution Id" +
		// rs.getLong("INSTITUTION_ID"));
		itemPhaseDTO.setItemPhaseName(rs.getString("item_phase_name"));
		// System.out.println("Printitng Institution Name" +
		// rs.getString("INSTITUTION_NAME"));
		return itemPhaseDTO;
	}

}
