package com.grocerybilling.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;

import com.grocerybilling.DTO.OrderDTO;

public class BillDetailMapper implements RowMapper<OrderDTO> {
	public OrderDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		OrderDTO BillDTO = new OrderDTO();
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		//int orderid;
				long billId = rs.getLong("bill_id");
				int intBillIdTemp = (int) billId;
				int intBillId = Long.valueOf(intBillIdTemp).intValue();
			
			//	BillDTO.setBillId(intBillId);
				BillDTO.setTotalAmount(rs.getDouble("total_amount"));
			
				//BillDTO.setTaxAmount(rs.getDouble("tax_amount"));
			
				
			
				//BillDTO.setTotalAmount(rs.getDouble("total_amount"));
				
		if (rs.getDate("transaction_date") != null) {
		//	BillDTO.setStartDate((dateformate.format(rs.getDate("transaction_date"))));
			
		}
	
		return BillDTO;
	}

}
