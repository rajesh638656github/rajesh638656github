package com.grocerybilling.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;

import com.grocerybilling.DTO.OrderDTO;

public class BillReportMapper implements RowMapper<OrderDTO> {
	public OrderDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		OrderDTO BillDTO = new OrderDTO();
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		//int orderid;
				long billId = rs.getLong("bill_id");
				int intBillIdTemp = (int) billId;
				int intBillId = Long.valueOf(intBillIdTemp).intValue();
			
		//		BillDTO.setBillId(intBillId);
				//BillDTO.setSubTotal(rs.getDouble("total_amount"));
			//	BillDTO.setInstitutionName(rs.getString("institution_name"));
			//	System.out.println("Printing Institution Name" + BillDTO.getInstitutionName());
			
				//BillDTO.setTaxAmount(rs.getDouble("tax_amount"));
			
				
			
			   BillDTO.setTotalAmount(rs.getDouble("total_amount"));
				
		/* if (rs.getDate("transaction_date") != null) {
			BillDTO.setTransactionDate(dateformate.format(rs.getDate("transaction_date")));
		}*/
	
		return BillDTO;
	}


}
