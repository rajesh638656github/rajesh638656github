package com.grocerybilling.dao;
import com.grocerybilling.DTO.ItemDTO;
import com.grocerybilling.DTO.ItemDTO;
import com.grocerybilling.model.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class ItemWithDepartmentMapper implements RowMapper<ItemDTO> {
	
	public ItemDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		ItemDTO itemDTO = new ItemDTO();
		itemDTO.setPhaseId(rs.getLong("item_phase_id"));
		itemDTO.setPhaseName(rs.getString("ITEM_PHASE_NAME"));
		itemDTO.setItemId(rs.getLong("ITEM_ID"));
		// System.out.println("Printitng Institution Id" + rs.getLong("ITEM_ID"));
		itemDTO.setItemName(rs.getString("ITEM_NAME"));
		itemDTO.setItemRate(rs.getDouble("ITEM_RATE"));
		if (rs.getString("department_name") != null) {
		itemDTO.setDepartmentName(rs.getString("department_name"));
		}
		
		// System.out.println("Printitng Institution Name" + rs.getString("ITEM_NAME"));
		return itemDTO;
	}

}