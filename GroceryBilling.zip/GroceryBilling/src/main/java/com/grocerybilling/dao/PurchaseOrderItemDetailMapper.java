package com.grocerybilling.dao;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.grocerybilling.model.PurchaseOrderItemDetailDTO;
import com.grocerybilling.DTO.PurchaseOrderItemDTO;

import java.text.*;
import java.util.*;
import java.math.BigInteger;
public class PurchaseOrderItemDetailMapper  implements RowMapper<PurchaseOrderItemDetailDTO> {
	public PurchaseOrderItemDetailDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		PurchaseOrderItemDetailDTO purchaseOrderItemDTO = new PurchaseOrderItemDetailDTO();
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		//int orderid;
				long id = rs.getLong("id");
				int orderid = (int) id;
				int orderid1 = Long.valueOf(id).intValue();
				long order_itemid = rs.getLong("purchase_order_item_id");
				int orderitemid = Long.valueOf(order_itemid).intValue();
		System.out.println("PurchaseOrderItemDetailMapper");
		purchaseOrderItemDTO.setRownum(rs.getLong("num_row"));
		System.out.println(" Purchase Order ID" + purchaseOrderItemDTO.getPurchaseOrderId());
		purchaseOrderItemDTO.setPurchaseOrderId(id);
		//orderItemDetailDTO.setInstitutionId(Integer.toString(rs.getInt("INSTITUTION_ID")));

	//	orderItemDetailDTO.setDepartmentId(Integer.toString(rs.getInt("DEPARTMENT_ID")));
		purchaseOrderItemDTO.setContactPersonName(rs.getString("contact_person_name"));
		purchaseOrderItemDTO.setContactNumber(rs.getString("contact_number"));
		purchaseOrderItemDTO.setTotal(rs.getDouble("total"));
		purchaseOrderItemDTO.setProfitMargin(rs.getDouble("profit_margin"));
		purchaseOrderItemDTO.setMonthOfPurchase(rs.getString("month_of_purchase"));
		purchaseOrderItemDTO.setComments(rs.getString("comments"));
		purchaseOrderItemDTO.setInstallmentNumber(rs.getString("installment_number"));
		purchaseOrderItemDTO.setTotalAmount(rs.getDouble("total_amount"));
		System.out.println("Department Name" + purchaseOrderItemDTO.getDepartmentName());
		purchaseOrderItemDTO.setPurchaseOrderItemId(order_itemid);
		
		purchaseOrderItemDTO.setItemId(rs.getLong("item_id"));
		purchaseOrderItemDTO.setItemPhaseId(rs.getLong("item_phase_id"));
		purchaseOrderItemDTO.setItemPhaseName(rs.getString("item_phase_name"));
		purchaseOrderItemDTO.setItemName(rs.getString("item_name"));
		purchaseOrderItemDTO.setItemRate(rs.getDouble("item_rate"));
		purchaseOrderItemDTO.setQuantity(rs.getDouble(("quantity")));
		purchaseOrderItemDTO.setUnitId(rs.getLong(("unit_id")));
		purchaseOrderItemDTO.setUnitName(rs.getString(("unit_name")));
		purchaseOrderItemDTO.setAmount(rs.getDouble("amount"));
		purchaseOrderItemDTO.setInstitutionId(rs.getLong("institution_id"));
		purchaseOrderItemDTO.setInstitutionName(rs.getString("institution_name"));
		
		purchaseOrderItemDTO.setDepartmentId(rs.getLong("department_id"));
		purchaseOrderItemDTO.setDepartmentName(rs.getString("department_name"));
				
				
	
		// orderDTO.setTransactionDate(rs.getDate("TRANSACTION_DATE"));
		if (rs.getDate("start_date") != null) {
			purchaseOrderItemDTO.setStartDate(dateformate.format(rs.getDate("start_date")));
		}
		if (rs.getDate("end_date") != null) {
			purchaseOrderItemDTO.setEndDate(dateformate.format(rs.getDate("end_date")));
		}
		// ordermultipleDTO.setStartDate(dateformate.format(rs.getDate("start_date")));

		return purchaseOrderItemDTO;
	}

}

