package com.grocerybilling.service.impl;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import com.grocerybilling.DTO.OrderDTO;
import com.grocerybilling.DTO.BillOrderDTO;
import com.grocerybilling.DTO.DepartmentDTO;
import com.grocerybilling.DTO.InstitutionDTO;
import com.grocerybilling.DTO.ItemDTO;
import com.grocerybilling.DTO.ItemDTO;
import com.grocerybilling.DTO.ItemPhaseDTO;
import com.grocerybilling.DTO.ItemStatusDTO;
import com.grocerybilling.DTO.OrderItemPriceDTO;
import com.grocerybilling.DTO.OrderMasterDTO;
import com.grocerybilling.DTO.SizeDTO;
import com.grocerybilling.DTO.UnitDTO;
import com.grocerybilling.dao.*;
import com.grocerybilling.model.*;
import com.grocerybilling.service.*;

import java.util.List;
import java.util.Date;
import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.beans.factory.annotation.Autowired;

@Service
@AllArgsConstructor

public class PopulateOrderScreenServiceImpl implements PopulateOrderScreenService {

	@Autowired
	private PopulateOrderScreenServiceDAO populateOrderScreenServiceDAO;

	@Override
	public List<InstitutionDTO> findAllInstitutions() {
		try {

			return populateOrderScreenServiceDAO.findAllInstitutions();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<InstitutionDTO> findInstitutionById(long institutionId) {
		try {

			return populateOrderScreenServiceDAO.findInstitutionById(institutionId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public List<DepartmentDTO> findAllDepartments() {
		try {

			return populateOrderScreenServiceDAO.findAllDepartments();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<DepartmentDTO> findAllValidDepartments() {
		try {

			return populateOrderScreenServiceDAO.findAllValidDepartments();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	
	
	
	public List<ItemDTO> findAllItems() {
		try {

			return populateOrderScreenServiceDAO.findAllItems();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	 
	public List<ItemDTO> findAllItemByIds(List itemIds) {
		try {

			return populateOrderScreenServiceDAO.findAllItemByIds(itemIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<ItemDTO> findAllItemWithDepartmentNameByItemIds(List itemIds) {
		try {

			return populateOrderScreenServiceDAO.findAllItemWithDepartmentNameByItemIds(itemIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public List<SizeDTO> findAllSizes() {
		try {

			return populateOrderScreenServiceDAO.findAllSizes();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public List<UnitDTO> findAllUnits() {
		try {

			return populateOrderScreenServiceDAO.findAllUnits();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<ItemPhaseDTO> findAllItemPhase(){
		try {

			return populateOrderScreenServiceDAO.findAllItemRatePhase();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<ItemStatusDTO> findAllItemStatus() {
		try {

			return populateOrderScreenServiceDAO.findAllItemStatus();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public List<OrderSearchDTO> findOrderByOrderIdorInstitutionIdorDepartmentId(OrderSearchDTO OrderSearchBillingDTO) {
		try {

			return populateOrderScreenServiceDAO.findOrderByOrderIdorInstitutionIdorDepartmentId(OrderSearchBillingDTO);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<OrderSearchDTO> findAllOrderForBillDraft() {
		try {

			return populateOrderScreenServiceDAO.findAllOrderForBillDraft();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<OrderDTO> findRevenueDetails(Date startDate,Date endDate) {
		try {

			return populateOrderScreenServiceDAO.findRevenueDetails(startDate, endDate);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<OrderDTO> findBillByInstitution(Date startDate,Date endDate,long institutionId) {
		try {

			return populateOrderScreenServiceDAO.findBillByInstitution(startDate, endDate,institutionId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<OrderDTO> findBillByInstitutionOrBillId(BillSearchDTO billSearchDTO) {
		try {

			return populateOrderScreenServiceDAO.findBillByInstitutionOrBillId(billSearchDTO);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<BillOrderDTO> findBillOrderDetailByBillId(long billId) {
		try {

			return populateOrderScreenServiceDAO.findBillOrderDetailByBillId(billId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<OrderItemPriceDTO> findOrderItemPriceDetailByOrderItemId(List<Long> orderItemIds) {
		try {
			
			return populateOrderScreenServiceDAO.findOrderItemPriceDetailByOrderItemId(orderItemIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	public List<OrderDTO> findBillByInstitutionOrBillIdForDuplicateBill(BillSearchDTO billSearchDTO) {
		try {

			return populateOrderScreenServiceDAO.findBillByInstitutionOrBillIdForDuplicateBill(billSearchDTO);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<OrderItemDetailDTO> findOrderItemDetailsForDuplicateBill(List<Long> orderIds) {
		try {

			return populateOrderScreenServiceDAO.findOrderItemDetailsForDuplicateBill(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	
	
	
	public List<BillOrderDTO> findBillOrderDetail() {
		try {

			return populateOrderScreenServiceDAO.findBillOrderDetail();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<BillOrderDTO> findBillOrderDetailForDuplicateBill() {
		try {

			return populateOrderScreenServiceDAO.findBillOrderDetailForDuplicateBill();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public List<OrderItemDetailDTO> findOrderItemDetails(List orderIds) {
		try {

			return populateOrderScreenServiceDAO.findOrderItemDetails(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<OrderItemDetailDTO> findClosedOrderItemDetails(List orderIds) {
		try {

			return populateOrderScreenServiceDAO.findClosedOrderItemDetails(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<PurchaseOrderItemDetailDTO> findPurchaseOrderItemDetails(List orderIds) {
		try {

			return populateOrderScreenServiceDAO.findPurchaseOrderItemDetails(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<PurchaseOrderItemDetailDTO> findClosedPurchaseOrderItemDetails(List orderIds) {
		try {

			return populateOrderScreenServiceDAO.findClosedPurchaseOrderItemDetails(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<PurchaseOrderItemDetailDTO> findDistinctInstitutionSupplierFromPurchaseOrder(List orderIds) {
		try {

			return populateOrderScreenServiceDAO.findDistinctInstitutionSupplierFromPurchaseOrder(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	
	public List<PurchaseOrderItemDetailDTO> findPurchaseOrderItemDetailsByItemId(long itemId) {
		try {

			return populateOrderScreenServiceDAO.findPurchaseOrderItemDetailsByItemId(itemId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<OrderMasterDTO> findClosedPurchaseOrderByInstitutionId(Integer institutionId) {
		try {

			return populateOrderScreenServiceDAO.findClosedPurchaseOrderByInstitutionId(institutionId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	
	public List<PurchaseOrderItemDetailDTO> findPurchaseOrderItemDetailsBySupplierId(List orderIds,long supplierId) {
		try {

			return populateOrderScreenServiceDAO.findPurchaseOrderItemDetailsBySupplierId(orderIds,supplierId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<PurchaseOrderItemDetailDTO> findPurchaseOrderItemDetailsByInstitutionId(List orderIds,long institutionId) {
		try {

			return populateOrderScreenServiceDAO.findPurchaseOrderItemDetailsByInstitutionId(orderIds,institutionId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<QuotationOrderItemDetailDTO> findQuotationOrderItemDetails(List orderIds) {
		try {

			return populateOrderScreenServiceDAO.findQuotationOrderItemDetails(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<PurchaseOrderAndAssociatedOrderDTO> findPurchaseOrderAndAssociatedOrders(List orderIds) {
		try {

			return populateOrderScreenServiceDAO.findPurchaseOrderAndAssociatedOrders(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	
	public List<PurchaseOrderAndAssociatedOrderDTO> findPurchaseOrderAndAssociatedOrdersForAllActivePurchaseOrder() {
		try {

			return populateOrderScreenServiceDAO.findPurchaseOrderAndAssociatedOrdersForAllActivePurchaseOrder();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<PurchaseOrderAndAssociatedOrderDTO> findPurchaseOrderAndAssociatedOrdersForAllCompletePurchaseOrder() {
		try {

			return populateOrderScreenServiceDAO.findPurchaseOrderAndAssociatedOrdersForAllCompletePurchaseOrder();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	
	public List<OrderItemDetailDTO> findOrderItemDetailsforBilling(List orderIds) {
		try {

			return populateOrderScreenServiceDAO.findOrderItemDetailsforBilling(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	
	public List<OrderItemDetailDTO> findAllActiveOrderItemDetails() {
		try {

			return populateOrderScreenServiceDAO.findAllActiveOrderItemDetails();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	
	
	
	 public List<OrderMasterDTO> findOrderMasterDetails(List orderIds) {
		try {

			return populateOrderScreenServiceDAO.findOrderMasterDetails(orderIds);
			
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	} 
	 
	 public List<OrderMasterDTO> findAllActiveOrders() {
	 try {

			return populateOrderScreenServiceDAO.findAllActiveOrders();
			
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	} 
	 
	 public List<OrderMasterDTO> findAllActiveOrdersByInstitution(List<Integer> institutionIds) {
		 try {

				return populateOrderScreenServiceDAO.findAllActiveOrdersByInstitution(institutionIds);
				
			} catch (Exception e) {
				System.out.println(e);
				throw new RuntimeException(e);
			}

		} 
	 
	 
	 public List<OrderMasterDTO> findAllCompleteOrdersByInstitution(List<Integer> institutionIds) {
		 try {

				return populateOrderScreenServiceDAO.findAllCompleteOrdersByInstitution(institutionIds);
				
			} catch (Exception e) {
				System.out.println(e);
				throw new RuntimeException(e);
			}

		} 
	 
	 public List<OrderMasterDTO> findAllActiveOrderForCreatingPurchaseOrder() {
		 try {

				return populateOrderScreenServiceDAO.findAllActiveOrderForCreatingPurchaseOrder();
				
			} catch (Exception e) {
				System.out.println(e);
				throw new RuntimeException(e);
			}

		} 
	 
	 
	 public List<OrderMasterDTO> findAllActiveOrderForCreatingQuotationOrder() {
		 try {

				return populateOrderScreenServiceDAO.findAllActiveOrderForCreatingQuotationOrder();
				
			} catch (Exception e) {
				System.out.println(e);
				throw new RuntimeException(e);
			}

		} 

	 public List<OrderMasterDTO> findAllActiveQuotationOrder(int year,String monthOfPurchase,String installmentNumber) {
		 try {

				return populateOrderScreenServiceDAO.findAllActiveQuotationOrder(year,monthOfPurchase,installmentNumber);
				
			} catch (Exception e) {
				System.out.println(e);
				throw new RuntimeException(e);
			}

		} 


	 
	 public List<OrderMasterDTO> findAllActivePurchaseOrders(int year,String monthOfPurchase,String installmentNumber) {
		 try {

				return populateOrderScreenServiceDAO.findAllActivePurchaseOrders(year,monthOfPurchase,installmentNumber);
				
			} catch (Exception e) {
				System.out.println(e);
				throw new RuntimeException(e);
			}

		} 
	 
	 
	 public List<OrderMasterDTO> findAllCompletePurchaseOrders() {
		 try {

				return populateOrderScreenServiceDAO.findAllCompletePurchaseOrders();
				
			} catch (Exception e) {
				System.out.println(e);
				throw new RuntimeException(e);
			}

		} 
	 
	 
	 public List<OrderItemDetailDTO> findAllOrdersByItemType(List itemIds) {
			try {

				return populateOrderScreenServiceDAO.findAllOrdersByItemType(itemIds);
				
			} catch (Exception e) {
				System.out.println(e);
				throw new RuntimeException(e);
			}

		} 

	
		public List<OrderSubTotalDTO> findSubTotalForBilling(List<Long> orderIds) {
		try {

			return populateOrderScreenServiceDAO.findSubTotalForBilling(orderIds);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
		
		public List<QuotationSubTotalDTO> findSubTotalForQuotation(Long quotationId) {
			try {

				return populateOrderScreenServiceDAO.findSubTotalForQuotation(quotationId);
			} catch (Exception e) {
				System.out.println(e);
				throw new RuntimeException(e);
			}

		}

	public List<OrderSubTotalDTO> findSubTotalforEachOrderId() {
		try {

			return populateOrderScreenServiceDAO.findSubTotalforEachOrderId();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public void updateQuoatationItems(long quotationId,int quantity,double price,double amount) {
		try {

		 populateOrderScreenServiceDAO.updateQuoatationItems(quotationId,quantity,price,amount);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public void deleteOrderItem(long orderItemId) {
		try {

			 populateOrderScreenServiceDAO.deleteOrderItem(orderItemId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public void deleteOrderItemPrice(long orderItemId) {
		try {

			 populateOrderScreenServiceDAO.deleteOrderItemPrice(orderItemId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	
	public void deleteOrderItems(long orderId) {
		try {

			 populateOrderScreenServiceDAO.deleteOrderItems(orderId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public int findMaxOrderID() {
		try {

			return populateOrderScreenServiceDAO.findMaxOrderID();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public int createInstitution(String institutionName) {
		try {

			return populateOrderScreenServiceDAO.createInstitution(institutionName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public int createDepartment(String departmentName) {
		try {

			return populateOrderScreenServiceDAO.createDepartment(departmentName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	

	public int createItem(String itemName) {
		try {

			return populateOrderScreenServiceDAO.createItem(itemName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public int createSize(String sizeName) {
		try {

			return populateOrderScreenServiceDAO.createSize(sizeName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public int createUnit(String unitName) {
		try {

			return populateOrderScreenServiceDAO.createUnit(unitName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public int createItemRate(String costItemName) {
		try {

			return populateOrderScreenServiceDAO.createCostItem(costItemName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

}
