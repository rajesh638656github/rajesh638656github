package com.grocerybilling.service;

import com.grocerybilling.DTO.OrderDTO;
import com.grocerybilling.DTO.BillOrderDTO;
import com.grocerybilling.DTO.DepartmentDTO;
import com.grocerybilling.DTO.InstitutionDTO;
import com.grocerybilling.DTO.ItemDTO;
import com.grocerybilling.DTO.ItemDTO;
import com.grocerybilling.DTO.ItemPhaseDTO;
import com.grocerybilling.DTO.ItemStatusDTO;
import com.grocerybilling.DTO.OrderItemPriceDTO;
import com.grocerybilling.DTO.OrderMasterDTO;
import com.grocerybilling.DTO.PhaseNameDTO;
import com.grocerybilling.DTO.SizeDTO;
import com.grocerybilling.DTO.UnitDTO;
import com.grocerybilling.DTO.BillItemPriceDTO;
import com.grocerybilling.DTO.PurchaseOrderItemDTO;
import com.grocerybilling.DTO.QuotationOrderItemDTO;
import com.grocerybilling.model.*;

import java.util.List;
import java.util.Date;


public interface PopulateOrderScreenService {
	public List<InstitutionDTO> findAllInstitutions();
	
	public List<InstitutionDTO> findInstitutionById(long institutionId);

	public List<DepartmentDTO> findAllDepartments();
	
	public List<DepartmentDTO> findAllValidDepartments();

	
	public List<ItemDTO> findAllItems();
	
	public List<ItemDTO> findAllItemByIds(List itemIds);
	
	public List<ItemDTO> findAllItemWithDepartmentNameByItemIds(List itemIds); 

	public List<SizeDTO> findAllSizes();

	public List<UnitDTO> findAllUnits();
	
	public List<ItemStatusDTO> findAllItemStatus();
	
	public List<ItemPhaseDTO> findAllItemPhase();
	
	public List<OrderMasterDTO> findAllActiveOrders();
	
	public List<OrderMasterDTO> findAllActiveOrderForCreatingPurchaseOrder();
	
	public List<OrderMasterDTO> findAllActiveOrderForCreatingQuotationOrder();
	
	public List<OrderMasterDTO> findAllActiveQuotationOrder(int year,String monthOfPurchase,String installmentNumber);
	
	public List<OrderMasterDTO> findAllActiveOrdersByInstitution(List<Integer> institutionId);
	
	public List<OrderMasterDTO> findAllCompleteOrdersByInstitution(List<Integer> institutionId);
	
	public List<OrderMasterDTO> findAllActivePurchaseOrders(int year,String monthOfPurchase,String installmentNumber);
	
	public List<OrderMasterDTO> findAllCompletePurchaseOrders();
		
	//public List<PhaseNameDTO> findAllPhaseNames();
	
	public List<OrderDTO> findRevenueDetails(Date startDate,Date endDate);
	
	public List<OrderDTO> findBillByInstitution(Date startDate,Date endDate,long institutionId);
	
	public List<OrderDTO> findBillByInstitutionOrBillId(BillSearchDTO billSearchDTO);
	
	public List<OrderDTO> findBillByInstitutionOrBillIdForDuplicateBill(BillSearchDTO billSearchDTO);
	
	public List<BillOrderDTO> findBillOrderDetailByBillId(long billId);
	
	//public List<OrderItemPriceDTO> findOrderItemPriceDetailByOrderItemId(List<Long> orderItemIds);
	
//	public List<BillItemPriceDTO> findBillItemPriceDetailByBillId(List<Long> billIds);
	
	public List<BillOrderDTO> findBillOrderDetail();
	
	public List<BillOrderDTO> findBillOrderDetailForDuplicateBill();
	
	public List<OrderItemDetailDTO> findAllOrdersByItemType(List itemIds);
	
	public List<OrderMasterDTO> findOrderMasterDetails(List orderIds);

	public List<OrderItemDetailDTO> findOrderItemDetails(List orderId);
	
	public List<OrderItemDetailDTO> findClosedOrderItemDetails(List orderId);
	
	public List<PurchaseOrderItemDetailDTO> findPurchaseOrderItemDetails(List orderId);
	
	public List<OrderMasterDTO> findClosedPurchaseOrderByInstitutionId(Integer institutionId);
	
	public List<PurchaseOrderItemDetailDTO> findClosedPurchaseOrderItemDetails(List orderId);
	
	public List<PurchaseOrderItemDetailDTO> findDistinctInstitutionSupplierFromPurchaseOrder(List orderId);
	
	public List<PurchaseOrderItemDetailDTO> findPurchaseOrderItemDetailsByItemId(long itemId);
	
	public List<PurchaseOrderItemDetailDTO> findPurchaseOrderItemDetailsBySupplierId(List orderId,long supplierId);
	
	public List<PurchaseOrderItemDetailDTO> findPurchaseOrderItemDetailsByInstitutionId(List orderId,long institutionId);
	
	public List<QuotationOrderItemDetailDTO> findQuotationOrderItemDetails(List orderId);
	
	public List<PurchaseOrderAndAssociatedOrderDTO> findPurchaseOrderAndAssociatedOrders(List orderId);
	
	public List<PurchaseOrderAndAssociatedOrderDTO> findPurchaseOrderAndAssociatedOrdersForAllActivePurchaseOrder();
	
	public List<PurchaseOrderAndAssociatedOrderDTO> findPurchaseOrderAndAssociatedOrdersForAllCompletePurchaseOrder();
	
	public void deleteOrderItems(long orderId);
	
	public List<OrderItemDetailDTO> findOrderItemDetailsforBilling(List orderId);
	
	public List<OrderItemDetailDTO> findOrderItemDetailsForDuplicateBill(List<Long> orderIds);
	
	public List<OrderItemDetailDTO> findAllActiveOrderItemDetails();
	
//	public List<OrderItemDetailDTO> findQuotationOrderItemDetails(List orderId,Long quotationId);

	public List<OrderSearchDTO> findOrderByOrderIdorInstitutionIdorDepartmentId(OrderSearchDTO OrderSearchBillingDTO);
	
	public List<OrderSearchDTO> findAllOrderForBillDraft();
	
	//public List<OrderSearchDTO> findAllBillForPrint();
	
	public void deleteOrderItem(long orderItemId);
	
	public void deleteOrderItemPrice(long orderItemPriceId);
	
	public void updateQuoatationItems(long quotationId,int quantity,double price,double amount);

	public int findMaxOrderID();

	public List<OrderSubTotalDTO> findSubTotalforEachOrderId();

	public List<OrderSubTotalDTO> findSubTotalForBilling(List<Long> orderIds);
	
	public List<QuotationSubTotalDTO> findSubTotalForQuotation(Long quotationId);

	public int createInstitution(String institutionName);

	public int createDepartment(String departmentName);

	public int createItem(String itemName);

	public int createSize(String itemSize);

	public int createUnit(String unitName);
	
	public int createItemRate(String itemName);

}
