package com.grocerybilling.PDFGenerator;
import java.awt.Color;
import java.io.IOException;
import java.util.List;
import com.grocerybilling.model.*;
 
import javax.servlet.http.HttpServletResponse;
 
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
public class UserPDFExporter {

	 private List<PurchaseOrderItemDetailDTO> listUsers;
     
	    public UserPDFExporter(List<PurchaseOrderItemDetailDTO> listUsers) {
	        this.listUsers = listUsers;
	    }
	 
	    private void writeTableHeader(PdfPTable table) {
	        PdfPCell cell = new PdfPCell();
	        cell.setBackgroundColor(Color.BLUE);
	        cell.setPadding(5);
	         
	        Font font = FontFactory.getFont(FontFactory.HELVETICA);
	        font.setColor(Color.WHITE);
	         
	        cell.setPhrase(new Phrase("Item Name", font));
	         
	        table.addCell(cell);
	         
	        cell.setPhrase(new Phrase("Quantity", font));
	        table.addCell(cell);
	         
	        cell.setPhrase(new Phrase("Unit", font));
	        table.addCell(cell);
	         
	        cell.setPhrase(new Phrase("Rate", font));
	        table.addCell(cell);
	         
	        cell.setPhrase(new Phrase("Amount", font));
	        table.addCell(cell);       
	    }
	     
	    private void writeTableData(PdfPTable table) {
	        for (PurchaseOrderItemDetailDTO item : listUsers) {
	            table.addCell(item.getItemName());
	            System.out.println("Printing Item name" + item.getItemName());
	            table.addCell(String.valueOf(item.getQuantity()));
	            table.addCell(item.getUnitName());
	            table.addCell(String.valueOf(item.getItemRate()));
	            table.addCell(String.valueOf(item.getAmount()));
	            System.out.println("Printing PDF Table" + table.toString());
	            
	        }
	    }
	     
	    public void export(jakarta.servlet.http.HttpServletResponse response) throws DocumentException, IOException {
	    	//  FontFactory.register("C:\\Windows\\Fonts\\NIRMALA.TTF");
	    	 FontFactory.register("D:\\migration\\GroceryBilling\\src\\main\\resources\\fonts\\BAMINI-Tamil10.ttf");
	    	 FontFactory.register("D:\\migration\\GroceryBilling\\src\\main\\resources\\fonts\\Latha.ttf");
	    	 // BaseFont baseFont = BaseFont.createFont("src/main/resources/fonts/BAMINI-Tamil10.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
	    	//  Font tamilFont = new Font(baseFont, 12);
	    	FontFactory.register("D:\\migration\\GroceryBilling\\src\\main\\resources\\fonts\\NIRMALA.TTF");
	    	  //FontFactory.register("C:\\Windows\\Fonts\\NIRMALA.TTF");
	        Document document = new Document(PageSize.A4.rotate());
	  
	        PdfWriter.getInstance(document, response.getOutputStream());
	         
	        document.open();
	        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
	      //  Font font = FontFactory.getFont("latha ui", "Identity-H",false,10,0,null);
	      
	     //   Font fonttamil = FontFactory.getFont("bamini ui", "Identity-H");
	      //  font.setSize(18);
	      //  font.setColor(Color.BLUE);
	        
	        document.add(new Chunk(
                    "தமிழ் எழுத்து முறை",
                    FontFactory.getFont("Latha ui", "",false,10,0,null)));
	        
	        document.add(new Chunk(
                    "தமிழ் எழுத்து முறை",
                    FontFactory.getFont("bamini ui", "",false,10,0,null)));
	        
	        document.add(new Chunk(
                    "नमस्ते",
                    FontFactory.getFont("nirmala ui", "Identity-H",false,10,0,null)));
	         
	        Paragraph p = new Paragraph("List of Users", font);
	        p.setAlignment(Paragraph.ALIGN_CENTER);
	      
	        document.add(p);
	         
	        PdfPTable table = new PdfPTable(5);
	        table.setWidthPercentage(100f);
	        table.setWidths(new float[] {1.5f, 3.5f, 3.0f, 3.0f, 1.5f});
	        table.setSpacingBefore(10);
	         
	        writeTableHeader(table);
	        writeTableData(table);
	         System.out.println("Printing PDF Table" + table.toString());
	        document.add(table);
	         
	        document.close();
	         
	    }
	}
