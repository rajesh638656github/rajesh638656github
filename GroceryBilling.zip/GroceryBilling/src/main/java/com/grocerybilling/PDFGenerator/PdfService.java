package com.grocerybilling.PDFGenerator;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import com.grocerybilling.model.*;

public class PdfService {
	  int serialNo = 1;
	 public byte[] generatePdf(String clientName, List<PurchaseOrderItemDetailDTO> items) throws IOException {
	        PDDocument document = new PDDocument();
	        PDPage page = new PDPage(PDRectangle.A4);
	        document.addPage(page);

	        float margin = 50;
	        float startY = page.getMediaBox().getHeight() - margin;
	        float tableWidth = page.getMediaBox().getWidth() - 2 * margin;
	        float[] colWidths = {40, 200, 80, 80, 95};
	        float cellHeight = 20f;
	      

	        try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
	            // Write Client Name
	            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
	            contentStream.beginText();
	            contentStream.newLineAtOffset(margin, startY);
	            contentStream.showText("Client Name: " + clientName);
	            contentStream.endText();
	            startY -= 30;

	            // Draw Table Header
	            drawTableHeader(contentStream, margin, startY, tableWidth, colWidths, cellHeight);
	            startY -= cellHeight;

	            // Draw Table Rows
	            double total = 0.0;
	            for (PurchaseOrderItemDetailDTO item : items) {
	                drawTableRow(contentStream, margin, startY, tableWidth, colWidths, cellHeight, item);
	                total += item.getItemRate() * item.getQuantity();
	                startY -= cellHeight;
	            }

	            // Draw Total
	            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
	            contentStream.beginText();
	            contentStream.newLineAtOffset(margin, startY - 20);
	            contentStream.showText(String.format("Total: $%.2f", total));
	            contentStream.endText();
	        }

	        ByteArrayOutputStream out = new ByteArrayOutputStream();
	        document.save(out);
	        document.close();
	        return out.toByteArray();
	    }

	    private void drawTableHeader(PDPageContentStream contentStream, float startX, float startY, float tableWidth, float[] colWidths, float cellHeight) throws IOException {
	        // Styling
	        contentStream.setStrokingColor(Color.BLACK);
	        contentStream.setLineWidth(1f);

	        // Draw Header Top Line
	        contentStream.moveTo(startX, startY);
	        contentStream.lineTo(startX + tableWidth, startY);
	        contentStream.stroke();

	        // Draw Column Vertical Lines
	        float columnX = startX;
	        for (float colWidth : colWidths) {
	            columnX += colWidth;
	            contentStream.moveTo(columnX, startY);
	            contentStream.lineTo(columnX, startY - cellHeight);
	            contentStream.stroke();
	        }

	        // Draw Header Bottom Line
	        contentStream.moveTo(startX, startY - cellHeight);
	        contentStream.lineTo(startX + tableWidth, startY - cellHeight);
	        contentStream.stroke();

	        // Header Text
	        String[] headers = {"Serial No", "Item Name", "Rate", "Quantity", "Amount"};
	        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
	        float textX = startX + 2;
	        float textY = startY - 15;
	        for (int i = 0; i < headers.length; i++) {
	            contentStream.beginText();
	            contentStream.newLineAtOffset(textX, textY);
	            contentStream.showText(headers[i]);
	            contentStream.endText();
	            textX += colWidths[i];
	        }
	    }

	    private void drawTableRow(PDPageContentStream contentStream, float startX, float startY, float tableWidth, float[] colWidths, float cellHeight, PurchaseOrderItemDetailDTO item) throws IOException {
	        // Styling
	        contentStream.setStrokingColor(Color.BLACK);
	        contentStream.setLineWidth(0.5f);

	        // Draw Row Top Line
	        contentStream.moveTo(startX, startY);
	        contentStream.lineTo(startX + tableWidth, startY);
	        contentStream.stroke();

	        // Draw Column Vertical Lines
	        float columnX = startX;
	        for (float colWidth : colWidths) {
	            columnX += colWidth;
	            contentStream.moveTo(columnX, startY);
	            contentStream.lineTo(columnX, startY - cellHeight);
	            contentStream.stroke();
	        }

	        // Draw Row Bottom Line
	        contentStream.moveTo(startX, startY - cellHeight);
	        contentStream.lineTo(startX + tableWidth, startY - cellHeight);
	        contentStream.stroke();

	        // Row Text
	        contentStream.setFont(PDType1Font.HELVETICA, 12);
	        float textX = startX + 2;
	        float textY = startY - 15;

	        // Serial No
	        contentStream.beginText();
	        contentStream.newLineAtOffset(textX, textY);
	        contentStream.showText(Integer.toString(serialNo));
	        		
	        contentStream.endText();
	        textX += colWidths[0];

	        // Item Name
	        contentStream.beginText();
	        contentStream.newLineAtOffset(textX, textY);
	        contentStream.showText(item.getItemName());
	        contentStream.endText();
	        textX += colWidths[1];

	        // Rate
	        contentStream.beginText();
	        contentStream.newLineAtOffset(textX, textY);
	        contentStream.showText(String.format("$%.2f", item.getItemRate()));
	        contentStream.endText();
	        textX += colWidths[2];

	        // Quantity
	        contentStream.beginText();
	        contentStream.newLineAtOffset(textX, textY);
	        contentStream.showText(String.valueOf(item.getQuantity()));
	        contentStream.endText();
	        textX += colWidths[3];

	        // Amount
	        contentStream.beginText();
	        contentStream.newLineAtOffset(textX, textY);
	        contentStream.showText(String.format("$%.2f", item.getItemRate() * item.getQuantity()));
	        contentStream.endText();
	    }
}
