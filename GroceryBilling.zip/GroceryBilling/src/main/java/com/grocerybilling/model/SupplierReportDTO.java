package com.grocerybilling.model;

public class SupplierReportDTO {

}
