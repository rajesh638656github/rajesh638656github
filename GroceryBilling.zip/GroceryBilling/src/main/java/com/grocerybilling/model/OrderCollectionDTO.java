package com.grocerybilling.model;

public class OrderCollectionDTO {
	
	Long[] orderIds;

	public Long[] getOrderIds() {
		return orderIds;
	}

	public void setOrderIds(Long[] orderIds) {
		this.orderIds = orderIds;
	}
	

}
