package com.grocerybilling.model;

public class OrderInvoiceSearchDTO {
	private String orderId;
	private String institutionId;
	private String departmentId;
	private String institutionName;
	private String departmentName;
	private String startDate;
	private String endDate;

	public OrderInvoiceSearchDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderInvoiceSearchDTO(String orderId, String institutionId, String departmentId, String startDate,
			String endDate) {
		super();
		this.orderId = orderId;
		this.institutionId = institutionId;
		this.departmentId = departmentId;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getInstitutionName() {
		return institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "OrderInvoiceSearchDTO [orderId=" + orderId + ", institutionId=" + institutionId + ", departmentId="
				+ departmentId + ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}

}
