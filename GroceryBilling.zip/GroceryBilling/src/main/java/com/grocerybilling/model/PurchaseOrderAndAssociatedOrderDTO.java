package com.grocerybilling.model;

public class PurchaseOrderAndAssociatedOrderDTO {
	private Long rownum;
	private Long purchaseOrderId;
	private String contactPersonName;
	private String contactNumber;
	private String status;
	private String installmentNumber;
	private String monthOfPurchase;
	private Double total;
	private Double profitMargin;
	private Double totalAmount;
	private String startDate;
	private String endDate;
		
	private long purchaseOrderOrderId;
	private long orderId;
	private String institutionName;
	public PurchaseOrderAndAssociatedOrderDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PurchaseOrderAndAssociatedOrderDTO(Long rownum, Long purchaseOrderId, String contactPersonName,
			String contactNumber, String status, String installmentNumber, Double total, Double profitMargin,
			Double totalAmount, String startDate, String endDate, long purchaseOrderOrderId, long orderId) {
		super();
		this.rownum = rownum;
		this.purchaseOrderId = purchaseOrderId;
		this.contactPersonName = contactPersonName;
		this.contactNumber = contactNumber;
		this.status = status;
		this.installmentNumber = installmentNumber;
		this.total = total;
		this.profitMargin = profitMargin;
		this.totalAmount = totalAmount;
		this.startDate = startDate;
		this.endDate = endDate;
		this.purchaseOrderOrderId = purchaseOrderOrderId;
		this.orderId = orderId;
	}
	public Long getRownum() {
		return rownum;
	}
	public void setRownum(Long rownum) {
		this.rownum = rownum;
	}
	public Long getPurchaseOrderId() {
		return purchaseOrderId;
	}
	public void setPurchaseOrderId(Long purchaseOrderId) {
		this.purchaseOrderId = purchaseOrderId;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getInstallmentNumber() {
		return installmentNumber;
	}
	public void setInstallmentNumber(String installmentNumber) {
		this.installmentNumber = installmentNumber;
	}
	public Double getTotal() {
		return total;
	}
	public void setTotal(Double total) {
		this.total = total;
	}
	public Double getProfitMargin() {
		return profitMargin;
	}
	public void setProfitMargin(Double profitMargin) {
		this.profitMargin = profitMargin;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public long getPurchaseOrderOrderId() {
		return purchaseOrderOrderId;
	}
	public void setPurchaseOrderOrderId(long purchaseOrderOrderId) {
		this.purchaseOrderOrderId = purchaseOrderOrderId;
	}
	public long getOrderId() {
		return orderId;
	}
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	public String getInstitutionName() {
		return institutionName;
	}
	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}
	public String getMonthOfPurchase() {
		return monthOfPurchase;
	}
	public void setMonthOfPurchase(String monthOfPurchase) {
		this.monthOfPurchase = monthOfPurchase;
	}
	
	

}
