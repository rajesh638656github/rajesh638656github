package com.grocerybilling.model;
import com.grocerybilling.model.*;
import java.util.*;

public class ItemRateUpdateForm {
	 private List<ItemRateDTO> itemRateUpdateDTOs = new ArrayList<>();

	    public List<ItemRateDTO> getItemRateUpdateDTOs() {
	        return itemRateUpdateDTOs;
	    }

	    public void setItemRateUpdateDTOs(List<ItemRateDTO> itemRateUpdateDTOs) {
	        this.itemRateUpdateDTOs = itemRateUpdateDTOs;
	    }

}
