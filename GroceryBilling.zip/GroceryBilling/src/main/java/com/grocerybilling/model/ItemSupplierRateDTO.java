package com.grocerybilling.model;

import java.util.Map;

public class ItemSupplierRateDTO {
	private String itemName; // Name of the item
	private Long itemId;
    private Map<String, Integer> supplierRates; // Supplier-wise quantities
    private int totalQuantity; // Total quantity across all Supplier
	public ItemSupplierRateDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ItemSupplierRateDTO(String itemName, Long itemId,Map<String, Integer> supplierRates, int totalQuantity) {
		super();
		this.itemName = itemName;
		this.itemId = itemId;
		this.supplierRates = supplierRates;
		this.totalQuantity = totalQuantity;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	
	
	public Long getItemId() {
		return itemId;
	}
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	public Map<String, Integer> getSupplierRates() {
		return supplierRates;
	}
	public void setSupplierRates(Map<String, Integer> supplierRates) {
		this.supplierRates = supplierRates;
	}
	public int getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
    

}
