package com.grocerybilling.model;

public class OrderItemDetailDTO {
	private String rownum;
	private String orderId;
	private Long institutionId;
	private String departmentId;
	private String orderItemId;
	
	private String status;
	private String institutionName;
	private String departmentName;
	private String contactPersonName;
	private String contactNumber;
	private String total;
	private String installmentNumber;
	
	private String monthOfPurchase;
	private String profitMargin;
	private String totalAmount;
	private String price;
	private String amount;
	private String startDate;
	private String endDate;
	private Long itemId;
	private Double itemRate;
	private Long unitId;
	private String unitName;
	private Double quantity;
	private String itemPhaseId;
	private String itemPhaseName;
	private String itemName;
	private String comments;
	public OrderItemDetailDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderItemDetailDTO(String rownum, String orderId, Long institutionId, String departmentId,
			String orderItemId, String status, String institutionName, String departmentName, String contactPersonName,
			String contactNumber, String total, String profitMargin, String totalAmount, String price, String amount,
			String startDate, String endDate, Long itemId, Double itemRate, Double quantity, Long unit,String itemPhaseId,
			String itemPhaseName, String itemName) {
		super();
		this.rownum = rownum;
		this.orderId = orderId;
		this.institutionId = institutionId;
		this.departmentId = departmentId;
		this.orderItemId = orderItemId;
		this.status = status;
		this.institutionName = institutionName;
		this.departmentName = departmentName;
		this.contactPersonName = contactPersonName;
		this.contactNumber = contactNumber;
		this.total = total;
		this.profitMargin = profitMargin;
		this.totalAmount = totalAmount;
		this.price = price;
		this.amount = amount;
		this.startDate = startDate;
		this.endDate = endDate;
		this.itemId = itemId;
		this.itemRate = itemRate;
		this.unitId = unitId; 
		this.quantity = quantity;
		this.itemPhaseId = itemPhaseId;
		this.itemPhaseName = itemPhaseName;
		this.itemName = itemName;
	}
	public String getRownum() {
		return rownum;
	}
	public void setRownum(String rownum) {
		this.rownum = rownum;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public Long getInstitutionId() {
		return institutionId;
	}
	public void setInstitutionId(Long institutionId) {
		this.institutionId = institutionId;
	}
	public String getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}
	public String getOrderItemId() {
		return orderItemId;
	}
	public void setOrderItemId(String orderItemId) {
		this.orderItemId = orderItemId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getInstitutionName() {
		return institutionName;
	}
	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getProfitMargin() {
		return profitMargin;
	}
	public void setProfitMargin(String profitMargin) {
		this.profitMargin = profitMargin;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Long getItemId() {
		return itemId;
	}
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	public Double getItemRate() {
		return itemRate;
	}
	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	
	
	public Long getUnitId() {
		return unitId;
	}
	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}
	
	
	public String getMonthOfPurchase() {
		return monthOfPurchase;
	}
	public void setMonthOfPurchase(String monthOfPurchase) {
		this.monthOfPurchase = monthOfPurchase;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getItemPhaseId() {
		return itemPhaseId;
	}
	public void setItemPhaseId(String itemPhaseId) {
		this.itemPhaseId = itemPhaseId;
	}
	public String getItemPhaseName() {
		return itemPhaseName;
	}
	public void setItemPhaseName(String itemPhaseName) {
		this.itemPhaseName = itemPhaseName;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	
	
	
	public String getInstallmentNumber() {
		return installmentNumber;
	}
	public void setInstallmentNumber(String installmentNumber) {
		this.installmentNumber = installmentNumber;
	}
	public String getUnitName() {
		return unitName;
	}
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
	@Override
	public String toString() {
		return "OrderItemDetailDTO [rownum=" + rownum + ", orderId=" + orderId + ", institutionId=" + institutionId
				+ ", departmentId=" + departmentId + ", orderItemId=" + orderItemId + ", status=" + status
				+ ", institutionName=" + institutionName + ", departmentName=" + departmentName + ", contactPersonName="
				+ contactPersonName + ", contactNumber=" + contactNumber + ", total=" + total + ", profitMargin="
				+ profitMargin + ", totalAmount=" + totalAmount + ", price=" + price + ", amount=" + amount
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", itemId=" + itemId + ", itemRate=" + itemRate
				+ ", quantity=" + quantity + ", itemPhaseId=" + itemPhaseId + ", itemPhaseName=" + itemPhaseName
				+ ", itemName=" + itemName + "]";
	}
	
	
	

}
