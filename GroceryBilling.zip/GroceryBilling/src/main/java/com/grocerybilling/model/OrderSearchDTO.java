package com.grocerybilling.model;

public class OrderSearchDTO {
	private String orderId;
	private String institutionId;
	private String departmentId;
	private String institutionName;
	private String departmentName;
	private String startDate;
	private String endDate;
	private String itemId;
	private String sizeId;
	private String unitId;
	private String itemStatusId;
	
	private String itemPhaseId;

	public OrderSearchDTO(String orderId, String institutionId, String departmentId, String institutionName,
			String departmentName, String startDate, String endDate, String itemId, String sizeId, String unitId,
			String itemStatusId, String itemPhaseId) {
		super();
		this.orderId = orderId;
		this.institutionId = institutionId;
		this.departmentId = departmentId;
		this.institutionName = institutionName;
		this.departmentName = departmentName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.itemId = itemId;
		this.sizeId = sizeId;
		this.unitId = unitId;
		this.itemStatusId = itemStatusId;
		this.itemPhaseId = itemPhaseId;
	}

	public OrderSearchDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getInstitutionName() {
		return institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getSizeId() {
		return sizeId;
	}

	public void setSizeId(String sizeId) {
		this.sizeId = sizeId;
	}

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getItemStatusId() {
		return itemStatusId;
	}

	public void setItemStatusId(String itemStatusId) {
		this.itemStatusId = itemStatusId;
	}

	public String getItemPhaseId() {
		return itemPhaseId;
	}

	public void setItemPhaseId(String itemPhaseId) {
		this.itemPhaseId = itemPhaseId;
	}

	

}
