package com.grocerybilling.model;

import com.grocerybilling.entity.QuotationOrder;

public class QuotationOrderItemDetailDTO {
	private Long rownum;
	private Long quotationOrderId;
	private String contactPersonName;
	private String contactNumber;
	private String status;
	private String installmentNumber;
	private String monthOfPurchase;
	private Long supplierId;
	private String supplierName;
	private Double total;
	private Double profitMargin;
	private Double totalAmount;
	private String startDate;
	private String endDate;
		
	private long quotationOrderItemId;
	private long itemId;
	private String itemName;
	private long unitId;
	private String unitName;
	private long itemPhaseId;
	private String itemPhaseName;
	private Double itemRate;
	
	
	private int quantity;
	
	private double amount;
	
	private Long departmentId;
	private String departmentName;
	
	private Long itemIdDB;
	private Long phaseIdDB;
	private String phaseNameDB;
	private String itemNameDB;
	
	
	private QuotationOrder quotationOrder;


	public QuotationOrderItemDetailDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public QuotationOrderItemDetailDTO(Long rownum, Long quotationOrderId, String contactPersonName,
			String contactNumber, String status, String installmentNumber, Double total, Double profitMargin,
			Double totalAmount, String startDate, String endDate, long quotationOrderItemId, long itemId,
			String itemName, long itemPhaseId, String itemPhaseName, Double itemRate, int quantity, double amount,
			Long departmentId, String departmentName, Long itemIdDB, Long phaseIdDB, String phaseNameDB,
			String itemNameDB, QuotationOrder quotationOrder) {
		super();
		this.rownum = rownum;
		this.quotationOrderId = quotationOrderId;
		this.contactPersonName = contactPersonName;
		this.contactNumber = contactNumber;
		this.status = status;
		this.installmentNumber = installmentNumber;
		this.total = total;
		this.profitMargin = profitMargin;
		this.totalAmount = totalAmount;
		this.startDate = startDate;
		this.endDate = endDate;
		this.quotationOrderItemId = quotationOrderItemId;
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPhaseId = itemPhaseId;
		this.itemPhaseName = itemPhaseName;
		this.itemRate = itemRate;
		this.quantity = quantity;
		this.amount = amount;
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.itemIdDB = itemIdDB;
		this.phaseIdDB = phaseIdDB;
		this.phaseNameDB = phaseNameDB;
		this.itemNameDB = itemNameDB;
		this.quotationOrder = quotationOrder;
	}


	public Long getRownum() {
		return rownum;
	}


	public void setRownum(Long rownum) {
		this.rownum = rownum;
	}


	public Long getQuotationOrderId() {
		return quotationOrderId;
	}


	public void setQuotationOrderId(Long quotationOrderId) {
		this.quotationOrderId = quotationOrderId;
	}


	public String getContactPersonName() {
		return contactPersonName;
	}


	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}


	public String getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getInstallmentNumber() {
		return installmentNumber;
	}


	public void setInstallmentNumber(String installmentNumber) {
		this.installmentNumber = installmentNumber;
	}
	
	


	public String getMonthOfPurchase() {
		return monthOfPurchase;
	}


	public void setMonthOfPurchase(String monthOfPurchase) {
		this.monthOfPurchase = monthOfPurchase;
	}

	
	

	public Long getSupplierId() {
		return supplierId;
	}


	public void setSupplierId(Long supplierId) {
		this.supplierId = supplierId;
	}


	public String getSupplierName() {
		return supplierName;
	}


	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}


	public Double getTotal() {
		return total;
	}


	public void setTotal(Double total) {
		this.total = total;
	}


	public Double getProfitMargin() {
		return profitMargin;
	}


	public void setProfitMargin(Double profitMargin) {
		this.profitMargin = profitMargin;
	}


	public Double getTotalAmount() {
		return totalAmount;
	}


	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}


	public String getStartDate() {
		return startDate;
	}


	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}


	public String getEndDate() {
		return endDate;
	}


	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}


	public long getQuotationOrderItemId() {
		return quotationOrderItemId;
	}


	public void setQuotationOrderItemId(long quotationOrderItemId) {
		this.quotationOrderItemId = quotationOrderItemId;
	}


	public long getItemId() {
		return itemId;
	}


	public void setItemId(long itemId) {
		this.itemId = itemId;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	
	

	public long getUnitId() {
		return unitId;
	}


	public void setUnitId(long unitId) {
		this.unitId = unitId;
	}


	public String getUnitName() {
		return unitName;
	}


	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}


	public long getItemPhaseId() {
		return itemPhaseId;
	}


	public void setItemPhaseId(long itemPhaseId) {
		this.itemPhaseId = itemPhaseId;
	}


	public String getItemPhaseName() {
		return itemPhaseName;
	}


	public void setItemPhaseName(String itemPhaseName) {
		this.itemPhaseName = itemPhaseName;
	}


	public Double getItemRate() {
		return itemRate;
	}


	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public Long getDepartmentId() {
		return departmentId;
	}


	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}


	public String getDepartmentName() {
		return departmentName;
	}


	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}


	public Long getItemIdDB() {
		return itemIdDB;
	}


	public void setItemIdDB(Long itemIdDB) {
		this.itemIdDB = itemIdDB;
	}


	public Long getPhaseIdDB() {
		return phaseIdDB;
	}


	public void setPhaseIdDB(Long phaseIdDB) {
		this.phaseIdDB = phaseIdDB;
	}


	public String getPhaseNameDB() {
		return phaseNameDB;
	}


	public void setPhaseNameDB(String phaseNameDB) {
		this.phaseNameDB = phaseNameDB;
	}


	public String getItemNameDB() {
		return itemNameDB;
	}


	public void setItemNameDB(String itemNameDB) {
		this.itemNameDB = itemNameDB;
	}


	public QuotationOrder getQuotationOrder() {
		return quotationOrder;
	}


	public void setQuotationOrder(QuotationOrder quotationOrder) {
		this.quotationOrder = quotationOrder;
	}
	
	

}
