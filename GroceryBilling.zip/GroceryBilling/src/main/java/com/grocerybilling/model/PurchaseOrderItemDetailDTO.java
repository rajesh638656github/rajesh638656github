package com.grocerybilling.model;

import com.grocerybilling.entity.PurchaseOrder;

public class PurchaseOrderItemDetailDTO {
	private Long rownum;
	private Long purchaseOrderId;
	private String contactPersonName;
	private String contactNumber;
	private String status;
	private String monthOfPurchase;
	private String installmentNumber;
	private Double total;
	private Double profitMargin;
	private Double totalAmount;
	private String startDate;
	private String endDate;
		
	private long purchaseOrderItemId;
	private Long institutionId;
	private String institutionName;
	private long itemId;
	private String itemName;
	
	private Long unitId;
	private String unitName;
	private long itemPhaseId;
	private String itemPhaseName;
	private Double itemRate;
	
	
	private Double quantity;
	
	private double amount;
	private String comments;
	
	private Long departmentId;
	private String departmentName;
	
	private Long itemIdDB;
	private Long phaseIdDB;
	private String phaseNameDB;
	private String itemNameDB;
	
	
	private PurchaseOrder purchaseOrder;


	public PurchaseOrderItemDetailDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public PurchaseOrderItemDetailDTO(Long rownum, Long purchaseOrderId, String contactPersonName, String contactNumber,
			String status, String installmentNumber, Double total, Double profitMargin, Double totalAmount,
			String startDate, String endDate, long purchaseOrderItemId, Long institutionId, String institutionName,
			long itemId, String itemName, Long unitId, long itemPhaseId, String itemPhaseName, Double itemRate,
			Double quantity, double amount, Long departmentId, String departmentName, Long itemIdDB, Long phaseIdDB,
			String phaseNameDB, String itemNameDB, PurchaseOrder purchaseOrder) {
		super();
		this.rownum = rownum;
		this.purchaseOrderId = purchaseOrderId;
		this.contactPersonName = contactPersonName;
		this.contactNumber = contactNumber;
		this.status = status;
		this.installmentNumber = installmentNumber;
		this.total = total;
		this.profitMargin = profitMargin;
		this.totalAmount = totalAmount;
		this.startDate = startDate;
		this.endDate = endDate;
		this.purchaseOrderItemId = purchaseOrderItemId;
		this.institutionId = institutionId;
		this.institutionName = institutionName;
		this.itemId = itemId;
		this.itemName = itemName;
		this.unitId = unitId;
		this.itemPhaseId = itemPhaseId;
		this.itemPhaseName = itemPhaseName;
		this.itemRate = itemRate;
		this.quantity = quantity;
		this.amount = amount;
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.itemIdDB = itemIdDB;
		this.phaseIdDB = phaseIdDB;
		this.phaseNameDB = phaseNameDB;
		this.itemNameDB = itemNameDB;
		this.purchaseOrder = purchaseOrder;
	}


	public Long getRownum() {
		return rownum;
	}


	public void setRownum(Long rownum) {
		this.rownum = rownum;
	}


	public Long getPurchaseOrderId() {
		return purchaseOrderId;
	}


	public void setPurchaseOrderId(Long purchaseOrderId) {
		this.purchaseOrderId = purchaseOrderId;
	}


	public String getContactPersonName() {
		return contactPersonName;
	}


	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}


	public String getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getInstallmentNumber() {
		return installmentNumber;
	}


	public void setInstallmentNumber(String installmentNumber) {
		this.installmentNumber = installmentNumber;
	}


	public Double getTotal() {
		return total;
	}


	public void setTotal(Double total) {
		this.total = total;
	}


	public Double getProfitMargin() {
		return profitMargin;
	}


	public void setProfitMargin(Double profitMargin) {
		this.profitMargin = profitMargin;
	}


	public Double getTotalAmount() {
		return totalAmount;
	}


	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}


	public String getStartDate() {
		return startDate;
	}


	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}


	public String getEndDate() {
		return endDate;
	}


	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}


	public long getPurchaseOrderItemId() {
		return purchaseOrderItemId;
	}


	public void setPurchaseOrderItemId(long purchaseOrderItemId) {
		this.purchaseOrderItemId = purchaseOrderItemId;
	}


	public Long getInstitutionId() {
		return institutionId;
	}


	public void setInstitutionId(Long institutionId) {
		this.institutionId = institutionId;
	}


	public String getInstitutionName() {
		return institutionName;
	}


	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}


	public long getItemId() {
		return itemId;
	}


	public void setItemId(long itemId) {
		this.itemId = itemId;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public Long getUnitId() {
		return unitId;
	}


	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}


	public long getItemPhaseId() {
		return itemPhaseId;
	}


	public void setItemPhaseId(long itemPhaseId) {
		this.itemPhaseId = itemPhaseId;
	}


	public String getItemPhaseName() {
		return itemPhaseName;
	}


	public void setItemPhaseName(String itemPhaseName) {
		this.itemPhaseName = itemPhaseName;
	}


	public Double getItemRate() {
		return itemRate;
	}


	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}


	public Double getQuantity() {
		return quantity;
	}


	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public Long getDepartmentId() {
		return departmentId;
	}


	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}


	public String getDepartmentName() {
		return departmentName;
	}


	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}


	public Long getItemIdDB() {
		return itemIdDB;
	}


	public void setItemIdDB(Long itemIdDB) {
		this.itemIdDB = itemIdDB;
	}


	public Long getPhaseIdDB() {
		return phaseIdDB;
	}


	public void setPhaseIdDB(Long phaseIdDB) {
		this.phaseIdDB = phaseIdDB;
	}


	public String getPhaseNameDB() {
		return phaseNameDB;
	}


	public void setPhaseNameDB(String phaseNameDB) {
		this.phaseNameDB = phaseNameDB;
	}


	public String getItemNameDB() {
		return itemNameDB;
	}


	public void setItemNameDB(String itemNameDB) {
		this.itemNameDB = itemNameDB;
	}

	
	public String getMonthOfPurchase() {
		return monthOfPurchase;
	}


	public void setMonthOfPurchase(String monthOfPurchase) {
		this.monthOfPurchase = monthOfPurchase;
	}


	public String getComments() {
		return comments;
	}


	public void setComments(String comments) {
		this.comments = comments;
	}


	public PurchaseOrder getPurchaseOrder() {
		return purchaseOrder;
	}


	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}


	public String getUnitName() {
		return unitName;
	}


	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}


	

	



}
