package com.grocerybilling.model;

import java.util.*;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;

public class ItemRateDTO {
	private String itemName; // Name of the item
	private Long itemId;
	@NotNull(message = "Please enter a valid numeric value with up to 2 decimal places.")
    @Digits(integer = 10, fraction = 2, message = "This field cannot be empty.")
    private Map<Long, Double> supplierRates; // Supplier-wise quantities
    private int totalQuantity; // Total quantity across all Supplier
	public ItemRateDTO() {
		super();
		this.supplierRates = new HashMap<>(); // Initialize to prevent null issues
		// TODO Auto-generated constructor stub
	}
	public ItemRateDTO(String itemName, Long itemId,Map<Long, Double> supplierRates, int totalQuantity) {
		super();
		this.itemName = itemName;
		this.itemId = itemId;
		this.supplierRates = supplierRates;
		this.totalQuantity = totalQuantity;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	
	
	public Long getItemId() {
		return itemId;
	}
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	public Map<Long, Double> getSupplierRates() {
		return supplierRates;
	}
	public void setSupplierRates(Map<Long, Double> supplierRates) {
		this.supplierRates = supplierRates;
	}
	public int getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
    


}
