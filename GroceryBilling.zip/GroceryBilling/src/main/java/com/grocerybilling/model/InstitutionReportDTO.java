package com.grocerybilling.model;

public class InstitutionReportDTO {

}
