package com.grocerybilling.model;
import java.util.Date;

public class BillSearchDTO {
	private Date startDate;
	private Date endDate;
	private String institutionId;
	private String billId;
	
	
	public BillSearchDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BillSearchDTO(Date startDate, Date endDate,String institutionId,String billId) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.institutionId = institutionId;
		this.billId = billId;
	}
	
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getInstitutionId() {
		return institutionId;
	}
	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}
	public String getBillId() {
		return billId;
	}
	public void setBillId(String billId) {
		this.billId = billId;
	}
	@Override
	public String toString() {
		return "BillSearchDTO [startDate=" + startDate + ", endStart=" + endDate + "]";
	}
	

}
