package com.grocerybilling.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.grocerybilling.DTO.ItemPriceDTO;
import com.grocerybilling.DTO.ItemDTO;
import com.grocerybilling.DTO.OrderItemDTO;

import jakarta.validation.Valid;

public class ItemPriceCalculation {
	private long orderId;
	private long orderItemId;
	private String orderItemName;
	private String phaseId;
	private long[] itemRateIds;
	private long[] itemRateNoOfItems;
	private Double[] itemRateAmounts;
	private int orderItemQuantity;
	private Double orderItemPrice;
	private Double orderItemTotal;
    @Valid
	private List<ItemPriceDTO> ItemPriceDTOs;
	
	

	
	public ItemPriceCalculation() {
		super();
		ItemPriceDTOs = new ArrayList<>();
		
	
		
		// TODO Auto-generated constructor stub
	}
	public long getOrderId() {
		return orderId;
	}
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	public long getOrderItemId() {
		return orderItemId;
	}
	public void setOrderItemId(long orderItemId) {
		this.orderItemId = orderItemId;
	}
	public String getOrderItemName() {
		return orderItemName;
	}
	public void setOrderItemName(String orderItemName) {
		this.orderItemName = orderItemName;
	}
	
		public String getPhaseId() {
		return phaseId;
	}
	public void setPhaseId(String phaseId) {
		this.phaseId = phaseId;
	}
	public long[] getItemRateIds() {
		return itemRateIds;
	}
	public void setItemRateIds(long[] itemRateIds) {
		System.out.println("Printing from setItemRateIds from ItemPriceCalculation");
		this.itemRateIds = itemRateIds;
	}

	public long[] getItemRateNoOfItems() {
		return itemRateNoOfItems;
	}
	public void setItemRateNoOfItems(long[] itemRateNoOfItems) {
		System.out.println("Printing from setItemRateNoOfItems from ItemPriceCalculation");
		this.itemRateNoOfItems = itemRateNoOfItems;
	}
	public Double[] getItemRateAmounts() {
		return itemRateAmounts;
	}
	public void setItemRateAmounts(Double[] itemRateAmounts) {
		this.itemRateAmounts = itemRateAmounts;
	}
	public Double getOrderItemPrice() {
		return orderItemPrice;
	}
	public void setOrderItemPrice(Double orderItemPrice) {
		this.orderItemPrice = orderItemPrice;
	}

	

	public int getOrderItemQuantity() {
		return orderItemQuantity;
	}
	public void setOrderItemQuantity(int orderItemQuantity) {
		this.orderItemQuantity = orderItemQuantity;
	}
	public Double getOrderItemTotal() {
		return orderItemTotal;
	}
	public void setOrderItemTotal(Double orderItemTotal) {
		this.orderItemTotal = orderItemTotal;
	}
	public List<ItemPriceDTO> getItemPriceDTOs() {
		return ItemPriceDTOs;
	}
	public void setItemPriceDTOs(List<ItemPriceDTO> itemPriceDTOs) {
		ItemPriceDTOs = itemPriceDTOs;
	}
	public void add(ItemPriceDTO item) {

        if (item != null) {
            if (ItemPriceDTOs == null) {
            	ItemPriceDTOs = new ArrayList<>();
            }

            ItemPriceDTOs.add(item);
           // item.setOrder(this);
        }
    }
	
	
	

}
