package com.grocerybilling.model;
import java.util.Map;

public class ItemReportDTO {
	private String itemName; // Name of the item
    private Map<String, Double> institutionQuantities; // Client-wise quantities
    private Double totalQuantity; // Total quantity across all clients
	public ItemReportDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ItemReportDTO(String itemName, Map<String, Double> institutionQuantities, Double totalQuantity) {
		super();
		this.itemName = itemName;
		this.institutionQuantities = institutionQuantities;
		this.totalQuantity = totalQuantity;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Map<String, Double> getInstitutionQuantities() {
		return institutionQuantities;
	}
	public void setInstitutionQuantities(Map<String, Double> institutionQuantities) {
		this.institutionQuantities = institutionQuantities;
	}
	public Double getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(Double totalQuantity) {
		this.totalQuantity = totalQuantity;
	}



}
