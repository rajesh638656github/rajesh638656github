package com.grocerybilling.model;

public class OrderIdsForBilling {
	String[] orderIds;

	public OrderIdsForBilling() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderIdsForBilling(String[] orderIds) {
		super();
		this.orderIds = orderIds;
	}

	public String[] getOrderIds() {
		return orderIds;
	}

	public void setOrderIds(String[] orderIds) {
		this.orderIds = orderIds;
	}

}
