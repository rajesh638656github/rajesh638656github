package com.grocerybilling.model;

public class InstitutionQuantityDTO {
	private int institutionId;
	private Integer quantity;
	public InstitutionQuantityDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public InstitutionQuantityDTO(int institutionId, Integer quantity) {
		super();
		this.institutionId = institutionId;
		this.quantity = quantity;
	}
	public int getInstitutionId() {
		return institutionId;
	}
	public void setInstitutionId(int institutionId) {
		this.institutionId = institutionId;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
	

}
