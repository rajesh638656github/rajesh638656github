package com.grocerybilling.model;

public class Order1 {
	private int orderId;
	private int institutionId;
	private int departmentId;
	private int itemId;
	private int sizeId;
	private int unitId;
	private double price;

	public Order1() {

	}

	public Order1(int orderId, int institutionId, int departmentId, int itemId, int sizeId, int unitId) {
		super();
		this.orderId = orderId;
		this.institutionId = institutionId;
		this.departmentId = departmentId;
		this.itemId = itemId;
		this.sizeId = sizeId;
		this.unitId = unitId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(int institutionId) {
		this.institutionId = institutionId;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getSizeId() {
		return sizeId;
	}

	public void setSizeId(int sizeId) {
		this.sizeId = sizeId;
	}

	public int getUnitId() {
		return unitId;
	}

	public void setUnitId(int unitId) {
		this.unitId = unitId;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", institutionId=" + institutionId + ", departmentId=" + departmentId
				+ ", itemId=" + itemId + ", sizeId=" + sizeId + ", unitId=" + unitId + "]";
	}

}
