package com.grocerybilling.model;

public class QuotationSubTotalDTO {
	private long QuotationId;
	private double QuotationPrice;
	
	
	public QuotationSubTotalDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public QuotationSubTotalDTO(long quotationId, double quotationPrice) {
		super();
		QuotationId = quotationId;
		QuotationPrice = quotationPrice;
	}
	
	public long getQuotationId() {
		return QuotationId;
	}
		public void setQuotationId(long quotationId) {
		QuotationId = quotationId;
	}
	public double getQuotationPrice() {
		return QuotationPrice;
	}
	public void setQuotationPrice(double quotationPrice) {
		QuotationPrice = quotationPrice;
	}
	
}
