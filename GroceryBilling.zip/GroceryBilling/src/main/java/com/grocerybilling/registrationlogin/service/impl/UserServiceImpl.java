package com.grocerybilling.registrationlogin.service.impl;

import com.grocerybilling.registrationlogin.dto.RoleDto;
import com.grocerybilling.registrationlogin.dto.UserDto;
import com.grocerybilling.registrationlogin.entity.Role;
import com.grocerybilling.registrationlogin.entity.GroceryUser;
import com.grocerybilling.registrationlogin.repository.RoleRepository;
import com.grocerybilling.registrationlogin.repository.UserRepository;
import com.grocerybilling.registrationlogin.service.UserService;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;
    private RoleRepository roleRepository;
    private PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository,
                           RoleRepository roleRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void saveUser(UserDto userDto) {
        GroceryUser user = new GroceryUser();
        user.setName(userDto.getFirstName() + " " + userDto.getLastName());
        user.setInstitutionId(userDto.getInstitutionId());
        user.setEmail(userDto.getEmail());
       // List<RoleDto> roleNames = userDto.getRoles();
      //  RoleDto roleDto =  roleNames.get(0);
        String roleId= userDto.getRoles();

        //encrypt the password once we integrate spring security
        //user.setPassword(userDto.getPassword());
        user.setPassword(passwordEncoder.encode(userDto.getPassword()));
        Long size = roleRepository.count();
       // Role role = roleRepository.findByName(roleName);
        if(size == 0){
        	populateRoleTable();
        }
        Role role = roleRepository.findById(Long.parseLong(roleId));
        user.setRoles(Arrays.asList(role));
        userRepository.save(user);
    }
    
    @Override
    public void updatePassword(UserDto userDto) {
    	GroceryUser existing = userRepository.findByEmail(userDto.getEmail());
    	System.out.println("Printing existing user id" + existing.getEmail());
    	System.out.println("Printing existing Password" + existing.getPassword());
       	existing.setPassword(passwordEncoder.encode(userDto.getPassword()));
        userRepository.save(existing);
    }

    @Override
    public GroceryUser findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    @Override
    public GroceryUser findByName(String name) {
        return userRepository.findByName(name);
    }

    @Override
    public List<UserDto> findAllUsers() {
        List<GroceryUser> users = userRepository.findAll();
        return users.stream().map((user) -> convertEntityToDto(user))
                .collect(Collectors.toList());
    }

    private UserDto convertEntityToDto(GroceryUser user){
        UserDto userDto = new UserDto();
        String[] name = user.getName().split(" ");
        userDto.setFirstName(name[0]);
        userDto.setLastName(name[1]);
        userDto.setInstitutionId(user.getInstitutionId());
        userDto.setEmail(user.getEmail());
        return userDto;
    }

    private Role checkRoleExist() {
        Role role = new Role();
        role.setName("ROLE_ADMIN");
        return roleRepository.save(role);
    }
    
   private void populateRoleTable() {
	   Role role = new Role();
       role.setName("ROLE_ADMIN");
       roleRepository.save(role);
       Role role1 = new Role();
       role1.setName("ROLE_USER");
       roleRepository.save(role1);
   }
   
}
