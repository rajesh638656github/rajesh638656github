package com.grocerybilling.registrationlogin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grocerybilling.registrationlogin.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {
    Role findByName(String name);
    Role findById(long id);
}
