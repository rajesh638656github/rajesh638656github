package com.grocerybilling.registrationlogin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grocerybilling.registrationlogin.entity.GroceryUser;

public interface UserRepository extends JpaRepository<GroceryUser, Long> {
    GroceryUser findByEmail(String email);
    GroceryUser findByName(String name);
}
