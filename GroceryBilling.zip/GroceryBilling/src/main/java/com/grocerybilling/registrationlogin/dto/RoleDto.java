package com.grocerybilling.registrationlogin.dto;

import java.util.List;

import com.grocerybilling.registrationlogin.entity.GroceryUser;

public class RoleDto {
	  private Long id;
	  private String name;
	  private List<UserDto> users;
	public RoleDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RoleDto(Long id, String name, List<UserDto> users) {
		super();
		this.id = id;
		this.name = name;
		this.users = users;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<UserDto> getUsers() {
		return users;
	}
	public void setUsers(List<UserDto> users) {
		this.users = users;
	}
	  

}
