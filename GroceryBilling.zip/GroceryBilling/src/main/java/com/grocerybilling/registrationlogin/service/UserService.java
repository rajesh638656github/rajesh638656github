package com.grocerybilling.registrationlogin.service;

import com.grocerybilling.registrationlogin.dto.UserDto;
import com.grocerybilling.registrationlogin.entity.GroceryUser;

import java.util.List;

public interface UserService {
    void saveUser(UserDto userDto);
    
    void updatePassword(UserDto userDto);

    GroceryUser findByEmail(String email);

    List<UserDto> findAllUsers();
    
    GroceryUser findByName(String name);
}
