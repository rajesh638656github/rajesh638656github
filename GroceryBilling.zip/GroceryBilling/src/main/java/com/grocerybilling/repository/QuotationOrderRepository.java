package com.grocerybilling.repository;
import java.util.List;


import com.grocerybilling.entity.QuotationOrder;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface QuotationOrderRepository extends JpaRepository<QuotationOrder, Integer>{
	QuotationOrder findById(long orderId);
}
