package com.grocerybilling.repository;
import java.util.List;


import com.grocerybilling.entity.PurchaseOrderItem;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PurchaseOrderItemRepository extends JpaRepository<PurchaseOrderItem, Integer> {
	PurchaseOrderItem findById(long orderItemId);
}
