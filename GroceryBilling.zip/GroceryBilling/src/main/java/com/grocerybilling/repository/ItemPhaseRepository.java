package com.grocerybilling.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.grocerybilling.entity.ItemPhase;

@Repository
public interface ItemPhaseRepository  extends JpaRepository<ItemPhase, Integer> {
	ItemPhase findByItemPhaseId(long itemRatePhaseId);
}