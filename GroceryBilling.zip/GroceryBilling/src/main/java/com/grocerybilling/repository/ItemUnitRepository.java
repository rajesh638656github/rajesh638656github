package com.grocerybilling.repository;
import java.util.List;


import com.grocerybilling.entity.ItemUnit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository

public interface ItemUnitRepository extends JpaRepository<ItemUnit, Integer> {
	ItemUnit findById(long itemId);
}
