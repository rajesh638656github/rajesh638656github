package com.grocerybilling.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.grocerybilling.entity.Item;

@Repository

public interface ItemRepository  extends JpaRepository<Item, Long> {
	Item findByItemId(long itemId);
	List<Item> findAllByOrderByItemPhaseId();
	//List<ItemRate> findByItemRatePhaseNameIn(List<String> itemRatePhaseName);
}

