package com.grocerybilling.repository;
import java.util.List;


import com.grocerybilling.entity.PurchaseOrder;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PurchaseOrderRepository extends JpaRepository<PurchaseOrder, Integer> {
	PurchaseOrder findById(long orderId);

}
