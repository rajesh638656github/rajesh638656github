package com.grocerybilling.repository;
import java.util.List;


import com.grocerybilling.entity.QuotationOrderItem;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository

public interface QuotationOrderItemRepository extends JpaRepository<QuotationOrderItem, Integer>{
	QuotationOrderItem findById(long orderItemId);
}
