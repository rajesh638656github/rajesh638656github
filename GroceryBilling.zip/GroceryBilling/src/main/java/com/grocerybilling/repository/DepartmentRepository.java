package com.grocerybilling.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.grocerybilling.entity.Department;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Integer> {
	Department findByDepartmentId(long departmentId);
}
