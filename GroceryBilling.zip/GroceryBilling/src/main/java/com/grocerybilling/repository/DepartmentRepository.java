package com.grocerybilling.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.grocerybilling.entity.Department;
import com.grocerybilling.entity.Institution;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Integer> {
	Department findByDepartmentId(long departmentId);
	


}
