package com.grocerybilling.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.ArrayList;

@Entity
@Table(name = "purchase_order_item")

public class PurchaseOrderItem {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name= "institution_id")
	private Long institutionId;
	
	@Column(name= "item_id")
	private Long itemId;
	
	@Column(name= "item_rate")
	private Double itemRate;
	
	@Column(name= "quantity")
	private Double quantity;
	@Column(name = "unit_id")
	private Long unitId;
	@Column(name= "amount")
	private Double amount;
	@Column(name= "department_id")
	private Long departmentId;
	@Column(name = "comments")
	private String comments;
	
	
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "purchase_order_id")
	//@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	//@JoinColumn(name = "order_id", nullable = false)
	//@OnDelete(action = OnDeleteAction.CASCADE)
	private PurchaseOrder purchaseOrder;


	public PurchaseOrderItem() {
		super();
		// TODO Auto-generated constructor stub
	}


	public PurchaseOrderItem(Long id, Long institutionId, Long itemId, Double itemRate, Double quantity,Long unitId,
			Double amount, Long departmentId, PurchaseOrder purchaseOrder) {
		super();
		this.id = id;
		this.institutionId = institutionId;
		this.itemId = itemId;
		this.itemRate = itemRate;
		this.quantity = quantity;
		this.unitId = unitId;
		this.amount = amount;
		this.departmentId = departmentId;
		this.purchaseOrder = purchaseOrder;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Long getInstitutionId() {
		return institutionId;
	}


	public void setInstitutionId(Long institutionId) {
		this.institutionId = institutionId;
	}


	public Long getItemId() {
		return itemId;
	}


	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}


	public Double getItemRate() {
		return itemRate;
	}


	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}


	public Double getQuantity() {
		return quantity;
	}


	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	
	public Long getUnitId() {
		return unitId;
	}


	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public Long getDepartmentId() {
		return departmentId;
	}


	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}

	public String getComments() {
		return comments;
	}


	public void setComments(String comments) {
		this.comments = comments;
	}


	public PurchaseOrder getPurchaseOrder() {
		return purchaseOrder;
	}


	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}
	
	


	
	
}
