package com.grocerybilling.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.ArrayList;

@Entity
@Table(name = "purchase_order_supplier_quote")


public class PurchaseOrderSupplierQuote {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	
	@Column(name= "item_id")
	private Long itemId;
	
	@Column(name= "item_rate")
	private Double itemRate;
	

	@Column(name = "unit")
	private String unit;

	@Column(name= "department_id")
	private Long departmentId;
	
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "purchase_order_id")
	//@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	//@JoinColumn(name = "order_id", nullable = false)
	//@OnDelete(action = OnDeleteAction.CASCADE)
	private PurchaseOrder PurchaseOrder;

	public PurchaseOrderSupplierQuote() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PurchaseOrderSupplierQuote(Long id, Long itemId, Double itemRate, String unit, Long departmentId,
			com.grocerybilling.entity.PurchaseOrder purchaseOrder) {
		super();
		this.id = id;
		this.itemId = itemId;
		this.itemRate = itemRate;
		this.unit = unit;
		this.departmentId = departmentId;
		PurchaseOrder = purchaseOrder;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public Double getItemRate() {
		return itemRate;
	}

	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public Long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}

	public PurchaseOrder getPurchaseOrder() {
		return PurchaseOrder;
	}

	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		PurchaseOrder = purchaseOrder;
	}
	
	

}
