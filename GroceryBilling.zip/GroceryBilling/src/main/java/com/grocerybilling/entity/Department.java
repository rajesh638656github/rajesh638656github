package com.grocerybilling.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "department", uniqueConstraints = @UniqueConstraint(columnNames = {"department_name"}))

public class Department {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "department_id")
	private long departmentId;
	@Column(name = "department_name", nullable = false)
	private String departmentName;
	@Column(name = "first_contact_person_name")
	private String firstContactPersonName;
	@Column(name = "first_contact_person_contact_number")
	private String firstContactPersonContactNumber;
	@Column(name = "second_contact_person_name")
	private String secondContactPersonName;
	@Column(name = "second_contact_person_contact_number")
	private String secondContactPersonContactNumber;
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(long departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getFirstContactPersonName() {
		return firstContactPersonName;
	}

	public void setFirstContactPersonName(String firstContactPersonName) {
		this.firstContactPersonName = firstContactPersonName;
	}

	public String getFirstContactPersonContactNumber() {
		return firstContactPersonContactNumber;
	}

	public void setFirstContactPersonContactNumber(String firstContactPersonContactNumber) {
		this.firstContactPersonContactNumber = firstContactPersonContactNumber;
	}

	public String getSecondContactPersonName() {
		return secondContactPersonName;
	}

	public void setSecondContactPersonName(String secondContactPersonName) {
		this.secondContactPersonName = secondContactPersonName;
	}

	public String getSecondContactPersonContactNumber() {
		return secondContactPersonContactNumber;
	}

	public void setSecondContactPersonContactNumber(String secondContactPersonContactNumber) {
		this.secondContactPersonContactNumber = secondContactPersonContactNumber;
	}
	
	
	

	public Department orElse(Object object) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
