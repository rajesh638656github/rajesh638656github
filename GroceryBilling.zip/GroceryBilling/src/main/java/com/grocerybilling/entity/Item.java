package com.grocerybilling.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "item", uniqueConstraints = @UniqueConstraint(columnNames = {"item_phase_id","item_name"}))

public class Item {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_id")
	private long itemId;
	@NotNull
	@Column(name = "item_phase_id", nullable = false)
	private long itemPhaseId;
	@NotNull
	@Column(name = "item_name", nullable = false)
	private String itemName;
	@Column(name = "item_rate")
	private Double itemRate;
	
	
	
	
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Item(long itemId, @NotNull long itemPhaseId, @NotNull String itemName, Double itemRate) {
		super();
		this.itemId = itemId;
		this.itemPhaseId = itemPhaseId;
		this.itemName = itemName;
		this.itemRate = itemRate;
	}
	public long getItemId() {
		return itemId;
	}
	public void setItemId(long itemId) {
		this.itemId = itemId;
	}
	public long getItemPhaseId() {
		return itemPhaseId;
	}
	public void setItemPhaseId(long itemPhaseId) {
		this.itemPhaseId = itemPhaseId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Double getItemRate() {
		return itemRate;
	}
	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}
	

}
