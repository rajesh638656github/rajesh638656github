package com.grocerybilling.entity;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "item", uniqueConstraints = @UniqueConstraint(columnNames = {"item_phase_id","item_name"}))

public class Item {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_id")
	private long itemId;
	@NotNull
	@Column(name = "item_phase_id", nullable = false)
	private long itemPhaseId;
	@NotNull
	@Column(name = "item_name", nullable = false)
	private String itemName;
	@Column(name= "item_rate")
	private Double itemRate;
	@Column(name= "department_id")
	private Long departmentId;
	//@ManyToOne
  //  @JoinColumn(name = "department_id")
  //  private Department department;

	@OneToMany(mappedBy = "item",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	//@JoinColumn(name = "order_id")
	// private Set<OrderItem> orderitems;
    @Valid
	private List<ItemUnit> itemUnits;
	
	
	public Item() {
		super();
		itemUnits = new ArrayList<>();
		// TODO Auto-generated constructor stub
	}
	public Item(long itemId, @NotNull long itemPhaseId, @NotNull String itemName,Double itemRate) {
		super();
		this.itemId = itemId;
		this.itemPhaseId = itemPhaseId;
		this.itemName = itemName;
		this.itemRate = itemRate;
	
	}
	public long getItemId() {
		return itemId;
	}
	public void setItemId(long itemId) {
		this.itemId = itemId;
	}
	public long getItemPhaseId() {
		return itemPhaseId;
	}
	public void setItemPhaseId(long itemPhaseId) {
		this.itemPhaseId = itemPhaseId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Double getItemRate() {
		return itemRate;
	}
	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}
	public Long getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}

	public void add(ItemUnit item) {

        if (item != null) {
            if (itemUnits == null) {
            	itemUnits = new ArrayList<>();
            }

            itemUnits.add(item);
          item.setItem(this);
        }
    }
	
	

	public void remove(OrderItem item) {
       
		itemUnits.remove(item);
           item.setOrder(null);
       
    }
	public List<ItemUnit> getItemUnits() {
		return itemUnits;
	}
	public void setItemUnits(List<ItemUnit> itemUnits) {
		this.itemUnits = itemUnits;
	}
	
	
	

}
