package com.grocerybilling.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.*;
//import jakarta.annotation
import jakarta.validation.Valid;

import com.grocerybilling.entity.OrderItem;

import lombok.*;
import java.util.HashSet;
import java.util.Set;

@Entity
//@DynamicInsert
@Table(name = "item_unit")

public class ItemUnit {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "unit_id")
	private long unitId;
	


	
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "item_id")
	//@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	//@JoinColumn(name = "order_id", nullable = false)
	//@OnDelete(action = OnDeleteAction.CASCADE)
	private Item item;
	
	public ItemUnit() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ItemUnit(Long id, long unitId, Item item) {
		super();
		this.id = id;
		this.unitId = unitId;
		this.item = item;
	}


	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}
	
	public long getUnitId() {
		return unitId;
	}

	public void setUnitId(long unitId) {
		this.unitId = unitId;
	}
	

}
