package com.grocerybilling.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.ArrayList;

@Entity
@Table(name = "order_items")

public class OrderItem {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name= "item_id")
	private Long itemId;
	
	@Column(name= "item_rate")
	private Double itemRate;
	
	@Column(name= "quantity")
	private Double quantity;
	@Column(name = "unit_id")
	private Long unitId;
	@Column(name= "amount")
	private Double amount;
	@Column(name = "comments")
	private String comments;
	
	
	
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "order_id")
	//@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	//@JoinColumn(name = "order_id", nullable = false)
	//@OnDelete(action = OnDeleteAction.CASCADE)
	private Order order;



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public Long getItemId() {
		return itemId;
	}



	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}



	public Double getItemRate() {
		return itemRate;
	}



	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}



	public Double getQuantity() {
		return quantity;
	}



	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}




	public Long getUnitId() {
		return unitId;
	}



	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}



	public Double getAmount() {
		return amount;
	}



	public void setAmount(Double amount) {
		this.amount = amount;
	}



	public Order getOrder() {
		return order;
	}



	public void setOrder(Order order) {
		this.order = order;
	}



	public String getComments() {
		return comments;
	}



	public void setComments(String comments) {
		this.comments = comments;
	}

	
	

}
