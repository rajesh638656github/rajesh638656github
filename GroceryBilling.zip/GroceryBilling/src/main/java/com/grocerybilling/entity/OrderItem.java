package com.grocerybilling.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.ArrayList;

@Entity
@Table(name = "order_items")

public class OrderItem {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name= "item_id")
	private long itemId;
	
	@Column(name= "item_rate")
	private Double itemRate;
	
	@Column(name= "quantity")
	private int quantity;
	@Column(name= "amount")
	private double amount;
	
	
	
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "order_id")
	//@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	//@JoinColumn(name = "order_id", nullable = false)
	//@OnDelete(action = OnDeleteAction.CASCADE)
	private Order order;

	
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

		public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public Double getItemRate() {
		return itemRate;
	}

	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}

	
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}
	
	

}
