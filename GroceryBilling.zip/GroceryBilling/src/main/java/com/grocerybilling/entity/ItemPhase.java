package com.grocerybilling.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "item_phase", uniqueConstraints = @UniqueConstraint(columnNames = {"item_phase_name"}))

public class ItemPhase {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_phase_id")
	private long itemPhaseId;
    @NotNull
	@Column(name = "item_phase_name", nullable = false)
	private String itemPhaseName;
	
	
	public ItemPhase() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	


	public ItemPhase(long itemPhaseId, @NotNull String itemPhaseName) {
		super();
		this.itemPhaseId = itemPhaseId;
		this.itemPhaseName = itemPhaseName;
	}




	public long getItemPhaseId() {
		return itemPhaseId;
	}


	public void setItemPhaseId(long itemPhaseId) {
		this.itemPhaseId = itemPhaseId;
	}


	public String getItemPhaseName() {
		return itemPhaseName;
	}


	public void setItemPhaseName(String itemPhaseName) {
		this.itemPhaseName = itemPhaseName;
	}

	
	


}
