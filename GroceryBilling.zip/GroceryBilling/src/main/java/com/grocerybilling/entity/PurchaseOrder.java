package com.grocerybilling.entity;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.*;
//import jakarta.annotation

import com.grocerybilling.entity.PurchaseOrderItem;


import lombok.*;
import java.util.HashSet;
import java.util.Set;

@Entity
//@DynamicInsert
@Table(name = "purchase_orders")
public class PurchaseOrder {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	@Column(name = "start_date")
	// @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate startDate;
	// @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column(name = "end_date")
	private LocalDate endDate;
	@Column(name = "contact_person_name")
	private String contactPersonName;
	
	@Column(name = "contact_number")
	private String contactNumber;
	@Column(name = "month_of_purchase")
	private String monthOfPurchase;
	@Column(name = "installment_number")
	private String installmentNumber;
 // @Column(columnDefinition = "varchar(255) default 'active'")
   @Column(name = "status")
    private String status = "active";
   @Column(name = "bill_draft")
   private String billDraft = "no";
   @Column(name = "total")
	private Double total;
   @Column(name = "profit_margin")
	private Double profitMargin;
   @Column(name = "total_amount")
	private Double totalAmount;
  
   @OneToMany(mappedBy = "purchaseOrder",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
   private List<PurchaseOrderItem> purchaseOrderItems;
   
   @OneToMany(mappedBy = "PurchaseOrder",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
   private List<PurchaseOrderItemRate> purchaseOrderItemRates;
   
   @OneToMany(mappedBy = "PurchaseOrder",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
   private List<PurchaseOrderSupplierQuote> purchaseOrderSupplierQuotes;
   
   @OneToMany
   @JoinTable(name = "purchase_orders_orders", 
     joinColumns = {@JoinColumn(name = "purchase_order_id", referencedColumnName = "id")},
     inverseJoinColumns = {@JoinColumn(name = "order_id", referencedColumnName = "id")})
   private Set<Order> orders;
  
public PurchaseOrder() {
	//super();
	purchaseOrderItems = new ArrayList<>();
	
	
	// TODO Auto-generated constructor stub
}



public PurchaseOrder(Long id, LocalDate startDate, LocalDate endDate, String contactPersonName, String contactNumber,
		String status, String billDraft, Double total, Double profitMargin, Double totalAmount) {
	super();
	this.id = id;
	this.startDate = startDate;
	this.endDate = endDate;
	this.contactPersonName = contactPersonName;
	this.contactNumber = contactNumber;
	this.status = status;
	this.billDraft = billDraft;
	this.total = total;
	this.profitMargin = profitMargin;
	this.totalAmount = totalAmount;
}



public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public LocalDate getStartDate() {
	return startDate;
}
public void setStartDate(LocalDate startDate) {
	this.startDate = startDate;
}
public LocalDate getEndDate() {
	return endDate;
}
public void setEndDate(LocalDate endDate) {
	this.endDate = endDate;
}




public String getInstallmentNumber() {
	return installmentNumber;
}



public void setInstallmentNumber(String installmentNumber) {
	this.installmentNumber = installmentNumber;
}



public String getContactPersonName() {
	return contactPersonName;
}
public void setContactPersonName(String contactPersonName) {
	this.contactPersonName = contactPersonName;
}
public String getContactNumber() {
	return contactNumber;
}
public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getBillDraft() {
	return billDraft;
}
public void setBillDraft(String billDraft) {
	this.billDraft = billDraft;
}
public Double getTotal() {
	return total;
}
public void setTotal(Double total) {
	this.total = total;
}
public Double getProfitMargin() {
	return profitMargin;
}
public void setProfitMargin(Double profitMargin) {
	this.profitMargin = profitMargin;
}
public Double getTotalAmount() {
	return totalAmount;
}
public void setTotalAmount(Double totalAmount) {
	this.totalAmount = totalAmount;
}
   
public void add(PurchaseOrderItem item) {

    if (item != null) {
        if (purchaseOrderItems == null) {
        	purchaseOrderItems = new ArrayList<>();
        }

        purchaseOrderItems.add(item);
      item.setPurchaseOrder(this);
    }
}

public void remove(PurchaseOrderItem item) {
   
	purchaseOrderItems.remove(item);
       item.setPurchaseOrder(null);
   
}


public Set<Order> getOrders() {
	return orders;
}



public void setOrders(Set<Order> orders) {
	this.orders = orders;
}



public List<PurchaseOrderItem> getPurchaseOrderItems() {
	return purchaseOrderItems;
}



public void setPurchaseOrderItems(List<PurchaseOrderItem> purchaseOrderItems) {
	this.purchaseOrderItems = purchaseOrderItems;
}



public String getMonthOfPurchase() {
	return monthOfPurchase;
}



public void setMonthOfPurchase(String monthOfPurchase) {
	this.monthOfPurchase = monthOfPurchase;
}



public List<PurchaseOrderItemRate> getPurchaseOrderItemRates() {
	return purchaseOrderItemRates;
}



public void setPurchaseOrderItemRates(List<PurchaseOrderItemRate> purchaseOrderItemRates) {
	this.purchaseOrderItemRates = purchaseOrderItemRates;
}



public List<PurchaseOrderSupplierQuote> getPurchaseOrderSupplierQuotes() {
	return purchaseOrderSupplierQuotes;
}



public void setPurchaseOrderSupplierQuotes(List<PurchaseOrderSupplierQuote> purchaseOrderSupplierQuotes) {
	this.purchaseOrderSupplierQuotes = purchaseOrderSupplierQuotes;
}





   
	
}
