package com.grocerybilling.entity;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.*;
//import jakarta.annotation

import com.grocerybilling.entity.PurchaseOrderItem;


import lombok.*;
import java.util.HashSet;
import java.util.Set;

@Entity
//@DynamicInsert
@Table(name = "quotation_orders")

public class QuotationOrder {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	@Column(name = "start_date")
	// @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private Date startDate;
	// @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column(name = "end_date")
	private Date endDate;
	@Column(name = "contact_person_name")
	private String contactPersonName;
	
	@Column(name = "contact_number")
	private String contactNumber;
	@Column(name = "month_of_purchase")
	private String monthOfPurchase;
	@Column(name = "installment_number")
	private String installmentNumber;
 // @Column(columnDefinition = "varchar(255) default 'active'")
   @Column(name = "status")
    private String status = "active";
   @Column(name = "bill_draft")
   private String billDraft = "no";
   @Column(name= "department_id")
	private Long departmentId;
   @Column(name = "total")
	private Double total;
   @Column(name = "profit_margin")
	private Double profitMargin;
   @Column(name = "total_amount")
	private Double totalAmount;
   @OneToMany(mappedBy = "quotationOrder",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
   private List<QuotationOrderItem> quotationOrderItems;
   
  
   
   @ManyToMany
   @JoinTable(
       name = "quotation_orders_orders", 
    		   joinColumns = {@JoinColumn(name = "quotation_order_id", referencedColumnName = "id")},
    		     inverseJoinColumns = {@JoinColumn(name = "order_id", referencedColumnName = "id")})
   private Set<Order> orders;

public QuotationOrder() {
	super();
	quotationOrderItems = new ArrayList<>();
	// TODO Auto-generated constructor stub
}

public QuotationOrder(Long id, Date startDate, Date endDate, String contactPersonName, String contactNumber,
		String installmentNumber, String status, String billDraft, Double total, Double profitMargin,
		Double totalAmount, List<QuotationOrderItem> quotationOrderItems, Set<Order> orders) {
	super();
	this.id = id;
	this.startDate = startDate;
	this.endDate = endDate;
	this.contactPersonName = contactPersonName;
	this.contactNumber = contactNumber;
	this.installmentNumber = installmentNumber;
	this.status = status;
	this.billDraft = billDraft;
	this.total = total;
	this.profitMargin = profitMargin;
	this.totalAmount = totalAmount;
	this.quotationOrderItems = quotationOrderItems;
	this.orders = orders;
}

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public Date getStartDate() {
	return startDate;
}

public void setStartDate(Date startDate) {
	this.startDate = startDate;
}

public Date getEndDate() {
	return endDate;
}

public void setEndDate(Date endDate) {
	this.endDate = endDate;
}

public String getContactPersonName() {
	return contactPersonName;
}

public void setContactPersonName(String contactPersonName) {
	this.contactPersonName = contactPersonName;
}

public String getContactNumber() {
	return contactNumber;
}

public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}

public String getMonthOfPurchase() {
	return monthOfPurchase;
}

public void setMonthOfPurchase(String monthOfPurchase) {
	this.monthOfPurchase = monthOfPurchase;
}

public String getInstallmentNumber() {
	return installmentNumber;
}

public void setInstallmentNumber(String installmentNumber) {
	this.installmentNumber = installmentNumber;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public String getBillDraft() {
	return billDraft;
}

public void setBillDraft(String billDraft) {
	this.billDraft = billDraft;
}

public Long getDepartmentId() {
	return departmentId;
}

public void setDepartmentId(Long departmentId) {
	this.departmentId = departmentId;
}

public Double getTotal() {
	return total;
}

public void setTotal(Double total) {
	this.total = total;
}

public Double getProfitMargin() {
	return profitMargin;
}

public void setProfitMargin(Double profitMargin) {
	this.profitMargin = profitMargin;
}

public Double getTotalAmount() {
	return totalAmount;
}

public void setTotalAmount(Double totalAmount) {
	this.totalAmount = totalAmount;
}

public List<QuotationOrderItem> getQuotationOrderItems() {
	return quotationOrderItems;
}

public void setQuotationOrderItems(List<QuotationOrderItem> quotationOrderItems) {
	this.quotationOrderItems = quotationOrderItems;
}

public Set<Order> getOrders() {
	return orders;
}

public void setOrders(Set<Order> orders) {
	this.orders = orders;
}
   

public void add(QuotationOrderItem item) {

    if (item != null) {
        if (quotationOrderItems == null) {
        	quotationOrderItems = new ArrayList<>();
        }

        quotationOrderItems.add(item);
     // item.setPurchaseOrder(this);
    }
}

public void remove(QuotationOrderItem item) {
	   
	quotationOrderItems.remove(item);
     //  item.setPurchaseOrder(null);
   
}

   

}
