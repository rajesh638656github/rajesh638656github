package com.grocerybilling.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.*;
//import jakarta.annotation

import com.grocerybilling.entity.OrderItem;

import lombok.*;
import java.util.HashSet;
import java.util.Set;

@Entity
//@DynamicInsert
@Table(name = "orders")

public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name = "order_id")
	private long id;
	@Column(name = "start_date")
	// @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private Date startDate;
	// @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column(name = "end_date")
	private Date endDate;
	@Column(name = "institution_id")
	private int institutionId;
	@Column(name = "department_id")
	private int departmentId;
	@Column(name = "contact_person_name")
	private String contactPersonName;
	
	@Column(name = "contact_number")
	private String contactNumber;

 // @Column(columnDefinition = "varchar(255) default 'active'")
   @Column(name = "status")
    private String status = "active";
   @Column(name = "bill_draft")
   private String billDraft = "no";
   @Column(name = "total")
	private Double total;
   @Column(name = "profit_margin")
	private Double profitMargin;
   @Column(name = "total_amount")
	private Double totalAmount;
	

	// @OneToMany(cascade = CascadeType.ALL)
	// @JsonIgnoreProperties("orders")
	// @JoinColumn(name = "oi_fid", referencedColumnName = "orderId")
	// @OneToMany(fetch = FetchType.LAZY, mappedBy = "orders", cascade =
	// CascadeType.ALL)
	// @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	// @JoinColumn(name = "order_id", referencedColumnName = "id")
	// List<Item> itemList;
	// List<Item> itemList = new ArrayList<>();



	

	@OneToMany(mappedBy = "order",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	//@JoinColumn(name = "order_id")
	// private Set<OrderItem> orderitems;
	private List<OrderItem> orderitems;

	public Order() {
		orderitems = new ArrayList<>();
		// TODO Auto-generated constructor stub
	}

	//public Order(Date startDate, Date endDate, int institutionId, int departmentId, String status) {
		public Order(Date startDate, Date endDate, int institutionId, int departmentId,String contactPersonName,String contactNumber,Double totalAmount) {

		this.startDate = startDate;
		this.endDate = endDate;
		this.institutionId = institutionId;
		this.departmentId = departmentId;
		this.contactPersonName = contactPersonName;
		this.contactNumber = contactNumber;
		this.totalAmount = totalAmount;
		//this.status = status;
	}




	public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public int getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(int institutionId) {
		this.institutionId = institutionId;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	} 
 public String getBillDraft() {
			return billDraft;
		}

public void setBillDraft(String billDraft) {
			this.billDraft = billDraft;
			}


public Double getTotal() {
return total;
}

public void setTotal(Double total) {
this.total = total;
}

public Double getProfitMargin() {
return profitMargin;
}

public void setProfitMargin(Double profitMargin) {
this.profitMargin = profitMargin;
}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public void add(OrderItem item) {

        if (item != null) {
            if (orderitems == null) {
            	orderitems = new ArrayList<>();
            }

            orderitems.add(item);
          item.setOrder(this);
        }
    }
	
	public void remove(OrderItem item) {
       
            orderitems.remove(item);
           item.setOrder(null);
       
    }

	public List<OrderItem> getOrderitems() {
		return orderitems;
	}

	public void setOrderitems(List<OrderItem> orderitems) {
		this.orderitems = orderitems;
	}

}
