package com.grocerybilling.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.*;
//import jakarta.annotation
import jakarta.validation.Valid;

import com.grocerybilling.entity.OrderItem;

import lombok.*;
import java.util.HashSet;
import java.util.Set;

@Entity
//@DynamicInsert
@Table(name = "orders")

public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name = "order_id")
	private Long id;
	@Column(name = "start_date")
	// @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private Date startDate;
	// @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column(name = "end_date")
	private Date endDate;
	@Column(name = "institution_id")
	private Integer institutionId;
	@Column(name = "month_of_purchase")
	private String monthOfPurchase;
	@Column(name = "installment_number")
	private String installmentNumber;
	
	@Column(name = "contact_person_name")
	private String contactPersonName;
	
	@Column(name = "contact_number")
	private String contactNumber;

 // @Column(columnDefinition = "varchar(255) default 'active'")
   @Column(name = "status")
    private String status = "active";
   @Column(name = "purchase_order_created")
   private String purchaseOrderCreated = "no";
   @Column(name = "quotation_order_created")
   private String quotationOrderCreated = "no";
   @Column(name = "purchase_order_id")
   private Long purchaseOrderId;
   @Column(name = "bill_draft")
   private String billDraft = "no";
   @Column(name = "total")
	private Double total;
   @Column(name = "profit_margin")
	private Double profitMargin;
   @Column(name = "total_amount")
	private Double totalAmount;
	

	// @OneToMany(cascade = CascadeType.ALL)
	// @JsonIgnoreProperties("orders")
	// @JoinColumn(name = "oi_fid", referencedColumnName = "orderId")
	// @OneToMany(fetch = FetchType.LAZY, mappedBy = "orders", cascade =
	// CascadeType.ALL)
	// @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	// @JoinColumn(name = "order_id", referencedColumnName = "id")
	// List<Item> itemList;
	// List<Item> itemList = new ArrayList<>();



	

	@OneToMany(mappedBy = "order",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	//@JoinColumn(name = "order_id")
	// private Set<OrderItem> orderitems;
    @Valid
	private List<OrderItem> orderitems;
	
	@ManyToMany(mappedBy = "orders")
    private Set<QuotationOrder> QuotationOrders;

	public Order() {
		orderitems = new ArrayList<>();
		// TODO Auto-generated constructor stub
	}

	//public Order(Date startDate, Date endDate, int institutionId, int departmentId, String status) {
		
	public Order(Long id, Date startDate, Date endDate, Integer institutionId, String monthOfPurchase,String installmentNumber,Integer unitId,
			String contactPersonName, String contactNumber, String status, String billDraft, Double total,
			Double profitMargin, Double totalAmount, List<OrderItem> orderitems) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
		this.institutionId = institutionId;
		this.monthOfPurchase = monthOfPurchase;
		this.installmentNumber = installmentNumber;
		this.contactPersonName = contactPersonName;
		this.contactNumber = contactNumber;
		this.status = status;
		this.billDraft = billDraft;
		this.total = total;
		this.profitMargin = profitMargin;
		this.totalAmount = totalAmount;
		this.orderitems = orderitems;
	}
	
	
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Integer getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(Integer institutionId) {
		this.institutionId = institutionId;
	}

	
	public String getMonthOfPurchase() {
		return monthOfPurchase;
	}

	public void setMonthOfPurchase(String monthOfPurchase) {
		this.monthOfPurchase = monthOfPurchase;
	}

	public String getInstallmentNumber() {
		return installmentNumber;
	}

	public void setInstallmentNumber(String installmentNumber) {
		this.installmentNumber = installmentNumber;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBillDraft() {
		return billDraft;
	}

	public void setBillDraft(String billDraft) {
		this.billDraft = billDraft;
	}
	
	public String getPurchaseOrderCreated() {
		return purchaseOrderCreated;
	}

	public void setPurchaseOrderCreated(String purchaseOrderCreated) {
		this.purchaseOrderCreated = purchaseOrderCreated;
	}

	public Double getTotal() {
		return total;
	}

	public void setTotal(Double total) {
		this.total = total;
	}

	public Double getProfitMargin() {
		return profitMargin;
	}

	public void setProfitMargin(Double profitMargin) {
		this.profitMargin = profitMargin;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	
	public Long getPurchaseOrderId() {
		return purchaseOrderId;
	}

	public void setPurchaseOrderId(Long purchaseOrderId) {
		this.purchaseOrderId = purchaseOrderId;
	}

	public Set<QuotationOrder> getQuotationOrders() {
		return QuotationOrders;
	}

	public void setQuotationOrders(Set<QuotationOrder> quotationOrders) {
		QuotationOrders = quotationOrders;
	}

	public void add(OrderItem item) {

        if (item != null) {
            if (orderitems == null) {
            	orderitems = new ArrayList<>();
            }

            orderitems.add(item);
          item.setOrder(this);
        }
    }
	
	

	public void remove(OrderItem item) {
       
            orderitems.remove(item);
           item.setOrder(null);
       
    }

	public List<OrderItem> getOrderitems() {
		return orderitems;
	}

	public void setOrderitems(List<OrderItem> orderitems) {
		this.orderitems = orderitems;
	}

	public String getQuotationOrderCreated() {
		return quotationOrderCreated;
	}

	public void setQuotationOrderCreated(String quotationOrderCreated) {
		this.quotationOrderCreated = quotationOrderCreated;
	}

	

}
