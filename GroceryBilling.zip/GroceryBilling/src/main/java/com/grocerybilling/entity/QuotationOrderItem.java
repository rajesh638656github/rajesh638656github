package com.grocerybilling.entity;
import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.ArrayList;

@Entity
@Table(name = "quotation_order_item")

public class QuotationOrderItem {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name= "item_id")
	private Long itemId;
	
	@Column(name= "item_rate")
	private Double itemRate;
	
	@Column(name= "quantity")
	private Double quantity;
	@Column(name = "unit_id")
	private Long unitId;
	@Column(name= "amount")
	private Double amount;
	@Column(name= "department_id")
	private Long departmentId;
	
	
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "quotation_order_id")
	//@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	//@JoinColumn(name = "order_id", nullable = false)
	//@OnDelete(action = OnDeleteAction.CASCADE)
	private QuotationOrder quotationOrder;


	public QuotationOrderItem() {
		super();
		// TODO Auto-generated constructor stub
	}


	public QuotationOrderItem(Long id, Long itemId, Double itemRate, Double quantity, Double amount, Long departmentId,
			QuotationOrder quotationOrder) {
		super();
		this.id = id;
		this.itemId = itemId;
		this.itemRate = itemRate;
		this.quantity = quantity;
		this.amount = amount;
		this.departmentId = departmentId;
		this.quotationOrder = quotationOrder;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Long getItemId() {
		return itemId;
	}


	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}


	public Double getItemRate() {
		return itemRate;
	}


	public void setItemRate(Double itemRate) {
		this.itemRate = itemRate;
	}


	public Double getQuantity() {
		return quantity;
	}


	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public Long getDepartmentId() {
		return departmentId;
	}


	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}


	public QuotationOrder getQuotationOrder() {
		return quotationOrder;
	}


	public void setQuotationOrder(QuotationOrder quotationOrder) {
		this.quotationOrder = quotationOrder;
	}


	public Long getUnitId() {
		return unitId;
	}


	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}
	
	


	

}
