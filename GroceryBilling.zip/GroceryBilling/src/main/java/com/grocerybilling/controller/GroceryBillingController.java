package com.grocerybilling.controller;
import java.util.Date;
import java.util.List;
import java.util.*;
import java.io.*;
import java.util.Map.Entry;
import java.beans.PropertyEditorSupport;
import org.springframework.http.*;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import org.springframework.core.io.InputStreamResource;

import com.grocerybilling.PDFGenerator.PdfService;

//import be.quodlibet.boxable.BaseTable;
//import be.quodlibet.boxable.TableDrawer;
import be.quodlibet.boxable.Table;
//import be.quodlibet.boxable.TableRow;
import be.quodlibet.boxable.TableCell;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

//import org.springframework.mail.javamail.MimeMessageHelper;
//import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMultipart;
import org.springframework.core.io.ByteArrayResource;
import java.util.Base64;
//import javax.servlet.http.HttpServletResponse;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.lang.Math;
import java.time.YearMonth;
import org.modelmapper.ModelMapper;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.dao.DataIntegrityViolationException;
//import org.springframework.util.StringUtils;

import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.transaction.annotation.Transactional;

import com.grocerybilling.registrationlogin.dto.UserDto;
import org.springframework.security.core.userdetails.User;
import com.grocerybilling.registrationlogin.entity.GroceryUser;
import com.grocerybilling.registrationlogin.service.UserService;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;

import java.time.LocalDate;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.text.*;
import java.util.HashSet;
import java.util.Iterator;
import jakarta.validation.Valid;

import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.validation.ConstraintValidatorFactory;
import jakarta.validation.Configuration;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintViolation;
import com.grocerybilling.service.PopulateOrderScreenService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import com.grocerybilling.registrationlogin.dto.UserDto;
import com.grocerybilling.registrationlogin.entity.GroceryUser;
import com.grocerybilling.registrationlogin.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import com.grocerybilling.service.PopulateOrderScreenService;
import com.grocerybilling.model.*;
import com.grocerybilling.registrationlogin.dto.UserDto;
import com.grocerybilling.registrationlogin.entity.GroceryUser;
import com.grocerybilling.registrationlogin.service.UserService;
//import com.grocerybilling.model.SizeDTO;

import com.grocerybilling.DTO.OrderDTO;
import com.grocerybilling.DTO.BillOrderDTO;
import com.grocerybilling.DTO.DepartmentDTO;
import com.grocerybilling.DTO.InstitutionDTO;
import com.grocerybilling.DTO.ItemDTO;
import com.grocerybilling.DTO.ItemPriceDTO;
import com.grocerybilling.DTO.ItemBatchDTO;
import com.grocerybilling.DTO.ItemDTO;
import com.grocerybilling.DTO.ItemStatusDTO;
import com.grocerybilling.DTO.ItemPhaseDTO;
import com.grocerybilling.DTO.OrderDTO;
import com.grocerybilling.DTO.OrderItemDTO;

import com.grocerybilling.DTO.OrderUpdateDTO;
import com.grocerybilling.DTO.RateComparisonFormDTO;

import com.grocerybilling.DTO.PhaseNameDTO;
import com.grocerybilling.DTO.PurchaseOrderDTO;
import com.grocerybilling.DTO.PurchaseOrderItemDTO;
import com.grocerybilling.DTO.QuotationOrderDTO;
import com.grocerybilling.DTO.QuotationOrderItemDTO;
import com.grocerybilling.DTO.OrderItemUpdateDTO;
import com.grocerybilling.DTO.OrderMasterDTO;
import com.grocerybilling.DTO.OrderAddItemDTO;
import com.grocerybilling.DTO.OrderItemAddItemDTO;
import com.grocerybilling.DTO.SizeDTO;
import com.grocerybilling.DTO.UnitDTO;
import com.grocerybilling.DTO.OrderItemPriceDTO;
import com.grocerybilling.entity.*;
import com.grocerybilling.repository.*;
import com.grocerybilling.util.*;
import com.grocerybilling.util.ConvertNumberToWords;

import jakarta.servlet.http.HttpServletResponse;

import com.grocerybilling.util.PDFThymeleaf;
import com.lowagie.text.DocumentException;
import com.grocerybilling.entity.Unit;
import com.grocerybilling.util.PDFThymeleafExampleModified;


import java.io.InputStream;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import org.apache.commons.io.IOUtils;
import jakarta.servlet.ServletOutputStream;
import com.grocerybilling.PDFGenerator.*;
import com.lowagie.text.DocumentException;
import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.pdmodel.font.*;

import java.io.File;
import org.springframework.web.client.RestTemplate;

import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
@CrossOrigin(origins = "http://localhost:5000") //

@Controller
public class GroceryBillingController {
	SecurityContextLogoutHandler logoutHandler = new SecurityContextLogoutHandler();
	@Autowired
	private UserService userService;
	@Autowired
	private PopulateOrderScreenService populateOrderScreenService;
	@Autowired
	private InstitutionRepository institutionRepository;
	@Autowired
	private DepartmentRepository departmentRepository;
	@Autowired
	private ItemRepository itemRepository;
	@Autowired
	private UnitRepository unitRepository;
	
	@Autowired
	private ItemPhaseRepository itemPhaseRepository;
	
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private OrderItemRepository orderItemRepository;
	@Autowired
	private PurchaseOrderRepository purchaseOrderRepository;
	@Autowired
	private PurchaseOrderItemRepository purchaseOrderItemRepository;
	@Autowired
	private QuotationOrderRepository quotationOrderRepository;
	@Autowired
	private QuotationOrderItemRepository quotationOrderItemRepository;
	@Autowired
	private JavaMailSender emailSender;
	//@Autowired
	private RestTemplate restTemplate;
	
	private  PdfService pdfService = new PdfService();
	@Bean
	public RestTemplate restTemplate() {
	    SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
	    factory.setConnectTimeout(5000);
	    factory.setReadTimeout(5000);
	    return new RestTemplate(factory);
	}
	
	@GetMapping("/purchase-report")
	  public String getPurchaseReport(Model model) throws Exception {
		System.out.println("Printing in purchase-report");
		  // Sample Data (Replace with actual database fetch)
		
		
        List<Map<String, Object>> items1 = List.of(
            Map.of("itemName", "சீரக சம்பா அரிசி (26 கி - 1 சிப்பம்)", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "இட்லி அரிசி குருணை (75 கி-1 மூட்டை)", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
            Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
            Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450)
        );
        
        
        List<Map<String, Object>> items2 = List.of(
                Map.of("itemName", "சீரக சம்பா அரிசி (26 கி - 1 சிப்பம்)", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "இட்லி அரிசி குருணை (75 கி-1 மூட்டை)", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450),
                Map.of("itemName", "தமிழ் பொருள்", "rate", 100, "quantity", 2, "amount", 200),
                Map.of("itemName", "மற்றொரு பொருள்", "rate", 150, "quantity", 3, "amount", 450)
            );

      /*  List<List<String>> data = Arrays.asList(
        	    Arrays.asList("1", "பஞ்சு", "100", "5", "500"),
        	    Arrays.asList("2", "கம்பளி", "200", "3", "600"),
        	    Arrays.asList("3", "ரேஷ்மி", "150", "2", "300")
        	);
        */
        List<Long> purchaseOrderId0= new ArrayList<Long>();
        purchaseOrderId0.add(2L);
		  List<PurchaseOrderItemDetailDTO> purchaseOrderdetails1 = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderId0);
		  List<Long> purchaseOrderId1= new ArrayList<Long>();
		  purchaseOrderId1.add(1L);
		  List<PurchaseOrderItemDetailDTO> purchaseOrderdetails2 = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderId1);
		  
		  
		  
        
       List items = new ArrayList<>();
       items.add(purchaseOrderdetails1);
       items.add(purchaseOrderdetails2);
       
       model.addAttribute("items", items);

     //  int total = items1.stream().mapToInt(item -> (int) item.get("amount")).sum();
        
       Double total = purchaseOrderdetails2.stream().mapToDouble(PurchaseOrderItemDetailDTO::getAmount).sum();
        // Add data to the model
       
      // for( int i=0;i<items.size();i++) {
    //    model.addAttribute("items", purchaseOrderdetails2);
     //   model.addAttribute("total", total);
        
    //   }
        
        
        // Step 2: Send data to Node.js for PDF generation
        
    /*   
        String nodeJsPdfServiceUrl = "http://localhost:5000/generate-pdf";
        String emailAddress = "rajesh638656@gmail.com";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
       // HttpEntity<List<Map<String, Object>>> request = new HttpEntity<>(items, headers);
        HttpEntity<List<PurchaseOrderItemDetailDTO>> request = new HttpEntity<>(purchaseOrderdetails2, headers);

        
        restTemplate = restTemplate();
        ResponseEntity<byte[]> response = restTemplate.exchange(
            nodeJsPdfServiceUrl, HttpMethod.POST, request, byte[].class);
        
        String responseStatus = null;
        if (response.getStatusCode() == HttpStatus.OK) {
            byte[] pdfBytes = response.getBody();

            // Step 3: Send email with PDF attachment
            sendEmailWithAttachment(emailAddress, pdfBytes);

            responseStatus ="PDF generated and email sent successfully.";
        } else {
        	responseStatus = "Failed to generate PDF.";
        }
        
        */
        
       for( int i=0;i<items.size();i++) {
         
        String nodeJsPdfServiceUrl = "http://localhost:3001/generate-pdf";
        String emailAddress = "rajesh638656@gmail.com";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
       // HttpEntity<List<Map<String, Object>>> request = new HttpEntity<>(items, headers);
       // HttpEntity<List<PurchaseOrderItemDetailDTO>> request = new HttpEntity<>(purchaseOrderdetails2, headers);
       // PurchaseData purchaseData = new PurchaseData(purchaseOrderdetails2, total);
        List<PurchaseOrderItemDetailDTO> item = (List<PurchaseOrderItemDetailDTO>) items.get(i);
        HttpEntity<List<PurchaseOrderItemDetailDTO>> request = new HttpEntity<>(item, headers);

        
        restTemplate = restTemplate();
        ResponseEntity<byte[]> response = restTemplate.exchange(
            nodeJsPdfServiceUrl, HttpMethod.POST, request, byte[].class);
        
        String responseStatus = null;
        if (response.getStatusCode() == HttpStatus.OK) {
            byte[] pdfBytes = response.getBody();

            // Step 3: Send email with PDF attachment
            sendEmailWithAttachment(emailAddress, pdfBytes);

            responseStatus ="PDF generated and email sent successfully.";
        } else {
        	responseStatus = "Failed to generate PDF.";
        }
        
       }
   
       
    //   return "purchase-report-with-single-report"; 
	   // return "purchase-report4"; // Thymeleaf template name
	    //return "purchase-report3";
	 return "purchase-report-with-multiple-reports";
	  
	    // Thymeleaf template name
	  }

	  // Inner class for PurchaseItem
	  public static class PurchaseItem {
	    private String itemName;
	    private int rate;
	    private int quantity;
	    private int amount;

	    public PurchaseItem(String itemName, int rate, int quantity, int amount) {
	      this.itemName = itemName;
	      this.rate = rate;
	      this.quantity = quantity;
	      this.amount = amount;
	    }
	    // Getters and Setters
	    public String getItemName() { return itemName; }
	    public int getRate() { return rate; }
	    public int getQuantity() { return quantity; }
	    public int getAmount() { return amount; }
	  }
	  
	  public static class PurchaseData {
		    private List<PurchaseOrderItemDetailDTO> data;
		    private Double total;

		    public PurchaseData(List<PurchaseOrderItemDetailDTO> data, Double total) {
		      this.data = data;
		      this.total = total;
		    }

		    // Getters
		    public List<PurchaseOrderItemDetailDTO> getData() { return data; }
		    public Double getTotal() { return total; }
		  }
	  
	  
	  private void sendEmailWithAttachment(String email, byte[] pdfBytes) throws MessagingException {
	        MimeMessage message = emailSender.createMimeMessage();
	        MimeMessageHelper helper = new MimeMessageHelper(message, true);

	        helper.setTo(email);
	        helper.setSubject("Purchase Report");
	        helper.setText("Please find the attached purchase report.");

	        // Attach the PDF
	        helper.addAttachment("PurchaseReport.pdf", new ByteArrayResource(pdfBytes));

	        emailSender.send(message);
	    }
	  
	  

	  @PostMapping("/sendPdfEmail")
	    public ResponseEntity<String> sendEmailWithAttachment(@RequestBody PdfData pdfData) {
	        try {
	            // Decode the base64 string to get the PDF content
	            byte[] decodedBytes = Base64.getDecoder().decode(pdfData.getPdfContent());
	           // byte[] institutionNameBytes = Base64.getDecoder().decode(pdfData.fileName);
	          //  ByteArrayInputStream inputStream = new ByteArrayInputStream(decodedBytes);
	          //  String institutionName = new String(institutionNameBytes, StandardCharsets.UTF_8);
	          //  StringBuffer fileName = new StringBuffer();
	          //  fileName.append(institutionName);
	          //  fileName.append(".pdf");
	            		
	            String fileName = pdfData.fileName.trim();
	            // Prepare the email content
	            MimeMessage message = emailSender.createMimeMessage();
	            MimeMessageHelper helper = new MimeMessageHelper(message, true);
	            helper.setTo("rajesh638656@gmail.com"); // Change to the desired email address
	            helper.setSubject("Purchase Report");
	            helper.setText("Please find the attached purchase report.");
	          //  helper.addAttachment("PurchaseReport.pdf", new ByteArrayResource(decodedBytes));
	            helper.addAttachment(fileName, new ByteArrayResource(decodedBytes));

	            // Attach the PDF
	          //  MimeBodyPart attachment = new MimeBodyPart();
	          //  attachment.setFileName(pdfData.getFileName());
	          //  attachment.setContent(inputStream, "application/pdf");

	            // Create a multipart message and add the attachment
	         //   MimeMultipart multipart = new MimeMultipart();
	         //   multipart.addBodyPart(attachment);
	         //   message.setContent(multipart);

	            // Send the email
	            emailSender.send(message);
	            return ResponseEntity.ok("Email sent successfully!");

	        } catch (MessagingException e) {
	            e.printStackTrace();
	            return ResponseEntity.status(500).body("Failed to send email");
	        }
	    }
	    // Class to hold PDF data
	    public static class PdfData {
	        private String pdfContent;
	        private String fileName;

	        // Getters and setters
	        public String getPdfContent() {
	            return pdfContent;
	        }

	        public void setPdfContent(String pdfContent) {
	            this.pdfContent = pdfContent;
	        }

	        public String getFileName() {
	            return fileName;
	        }

	        public void setFileName(String fileName) {
	            this.fileName = fileName;
	        }
	    }
	 
	




@PostMapping("/send-email")
public String sendEmail(@RequestParam("pdf") MultipartFile pdfFile, @RequestParam("email") String email) throws MessagingException, IOException {
    // Prepare the email
	
	System.out.println("printing in send email method" );
    MimeMessage message = emailSender.createMimeMessage();
    MimeMessageHelper helper = new MimeMessageHelper(message, true);

    // Set email attributes
    helper.setFrom("rajesh638656@gmail.com");
    helper.setTo(email);  // Recipient email address
    helper.setSubject("Supplier Report");
    helper.setText("Please find the attached PDF report.");
    
    // Attach the PDF file to the email
    ByteArrayResource pdfResource = new ByteArrayResource(pdfFile.getBytes());
    helper.addAttachment("supplier_report.pdf", pdfResource);

    // Send the email
    emailSender.send(message);
    
   // return "emailforwardsuccess";

    return "{\"success\": true, \"message\": \"Email sent successfully!\"}";
}
	
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		System.out.println("Init Binder is invoked");

		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));

	}

	@InitBinder
	public void initBinderForDouble(WebDataBinder binder) {
	    binder.registerCustomEditor(Double.class, new PropertyEditorSupport() {
	        @Override
	        public void setAsText(String text) {
	            if (text == null || text.trim().isEmpty()) {
	                setValue(null); // Allow empty values without marking as invalid
	            } else {
	                try {
	                    setValue(Double.parseDouble(text)); // Convert valid numeric input
	                } catch (NumberFormatException e) {
	                    setValue(-1.0); // Use a sentinel value to indicate invalid input
	                }
	            }
	        }
	    });
	}
	
	@RequestMapping(value = { "/welcome" }, method = RequestMethod.GET)
	public String showWelcome(Model model, Authentication authentication) {
		System.out.println("Printing from welcome");
		
		String returnPage = null;
		String userName = null;
		  if (authentication != null) {
	          User user = (User) authentication.getPrincipal();
	            String role = user.getAuthorities().toString();
	            userName = user.getUsername();

	            if (role.contains("ROLE_ADMIN")) {
	            	returnPage = "admin-welcome";  // Thymeleaf template for admin
	            } else if (role.contains("ROLE_USER")) {
	            	returnPage =  "user-welcome";  // Thymeleaf template for user
	            }
	        }
     model.addAttribute("userName", userName);
		return returnPage;
	}
	
	
	
	@GetMapping("index")
	public String home() {
		return "index";
	}

	@GetMapping("/login")
	public String loginForm() {
		return "login";
	}

	@PostMapping("/my/logout")
	public String performLogout(Authentication authentication, HttpServletRequest request) {
		// .. perform logout
		// this.logoutHandler.doLogout(request, response, authentication);
		this.logoutHandler.setInvalidateHttpSession(true);
		return "redirect:/home";
	}

	@GetMapping("register")
	public String showRegistrationForm(Model model) {
		UserDto user = new UserDto();
		model.addAttribute("user", user);
		populateDropDowns(model);
		return "register";
	}
	
	@PostMapping("/register/save")
	public String registration(@Valid @ModelAttribute("user") UserDto user, BindingResult result, Model model) {
		GroceryUser existing = userService.findByEmail(user.getEmail());
		
		System.out.println("Printing Role Name" + user.getRoles());
		if (existing != null) {
			result.rejectValue("email", null, "There is already an account registered with that email");
		}
		if (result.hasErrors()) {
			model.addAttribute("user", user);
			return "register";
		}
		userService.saveUser(user);
		return "redirect:/register?success";
	}



	@GetMapping("/update-password")
	public String updatePasswordForm(Model model) {
		UserDto user = new UserDto();
		model.addAttribute("user", user);
		return "update-password";
	}
	
	
	
	@PostMapping("/update-password")
	public String saveNewPassword(@ModelAttribute("user") UserDto user, BindingResult result, Model model) {
		 try {
			 System.out.println("Printing Email ID"+user.getEmail());
		GroceryUser existing = userService.findByEmail(user.getEmail());
		//System.out.println("Printing existing user id" + existing.getEmail());
    	//System.out.println("Printing existing Password" + existing.getPassword());
		model.addAttribute("user", user);
	
		if (existing == null) {
            model.addAttribute("error", "New passwords do not match");
            return "update-password";
        }
			
		userService.updatePassword(user);
        model.addAttribute("message", "Password updated successfully");
    } catch (Exception e) {
        // Handles exceptions during password update process.
        model.addAttribute("error", e.getMessage());
    }
    return "redirect:/update-password?success";
}
		
		
	

	
	// handler method to handle register user form submit request
	
	@GetMapping("/users")
	public String listRegisteredUsers(Model model) {
		List<UserDto> users = userService.findAllUsers();
	
		model.addAttribute("users", users);
		return "users";
	}
	
	
	@GetMapping(value = { "/createorder" })

	public String createOrder(OrderDTO orderDTO, Model model) {
		List<Item> ItemEntityList = itemRepository.findAllByOrderByItemPhaseId();
		List<String> phaseNames = new ArrayList<String>();
		
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		orderDTO.setStartDate(dateformate.format(new Date()));
		
		ItemEntityList.forEach(item -> {

			OrderItemDTO orderItemDTO = new OrderItemDTO();
			orderItemDTO.setItemIdDB(item.getItemId());
			orderItemDTO.setPhaseIdDB(item.getItemPhaseId());
			orderItemDTO.setItemNameDB(item.getItemName());
			
			orderDTO.add(orderItemDTO);
			

		}); 
		
		List<ItemPhaseDTO> itemPhaseList = populateOrderScreenService.findAllItemPhase();
		model.addAttribute("itemPhaseList", itemPhaseList);
		model.addAttribute("orderDTO", orderDTO);

		populateDropDowns(model);
		return "createorder";
	}
	
	
	
	
	 @PostMapping("/saveorder")
	public String saveOrder(@ModelAttribute("orderDTO") OrderDTO orderDTO,
			BindingResult bindingResult, HttpServletRequest request, Model model, RedirectAttributes redirectAttributes) {
		 
		 DecimalFormat df = new DecimalFormat("0.00");
		 Order order = new Order();
		 order.setInstitutionId(orderDTO.getInstitutionId());
		 order.setInstallmentNumber(orderDTO.getInstallmentNumber());
		 order.setProfitMargin(orderDTO.getProfitMargin());
		 order.setStartDate(new Date());
		 orderRepository.save(order);
		 
		 Long OrderId = order.getId();
		 
		 System.out.println("printing newly created orderid "+ OrderId);
		 
		 
		 List<OrderItemDTO> OrderItemDTOs = orderDTO.getOrderItemDTOs();
		 List<Item> ItemEntityList = itemRepository.findAllByOrderByItemPhaseId();
		 
		// ItemEntityList.
		 
			
			Double orderTotal = 0.0;
		 
		 for (int i=0;i<OrderItemDTOs.size();i++) {
		//	for (OrderItemDTO orderItemDTO : OrderItemDTOs) {
				OrderItemDTO orderItemDTO = OrderItemDTOs.get(i);
				Item item = ItemEntityList.get(i);

				if (orderItemDTO.getQuantity() != null) {
					System.out.println("Printing Rate Item Id" + orderItemDTO.getItemId());
					System.out.println("Printing Rate Item Id From getItemIdDB" + orderItemDTO.getItemIdDB());
					
					
					OrderItem orderItem = new OrderItem();
					orderItem.setItemId(item.getItemId());
					orderItem.setQuantity(orderItemDTO.getQuantity());
				//	Item itemRateEntity = itemRepository.findByItemId(orderItemDTO.getItemId());

				//	Long phaseName = itemRateEntity.getItemPhaseId();
					Double itemAmount = 0.0;
					if (orderItemDTO.getItemRate()!=null)
					{
					Double itemRate = orderItemDTO.getItemRate();
					Double quantity = orderItemDTO.getQuantity();
				
					
					
					System.out.println("Printing Rate " + itemRate);
				
				//	System.out.println("Printing Phase Name " + phaseName);
					
					
				
					orderItem.setItemRate(Double.parseDouble(df.format(orderItemDTO.getItemRate())));
					
					System.out.println("Printing Quantity " + quantity);
					
					itemAmount = quantity * itemRate;
					System.out.println("Printing Amount " + itemAmount);
					orderItem.setAmount(Double.parseDouble(df.format(itemAmount)));
					}
					orderItem.setOrder(order);
					orderItemRepository.save(orderItem);
					orderTotal = orderTotal+itemAmount;
			
			}
			}
			
			Order orderEntity = orderRepository.findById(OrderId);
			
			List<Long> orderIds = new ArrayList<Long>();
			orderIds.add(Long.valueOf(OrderId));

			
			orderEntity.setTotal(Double.parseDouble(df.format(orderTotal)));
			Double profitMargin = orderEntity.getProfitMargin();
			Double profit = 0.0;
			if (orderTotal != null && profitMargin != null) {
				profit = profitMargin/100*orderTotal;
			}
			
			orderEntity.setProfitMargin(orderDTO.getProfitMargin());
			orderEntity.setTotalAmount(Double.parseDouble(df.format(orderTotal + profit)));
			
			orderRepository.save(orderEntity);
			
			List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIds);
			List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIds);
			
			OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
			
			model.addAttribute("orderId", orderMasterDTO.getOrderId());
			model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
			model.addAttribute("OrderDate", orderMasterDTO.getStartDate());
			model.addAttribute("installmentNumber", orderMasterDTO.getInstallmentNumber());
			model.addAttribute("orderTotal", orderMasterDTO.getTotal());
			model.addAttribute("profitmargin", orderMasterDTO.getProfitMargin());
			model.addAttribute("orderGrandTotal", orderMasterDTO.getTotalAmount());
			model.addAttribute("orderdetails", orderdetails);
			
			
			
		 
		 return "saveordersuccess";
	}
	 
	 @GetMapping(value = { "/createorderclient" })

		public String createInstitutionOrder(OrderDTO orderDTO, Model model) {
			List<Item> ItemEntityList = itemRepository.findAllByOrderByItemPhaseId();
			List<String> phaseNames = new ArrayList<String>();
			
			SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
			orderDTO.setStartDate(dateformate.format(new Date()));
			 // Example input: the current date (you can change it to any date for testing)
	        LocalDate currentDate = LocalDate.now();

	        // Get the start and end of the current month
	        YearMonth currentMonth = YearMonth.from(currentDate);
	        LocalDate startOfMonth = currentMonth.atDay(1); // First day of the current month
	        LocalDate endOfMonth = currentMonth.atEndOfMonth(); // Last day of the current month

	        // Define your custom date ranges within the current month
	        LocalDate startDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1); // First start date
	        LocalDate endDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 15); // First end date

	        LocalDate startDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 16); // Second start date
	        
	        YearMonth yearMonth = YearMonth.from(currentDate);
	        int daysInCurrentMonth = yearMonth.lengthOfMonth();
	        
	        LocalDate endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), daysInCurrentMonth); // First end date
	     /*   LocalDate endDate2 = null;
	        if (currentDate.getMonthValue()!=2) {
	        endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 30); // Second end date
	        }
	        
	        if (currentDate.getMonthValue()==2) {
		        endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 28); // Second end date
		        }
		        */

	        // Define the variable to populate
	        String result = "";
	        String installmentNo= null;
	        String monthOfPurchase=null;
	        // Check if the current date is between the first range
	        if (!currentDate.isBefore(startDate1) && !currentDate.isAfter(endDate1)) {
	        	monthOfPurchase= LocalDate.now().getMonth().toString();
	            
	            result = "Value for first date range";
	            installmentNo = "2nd Installment";
	            
	        }
	        // Check if the current date is between the second range
	        else if (!currentDate.isBefore(startDate2) && !currentDate.isAfter(endDate2)) {
	        	LocalDate nextMonth = LocalDate.now().plusMonths(1);
	            
	            // Format next month to a string (e.g., "FEBRUARY")
	            String nextMonthStr = nextMonth.getMonth().toString();
	            monthOfPurchase = nextMonthStr;
	            installmentNo = "Ist Installment";
	            result = "Value for second date range";
	        }
	        // If the current date doesn't fall within any range
	        else {
	            result = "Date is not in any range";
	            installmentNo = "0";
	        }
	        orderDTO.setMonthOfPurchase(monthOfPurchase);
	        orderDTO.setInstallmentNumber(installmentNo);
	        // Output the result
	        System.out.println("Result: " + result);	
	        
	        Map<Long, String> itemNames = new HashMap<>();
	        
			ItemEntityList.forEach(item -> {

				OrderItemDTO orderItemDTO = new OrderItemDTO();
				orderItemDTO.setItemId(item.getItemId());
				orderItemDTO.setItemIdDB(item.getItemId());
				orderItemDTO.setPhaseIdDB(item.getItemPhaseId());
				orderItemDTO.setItemNameDB(item.getItemName());
				
				orderDTO.add(orderItemDTO);
				 itemNames.put(item.getItemId(), item.getItemName());
				

			}); 
			
			List<ItemPhaseDTO> itemPhaseList = populateOrderScreenService.findAllItemPhase();
			List<UnitDTO> units = populateOrderScreenService.findAllUnits();
			model.addAttribute("itemPhaseList", itemPhaseList);
			model.addAttribute("units", units);
			model.addAttribute("orderDTO", orderDTO);
			model.addAttribute("itemNames", itemNames);

			populateDropDowns(model);
			return "createorderclient";
		}
		
	 
	 @PostMapping("/saveorderclient")
		public String saveOrderClient(@Valid @ModelAttribute("orderDTO") OrderDTO orderDTO,
				BindingResult bindingResult, HttpServletRequest request, Model model, RedirectAttributes redirectAttributes,Authentication authentication) {
		 
		 
			if (bindingResult.hasErrors()) {
				System.out.println("Error block");
				System.out.println("printing error count" + bindingResult.getErrorCount());
				Map<String, Object> errorMessages = new HashMap();
				if (bindingResult.hasErrors()) {

					List<FieldError> fes = bindingResult.getFieldErrors();
					for (FieldError fe : fes) {
						errorMessages.put(fe.getField(), fe.getDefaultMessage());
					}

				}
				// model.addAttribute("orderDTO", orderDTO); 
				
				redirectAttributes.addFlashAttribute("errorMessages", errorMessages);
				redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.orderDTO",bindingResult);
				redirectAttributes.addFlashAttribute("orderDTO", orderDTO);
				return "redirect:/createorderclient";

			}
			
		 Integer institutionId = null;
				System.out.println("Printing from welcome");
				  if (authentication != null) {
			          User user = (User) authentication.getPrincipal();
			            String role = user.getAuthorities().toString();
			            String userName = user.getUsername();
			            System.out.println("Printing User Name" + userName);
			            GroceryUser groceryUser = userService.findByEmail(userName);
			            institutionId = groceryUser.getInstitutionId();
				  }
			            
			 
			 DecimalFormat df = new DecimalFormat("0.00");
			 Order order = new Order();
			 order.setInstitutionId(institutionId);
			 order.setMonthOfPurchase(orderDTO.getMonthOfPurchase());
			 order.setInstallmentNumber(orderDTO.getInstallmentNumber());
			 order.setProfitMargin(orderDTO.getProfitMargin());
			 order.setStartDate(new Date());
			 orderRepository.save(order);
			 
			 Long OrderId = order.getId();
			 
			 System.out.println("printing newly created orderid "+ OrderId);
			 
			 
			 List<OrderItemDTO> OrderItemDTOs = orderDTO.getOrderItemDTOs();
			 
			 System.out.println("Printing Item list Size" + OrderItemDTOs.size());
			 List<Item> ItemEntityList = itemRepository.findAllByOrderByItemPhaseId();
			// List<Item> ItemEntityList = itemRepository.findAll();
			 
			// ItemEntityList.
			 
				
				Double orderTotal = 0.0;
			 
			 for (int i=0;i<OrderItemDTOs.size();i++) {
			//	for (OrderItemDTO orderItemDTO : OrderItemDTOs) {
					OrderItemDTO orderItemDTO = OrderItemDTOs.get(i);
				

					if (orderItemDTO.getQuantity() != null) {
						Item item = ItemEntityList.get(i);
						System.out.println("Printing Rate Item Id" + orderItemDTO.getItemId());
						System.out.println("Printing Rate Item Id From getItemIdDB" + orderItemDTO.getItemIdDB());
						
						
						OrderItem orderItem = new OrderItem();
						orderItem.setItemId(item.getItemId());
						orderItem.setQuantity(orderItemDTO.getQuantity());
						orderItem.setUnitId(orderItemDTO.getUnitId());
						orderItem.setComments(orderItemDTO.getComments());
					//	Item itemRateEntity = itemRepository.findByItemId(orderItemDTO.getItemId());

					//	Long phaseName = itemRateEntity.getItemPhaseId();
						Double itemAmount = 0.0;
						if (orderItemDTO.getItemRate()!=null)
						{
						Double itemRate = orderItemDTO.getItemRate();
						Double quantity = orderItemDTO.getQuantity();
					
						
						
						System.out.println("Printing Rate " + itemRate);
					
					//	System.out.println("Printing Phase Name " + phaseName);
						
						
					
						orderItem.setItemRate(Double.parseDouble(df.format(orderItemDTO.getItemRate())));
						
						System.out.println("Printing Quantity " + quantity);
						
						itemAmount = quantity * itemRate;
						System.out.println("Printing Amount " + itemAmount);
						orderItem.setAmount(Double.parseDouble(df.format(itemAmount)));
						}
						orderItem.setOrder(order);
						orderItemRepository.save(orderItem);
						orderTotal = orderTotal+itemAmount;
				
				}
				}
				
				Order orderEntity = orderRepository.findById(OrderId);
				
				List<Long> orderIds = new ArrayList<Long>();
				orderIds.add(Long.valueOf(OrderId));

				
				orderEntity.setTotal(Double.parseDouble(df.format(orderTotal)));
				/* Double profitMargin = orderEntity.getProfitMargin();
				Double profit = 0.0;
				if (orderTotal != null && profitMargin != null) {
					profit = profitMargin/100*orderTotal;
				}
				*/
				
				orderEntity.setProfitMargin(orderDTO.getProfitMargin());
				//orderEntity.setTotalAmount(Double.parseDouble(df.format(orderTotal + profit)));
				
				orderRepository.save(orderEntity);
				
				List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIds);
				List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIds);
				
				OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
				
				model.addAttribute("orderId", orderMasterDTO.getOrderId());
				model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
				model.addAttribute("OrderDate", orderMasterDTO.getStartDate());
				model.addAttribute("monthOfPurchase", orderMasterDTO.getMonthOfPurchase());
				model.addAttribute("installmentNumber", orderMasterDTO.getInstallmentNumber());
				model.addAttribute("orderTotal", orderMasterDTO.getTotal());
				model.addAttribute("profitmargin", orderMasterDTO.getProfitMargin());
				model.addAttribute("orderGrandTotal", orderMasterDTO.getTotalAmount());
				model.addAttribute("orderdetails", orderdetails);
				
				
				
			// return "test";
			 return "saveorderclientsuccess";
		}
	 
	 
	 @GetMapping("/showallactiveorderforeditclient")
		public String showAllActiveOrderForEditClient(Model model, HttpServletRequest request,Authentication authentication) throws Exception {
		 	Integer institutionId = null;
			System.out.println("Printing from welcome");
			  if (authentication != null) {
		          User user = (User) authentication.getPrincipal();
		            String role = user.getAuthorities().toString();
		            String userName = user.getUsername();
		            System.out.println("Printing User Name" + userName);
		            GroceryUser groceryUser = userService.findByEmail(userName);
		            institutionId = groceryUser.getInstitutionId();
			  }
			  
			  List<Integer> institutionIds = new ArrayList<Integer>();
			  institutionIds.add(institutionId);
			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrdersByInstitution(institutionIds);
			model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
			
			return "showallactiveorderforeditclient";
		}
	 
	 

	 @GetMapping("/showeditorderclient/{orderId}")
		 public String showEditOrderClient(@PathVariable("orderId") long orderId, HttpServletResponse response,
					HttpServletRequest request, Model model) throws Exception {
			 
			 	Long orderID = orderId;
			 	
			 Order order = orderRepository.findById(orderID);
				
			 SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
			 
				
				List<OrderItemDTO> OrderItemDBDTOs = new ArrayList<OrderItemDTO>();
				List<OrderItem> orderItemEntityList = order.getOrderitems();
				orderItemEntityList.forEach(item -> {
					OrderItemDTO orderItemDTO = new OrderItemDTO();
					orderItemDTO.setOrderItemId(item.getId());
					System.out.println("Printing Order Item Price ID" + orderItemDTO.getOrderItemId());
					orderItemDTO.setItemId(item.getItemId());
					System.out.println("Printing Item Rate ID" + orderItemDTO.getItemId());
					if (item.getItemRate()!=null) {
						orderItemDTO.setItemRate(item.getItemRate());
					}
					System.out.println("Printing Item Rate" + orderItemDTO.getItemRate());
					orderItemDTO.setQuantity(item.getQuantity());
					orderItemDTO.setUnitId(item.getUnitId());
					orderItemDTO.setAmount(item.getAmount());
					orderItemDTO.setComments(item.getComments());
					OrderItemDBDTOs.add(orderItemDTO);
				});
				
				
				OrderDTO orderDTO = new OrderDTO();;
				orderDTO.setId(order.getId());
				orderDTO.setInstitutionId(order.getInstitutionId());
				orderDTO.setMonthOfPurchase(order.getMonthOfPurchase());
				orderDTO.setInstallmentNumber(order.getInstallmentNumber());
				orderDTO.setTotal(order.getTotal());
				orderDTO.setProfitMargin(order.getProfitMargin());
				orderDTO.setTotalAmount(order.getTotalAmount());
				orderDTO.setStartDate(dateformate.format(order.getStartDate()));
				
				//List<ItemDTO> itemList = new ArrayList<ItemDTO>();
				//List<Item> ItemEntityList = itemRepository.findAll();
				Map<Long, String> itemNames = new HashMap<>();
				List<Item> ItemEntityList = itemRepository.findAllByOrderByItemPhaseId();
				ItemEntityList.forEach(item -> {
				//	String phaseName = item.getItemRatePhaseName();
					OrderItemDTO orderItemDTO = new OrderItemDTO();
					orderItemDTO.setItemId(item.getItemId());
					orderItemDTO.setItemIdDB(item.getItemId());
				//	itemPriceDTO.setPhaseNameDB(item.getPhaseName());
					orderItemDTO.setPhaseIdDB(item.getItemPhaseId());
					orderItemDTO.setItemNameDB(item.getItemName());
					orderDTO.add(orderItemDTO);
					itemNames.put(item.getItemId(), item.getItemName());
				//	ItemPriceDTO itemPhaseName = new ItemPriceDTO();
					//itemPhaseName.setItemNameDB(item.getItemRatePhaseName());
					
				

					

				}); 
				
				

				List<ItemPhaseDTO> itemRatePhaseList = populateOrderScreenService.findAllItemPhase();

				


				//List<ItemPriceDTO> ItemPriceDTOs = itemPriceCalculation.getItemPriceDTOs();
				//int sizeOfItemPriceArray1 = ItemPriceDTOs.size();

				

				
				int i = 0;
				for (OrderItemDTO orderItemDTO : orderDTO.getOrderItemDTOs()) {
					System.out.println("Printing index" + i);
					i = i + 1;
					System.out.println("Iterating through Bean Collection" + orderItemDTO.getItemId() + "::::"
							+ orderItemDTO.getItemIdDB() + ":::" + orderItemDTO.getItemRate());

				}

				for (OrderItem orderItem : orderItemEntityList) {

					long selectedRateId = orderItem.getItemId();
					System.out.println("Printing Selected Rate Id from DataBase" + selectedRateId);
					int tableIndex = 0;

					// ItemRateEntityList.forEach(item-> {
					for (Item item : ItemEntityList) {

						if (item.getItemId() == selectedRateId) {
							break;

						}
						tableIndex = tableIndex + 1;

						System.out.println("Printing Item Rate Index" + tableIndex);
					}

					// });

					
					if (tableIndex >=0 && tableIndex < ItemEntityList.size()) {
						OrderItemDTO OrderItemDTO = orderDTO.getOrderItemDTOs().get(tableIndex);

					System.out.println("Printing Corresponding Rate Id from Bean " + OrderItemDTO.getItemIdDB());
					System.out.println(
							"Printing Corresponding Rate Id from Bean Befroe updating " + OrderItemDTO.getItemId());
					OrderItemDTO.setItemId(orderItem.getItemId());
					System.out.println(
							"Printing Corresponding Rate Id from Bean After updating " + OrderItemDTO.getItemId());
				
					OrderItemDTO.setItemRate(orderItem.getItemRate());
					OrderItemDTO.setQuantity(orderItem.getQuantity());
					OrderItemDTO.setAmount(orderItem.getAmount());
					OrderItemDTO.setUnitId(orderItem.getUnitId());
					OrderItemDTO.setComments(orderItem.getComments());
					}
				}
				System.out.println("Mappings of itemNames hm1 are : "
                        + itemNames);

				List<ItemPhaseDTO> itemPhaseList = populateOrderScreenService.findAllItemPhase();
				model.addAttribute("itemPhaseList", itemPhaseList);
				model.addAttribute("orderDTO", orderDTO);
				//model.addAttribute("orderDTO", orderDTO);
				model.addAttribute("itemNames", itemNames);
				List<UnitDTO> units = populateOrderScreenService.findAllUnits();
				model.addAttribute("units", units);
				populateDropDowns(model);

			 
			 return"editorderclient";
		 
		 }
		 
	 
	 @PostMapping("/saveeditorderclient")
		public String saveEditOrderClient(@ModelAttribute("orderDTO") OrderDTO orderDTO,
				BindingResult bindingResult, @RequestParam("Id") Long orderId, HttpServletRequest request, Model model, RedirectAttributes redirectAttributes) {
		 
	/*	 if (bindingResult.hasErrors()) {
				System.out.println("Error block");
				System.out.println("printing error count" + bindingResult.getErrorCount());
				Map<String, Object> errorMessages = new HashMap();
				if (bindingResult.hasErrors()) {

					List<FieldError> fes = bindingResult.getFieldErrors();
					for (FieldError fe : fes) {
						errorMessages.put(fe.getField(), fe.getDefaultMessage());
					}

				}
				// model.addAttribute("orderDTO", orderDTO); 
				 redirectAttributes.addAttribute("error", "true");
				redirectAttributes.addAttribute("orderId", orderDTO.getId());
				redirectAttributes.addFlashAttribute("errorMessages", errorMessages);
				redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.orderDTO",bindingResult);
				redirectAttributes.addFlashAttribute("orderDTO", orderDTO);
				
				return "redirect:/showeditorderclient";

			}
			*/
		 
		 DecimalFormat df = new DecimalFormat("0.00");
		 Order orderEntity = orderRepository.findById(orderId);
		 List<OrderItem> orderItems = orderEntity.getOrderitems();
		// orderItemRepository.deleteAll(orderItems);
		 populateOrderScreenService.deleteOrderItems(orderId);
		 
		 List<Item> ItemEntityList = itemRepository.findAllByOrderByItemPhaseId();
		 
		 List<OrderItemDTO> orderItemDTOs = orderDTO.getOrderItemDTOs();
		 
			Double orderTotal = 0.0;
			for (int i=0;i<orderItemDTOs.size();i++) {
			//for (OrderItemDTO orderItemDTO : orderItemDTOs) {
				OrderItemDTO orderItemDTO = orderItemDTOs.get(i);
				Item item = ItemEntityList.get(i);
				Double itemAmount = 0.0;
				if (orderItemDTO.getQuantity() != null) {
					System.out.println("Printing Rate Item Id" + orderItemDTO.getItemId());
					OrderItem orderItem = new OrderItem();
					orderItem.setItemId(item.getItemId());
					orderItem.setQuantity(orderItemDTO.getQuantity());
					orderItem.setUnitId(orderItemDTO.getUnitId());
					orderItem.setComments(orderItemDTO.getComments());
					if (orderItemDTO.getItemRate()!=null) {
						Double itemRate = orderItemDTO.getItemRate();
					Double quantity = orderItemDTO.getQuantity();
				
					
					
					System.out.println("Printing Rate " + itemRate);
				
					
					
					orderItem.setQuantity(orderItemDTO.getQuantity());
				
					orderItem.setItemRate(orderItemDTO.getItemRate());
					
					orderItem.setUnitId(orderItemDTO.getUnitId());
					
					orderItem.setComments(orderItemDTO.getComments());
					
					System.out.println("Printing Quantity " + quantity);
					
					itemAmount = quantity * itemRate;
					System.out.println("Printing Amount " + itemAmount);
					orderItem.setAmount(itemAmount);
				}
					orderItem.setOrder(orderEntity);
					orderItemRepository.save(orderItem);
					orderTotal = orderTotal+itemAmount;
			
			}
			}
		 
			List<Long> orderIds = new ArrayList<Long>();
			orderIds.add(orderEntity.getId());
			orderEntity.setMonthOfPurchase(orderDTO.getMonthOfPurchase());
			orderEntity.setInstallmentNumber(orderDTO.getInstallmentNumber());
			
			orderEntity.setTotal(Double.parseDouble(df.format(orderTotal)));
		
			
			orderEntity.setProfitMargin(orderDTO.getProfitMargin());
		
			orderRepository.save(orderEntity);
			
			List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIds);
			List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIds);
			
			OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
			
			model.addAttribute("orderId", orderMasterDTO.getOrderId());
			model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
			model.addAttribute("OrderDate", orderMasterDTO.getStartDate());
			model.addAttribute("monthOfPurchase", orderMasterDTO.getMonthOfPurchase());
			model.addAttribute("installmentNumber", orderMasterDTO.getInstallmentNumber());
			model.addAttribute("orderTotal", orderMasterDTO.getTotal());
			model.addAttribute("profitmargin", orderMasterDTO.getProfitMargin());
			model.addAttribute("orderGrandTotal", orderMasterDTO.getTotalAmount());
			model.addAttribute("orderdetails", orderdetails);
			
			
			
		 
		 return "saveeditordersuccessclient";
		 
	 
	 }


	 
	 @GetMapping("/showallactiveorderforedit")
		public String showAllActiveOrderForEdit(Model model, HttpServletRequest request) throws Exception {

			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrders();
			model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
			
			return "showallactiveorderforedit";
		}

	 
	 @GetMapping("/showeditorder/{orderId}")
	 public String showEditOrder(@PathVariable("orderId") long orderId, HttpServletResponse response,
				HttpServletRequest request, Model model) throws Exception {
		 
		 	Long orderID = orderId;
		 	
		 Order order = orderRepository.findById(orderID);
			
		 SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		 
			
			List<OrderItemDTO> OrderItemDBDTOs = new ArrayList<OrderItemDTO>();
			List<OrderItem> orderItemEntityList = order.getOrderitems();
			orderItemEntityList.forEach(item -> {
				OrderItemDTO orderItemDTO = new OrderItemDTO();
				orderItemDTO.setOrderItemId(item.getId());
				System.out.println("Printing Order Item Price ID" + orderItemDTO.getOrderItemId());
				orderItemDTO.setItemId(item.getItemId());
				System.out.println("Printing Item Rate ID" + orderItemDTO.getItemId());
				if (item.getItemRate()!=null) {
					orderItemDTO.setItemRate(item.getItemRate());
				}
				System.out.println("Printing Item Rate" + orderItemDTO.getItemRate());
				orderItemDTO.setQuantity(item.getQuantity());
				orderItemDTO.setAmount(item.getAmount());
				OrderItemDBDTOs.add(orderItemDTO);
			});
			
			
			OrderDTO orderDTO = new OrderDTO();;
			orderDTO.setId(order.getId());
			orderDTO.setInstitutionId(order.getInstitutionId());
			orderDTO.setInstallmentNumber(order.getInstallmentNumber());
			orderDTO.setTotal(order.getTotal());
			orderDTO.setProfitMargin(order.getProfitMargin());
			orderDTO.setTotalAmount(order.getTotalAmount());
			orderDTO.setStartDate(dateformate.format(order.getStartDate()));
			
			//List<ItemDTO> itemList = new ArrayList<ItemDTO>();
			List<Item> ItemEntityList = itemRepository.findAll();
			ItemEntityList.forEach(item -> {
			//	String phaseName = item.getItemRatePhaseName();
				OrderItemDTO orderItemDTO = new OrderItemDTO();
				orderItemDTO.setItemIdDB(item.getItemId());
			//	itemPriceDTO.setPhaseNameDB(item.getPhaseName());
				orderItemDTO.setPhaseIdDB(item.getItemPhaseId());
				orderItemDTO.setItemNameDB(item.getItemName());
				
				orderDTO.add(orderItemDTO);
			//	ItemPriceDTO itemPhaseName = new ItemPriceDTO();
				//itemPhaseName.setItemNameDB(item.getItemRatePhaseName());
				
			

				

			}); 
			
			

			List<ItemPhaseDTO> itemRatePhaseList = populateOrderScreenService.findAllItemPhase();

			


			//List<ItemPriceDTO> ItemPriceDTOs = itemPriceCalculation.getItemPriceDTOs();
			//int sizeOfItemPriceArray1 = ItemPriceDTOs.size();

			

			
			int i = 0;
			for (OrderItemDTO orderItemDTO : orderDTO.getOrderItemDTOs()) {
				System.out.println("Printing index" + i);
				i = i + 1;
				System.out.println("Iterating through Bean Collection" + orderItemDTO.getItemId() + "::::"
						+ orderItemDTO.getItemIdDB() + ":::" + orderItemDTO.getItemRate());

			}

			for (OrderItemDTO orderItemDTO : OrderItemDBDTOs) {

				long selectedRateId = orderItemDTO.getItemId();
				System.out.println("Printing Selected Rate Id from DataBase" + selectedRateId);
				int tableIndex = 0;

				// ItemRateEntityList.forEach(item-> {
				for (Item item : ItemEntityList) {

					if (item.getItemId() == selectedRateId) {
						break;

					}
					tableIndex = tableIndex + 1;

					System.out.println("Printing Item Rate Index" + tableIndex);
				}

				// });

				
				if (tableIndex >=0 && tableIndex < ItemEntityList.size()) {
					OrderItemDTO OrderItemDTO = orderDTO.getOrderItemDTOs().get(tableIndex);

				System.out.println("Printing Corresponding Rate Id from Bean " + OrderItemDTO.getItemIdDB());
				System.out.println(
						"Printing Corresponding Rate Id from Bean Befroe updating " + OrderItemDTO.getItemId());
				OrderItemDTO.setItemId(orderItemDTO.getItemId());
				System.out.println(
						"Printing Corresponding Rate Id from Bean After updating " + OrderItemDTO.getItemId());
			
				OrderItemDTO.setItemRate(orderItemDTO.getItemRate());
				OrderItemDTO.setQuantity(orderItemDTO.getQuantity());
				OrderItemDTO.setAmount(orderItemDTO.getAmount());
				}
			}
			
			List<ItemPhaseDTO> itemPhaseList = populateOrderScreenService.findAllItemPhase();
			model.addAttribute("itemPhaseList", itemPhaseList);
			model.addAttribute("orderDTO", orderDTO);
			model.addAttribute("orderDTO", orderDTO);

			populateDropDowns(model);

		 
		 return"editorder";
	 
	 }
	 
	 
	 @PostMapping("/saveeditorder")
		public String saveEditOrder(@ModelAttribute("orderDTO") OrderDTO orderDTO,
				BindingResult bindingResult, @RequestParam("Id") Long orderId, HttpServletRequest request, Model model, RedirectAttributes redirectAttributes) {
		 DecimalFormat df = new DecimalFormat("0.00");
		 Order orderEntity = orderRepository.findById(orderId);
		 List<OrderItem> orderItems = orderEntity.getOrderitems();
		// orderItemRepository.deleteAll(orderItems);
		 populateOrderScreenService.deleteOrderItems(orderId);
		 
		 List<Item> ItemEntityList = itemRepository.findAllByOrderByItemPhaseId();
		 
		 List<OrderItemDTO> orderItemDTOs = orderDTO.getOrderItemDTOs();
		 
			Double orderTotal = 0.0;
			for (int i=0;i<orderItemDTOs.size();i++) {
			//for (OrderItemDTO orderItemDTO : orderItemDTOs) {
				OrderItemDTO orderItemDTO = orderItemDTOs.get(i);
				Item item = ItemEntityList.get(i);
				Double itemAmount = 0.0;
				if (orderItemDTO.getQuantity() != null) {
					System.out.println("Printing Rate Item Id" + orderItemDTO.getItemId());
					OrderItem orderItem = new OrderItem();
					orderItem.setItemId(item.getItemId());
					orderItem.setQuantity(orderItemDTO.getQuantity());

					if (orderItemDTO.getItemRate()!=null) {
						Double itemRate = orderItemDTO.getItemRate();
					Double quantity = orderItemDTO.getQuantity();
				
					
					
					System.out.println("Printing Rate " + itemRate);
				
					
					
					orderItem.setQuantity(orderItemDTO.getQuantity());
				
					orderItem.setItemRate(orderItemDTO.getItemRate());
					
					System.out.println("Printing Quantity " + quantity);
					
					itemAmount = quantity * itemRate;
					System.out.println("Printing Amount " + itemAmount);
					orderItem.setAmount(itemAmount);
				}
					orderItem.setOrder(orderEntity);
					orderItemRepository.save(orderItem);
					orderTotal = orderTotal+itemAmount;
			
			}
			}
		 
			List<Long> orderIds = new ArrayList<Long>();
			orderIds.add(orderEntity.getId());
			orderEntity.setInstallmentNumber(orderDTO.getInstallmentNumber());
			
			orderEntity.setTotal(Double.parseDouble(df.format(orderTotal)));
			Double profitMargin = orderEntity.getProfitMargin();
			Double profit = 0.0;
			if (orderTotal != null && profitMargin != null) {
				profit = profitMargin/100*orderTotal;
			}
			
			orderEntity.setProfitMargin(orderDTO.getProfitMargin());
			orderEntity.setTotalAmount(Double.parseDouble(df.format(orderTotal + profit)));
			orderRepository.save(orderEntity);
			
			List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIds);
			List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIds);
			
			OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
			
			model.addAttribute("orderId", orderMasterDTO.getOrderId());
			model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
			model.addAttribute("OrderDate", orderMasterDTO.getStartDate());
			model.addAttribute("installmentNumber", orderMasterDTO.getInstallmentNumber());
			model.addAttribute("orderTotal", orderMasterDTO.getTotal());
			model.addAttribute("profitmargin", orderMasterDTO.getProfitMargin());
			model.addAttribute("orderGrandTotal", orderMasterDTO.getTotalAmount());
			model.addAttribute("orderdetails", orderdetails);
			
			
			
		 
		 return "saveeditordersuccess";
		 
	 
	 }
	 
	 
	 @GetMapping("/showallcompleteordersbyinstitution")
		public String showAllCompleteOrdersByInstitution(Model model, HttpServletRequest request,Authentication authentication) throws Exception {
		 	Integer institutionId = null;
			System.out.println("Printing from welcome");
			  if (authentication != null) {
		          User user = (User) authentication.getPrincipal();
		            String role = user.getAuthorities().toString();
		            String userName = user.getUsername();
		            System.out.println("Printing User Name" + userName);
		            GroceryUser groceryUser = userService.findByEmail(userName);
		            institutionId = groceryUser.getInstitutionId();
			  }
			  
			  List<Integer> institutionIds = new ArrayList<Integer>();
			  institutionIds.add(institutionId);
			//List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllCompleteOrdersByInstitution(institutionIds);
			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService.findClosedPurchaseOrderByInstitutionId(institutionId);
			model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
			
			return "showallcompleteordersbyinstitution";
		}
	 
	 
	 @GetMapping("/showcompleteorderclient/{orderId}")
	 public String showCompleteOrderClient(@PathVariable("orderId") long orderId, HttpServletResponse response,
				HttpServletRequest request, Model model) throws Exception {
		 
		 	Long orderID = orderId;
		 	
		 Order orderEntity = orderRepository.findById(orderID);

		List<Long> orderIds = new ArrayList<Long>();
	     orderIds.add(orderEntity.getId());
		//List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIds);
		List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findClosedOrderItemDetails(orderIds);
		
		OrderItemDetailDTO orderMasterDTO = orderdetails.get(0);
		
		model.addAttribute("orderId", orderMasterDTO.getOrderId());
		model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
		model.addAttribute("OrderDate", orderMasterDTO.getStartDate());
		model.addAttribute("monthOfPurchase", orderMasterDTO.getMonthOfPurchase());
		model.addAttribute("installmentNumber", orderMasterDTO.getInstallmentNumber());
		model.addAttribute("orderTotal", orderMasterDTO.getTotal());
		model.addAttribute("profitmargin", orderMasterDTO.getProfitMargin());
		model.addAttribute("orderGrandTotal", orderMasterDTO.getTotalAmount());
		model.addAttribute("orderdetails", orderdetails);
		 return "showcompleteclientorder";
		 
		 }
	 
	 
	 @GetMapping("/showallorderforcreatingquotationorder")

		public String showallorderforcreatingquotationorder(Model model) throws Exception {
			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrderForCreatingQuotationOrder();
				model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
				
				

				OrderCollectionDTO orderIdsForCreatingQuotationOrder = new OrderCollectionDTO();
			model.addAttribute("orderIdsForCreatingQuotationOrder", orderIdsForCreatingQuotationOrder);

			return "showallorderforcreatingquotationorder";
		}
	 
	 
	 @PostMapping("/createquotationorder")
	 public String createQuotationOrder(@ModelAttribute("orderIdsForCreatingPurchaseOrder") OrderCollectionDTO orderCollectionDTO,Model model) throws Exception {
		 List<Item> purchaseItemList = itemRepository.findAllByOrderByItemPhaseId();
		 
		 
		 
		 Long[] orderIDs = orderCollectionDTO.getOrderIds();
		 System.out.println("Printing Selected Order ids" + orderIDs);
		 List<Long> orderIds= new ArrayList<Long>();
		 for (int i = 0; i < orderIDs.length; i++) {
			 System.out.println("Printing id" +orderIDs[i] );
			 orderIds.add(orderIDs[i]);
		 }
		 System.out.println("Printing Selected Order ids" + orderIds);
		
		 
		 Set<Order> orders = new HashSet<>();
		 
		 		 
		 for (Long orderId : orderIds) {
			 Order orderEntity = orderRepository.findById(orderId);
			 orders.add(orderEntity);
			}
		 
		 
		 LocalDate currentDate = LocalDate.now();

	        // Get the start and end of the current month
	        YearMonth currentMonth = YearMonth.from(currentDate);
	        LocalDate startOfMonth = currentMonth.atDay(1); // First day of the current month
	        LocalDate endOfMonth = currentMonth.atEndOfMonth(); // Last day of the current month

	        // Define your custom date ranges within the current month
	        LocalDate startDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1); // First start date
	        LocalDate endDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 15); // First end date

	        LocalDate startDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 16); // Second start date
	        
	        YearMonth yearMonth = YearMonth.from(currentDate);
	        int daysInCurrentMonth = yearMonth.lengthOfMonth();
	        
	        LocalDate endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), daysInCurrentMonth); // First end date
	        

        // Define the variable to populate
        String result = "";
        String installmentNo= null;
        String monthOfPurchase=null;
        // Check if the current date is between the first range
        if (!currentDate.isBefore(startDate1) && !currentDate.isAfter(endDate1)) {
        	monthOfPurchase= LocalDate.now().getMonth().toString();
            
            result = "Value for first date range";
            installmentNo = "2nd Installment";
            
        }
        // Check if the current date is between the second range
        else if (!currentDate.isBefore(startDate2) && !currentDate.isAfter(endDate2)) {
        	LocalDate nextMonth = LocalDate.now().plusMonths(1);
            
            // Format next month to a string (e.g., "FEBRUARY")
            String nextMonthStr = nextMonth.getMonth().toString();
            monthOfPurchase = nextMonthStr;
            installmentNo = "Ist Installment";
            result = "Value for second date range";
        }
        // If the current date doesn't fall within any range
        else {
            result = "Date is not in any range";
            installmentNo = "0";
        }
		
		  
		//  List<PurchaseOrderItem> purchaseOrderItems = purchaseOrder.getPurchaseOrderItems();
		  List<OrderItemDetailDTO> orderItemDetailDTOs = populateOrderScreenService.findOrderItemDetails(orderIds);
		  Set<Long> itemIdsOfSelectedOrders = new HashSet<>();
		  for (OrderItemDetailDTO orderItem :orderItemDetailDTOs) {
			  itemIdsOfSelectedOrders.add(orderItem.getItemId());
		  }
		  
		  List<QuotationOrderItemDTO> quotationOrderItemDTOs = new ArrayList<QuotationOrderItemDTO>();
		  
		  for (Long itemId : itemIdsOfSelectedOrders) {
			  QuotationOrderItemDTO quotationOrderItemDTO = new QuotationOrderItemDTO();
			  quotationOrderItemDTO.setItemId(itemId);
			  quotationOrderItemDTOs.add(quotationOrderItemDTO);
		  }
		 
		/* purchaseItemList.forEach(item -> {

				PurchaseOrderItem purchaseOrderItem = new PurchaseOrderItem();
			//	purchaseOrderItemDTO.setItemIdDB(item.getItemId());
			//	purchaseOrderItemDTO.setPhaseIdDB(item.getItemPhaseId());
			//	purchaseOrderItemDTO.setItemNameDB(item.getItemName());
				purchaseOrderItem.setItemId(item.getItemId());
			//	purchaseOrderItem.setItemRate(item.getItemRate());
				purchaseOrder.add(purchaseOrderItem);
				

			}); 
			*/
		 
		 
		
		 for (OrderItemDetailDTO orderItem :orderItemDetailDTOs) {
			 
			// System.out.println("Printing order item Record" + orderItem.toString());
			 for ( QuotationOrderItemDTO quotationOrderItemDTO :quotationOrderItemDTOs) {
				// System.out.println("Printing Purchase order item Record" + purchaseOrderItem.toString());
				 
				 if (orderItem.getItemId() == quotationOrderItemDTO.getItemId()) {
					 System.out.println("OrderItem Quantity" + orderItem.getQuantity());
					 System.out.println("Quotation Order item Quantity" + quotationOrderItemDTO.getQuantity());
					 
					 if (orderItem.getQuantity()!=null) {
						 
						 if (quotationOrderItemDTO.getQuantity()!=null) {
							 quotationOrderItemDTO.setQuantity(quotationOrderItemDTO.getQuantity() + orderItem.getQuantity());
							 quotationOrderItemDTO.setUnitId(orderItem.getUnitId());
					 } else {
						 quotationOrderItemDTO.setQuantity(orderItem.getQuantity());
						 quotationOrderItemDTO.setUnitId(orderItem.getUnitId());
					 }
					 }
					 System.out.println("OrderItem Quantity" + orderItem.getQuantity());
					 System.out.println("Quotation Order item Quantity" + quotationOrderItemDTO.getQuantity());
					// purchaseOrderItem.setPurchaseOrder(purchaseOrder);
					// purchaseOrderItemRepository.save(purchaseOrderItem);
				 }
			 }
			 
			 
			/* for ( PurchaseOrderItemDTO purchaseOrderItemDTO :purchaseOrderItemDTOs) {
				 System.out.println("Printing Purchase order item Record" + purchaseOrderItem.toString());
				 if (purchaseOrderItem.getQuantity().equals(orderItemDetailDTOs)) {
					 System.out.println("Printing purchase order item quantity"+ purchaseOrderItem.getQuantity());
					purchaseOrderItem.setPurchaseOrder(purchaseOrder);
				     purchaseOrderItemRepository.save(purchaseOrderItem);
					 
				 }
			 } */
		 }
		 


		 List<DepartmentDTO> supplierList = populateOrderScreenService.findAllValidDepartments();
		 
		 List<Long> quotationIds = new ArrayList<Long>();
		  QuotationOrder quotationOrder = null;
		 
		 for (DepartmentDTO supplier : supplierList) {
			 
			  quotationOrder =  new QuotationOrder();
			  quotationOrder.setStartDate(new Date());
			  quotationOrder.setOrders(orders);
			  quotationOrder.setDepartmentId(supplier.getDepartmentId());
			  quotationOrder.setMonthOfPurchase(monthOfPurchase);
			  quotationOrder.setInstallmentNumber(installmentNo);
			
				 
				
				 QuotationOrder qo = quotationOrderRepository.save(quotationOrder);
				 System.out.println("Printing Quotation Id" + qo.getId());
				 Long quotationId = qo.getId();
				 quotationIds.add(quotationId);		
				

				 
				 for ( QuotationOrderItemDTO quotationOrderItemDTO :quotationOrderItemDTOs) {
					 System.out.println("Printing Quotation Order Item Id and Quantity" + quotationOrderItemDTO.getItemId() + ":::::" + quotationOrderItemDTO.getQuantity());
					 QuotationOrderItem quotationOrderItem = new QuotationOrderItem();
						
					 quotationOrderItem.setItemId(quotationOrderItemDTO.getItemId());
					 quotationOrderItem.setQuantity(quotationOrderItemDTO.getQuantity());
					 quotationOrderItem.setUnitId(quotationOrderItemDTO.getUnitId());
					 quotationOrderItem.setQuotationOrder(quotationOrder);
					 quotationOrderItem.setDepartmentId(Long.parseLong("1"));
					 quotationOrderItemRepository.save(quotationOrderItem);
							//purchaseOrder.add(purchaseOrderItem);
							
					 
				 }
				 quotationOrderRepository.save(quotationOrder);
				 
			 
			 
		 }
		 
		
		 for (Long item : quotationIds) {
			 System.out.println("Printing Quotation Ids" + item.toString());
		 }

		


for (Long orderId : orderIds) {
	 Order orderEntity = orderRepository.findById(orderId);
	 orderEntity.setQuotationOrderCreated("yes");
	 orderRepository.save(orderEntity);
	}

List<QuotationOrderItemDTO> quotationList = new ArrayList<QuotationOrderItemDTO>();

for (Long quotationId : quotationIds)
	
{
	QuotationOrder qo = quotationOrderRepository.findById(quotationId);
	QuotationOrderItemDTO QuotationOrderItemDTO = new QuotationOrderItemDTO();
	QuotationOrderItemDTO.setQuotationId(qo.getId());
	Department dt = departmentRepository.findByDepartmentId(qo.getDepartmentId());
	QuotationOrderItemDTO.setDepartmentName(dt.getDepartmentName());
	quotationList.add(QuotationOrderItemDTO);
	
}

List items = new ArrayList<>();

for (Long item : quotationIds) {
	 System.out.println("Printing Quotation Ids" + item.toString());
	 List<Long> quotationId= new ArrayList<Long>();
	 quotationId.add(item);
	 List<QuotationOrderItemDetailDTO> quotationOrderdetails = populateOrderScreenService.findQuotationOrderItemDetails(quotationId);
	 items.add(quotationOrderdetails);
}

model.addAttribute("items", items);

model.addAttribute("quotationList", quotationList);

//List<QuotationOrderItemDetailDTO> quotationOrderdetails = populateOrderScreenService.findQuotationOrderItemDetails(quotationOrderIds);

//return "savequotationordersuccessdisplaysupplierwisequotations";

return "supplierwisequotationrequest";
		
		 
		// Long purchaseOrderId = purchaseOrder.getId();

/*
		 List<Long> quotationOrderIds= new ArrayList<Long>();
		 quotationOrderIds.add(purchaseOrderId);
		 
		 List<QuotationOrderItemDetailDTO> quotationOrderdetails = populateOrderScreenService.findQuotationOrderItemDetails(quotationOrderIds);
		 System.out.println("Prinitng quotationOrderdetails size"+ quotationOrderdetails.size());
		 QuotationOrderItemDetailDTO quotationOrderdetail =quotationOrderdetails.get(0);
		 			model.addAttribute("quotationOrderId", quotationOrderdetail.getQuotationOrderId());
		 			model.addAttribute("orderDate", quotationOrderdetail.getStartDate());
					model.addAttribute("installmentNumber", quotationOrderdetail.getInstallmentNumber());
					model.addAttribute("orderTotal", quotationOrderdetail.getTotal());
					model.addAttribute("profitmargin", quotationOrderdetail.getProfitMargin());
					model.addAttribute("orderGrandTotal", quotationOrderdetail.getTotalAmount());
					model.addAttribute("quotationOrderdetails", quotationOrderdetails);
					*/
		 
		// return "savequotationordersuccess";
	 }
	 
	 
	 @GetMapping("/showallactivequotationrequestreport")
		 public String showAllActiveQuotation(Model model) throws Exception {
		 LocalDate currentDate = LocalDate.now();

	        // Get the start and end of the current month
	        YearMonth currentMonth = YearMonth.from(currentDate);
	        LocalDate startOfMonth = currentMonth.atDay(1); // First day of the current month
	        LocalDate endOfMonth = currentMonth.atEndOfMonth(); // Last day of the current month

	        // Define your custom date ranges within the current month
	        LocalDate startDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1); // First start date
	        LocalDate endDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 15); // First end date

	        LocalDate startDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 16); // Second start date
	        
	        YearMonth yearMonth = YearMonth.from(currentDate);
	        int daysInCurrentMonth = yearMonth.lengthOfMonth();
	        
	        LocalDate endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), daysInCurrentMonth); // First end date

	        // Define the variable to populate
	        String result = "";
	        String installmentNo= null;
	        String monthOfPurchase=null;
	        int currentYear = currentDate.getYear();
	        // Check if the current date is between the first range
	        if (!currentDate.isBefore(startDate1) && !currentDate.isAfter(endDate1)) {
	        	monthOfPurchase= LocalDate.now().getMonth().toString();
	            
	            result = "Value for first date range";
	            installmentNo = "2nd Installment";
	            
	        }
	        // Check if the current date is between the second range
	        else if (!currentDate.isBefore(startDate2) && !currentDate.isAfter(endDate2)) {
	        	LocalDate nextMonth = LocalDate.now().plusMonths(1);
	            
	            // Format next month to a string (e.g., "FEBRUARY")
	            String nextMonthStr = nextMonth.getMonth().toString();
	            monthOfPurchase = nextMonthStr;
	            installmentNo = "Ist Installment";
	            result = "Value for second date range";
	        }
	        // If the current date doesn't fall within any range
	        else {
	            result = "Date is not in any range";
	            installmentNo = "0";
	        }
			
	        
	        System.out.println("Printing Month Of Purchase and Installment No" + monthOfPurchase + " Installment no" + installmentNo );
				List<OrderMasterDTO> quotations = populateOrderScreenService.findAllActiveQuotationOrder(currentYear,monthOfPurchase,installmentNo);
				OrderMasterDTO quotation = quotations.get(0);
				List<QuotationOrderItemDTO> quotationList = new ArrayList<QuotationOrderItemDTO>();

				for (OrderMasterDTO quotationId : quotations)
					
				{
					QuotationOrder qo = quotationOrderRepository.findById(Long.parseLong(quotationId.getOrderId()));
					QuotationOrderItemDTO QuotationOrderItemDTO = new QuotationOrderItemDTO();
					QuotationOrderItemDTO.setQuotationId(qo.getId());
					Department dt = departmentRepository.findByDepartmentId(qo.getDepartmentId());
					QuotationOrderItemDTO.setDepartmentName(dt.getDepartmentName());
					quotationList.add(QuotationOrderItemDTO);
					
				}
				model.addAttribute("OrderDate", quotation.getStartDate());
				model.addAttribute("monthOfPurchase", quotation.getMonthOfPurchase());
				model.addAttribute("installmentNumber", quotation.getInstallmentNumber());
				model.addAttribute("quotations", quotationList);
					model.addAttribute("quotationList", quotationList);
					
					

					//OrderCollectionDTO orderIdsForItemRateComparison = new OrderCollectionDTO();
				//model.addAttribute("orderIdsForItemRateComparison", orderIdsForItemRateComparison);

				return "showallactivequotationrequestreport";
			}
	 
	 
	 
	 @GetMapping("/downloadquotationrequest")
	 public String downloadQuotationRequest( HttpServletResponse response,
				HttpServletRequest request, Model model) throws Exception {
		 

         LocalDate currentDate = LocalDate.now();

	        // Get the start and end of the current month
	        YearMonth currentMonth = YearMonth.from(currentDate);
	        LocalDate startOfMonth = currentMonth.atDay(1); // First day of the current month
	        LocalDate endOfMonth = currentMonth.atEndOfMonth(); // Last day of the current month

	        // Define your custom date ranges within the current month
	        LocalDate startDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1); // First start date
	        LocalDate endDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 15); // First end date

	        LocalDate startDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 16); // Second start date
	        
	        YearMonth yearMonth = YearMonth.from(currentDate);
	        int daysInCurrentMonth = yearMonth.lengthOfMonth();
	        
	        LocalDate endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), daysInCurrentMonth); // First end date

	        // Define the variable to populate
	        String result = "";
	        String installmentNo= null;
	        String monthOfPurchase=null;
	        int currentYear = currentDate.getYear();
	        // Check if the current date is between the first range
	        if (!currentDate.isBefore(startDate1) && !currentDate.isAfter(endDate1)) {
	        	monthOfPurchase= LocalDate.now().getMonth().toString();
	            
	            result = "Value for first date range";
	            installmentNo = "2nd Installment";
	            
	        }
	        // Check if the current date is between the second range
	        else if (!currentDate.isBefore(startDate2) && !currentDate.isAfter(endDate2)) {
	        	LocalDate nextMonth = LocalDate.now().plusMonths(1);
	            
	            // Format next month to a string (e.g., "FEBRUARY")
	            String nextMonthStr = nextMonth.getMonth().toString();
	            monthOfPurchase = nextMonthStr;
	            installmentNo = "Ist Installment";
	            result = "Value for second date range";
	        }
	        // If the current date doesn't fall within any range
	        else {
	            result = "Date is not in any range";
	            installmentNo = "0";
	        }
			
	        
	        System.out.println("Printing Month Of Purchase and Installment No" + monthOfPurchase + " Installment no" + installmentNo );
				List<OrderMasterDTO> quotationIds = populateOrderScreenService.findAllActiveQuotationOrder(currentYear,monthOfPurchase,installmentNo);
				
				System.out.println("Printing the no of records returned from findAllActiveQuotationOrder" + quotationIds.size());
			
			
			List items = new ArrayList<>();

for (OrderMasterDTO item : quotationIds) {
	 System.out.println("Printing Quotation Ids" + item.toString());
	 List<Long> quotationId= new ArrayList<Long>();
	 quotationId.add(Long.valueOf(item.getOrderId()));
		
	 List<QuotationOrderItemDetailDTO> quotationOrderdetails = populateOrderScreenService.findQuotationOrderItemDetails(quotationId);
	 items.add(quotationOrderdetails);
}

model.addAttribute("items", items);



//List<QuotationOrderItemDetailDTO> quotationOrderdetails = populateOrderScreenService.findQuotationOrderItemDetails(quotationOrderIds);

//return "savequotationordersuccessdisplaysupplierwisequotations";

return "supplierwisequotationrequest";

		 
	 }
	 
	 
		@GetMapping("/downloadsupplierreport")
		public String downloadSupplierReport(HttpServletResponse response, HttpServletRequest request, Model model)
				throws Exception {

			LocalDate currentDate = LocalDate.now();

			// Get the start and end of the current month
			YearMonth currentMonth = YearMonth.from(currentDate);
			LocalDate startOfMonth = currentMonth.atDay(1); // First day of the current month
			LocalDate endOfMonth = currentMonth.atEndOfMonth(); // Last day of the current month

			// Define your custom date ranges within the current month
			LocalDate startDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1); // First start date
			LocalDate endDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 15); // First end date

			LocalDate startDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 16); // Second start date

			YearMonth yearMonth = YearMonth.from(currentDate);
			int daysInCurrentMonth = yearMonth.lengthOfMonth();

			LocalDate endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), daysInCurrentMonth); // First
																													// end
																													// date

			// Define the variable to populate
			String result = "";
			String installmentNo = null;
			String monthOfPurchase = null;
			int currentYear = currentDate.getYear();
			// Check if the current date is between the first range
			if (!currentDate.isBefore(startDate1) && !currentDate.isAfter(endDate1)) {
				monthOfPurchase = LocalDate.now().getMonth().toString();

				result = "Value for first date range";
				installmentNo = "2nd Installment";

			}
			// Check if the current date is between the second range
			else if (!currentDate.isBefore(startDate2) && !currentDate.isAfter(endDate2)) {
				LocalDate nextMonth = LocalDate.now().plusMonths(1);

				// Format next month to a string (e.g., "FEBRUARY")
				String nextMonthStr = nextMonth.getMonth().toString();
				monthOfPurchase = nextMonthStr;
				installmentNo = "Ist Installment";
				result = "Value for second date range";
			}
			// If the current date doesn't fall within any range
			else {
				result = "Date is not in any range";
				installmentNo = "0";
			}

			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService
					.findAllActivePurchaseOrders(currentYear, monthOfPurchase, installmentNo);

			OrderMasterDTO purchaseOrder = OrderItemDTOActiveList.get(0);

			List<Long> purchaseOrderIds = new ArrayList<Long>();
			purchaseOrderIds.add(Long.valueOf(purchaseOrder.getOrderId()));

			List<PurchaseOrderItemDetailDTO> purchaseOrderDetails = populateOrderScreenService
					.findPurchaseOrderItemDetails(purchaseOrderIds);
			Set<Long> supplierIds = new HashSet<>();
			for (PurchaseOrderItemDetailDTO orderItem : purchaseOrderDetails) {
				supplierIds.add(orderItem.getDepartmentId());
			}

			List items = new ArrayList<>();

			for (Long item : supplierIds) {
				System.out.println("Printing Quotation Ids" + item.toString());

				List<PurchaseOrderItemDetailDTO> purchaseOrderDetailsBySupplier = populateOrderScreenService
						.findPurchaseOrderItemDetailsBySupplierId(purchaseOrderIds, item);
				items.add(purchaseOrderDetailsBySupplier);
			}

			model.addAttribute("items", items);

			return "downloadsupplierreport";

		}
		
		
		@GetMapping("/downloadinstitutionreport")
		public String downloadInstitutionReport(HttpServletResponse response, HttpServletRequest request, Model model)
				throws Exception {

			LocalDate currentDate = LocalDate.now();

			// Get the start and end of the current month
			YearMonth currentMonth = YearMonth.from(currentDate);
			LocalDate startOfMonth = currentMonth.atDay(1); // First day of the current month
			LocalDate endOfMonth = currentMonth.atEndOfMonth(); // Last day of the current month

			// Define your custom date ranges within the current month
			LocalDate startDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1); // First start date
			LocalDate endDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 15); // First end date

			LocalDate startDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 16); // Second start date

			YearMonth yearMonth = YearMonth.from(currentDate);
			int daysInCurrentMonth = yearMonth.lengthOfMonth();

			LocalDate endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), daysInCurrentMonth); // First
																													// end
																													// date

			// Define the variable to populate
			String result = "";
			String installmentNo = null;
			String monthOfPurchase = null;
			int currentYear = currentDate.getYear();
			// Check if the current date is between the first range
			if (!currentDate.isBefore(startDate1) && !currentDate.isAfter(endDate1)) {
				monthOfPurchase = LocalDate.now().getMonth().toString();

				result = "Value for first date range";
				installmentNo = "2nd Installment";

			}
			// Check if the current date is between the second range
			else if (!currentDate.isBefore(startDate2) && !currentDate.isAfter(endDate2)) {
				LocalDate nextMonth = LocalDate.now().plusMonths(1);

				// Format next month to a string (e.g., "FEBRUARY")
				String nextMonthStr = nextMonth.getMonth().toString();
				monthOfPurchase = nextMonthStr;
				installmentNo = "Ist Installment";
				result = "Value for second date range";
			}
			// If the current date doesn't fall within any range
			else {
				result = "Date is not in any range";
				installmentNo = "0";
			}

			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService
					.findAllActivePurchaseOrders(currentYear, monthOfPurchase, installmentNo);

			OrderMasterDTO purchaseOrder = OrderItemDTOActiveList.get(0);

			List<Long> purchaseOrderIds = new ArrayList<Long>();
			purchaseOrderIds.add(Long.valueOf(purchaseOrder.getOrderId()));

			List<PurchaseOrderItemDetailDTO> purchaseOrderDetails = populateOrderScreenService
					.findPurchaseOrderItemDetails(purchaseOrderIds);
			Set<Long> institutionIds = new HashSet<>();
			for (PurchaseOrderItemDetailDTO orderItem : purchaseOrderDetails) {
				institutionIds.add(orderItem.getInstitutionId());
				System.out.println("Printing Institution Ids" + orderItem.getInstitutionId());
			}

			List items = new ArrayList<>();

			for (Long item : institutionIds) {
				System.out.println("Printing Institution Ids" + item.toString());

				List<PurchaseOrderItemDetailDTO> purchaseOrderDetailsByInstitution = populateOrderScreenService
						.findPurchaseOrderItemDetailsByInstitutionId(purchaseOrderIds, item);
				System.out.println("Printing No of records from Institution Report" + purchaseOrderDetailsByInstitution.size());
				items.add(purchaseOrderDetailsByInstitution);
			}

			model.addAttribute("items", items);

			return "downloadinstituionreport";

		}
	 
		
		
		 @GetMapping("/showitemreport")
		 public String showitemreport(Model model, HttpServletRequest request) throws Exception {
		 
		 
		 			LocalDate currentDate = LocalDate.now();

				// Get the start and end of the current month
				YearMonth currentMonth = YearMonth.from(currentDate);
				LocalDate startOfMonth = currentMonth.atDay(1); // First day of the current month
				LocalDate endOfMonth = currentMonth.atEndOfMonth(); // Last day of the current month

				// Define your custom date ranges within the current month
				LocalDate startDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1); // First start date
				LocalDate endDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 15); // First end date

				LocalDate startDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 16); // Second start date

				YearMonth yearMonth = YearMonth.from(currentDate);
				int daysInCurrentMonth = yearMonth.lengthOfMonth();

				LocalDate endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), daysInCurrentMonth); // First
																														// end
																														// date

				// Define the variable to populate
				String result = "";
				String installmentNo = null;
				String monthOfPurchase = null;
				int currentYear = currentDate.getYear();
				// Check if the current date is between the first range
				if (!currentDate.isBefore(startDate1) && !currentDate.isAfter(endDate1)) {
					monthOfPurchase = LocalDate.now().getMonth().toString();

					result = "Value for first date range";
					installmentNo = "2nd Installment";

				}
				// Check if the current date is between the second range
				else if (!currentDate.isBefore(startDate2) && !currentDate.isAfter(endDate2)) {
					LocalDate nextMonth = LocalDate.now().plusMonths(1);

					// Format next month to a string (e.g., "FEBRUARY")
					String nextMonthStr = nextMonth.getMonth().toString();
					monthOfPurchase = nextMonthStr;
					installmentNo = "Ist Installment";
					result = "Value for second date range";
				}
				// If the current date doesn't fall within any range
				else {
					result = "Date is not in any range";
					installmentNo = "0";
				}

				List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService
						.findAllActivePurchaseOrders(currentYear, monthOfPurchase, installmentNo);

				OrderMasterDTO purchaseOrder = OrderItemDTOActiveList.get(0);

				List<Long> purchaseOrderIds = new ArrayList<Long>();
				purchaseOrderIds.add(Long.valueOf(purchaseOrder.getOrderId()));
				
			 PurchaseOrder purchaseOrderEntity = purchaseOrderRepository.findById(Long.valueOf(purchaseOrder.getOrderId()));
			 List<PurchaseOrderItem> purchaseOrderItems = purchaseOrderEntity.getPurchaseOrderItems();
			 Set<Order> orders = purchaseOrderEntity.getOrders();
			 
				
			 	 List<Long> orderIds= new ArrayList<Long>();
				 
			 for (Order order: orders) {
				 orderIds.add(order.getId());
				 
			 }
			 List<Order> orderList = new ArrayList<>(orders);
			 
			 List<PurchaseOrderItemDetailDTO> purchaseOrderDetails = populateOrderScreenService
						.findPurchaseOrderItemDetails(purchaseOrderIds);
			 
			// List<OrderItemDetailDTO> orderItemDetailDTOs = populateOrderScreenService.findOrderItemDetails(orderIds);
			 Map<String, ItemReportDTO> reportMap = new HashMap<>();

		        // Process each order
		        for (PurchaseOrderItemDetailDTO orderItem : purchaseOrderDetails) {
		        	System.out.println("Printing Order Item " + " -> Institution Name" + orderItem.getInstitutionName()+" -> Item Name" + orderItem.getItemName()+" -> Item Quantity" + orderItem.getQuantity());
		            reportMap.putIfAbsent(orderItem.getItemName(), new ItemReportDTO());
		            ItemReportDTO report = reportMap.get(orderItem.getItemName());

		            report.setItemName(orderItem.getItemName());
		            if (report.getInstitutionQuantities() == null) {
		                report.setInstitutionQuantities(new HashMap<>());
		            }

		            report.getInstitutionQuantities().putIfAbsent(orderItem.getInstitutionName(), 0.0);
		           // report.getInstitutionQuantities().put(orderItem.getInstitutionName(),
		                 //   report.getInstitutionQuantities().get(orderItem.getInstitutionName()) + orderItem.getQuantity());
		       
		            report.getInstitutionQuantities().put(orderItem.getInstitutionName(),
	                 orderItem.getQuantity());
		            
		            System.out.println("Printing Insistution wise Item Quantity for Item " +report.getItemName() + "And for Institution " + orderItem.getInstitutionName()+ + report.getInstitutionQuantities().get(orderItem.getInstitutionName()));
		           
		          // report.getInstitutionQuantities().forEach( (k, v) -> { System.out.println(k + " -> " + v);
		           }

		        // Calculate total quantities
		        
		        List<ItemReportDTO> reportDTOs = new ArrayList<ItemReportDTO>();
		        
		        System.out.println("Printing reportMap.values()" + reportMap.values());;
		        for (ItemReportDTO report : reportMap.values()) {
		        	
		        	System.out.println("Printing Item Report Details"  + report.getInstitutionQuantities());
		            Double total = report.getInstitutionQuantities().values().stream().mapToDouble(Double::doubleValue).sum();
		            report.setTotalQuantity(total);
		            reportDTOs.add(report);
		            //report.getInstitutionQuantities().forEach( (k, v) -> { System.out.println(k + " -> " + v);
		        }
		        
		       // reportMap.forEach( (k, v) -> { System.out.println(k + " -> " + v.getItemName()+ " -> " + v.getTotalQuantity()); } );

		       // return new ArrayList<>(reportMap.values());
		        List<ItemReportDTO>  itemReportDTOs = new ArrayList<>(reportMap.values());
		        
		        List<String> institutions = getAllInstitutions();
		        
		        for (String institution: institutions) {
		        System.out.println("Printing Client Names" + institution);
		        }
		        
		     //   List<Long> purchaseOrderIds= new ArrayList<Long>();
				// purchaseOrderIds.add(purchaseOrderEntity.getId());
		        List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIds);
				 PurchaseOrderItemDetailDTO purchaseOrderdetail =purchaseOrderdetails.get(0);
				 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
				 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
							model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
							model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
							model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
							model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
							model.addAttribute("purchaseOrderdetails", purchaseOrderdetails);
		        model.addAttribute("report", reportDTOs);
		        model.addAttribute("institutions", institutions);
		        
		        return "showitemreportwithprint";
		
		 }

		 
		 @GetMapping("/showsupplierwiseitemreport") 
		 public String showsupplierwiseitemreport(Model model, HttpServletRequest request) throws Exception {
			 
			 	LocalDate currentDate = LocalDate.now();

				// Get the start and end of the current month
				YearMonth currentMonth = YearMonth.from(currentDate);
				LocalDate startOfMonth = currentMonth.atDay(1); // First day of the current month
				LocalDate endOfMonth = currentMonth.atEndOfMonth(); // Last day of the current month

				// Define your custom date ranges within the current month
				LocalDate startDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1); // First start date
				LocalDate endDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 15); // First end date

				LocalDate startDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 16); // Second start date

				YearMonth yearMonth = YearMonth.from(currentDate);
				int daysInCurrentMonth = yearMonth.lengthOfMonth();

				LocalDate endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), daysInCurrentMonth); // First
																														// end
																														// date

				// Define the variable to populate
				String result = "";
				String installmentNo = null;
				String monthOfPurchase = null;
				int currentYear = currentDate.getYear();
				// Check if the current date is between the first range
				if (!currentDate.isBefore(startDate1) && !currentDate.isAfter(endDate1)) {
					monthOfPurchase = LocalDate.now().getMonth().toString();

					result = "Value for first date range";
					installmentNo = "2nd Installment";

				}
				// Check if the current date is between the second range
				else if (!currentDate.isBefore(startDate2) && !currentDate.isAfter(endDate2)) {
					LocalDate nextMonth = LocalDate.now().plusMonths(1);

					// Format next month to a string (e.g., "FEBRUARY")
					String nextMonthStr = nextMonth.getMonth().toString();
					monthOfPurchase = nextMonthStr;
					installmentNo = "Ist Installment";
					result = "Value for second date range";
				}
				// If the current date doesn't fall within any range
				else {
					result = "Date is not in any range";
					installmentNo = "0";
				}

				List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService
						.findAllActivePurchaseOrders(currentYear, monthOfPurchase, installmentNo);

				OrderMasterDTO purchaseOrder = OrderItemDTOActiveList.get(0);

				List<Long> purchaseOrderIds = new ArrayList<Long>();
				purchaseOrderIds.add(Long.valueOf(purchaseOrder.getOrderId()));
		        List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIds);
				 PurchaseOrderItemDetailDTO purchaseOrderdetail =purchaseOrderdetails.get(0);
				 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
				 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
							model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
							model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
							model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
							model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
							model.addAttribute("purchaseOrderdetails", purchaseOrderdetails);
							
							 
							 HashSet<Long> supplierIds = new HashSet<>();
							for (PurchaseOrderItemDetailDTO item : purchaseOrderdetails) {
							
								supplierIds.add(item.getDepartmentId());
								
							}
							
							
							List<Long> SupplierIds= new ArrayList<Long>();
							
							
							 Iterator<Long> Supplieriterator1 = supplierIds.iterator();
							 
						
							
							 while (Supplieriterator1.hasNext()) {
								 
								 SupplierIds.add(Supplieriterator1.next());
								 
							 }
							 System.out.println("Printing Supplier Ids" + SupplierIds);
							 SupplierIds.remove(Long.valueOf(1));
							 
							 System.out.println("Printing Supplier Ids" + SupplierIds);
							
							 
							 List<DepartmentDTO> departmentlist = new ArrayList<DepartmentDTO>(); 
						//	 List<Department> suppliers = departmentRepository.findDepartmentByDepartmentIdList(SupplierIds);
							 for (Long item : SupplierIds) {
								 
								 Department supplier = departmentRepository.findByDepartmentId(item.longValue());
								 if (supplier!=null) {
								String departmentName = supplier.getDepartmentName();
								 
								DepartmentDTO departmentDTO = new DepartmentDTO();
								departmentDTO.setDepartmentId((Long)(supplier.getDepartmentId())); 
								departmentDTO.setDepartmentName(departmentName);
								departmentlist.add(departmentDTO);
								 }
								 
								 
							 }
							 
			 List<DepartmentDTO> supplierDetails =  populateOrderScreenService.findAllDepartments();
			 model.addAttribute("supplierDetails", supplierDetails);
			
	 
		
			 return "showsupplierwiseitemreport";
		 }
		 
		
		 
		 @GetMapping("/generatesupplierwiseitemreport")
		 public String generateSupplierWiseItemReport(Model model, HttpServletRequest request) throws Exception {
		 
		 
			 long purchaseOrderId = Long.parseLong(request.getParameter("purchaseOrderId"));
			 long departmentId = Long.parseLong(request.getParameter("departmentId"));
			 
			 List<Long> purchaseOrderIds = new ArrayList<Long>();
				purchaseOrderIds.add(Long.valueOf(purchaseOrderId));
						
				
			 List<PurchaseOrderItemDetailDTO> purchaseOrderDetails = populateOrderScreenService
						.findPurchaseOrderItemDetailsBySupplierId(purchaseOrderIds,departmentId);
			 
			// List<OrderItemDetailDTO> orderItemDetailDTOs = populateOrderScreenService.findOrderItemDetails(orderIds);
			 Map<String, ItemReportDTO> reportMap = new HashMap<>();

		        // Process each order
		        for (PurchaseOrderItemDetailDTO orderItem : purchaseOrderDetails) {
		        	System.out.println("Printing Order Item " + " -> Institution Name" + orderItem.getInstitutionName()+" -> Item Name" + orderItem.getItemName()+" -> Item Quantity" + orderItem.getQuantity());
		            reportMap.putIfAbsent(orderItem.getItemName(), new ItemReportDTO());
		            ItemReportDTO report = reportMap.get(orderItem.getItemName());

		            report.setItemName(orderItem.getItemName());
		            if (report.getInstitutionQuantities() == null) {
		                report.setInstitutionQuantities(new HashMap<>());
		            }

		            report.getInstitutionQuantities().putIfAbsent(orderItem.getInstitutionName(), 0.0);
		           // report.getInstitutionQuantities().put(orderItem.getInstitutionName(),
		                 //   report.getInstitutionQuantities().get(orderItem.getInstitutionName()) + orderItem.getQuantity());
		       
		            report.getInstitutionQuantities().put(orderItem.getInstitutionName(),
	                 orderItem.getQuantity());
		            
		            System.out.println("Printing Insistution wise Item Quantity for Item " +report.getItemName() + "And for Institution " + orderItem.getInstitutionName()+ + report.getInstitutionQuantities().get(orderItem.getInstitutionName()));
		           
		          // report.getInstitutionQuantities().forEach( (k, v) -> { System.out.println(k + " -> " + v);
		           }

		        // Calculate total quantities
		        
		        List<ItemReportDTO> reportDTOs = new ArrayList<ItemReportDTO>();
		        
		        System.out.println("Printing reportMap.values()" + reportMap.values());;
		        for (ItemReportDTO report : reportMap.values()) {
		        	
		        	System.out.println("Printing Item Report Details"  + report.getInstitutionQuantities());
		            Double total = report.getInstitutionQuantities().values().stream().mapToDouble(Double::doubleValue).sum();
		            report.setTotalQuantity(total);
		            reportDTOs.add(report);
		            //report.getInstitutionQuantities().forEach( (k, v) -> { System.out.println(k + " -> " + v);
		        }
		        
		       // reportMap.forEach( (k, v) -> { System.out.println(k + " -> " + v.getItemName()+ " -> " + v.getTotalQuantity()); } );

		       // return new ArrayList<>(reportMap.values());
		        List<ItemReportDTO>  itemReportDTOs = new ArrayList<>(reportMap.values());
		        
		        List<String> institutions = getAllInstitutions();
		        
		        for (String institution: institutions) {
		        System.out.println("Printing Client Names" + institution);
		        }
		        
		     //   List<Long> purchaseOrderIds= new ArrayList<Long>();
				// purchaseOrderIds.add(purchaseOrderEntity.getId());
		        List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIds);
				 PurchaseOrderItemDetailDTO purchaseOrderdetail =purchaseOrderdetails.get(0);
				 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
				 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
							model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
							model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
							model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
							model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
							model.addAttribute("purchaseOrderdetails", purchaseOrderdetails);
		        model.addAttribute("report", reportDTOs);
		        model.addAttribute("institutions", institutions);
		        
		        return "showitemreportwithprint";
		
		 }

		
		
		
	 @GetMapping("/showsuppliersreport/{quotationId}")
	 public String showSupplierReport(@PathVariable("quotationId") long quotationId, HttpServletResponse response,
				HttpServletRequest request, Model model) throws Exception {
				
		 System.out.println("printing Quotation Id" + quotationId);
				List<Long> quotationOrderIds= new ArrayList<Long>();
		 quotationOrderIds.add(quotationId);
		 
		 List<QuotationOrderItemDetailDTO> quotationOrderdetails = populateOrderScreenService.findQuotationOrderItemDetails(quotationOrderIds);
		  DecimalFormat df = new DecimalFormat("0.00");
		    int ITEMS_PER_PAGE = 16; 
			//double billtotallong = purchaseOrderEntity.getTotal();
			double billtotallong = 0;
			String amountinwords = "(Rupees in words  " + ConvertNumberToWords.numberToWords((long)billtotallong) + " only)";
			//Date billDate = purchaseOrderEntity.getEndDate();
			Date billDate = new Date();
			int billDateYear = YearMonth.now().getYear();
			String billDateYearStr = Integer.toString(billDateYear);
			String lastTwoDigitsOfbillDateYear = billDateYearStr.substring(2, 4);
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			
			String strDate = formatter.format(billDate);
			int totalNoofRows = 12;
			int orderdetailsize = quotationOrderdetails.size();
			
					
			int totalItems =quotationOrderdetails.size();
			int totalPages = (int) Math.ceil((double) totalItems / ITEMS_PER_PAGE);
			
			 List<List<QuotationOrderItemDetailDTO>> orderItemPages = new ArrayList<>();
		        for (int i = 0; i < totalPages; i++) {
		            int start = i * ITEMS_PER_PAGE;
		            int end = Math.min(start + ITEMS_PER_PAGE, totalItems);
		            orderItemPages.add(quotationOrderdetails.subList(start, end));
		        }
		        
		        int sizeOFLastPage = 0;
		    
		        		List<QuotationOrderItemDetailDTO> orderItemPage = orderItemPages.get(orderItemPages.size()-1);
		        		sizeOFLastPage = orderItemPage.size();
		        
		        int noOfEmptySpacesToBeAdded = ITEMS_PER_PAGE - sizeOFLastPage;
		        
		        model.addAttribute("orderItemPages", orderItemPages);
	  			model.addAttribute("lastTwoDigitsOfbillDateYear",lastTwoDigitsOfbillDateYear);
	  			model.addAttribute("billTotal",df.format(Math.round(billtotallong))); 
	  			model.addAttribute("amountinwords", amountinwords);
				model.addAttribute("noOfEmptySpacesToBeAdded", noOfEmptySpacesToBeAdded);
				model.addAttribute("date", strDate);
				model.addAttribute("pageSize", totalPages);
				model.addAttribute("itemperpage", ITEMS_PER_PAGE);
		
		 System.out.println("Prinitng quotationOrderdetails size"+ quotationOrderdetails.size());
		 QuotationOrderItemDetailDTO quotationOrderdetail =quotationOrderdetails.get(0);
		 			model.addAttribute("quotationOrderId", quotationOrderdetail.getQuotationOrderId());
		 			model.addAttribute("orderDate", quotationOrderdetail.getStartDate());
		 			model.addAttribute("supplierName", quotationOrderdetail.getSupplierName());
		 			model.addAttribute("monthOfPurchase", quotationOrderdetail.getMonthOfPurchase());
					model.addAttribute("installmentNumber", quotationOrderdetail.getInstallmentNumber());
					model.addAttribute("orderTotal", quotationOrderdetail.getTotal());
					model.addAttribute("profitmargin", quotationOrderdetail.getProfitMargin());
					model.addAttribute("orderGrandTotal", quotationOrderdetail.getTotalAmount());
					model.addAttribute("quotationOrderdetails", quotationOrderdetails);
					
					Map<String, Object> data = new HashMap<>();
					data.put("quotationOrderdetail", quotationOrderdetail);
					data.put("quotationOrderdetails", quotationOrderdetails);

					request.getSession().setAttribute("quotationdownload", data);
					
		 
		return "showquotationrequestsupplierwise";
		
		}
	
	 
	 @GetMapping("/showallorderforitemratecomparison")

		public String showallorderforitemratecomparison(Model model) throws Exception {
			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrderForCreatingPurchaseOrder();
				model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
				
				

				OrderCollectionDTO orderIdsForItemRateComparison = new OrderCollectionDTO();
			model.addAttribute("orderIdsForItemRateComparison", orderIdsForItemRateComparison);

			return "showallorderforitemratecomparison";
		}
	 
	 
	 
	 
	 @PostMapping("/showitemratecomparison")
	 public String showItemRateComparison(@ModelAttribute("orderIdsForItemRateComparison") OrderCollectionDTO orderCollectionDTO,Model model) throws Exception {
		 
		 System.out.println("Printing in showitemratecomparison");

		 Long[] orderIDs = orderCollectionDTO.getOrderIds();
		 System.out.println("Printing Selected Order ids" + orderIDs);
		 List<Long> orderIds= new ArrayList<Long>();
		 for (int i = 0; i < orderIDs.length; i++) {
			 System.out.println("Printing id" +orderIDs[i] );
			 orderIds.add(orderIDs[i]);
		 }
		 
		 
		 
		 List<OrderItemDetailDTO> orderItemDetailDTOs = populateOrderScreenService.findOrderItemDetails(orderIds);
		 Map<String, ItemSupplierRateDTO> reportMap = new HashMap<>();

	        // Process each order
	        for (OrderItemDetailDTO orderItem : orderItemDetailDTOs) {
	        	System.out.println("Printing Order Item " + " -> Institution Name" + orderItem.getInstitutionName()+" -> Item Name" + orderItem.getItemName()+" -> Item Quantity" + orderItem.getQuantity());
	            reportMap.putIfAbsent(orderItem.getItemName(), new ItemSupplierRateDTO());
	            ItemSupplierRateDTO report = reportMap.get(orderItem.getItemName());

	            report.setItemName(orderItem.getItemName());
	            if (report.getSupplierRates() == null) {
	                report.setSupplierRates(new HashMap<>());
	            }

	           // report.getSupplierRates().putIfAbsent(orderItem.getInstitutionName(), 0);
	           // report.getInstitutionQuantities().put(orderItem.getInstitutionName(),
	                 //   report.getInstitutionQuantities().get(orderItem.getInstitutionName()) + orderItem.getQuantity());
	       
	           // report.getSupplierRates().put(orderItem.getInstitutionName(),   orderItem.getQuantity());
	            
	         //   System.out.println("Printing Insistution wise Item Quantity for Item " +report.getItemName() + "And for Institution " + orderItem.getInstitutionName()+ + report.getInstitutionQuantities().get(orderItem.getInstitutionName()));
	           
	          // report.getInstitutionQuantities().forEach( (k, v) -> { System.out.println(k + " -> " + v);
	           }
	        
	        
	        List<String> suppliers = findAllValidDepartments();
	        
	        for (String supplier: suppliers) {
	        System.out.println("Printing Supplier Names" + suppliers);
	        
	       
 
	       
	        
	        Iterator<Entry<String, ItemSupplierRateDTO>> new_Iterator = reportMap.entrySet().iterator();
	        while (new_Iterator.hasNext()) {
	            Map.Entry<String, ItemSupplierRateDTO> new_Map
	                = (Map.Entry<String, ItemSupplierRateDTO>)
	                      new_Iterator.next();
	            System.out.println(new_Map.getKey() + " = "
                        + new_Map.getValue());
	          //  reportMap.get(new_Map.getKey()).getSupplierRates().putIfAbsent(supplier, 5);
	            System.out.println("Printing Supplier wise Item Item Rate for Item" + reportMap.get(new_Map.getKey()).getSupplierRates().get(supplier) );
		           // report.getInstitutionQuantities().put(orderItem.getInstitutionName(),
		                 //   report.getInstitutionQuantities().get(orderItem.getInstitutionName()) + orderItem.getQuantity());
		       
	           // reportMap.get(new_Map.getKey()).getSupplierRates().put(supplier,
	             //    orderItem.getQuantity());
	        }
	        
	        }
	        
	        RateComparisonFormDTO rateComparisonFormDTO = new RateComparisonFormDTO();
	        rateComparisonFormDTO.setReportMap(reportMap);
	        
	        reportMap.forEach( (k, v) -> { System.out.println(k + " -> " + v.getItemName()+ " -> " + v.getTotalQuantity()); } );

	        // Calculate total quantities
	        
	        List<ItemSupplierRateDTO> reportDTOs = new ArrayList<ItemSupplierRateDTO>();
	        
	        System.out.println("Printing reportMap.values()" + reportMap.values());;
	        for (ItemSupplierRateDTO report : reportMap.values()) {
	        	
	        	System.out.println("Printing Item Report Details"  + report.getSupplierRates());
	            int total = report.getSupplierRates().values().stream().mapToInt(Integer::intValue).sum();
	            report.setTotalQuantity(total);
	            reportDTOs.add(report);
	            //report.getInstitutionQuantities().forEach( (k, v) -> { System.out.println(k + " -> " + v);
	        }
	        
	       // reportMap.forEach( (k, v) -> { System.out.println(k + " -> " + v.getItemName()+ " -> " + v.getTotalQuantity()); } );

	       // return new ArrayList<>(reportMap.values());
	        List<ItemSupplierRateDTO>  itemReportDTOs = new ArrayList<>(reportMap.values());
	        
	   //     List<String> institutions = getAllInstitutions();
	        
	        model.addAttribute("report", reportDTOs);
	        model.addAttribute("suppliers", suppliers);
	        model.addAttribute("rateComparisonFormDTO", rateComparisonFormDTO);
	        
	     /*   for (String institution: institutions) {
	        System.out.println("Printing Client Names" + institution);
	        }
	        
	        */
	        
		 return "showitemratecomparison";
	 }
	 
	 
	 @GetMapping("/showallorderforitemrateupdates")

		public String showaAllOrderForItemRateUpdates(Model model) throws Exception {
			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrderForCreatingPurchaseOrder();
				model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
				
				

				OrderCollectionDTO orderIdsForItemRateComparison = new OrderCollectionDTO();
			model.addAttribute("orderIdsForItemRateComparison", orderIdsForItemRateComparison);

			return "showallorderforitemrateupdates";
		}
	 
	 @PostMapping("/showitemrateupdates")
	 public String showItemRateUpdates(@ModelAttribute("orderIdsForItemRateComparison") OrderCollectionDTO orderCollectionDTO,Model model, HttpServletRequest request) throws Exception {
		 
		 System.out.println("Printing in showitemrateupdates");
		 
	//	 request.getSession().setAttribute("orderCollectionDTO", orderCollectionDTO);

		 Long[] orderIDs = orderCollectionDTO.getOrderIds();
		 System.out.println("Printing Selected Order ids" + orderIDs);
		 List<Long> orderIds= new ArrayList<Long>();
		 for (int i = 0; i < orderIDs.length; i++) {
			 System.out.println("Printing id" +orderIDs[i] );
			 orderIds.add(orderIDs[i]);
		 }
		 
		 
		 
		 List<OrderItemDetailDTO> orderItemDetailDTOs = populateOrderScreenService.findOrderItemDetails(orderIds);
		 
		 
		 
		 Map<String, ItemSupplierRateDTO> reportMap = new HashMap<>();
		 
		 List<Long> itemIds = new ArrayList<Long>(); 
		 List<Long> itemIdsNoDuplicate = new ArrayList<Long>(); 
		 HashSet<Long> set = new HashSet();

	        // Process each order
	        for (OrderItemDetailDTO orderItem : orderItemDetailDTOs) {
	        	
	        	System.out.println("Printing Item Ids and Item name "+ orderItem.getItemId() +"------" + orderItem.getItemName());
	        //	itemIds.add(orderItem.getItemId());
	        	set.add(orderItem.getItemId());
	       // 	itemIds = List.of(set.toArray());

	        
	           }
	        
	        System.out.println("Printing No Of Item in set" + set.size());
	        
	        Iterator iter = set.iterator();
	       
		        
	        while (iter.hasNext()) {
	          //  System.out.println(iter.next());
	            itemIdsNoDuplicate.add((Long)iter.next());
	        }
	        
	       
	        Map<Long, String> itemNames = new HashMap<>();
	        
	        List<ItemDTO> itemList = populateOrderScreenService.findAllItemByIds(itemIdsNoDuplicate);
	        List<DepartmentDTO> supplierList = populateOrderScreenService.findAllValidDepartments();
	        ItemRateUpdateForm form = new ItemRateUpdateForm();
	        for (ItemDTO item : itemList) {
	        	System.out.println("Printing item id" +item.getItemId());
	        	System.out.println("Printing item name" +item.getItemName());
	        	ItemRateDTO dto = new ItemRateDTO();
	            dto.setItemId(item.getItemId());
	            dto.setSupplierRates(new HashMap<>()); // Initialize empty map
	            form.getItemRateUpdateDTOs().add(dto);
	            itemNames.put(item.getItemId(), item.getItemName());
	        }
	        
	        System.out.println("Printing DTOs size" +form.getItemRateUpdateDTOs().size());
	        
	        
	      
	        model.addAttribute("itemRateUpdateForm", form);
	        model.addAttribute("itemNames", itemNames);
	        model.addAttribute("supplierList", supplierList);
	        
	        request.getSession().setAttribute("itemRateUpdateForm", form);
	        request.getSession().setAttribute("itemNames", itemNames);
	        request.getSession().setAttribute("supplierList", supplierList);
	        
	        for (DepartmentDTO supplier: supplierList) {
	        System.out.println("Printing Supplier Names" + supplier.getDepartmentName());
	        
	        }
	        
	        for (ItemDTO item :  itemList) {
				 System.out.println("Printing id" +item.getItemName() );
				
			 }

		 return "showitemrateupdates";
	 }
	 
	 
	 @GetMapping("/showitemrateupdatestohandlevalidationerrors")
	 public String showItemRateUpdatesToHandleValidationError(Model model, HttpServletRequest request) throws Exception {
		 
		 System.out.println("Printing in showitemrateupdates");
		 ItemRateUpdateForm itemRateUpdateForm = (ItemRateUpdateForm) request.getSession().getAttribute("itemRateUpdateForm");
		 List<ItemDTO> itemNames = (List<ItemDTO>) request.getSession().getAttribute("itemNames");
		 List<DepartmentDTO> supplierList  = (List<DepartmentDTO>) request.getSession().getAttribute("supplierList");
		
	        
	        model.addAttribute("itemRateUpdateForm", itemRateUpdateForm);
	        model.addAttribute("itemNames", itemNames);
	        model.addAttribute("supplierList", supplierList);
	        
	      

		 return "showitemrateupdates";
	 }
	 

	 
	 @PostMapping("/update-rates")
	    public String updateRates(@Valid @ModelAttribute("itemRateUpdateForm") ItemRateUpdateForm itemRateUpdateForm,BindingResult bindingResult, Model model, RedirectAttributes redirectAttributes) {
		 System.out.println("Printing in updateRates Methods");
		 
		 if (bindingResult.hasErrors()) {
				System.out.println("Error block");
				System.out.println("printing error count" + bindingResult.getErrorCount());
				Map<String, Object> errorMessages = new HashMap();
				if (bindingResult.hasErrors()) {

					List<FieldError> fes = bindingResult.getFieldErrors();
					for (FieldError fe : fes) {
						errorMessages.put(fe.getField(), fe.getDefaultMessage());
					}

				}
				// model.addAttribute("orderDTO", orderDTO); 
				redirectAttributes.addFlashAttribute("errorMessages", errorMessages);
				redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.orderDTO",bindingResult);
				redirectAttributes.addFlashAttribute("itemRateUpdateForm", itemRateUpdateForm);
				return "redirect:/showitemrateupdatestohandlevalidationerrors";

			}
		 
		 
		 
	        updateItemRates(itemRateUpdateForm.getItemRateUpdateDTOs());
	        
	        
	        List<ItemRateDTO> itemRateUpdateDTOs = itemRateUpdateForm.getItemRateUpdateDTOs();
	        List<ItemDTO> itemDTOs = new ArrayList<ItemDTO>();
	        List<Long> itemIds = new ArrayList<Long>();
	        for (ItemRateDTO dto : itemRateUpdateDTOs) {
	        	itemIds.add(dto.getItemId());
	        	
	        	System.out.println("Printing Item Ids" + dto.getItemId());
	           
	        }
	        
	       // List<ItemDTO> items = populateOrderScreenService.findAllItemByIds(itemIds);
	        List<ItemDTO> items = populateOrderScreenService.findAllItemWithDepartmentNameByItemIds(itemIds);
	        
	        System.out.println("Printing Item Size" + items.size());
	        model.addAttribute("items", items);
	       // return "redirect:/update-rates";
	        return "showitemrateupdatesuccess";
	        
	    }
	 
	 @Transactional
	    public void updateItemRates(List<ItemRateDTO> itemRateUpdateDTOs) {
		 
		 System.out.println("Printing in updateItemRates Methods");
		 
		 List<ItemRateDTO> itemRatesDTOs =  itemRateUpdateDTOs;
	        for (ItemRateDTO dto : itemRatesDTOs) {
	            Optional<Item> itemOpt = itemRepository.findById(dto.getItemId());
	            if (itemOpt.isPresent()) {
	                Item item = itemOpt.get();
	                Map<Long, Double> rates = dto.getSupplierRates();

	                // Find the lowest rate
	                Map.Entry<Long, Double> lowestRateEntry = rates.entrySet()
	                    .stream()
	                    .min(Map.Entry.comparingByValue())
	                    .orElse(null);

	                if (lowestRateEntry != null) {
	                	System.out.println("Printing in Lowest rates " + "Supplier Id" + lowestRateEntry.getKey() + "Item Rate " + lowestRateEntry.getValue() );
	                    item.setItemRate(lowestRateEntry.getValue());
	                    Department deptEntity = departmentRepository.findByDepartmentId(lowestRateEntry.getKey());
	                    item.setDepartmentId(deptEntity.getDepartmentId());
	                    itemRepository.save(item);
	                }
	            }
	        }
	    }
	 
	 
	 
	 @GetMapping("/showallactivepurchaseorderforreports")
		public String showAllActivePurchaseOrderForReports(Model model, HttpServletRequest request) throws Exception {
		 

	      LocalDate currentDate = LocalDate.now();

		        // Get the start and end of the current month
		        YearMonth currentMonth = YearMonth.from(currentDate);
		        LocalDate startOfMonth = currentMonth.atDay(1); // First day of the current month
		        LocalDate endOfMonth = currentMonth.atEndOfMonth(); // Last day of the current month

		        // Define your custom date ranges within the current month
		        LocalDate startDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1); // First start date
		        LocalDate endDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 15); // First end date

		        LocalDate startDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 16); // Second start date
		        
		        YearMonth yearMonth = YearMonth.from(currentDate);
		        int daysInCurrentMonth = yearMonth.lengthOfMonth();
		        
		        LocalDate endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), daysInCurrentMonth); // First end date

	        // Define the variable to populate
	        String result = "";
	        String installmentNo= null;
	        String monthOfPurchase=null;
	        int currentYear = currentDate.getYear();
	        // Check if the current date is between the first range
	        if (!currentDate.isBefore(startDate1) && !currentDate.isAfter(endDate1)) {
	        	monthOfPurchase= LocalDate.now().getMonth().toString();
	            
	            result = "Value for first date range";
	            installmentNo = "2nd Installment";
	            
	        }
	        // Check if the current date is between the second range
	        else if (!currentDate.isBefore(startDate2) && !currentDate.isAfter(endDate2)) {
	        	LocalDate nextMonth = LocalDate.now().plusMonths(1);
	            
	            // Format next month to a string (e.g., "FEBRUARY")
	            String nextMonthStr = nextMonth.getMonth().toString();
	            monthOfPurchase = nextMonthStr;
	            installmentNo = "Ist Installment";
	            result = "Value for second date range";
	        }
	        // If the current date doesn't fall within any range
	        else {
	            result = "Date is not in any range";
	            installmentNo = "0";
	        }

		
		
			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActivePurchaseOrders(currentYear,monthOfPurchase,installmentNo);
			List<PurchaseOrderAndAssociatedOrderDTO> PurchaseOrderAndAssociatedOrdersForAllActivePurchaseOrder = populateOrderScreenService.findPurchaseOrderAndAssociatedOrdersForAllActivePurchaseOrder();
			model.addAttribute("OrderItemDTOActiveList", PurchaseOrderAndAssociatedOrdersForAllActivePurchaseOrder);
			
			return "showallactivepurchaseorderforreports";
		}
	 
	 public List<String> findAllValidDepartments() {
	        // Fetch unique client names from orders
	        return populateOrderScreenService.findAllValidDepartments().stream()
	                .map(DepartmentDTO::getDepartmentName)
	                .distinct()
	                .sorted()
	                .toList();
	    }
	 
	 @GetMapping("/showallorderforcreatingpurchaseorder")

		public String showallorderforcreatingpurchaseorder(Model model) throws Exception {
			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrderForCreatingPurchaseOrder();
				model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
				
				

				OrderCollectionDTO orderIdsForCreatingPurchaseOrder = new OrderCollectionDTO();
			model.addAttribute("orderIdsForCreatingPurchaseOrder", orderIdsForCreatingPurchaseOrder);

			return "showallorderforcreatingpurchaseorder";
		}
	 
	 @PostMapping("/createpurchaseorder")
	 public String createPurchaseOrder(@ModelAttribute("orderIdsForCreatingPurchaseOrder") OrderCollectionDTO orderCollectionDTO,Model model) throws Exception {
		 List<Item> purchaseItemList = itemRepository.findAllByOrderByItemPhaseId();
		 
		 
		 
		 Long[] orderIDs = orderCollectionDTO.getOrderIds();
		 System.out.println("Printing Selected Order ids" + orderIDs);
		 List<Long> orderIds= new ArrayList<Long>();
		 for (int i = 0; i < orderIDs.length; i++) {
			 System.out.println("Printing id" +orderIDs[i] );
			 orderIds.add(orderIDs[i]);
		 }
		 System.out.println("Printing Selected Order ids" + orderIds);
		 PurchaseOrder purchaseOrder =  new PurchaseOrder();
		 
		 purchaseOrder.setStartDate(LocalDate.now());
		 

		  LocalDate currentDate = LocalDate.now();

	        // Get the start and end of the current month
	        YearMonth currentMonth = YearMonth.from(currentDate);
	        LocalDate startOfMonth = currentMonth.atDay(1); // First day of the current month
	        LocalDate endOfMonth = currentMonth.atEndOfMonth(); // Last day of the current month

	        // Define your custom date ranges within the current month
	        LocalDate startDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1); // First start date
	        LocalDate endDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 15); // First end date

	        LocalDate startDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 16); // Second start date
	        
	        YearMonth yearMonth = YearMonth.from(currentDate);
	        int daysInCurrentMonth = yearMonth.lengthOfMonth();
	        
	        LocalDate endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), daysInCurrentMonth); // First end date

     // Define the variable to populate
     String result = "";
     String installmentNo= null;
     String monthOfPurchase=null;
     // Check if the current date is between the first range
     if (!currentDate.isBefore(startDate1) && !currentDate.isAfter(endDate1)) {
     	monthOfPurchase= LocalDate.now().getMonth().toString();
         
         result = "Value for first date range";
         installmentNo = "2nd Installment";
         
     }
     // Check if the current date is between the second range
     else if (!currentDate.isBefore(startDate2) && !currentDate.isAfter(endDate2)) {
     	LocalDate nextMonth = LocalDate.now().plusMonths(1);
         
         // Format next month to a string (e.g., "FEBRUARY")
         String nextMonthStr = nextMonth.getMonth().toString();
         monthOfPurchase = nextMonthStr;
         installmentNo = "Ist Installment";
         result = "Value for second date range";
     }
     // If the current date doesn't fall within any range
     else {
         result = "Date is not in any range";
         installmentNo = "0";
     }
	 
	 
         purchaseOrder.setMonthOfPurchase(monthOfPurchase);
		 purchaseOrder.setInstallmentNumber(installmentNo);
		 
		 Set<Order> orders = new HashSet<>();
		 
		 for (Long orderId : orderIds) {
			 Order orderEntity = orderRepository.findById(orderId);
			 orders.add(orderEntity);
			}
		 purchaseOrder.setOrders(orders);
		 
		 purchaseOrderRepository.save(purchaseOrder);
		  Long purchaseOrderId = purchaseOrder.getId();
		  
		//  List<PurchaseOrderItem> purchaseOrderItems = purchaseOrder.getPurchaseOrderItems();
		  List<OrderItemDetailDTO> orderItemDetailDTOs = populateOrderScreenService.findOrderItemDetails(orderIds);
		  Set<Long> itemIdsOfSelectedOrders = new HashSet<>();
		  for (OrderItemDetailDTO orderItem :orderItemDetailDTOs) {
			  itemIdsOfSelectedOrders.add(orderItem.getItemId());
		  }
		  
		  List<PurchaseOrderItemDTO> purchaseOrderItemDTOs = new ArrayList<PurchaseOrderItemDTO>();
		  
		  for (Long itemId : itemIdsOfSelectedOrders) {
			  PurchaseOrderItemDTO purchaseOrderItemDTO = new PurchaseOrderItemDTO();
			  purchaseOrderItemDTO.setItemId(itemId);
			  purchaseOrderItemDTOs.add(purchaseOrderItemDTO);
		  }
		 
		/* purchaseItemList.forEach(item -> {

				PurchaseOrderItem purchaseOrderItem = new PurchaseOrderItem();
			//	purchaseOrderItemDTO.setItemIdDB(item.getItemId());
			//	purchaseOrderItemDTO.setPhaseIdDB(item.getItemPhaseId());
			//	purchaseOrderItemDTO.setItemNameDB(item.getItemName());
				purchaseOrderItem.setItemId(item.getItemId());
			//	purchaseOrderItem.setItemRate(item.getItemRate());
				purchaseOrder.add(purchaseOrderItem);
				

			}); 
			*/
		 
		 
		
	/*	 for (OrderItemDetailDTO orderItem :orderItemDetailDTOs) {
			 
			// System.out.println("Printing order item Record" + orderItem.toString());
			 for ( PurchaseOrderItemDTO purchaseOrderItemDTO :purchaseOrderItemDTOs) {
				// System.out.println("Printing Purchase order item Record" + purchaseOrderItem.toString());
				 
				 if (orderItem.getItemId() == purchaseOrderItemDTO.getItemId()) {
					 System.out.println("OrderItem Quantity" + orderItem.getQuantity());
					 System.out.println("purchase Order item Quantity" + purchaseOrderItemDTO.getQuantity());
					 
					 if (orderItem.getQuantity()!=null) {
						 
						 if (purchaseOrderItemDTO.getQuantity()!=null) {
					 purchaseOrderItemDTO.setQuantity(purchaseOrderItemDTO.getQuantity() + orderItem.getQuantity());
					 } else {
						 purchaseOrderItemDTO.setQuantity(orderItem.getQuantity());
					 }
					 }
					 System.out.println("OrderItem Quantity" + orderItem.getQuantity());
					 System.out.println("purchase Order item Quantity" + purchaseOrderItemDTO.getQuantity());
					// purchaseOrderItem.setPurchaseOrder(purchaseOrder);
					// purchaseOrderItemRepository.save(purchaseOrderItem);
				 }
			 }
			 
			 
		
		 } */
		  
		  Double orderTotal = 0.0;
		 
		 for (OrderItemDetailDTO orderItem :orderItemDetailDTOs) {
			 System.out.println("Printing Purchase Order Item Id and Quantity" + orderItem.getItemId() + ":::::" + orderItem.getQuantity());
			 PurchaseOrderItem purchaseOrderItem = new PurchaseOrderItem();
			 		System.out.println("Printing Institution Id " + orderItem.getInstitutionId());
			 		purchaseOrderItem.setInstitutionId(orderItem.getInstitutionId());
			 		System.out.println("Printing Institution Id again " + purchaseOrderItem.getInstitutionId());
			 		purchaseOrderItem.setItemId(orderItem.getItemId());
			 		Item itemIdFromDB = itemRepository.findByItemId(orderItem.getItemId());
			 		if (itemIdFromDB.getItemRate()!=null) {
			 		Double itemRate = itemIdFromDB.getItemRate();
			 		purchaseOrderItem.setItemRate(itemRate);
			 		Long departmentId = itemIdFromDB.getDepartmentId();
			 		purchaseOrderItem.setDepartmentId(departmentId);
			 		}
					purchaseOrderItem.setQuantity(orderItem.getQuantity());
					
					purchaseOrderItem.setUnitId(orderItem.getUnitId());
					Double itemBaseAmount = 0.0;
					if (purchaseOrderItem.getItemRate()!=null && purchaseOrderItem.getQuantity()!=null) {
						 itemBaseAmount = purchaseOrderItem.getQuantity() * purchaseOrderItem.getItemRate();
						 purchaseOrderItem.setAmount(itemBaseAmount);
						 
						 if (orderItem.getProfitMargin()==null) {
							 itemBaseAmount = purchaseOrderItem.getQuantity() * purchaseOrderItem.getItemRate();
							 purchaseOrderItem.setAmount(itemBaseAmount);
						 }
						 
						 if (orderItem.getProfitMargin()!=null) {
							 
							 if (orderItem.getProfitMargin()!=orderItem.getProfitMargin()) {
								 purchaseOrderItem.setAmount(itemBaseAmount+(itemBaseAmount*Double.valueOf(orderItem.getProfitMargin())/100));
							 }
						 }
						 orderTotal = orderTotal+purchaseOrderItem.getAmount();
					 
				 }
					purchaseOrderItem.setPurchaseOrder(purchaseOrder);
					
					purchaseOrderItemRepository.save(purchaseOrderItem);
					//purchaseOrder.add(purchaseOrderItem);
					
			 
		 }
		 
		 purchaseOrder.setTotal(orderTotal);

purchaseOrderRepository.save(purchaseOrder);


for (Long orderId : orderIds) {
	 Order orderEntity = orderRepository.findById(orderId);
	 orderEntity.setPurchaseOrderCreated("yes");
	 orderEntity.setPurchaseOrderId(purchaseOrderId);
	 orderRepository.save(orderEntity);
	}
		
		 
		// Long purchaseOrderId = purchaseOrder.getId();
		 List<Long> purchaseOrderIds= new ArrayList<Long>();
		 purchaseOrderIds.add(purchaseOrderId);
		 
		 List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIds);
		 

		    Set<Long> supplierList = new HashSet<>();
		  for (PurchaseOrderItemDetailDTO orderItem :purchaseOrderdetails) {
			  supplierList.add(orderItem.getDepartmentId());
		  }
		  
		  
		  List items = new ArrayList<>();

for (Long item : supplierList) {
	 System.out.println("Printing Quotation Ids" + item.toString());
	
	  List<PurchaseOrderItemDetailDTO> supplierreportdeatils = populateOrderScreenService.findPurchaseOrderItemDetailsBySupplierId(purchaseOrderIds,item);
	 items.add(supplierreportdeatils);
}
		 PurchaseOrderItemDetailDTO purchaseOrderdetail =purchaseOrderdetails.get(0);
		 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
		 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
					model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
					model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
					model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
					model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
					model.addAttribute("purchaseOrderdetails", purchaseOrderdetails);
					
					model.addAttribute("items", items);
					
					
					//Item Report
			/*		PurchaseOrder purchaseOrderEntity = purchaseOrderRepository.findById(purchaseOrderId);
					 Set<Order> ordersForItemReport = purchaseOrderEntity.getOrders();
					 
						
				 	 List<Long> orderIdsForItemReport= new ArrayList<Long>();
					 
				 for (Order order: ordersForItemReport) {
					 orderIdsForItemReport.add(order.getId());
					 
				 }
				 List<Order> orderList = new ArrayList<>(orders);
				 
				 List<OrderItemDetailDTO> orderItemDetailDTOsForItemReport = populateOrderScreenService.findOrderItemDetails(orderIdsForItemReport);
				 Map<String, ItemReportDTO> reportMap = new HashMap<>();

			        // Process each order
			        for (OrderItemDetailDTO orderItem : orderItemDetailDTOsForItemReport) {
			        	System.out.println("Printing Order Item " + " -> Institution Name" + orderItem.getInstitutionName()+" -> Item Name" + orderItem.getItemName()+" -> Item Quantity" + orderItem.getQuantity());
			            reportMap.putIfAbsent(orderItem.getItemName(), new ItemReportDTO());
			            ItemReportDTO report = reportMap.get(orderItem.getItemName());

			            report.setItemName(orderItem.getItemName());
			            if (report.getInstitutionQuantities() == null) {
			                report.setInstitutionQuantities(new HashMap<>());
			            }

			            report.getInstitutionQuantities().putIfAbsent(orderItem.getInstitutionName(), 0.0);
			         
			            report.getInstitutionQuantities().put(orderItem.getInstitutionName(),
		                 orderItem.getQuantity());
			            
			            System.out.println("Printing Insistution wise Item Quantity for Item " +report.getItemName() + "And for Institution " + orderItem.getInstitutionName()+ + report.getInstitutionQuantities().get(orderItem.getInstitutionName()));
			           
			         
			           }

			        
			        
			        List<ItemReportDTO> reportDTOs = new ArrayList<ItemReportDTO>();
			        
			        System.out.println("Printing reportMap.values()" + reportMap.values());;
			        for (ItemReportDTO report : reportMap.values()) {
			        	
			        	System.out.println("Printing Item Report Details"  + report.getInstitutionQuantities());
			            Double total = report.getInstitutionQuantities().values().stream().mapToDouble(Double::doubleValue).sum();
			            report.setTotalQuantity(total);
			            reportDTOs.add(report);
			           
			        }
			        
			        List<ItemReportDTO>  itemReportDTOs = new ArrayList<>(reportMap.values());
			        
			        List<String> institutions = getAllInstitutions();
			        
			        for (String institution: institutions) {
			        System.out.println("Printing Client Names" + institution);
			        }
			        
			  
					 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
					 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
								model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
								model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
								model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
								model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
								model.addAttribute("purchaseOrderdetails", purchaseOrderdetails);
			        model.addAttribute("report", reportDTOs);
			        model.addAttribute("institutions", institutions);
			        */
			    					
					// return "supplierwisepurchaseorder";
					 
		 return "savepurchaseordersuccess";
	 }
	 
	
	 
	 @GetMapping("/showallactivepurchaseorderforedit")
		public String showAllActivePurchaseOrderForEdit(Model model, HttpServletRequest request) throws Exception {
		 

	      LocalDate currentDate = LocalDate.now();

		        // Get the start and end of the current month
		        YearMonth currentMonth = YearMonth.from(currentDate);
		        LocalDate startOfMonth = currentMonth.atDay(1); // First day of the current month
		        LocalDate endOfMonth = currentMonth.atEndOfMonth(); // Last day of the current month

		        // Define your custom date ranges within the current month
		        LocalDate startDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1); // First start date
		        LocalDate endDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 15); // First end date

		        LocalDate startDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 16); // Second start date
		        
		        YearMonth yearMonth = YearMonth.from(currentDate);
		        int daysInCurrentMonth = yearMonth.lengthOfMonth();
		        
		        LocalDate endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), daysInCurrentMonth); // First end date

	        // Define the variable to populate
	        String result = "";
	        String installmentNo= null;
	        String monthOfPurchase=null;
	        int currentYear = currentDate.getYear();
	        // Check if the current date is between the first range
	        if (!currentDate.isBefore(startDate1) && !currentDate.isAfter(endDate1)) {
	        	monthOfPurchase= LocalDate.now().getMonth().toString();
	            
	            result = "Value for first date range";
	            installmentNo = "2nd Installment";
	            
	        }
	        // Check if the current date is between the second range
	        else if (!currentDate.isBefore(startDate2) && !currentDate.isAfter(endDate2)) {
	        	LocalDate nextMonth = LocalDate.now().plusMonths(1);
	            
	            // Format next month to a string (e.g., "FEBRUARY")
	            String nextMonthStr = nextMonth.getMonth().toString();
	            monthOfPurchase = nextMonthStr;
	            installmentNo = "Ist Installment";
	            result = "Value for second date range";
	        }
	        // If the current date doesn't fall within any range
	        else {
	            result = "Date is not in any range";
	            installmentNo = "0";
	        }

		
		
			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActivePurchaseOrders(currentYear,monthOfPurchase,installmentNo);
			List<PurchaseOrderAndAssociatedOrderDTO> PurchaseOrderAndAssociatedOrdersForAllActivePurchaseOrder = populateOrderScreenService.findPurchaseOrderAndAssociatedOrdersForAllActivePurchaseOrder();
			model.addAttribute("OrderItemDTOActiveList", PurchaseOrderAndAssociatedOrdersForAllActivePurchaseOrder);
			
			return "showallactivepurchaseorderforedit";
		}
	 
	 
	 @GetMapping("/showeditpurchaseorder/{orderId}")
	 public String showEditPurchaseOrder(@PathVariable("orderId") long orderId, HttpServletResponse response,
				HttpServletRequest request, Model model) throws Exception {
		 
		 	Long orderID = Long.valueOf(orderId);
		 	 List<Long> purchaseOrderIds= new ArrayList<Long>();
			 purchaseOrderIds.add(orderID);
		 	
		 PurchaseOrder purchaseOrderEntity = purchaseOrderRepository.findById(orderID);
		 PurchaseOrderDTO purchaseOrderDTO = new PurchaseOrderDTO();
		 purchaseOrderDTO.setId(purchaseOrderEntity.getId());
		 purchaseOrderDTO.setStartDate(purchaseOrderEntity.getStartDate());
		 purchaseOrderDTO.setMonthOfPurchase(purchaseOrderEntity.getMonthOfPurchase());
		 purchaseOrderDTO.setInstallmentNumber(purchaseOrderEntity.getInstallmentNumber());
		 purchaseOrderDTO.setTotal(purchaseOrderEntity.getTotal());
		 purchaseOrderDTO.setProfitMargin(purchaseOrderEntity.getProfitMargin());
		 purchaseOrderDTO.setTotalAmount(purchaseOrderEntity.getTotalAmount());
		 
		 List<PurchaseOrderItemDTO> purchaseOrderItemDBDTOs = new ArrayList<PurchaseOrderItemDTO>();
			//List<PurchaseOrderItem> orderItemEntityList = purchaseOrderEntity.getPurchaseOrderItems();
			 List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIds);
			 purchaseOrderdetails.forEach(item -> {
				PurchaseOrderItemDTO purchaseOrderItemDTO = new PurchaseOrderItemDTO();
				purchaseOrderItemDTO.setPurchaseOrderItemId(item.getPurchaseOrderItemId());
				System.out.println("Printing Order Item Price ID" + purchaseOrderItemDTO.getPurchaseOrderItemId());
				System.out.println("Printing Institution Id" + item.getInstitutionId());
				purchaseOrderItemDTO.setInstitutionId(item.getInstitutionId());
				System.out.println("Printing Institution Id" + purchaseOrderItemDTO.getInstitutionId());
				purchaseOrderItemDTO.setItemId(item.getItemId());
				System.out.println("Printing Item Rate ID" + purchaseOrderItemDTO.getItemId());
				if (item.getItemRate()!=null) {
					purchaseOrderItemDTO.setItemRate(item.getItemRate());
				}
				System.out.println("Printing Item Rate" + purchaseOrderItemDTO.getItemRate());
				purchaseOrderItemDTO.setQuantity(item.getQuantity());
				purchaseOrderItemDTO.setUnitId(item.getUnitId());
				purchaseOrderItemDTO.setAmount(item.getAmount());
				purchaseOrderItemDTO.setItemIdDB(item.getItemId());
				//	itemPriceDTO.setPhaseNameDB(item.getPhaseName());
				purchaseOrderItemDTO.setPhaseIdDB(item.getItemPhaseId());
				purchaseOrderItemDTO.setItemNameDB(item.getItemName());
				purchaseOrderItemDTO.setDepartmentId(item.getDepartmentId());
				purchaseOrderItemDBDTOs.add(purchaseOrderItemDTO);
			});
			
			 purchaseOrderDTO.setPurchaseOrderItemDTOs(purchaseOrderItemDBDTOs);
		 
		 List<ItemPhaseDTO> itemPhaseList = populateOrderScreenService.findAllItemPhase();
		 List<UnitDTO> units = populateOrderScreenService.findAllUnits();
		 model.addAttribute("units", units);
		 model.addAttribute("itemPhaseList", itemPhaseList);
	     model.addAttribute("purchaseOrderDTO", purchaseOrderDTO);
		 model.addAttribute("orderId", orderID);
		 populateDropDowns(model);
			return "editpurchaseorder";
	 }
	 
	 
	 @PostMapping("/saveeditpurchaseorder")
	 public String saveEditPurchaseOrder(@ModelAttribute("purchaseOrderDTO") PurchaseOrderDTO purchaseOrderDTO,Model model) throws Exception {
		 
		 Long purchaseOrderId = purchaseOrderDTO.getId();
		 
		 List<PurchaseOrderItemDTO> purchaseOrderItemDTOs = purchaseOrderDTO.getPurchaseOrderItemDTOs();
		 
		 
		 PurchaseOrder purchaseOrderEntity = purchaseOrderRepository.findById(purchaseOrderId);
		 
		
		 List<PurchaseOrderItem> purchaseOrderItems = purchaseOrderEntity.getPurchaseOrderItems();
		 
		 Double orderTotal = 0.0;
		 for (int i=0;i<purchaseOrderItemDTOs.size();i++) {
			 Double itemBaseAmount = 0.0;
			 Double itemProfitMargin = 0.0;
			 Double totalAmount = 0.0;
				
			 PurchaseOrderItem purchaseOrderItem = purchaseOrderItems.get(i);
			 PurchaseOrderItemDTO PurchaseOrderItemDTO = purchaseOrderItemDTOs.get(i);
			
		 	/*	Item itemIdFromDB = itemRepository.findByItemId(purchaseOrderItem.getItemId());
		 		if (itemIdFromDB.getItemRate()!=null) {
		 		Double itemRate = itemIdFromDB.getItemRate();
		 		purchaseOrderItem.setItemRate(itemRate);
		 		 purchaseOrderItem.setDepartmentId(itemIdFromDB.getDepartmentId());
		 		}
		 		*/
			 
			// purchaseOrderItem.setItemRate(PurchaseOrderItemDTO.getItemRate());
			 purchaseOrderItem.setItemRate(PurchaseOrderItemDTO.getItemRate());
			 purchaseOrderItem.setQuantity(PurchaseOrderItemDTO.getQuantity());
			 purchaseOrderItem.setUnitId(PurchaseOrderItemDTO.getUnitId());
			 purchaseOrderItem.setDepartmentId(PurchaseOrderItemDTO.getDepartmentId());
			 
			 
			// purchaseOrderItem.setDepartmentId(PurchaseOrderItemDTO.getDepartmentId());
			 
			 if (PurchaseOrderItemDTO.getItemRate()!=null && PurchaseOrderItemDTO.getQuantity()!=null) {
				 
				 purchaseOrderItem.setAmount(PurchaseOrderItemDTO.getQuantity() * PurchaseOrderItemDTO.getItemRate());
				 
			//	 itemBaseAmount = PurchaseOrderItemDTO.getQuantity() * PurchaseOrderItemDTO.getItemRate();
			//	 itemProfitMargin = itemBaseAmount*(purchaseOrderDTO.getProfitMargin()/100);
			//	 purchaseOrderItem.setAmount(itemBaseAmount+itemProfitMargin);
				 
				/* if (purchaseOrderDTO.getProfitMargin()==null) {
					 itemBaseAmount = PurchaseOrderItemDTO.getQuantity() * PurchaseOrderItemDTO.getItemRate();
					 purchaseOrderItem.setAmount(itemBaseAmount);
				 }
				 
				 if (purchaseOrderDTO.getProfitMargin()!=null && purchaseOrderEntity.getProfitMargin()==null) {
					 
					 
						 purchaseOrderItem.setAmount(itemBaseAmount+(itemBaseAmount*purchaseOrderDTO.getProfitMargin()/100));
					 
				 }
				 
				 if (purchaseOrderDTO.getProfitMargin()!=null && purchaseOrderEntity.getProfitMargin()!=null) {
					 
					 if (purchaseOrderDTO.getProfitMargin()!=purchaseOrderEntity.getProfitMargin()) {
						 purchaseOrderItem.setAmount(itemBaseAmount+(itemBaseAmount*purchaseOrderDTO.getProfitMargin()/100));
					 }
				 }*/
				 orderTotal = orderTotal+purchaseOrderItem.getAmount();
			 
		 }
			 purchaseOrderItemRepository.save(purchaseOrderItem);
			 
			 	Item itemIdFromDB = itemRepository.findByItemId(purchaseOrderItem.getItemId());
		 		if (itemIdFromDB.getItemRate()!=null) {
		 		Double itemRate = itemIdFromDB.getItemRate();
		 		itemIdFromDB.setItemRate(purchaseOrderItem.getItemRate());
		 		itemIdFromDB.setDepartmentId(purchaseOrderItem.getDepartmentId());
		 		}
		 		
			 
		 }
		 
		 purchaseOrderEntity.setInstallmentNumber(purchaseOrderDTO.getInstallmentNumber());
		
		 if (purchaseOrderDTO.getProfitMargin()!=null) {
			 purchaseOrderEntity.setProfitMargin(purchaseOrderDTO.getProfitMargin());
				
			}
			
	
		 purchaseOrderEntity.setTotal(orderTotal);
		// purchaseOrderEntity.setTotalAmount(totalAmount);
		 purchaseOrderRepository.save(purchaseOrderEntity);
		 
		 List<Long> purchaseOrderIds= new ArrayList<Long>();
		 purchaseOrderIds.add(purchaseOrderId);
		 
		 List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIds);
		 PurchaseOrderItemDetailDTO purchaseOrderdetail =purchaseOrderdetails.get(0);
		 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
		 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
		 			model.addAttribute("monthOfPurchase", purchaseOrderdetail.getMonthOfPurchase());
					model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
					model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
					model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
					model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
					model.addAttribute("purchaseOrderdetails", purchaseOrderdetails);
		 
		 return "saveeditpurchaseordersuccess";
	 }
	 
	 
	 @GetMapping("/showclosepurchaseorder/{orderId}")
	 public String showClosePurchaseOrder(@PathVariable("orderId") long orderId, HttpServletResponse response,
				HttpServletRequest request, Model model) throws Exception {
		 
		 System.out.println("Printing in showclosepurchaseorder");
		 
		 List<Long> purchaseOrderIdsForInstitutionReport= new ArrayList<Long>();
		 purchaseOrderIdsForInstitutionReport.add(orderId);
		 List<PurchaseOrderItemDetailDTO> purchaseOrderdetailsForInstitutionReport = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIdsForInstitutionReport);
		 
		 Set<Long> institutionIds = new HashSet<>();
		 for (PurchaseOrderItemDetailDTO item : purchaseOrderdetailsForInstitutionReport ) {
			 institutionIds.add(item.getInstitutionId());
		 }
		 
		 List items = new ArrayList<>();

		 for (Long item : institutionIds) {
		 	 System.out.println("Printing Quotation Ids" + item.toString());
		 	// List<Long> institutionId= new ArrayList<Long>();
		 //	institutionId.add(item);
		 	 List<PurchaseOrderItemDetailDTO> institutionBillingReport = populateOrderScreenService.findPurchaseOrderItemDetailsByInstitutionId(purchaseOrderIdsForInstitutionReport,item);
		 	 items.add(institutionBillingReport);
		 }

		 
		 	Long orderID = Long.valueOf(orderId);
		 	 List<Long> purchaseOrderIds= new ArrayList<Long>();
			 purchaseOrderIds.add(orderID);
		 	
		 PurchaseOrder purchaseOrderEntity = purchaseOrderRepository.findById(orderID);
		 purchaseOrderEntity.setStatus("complete");
		 purchaseOrderRepository.save(purchaseOrderEntity);
		 
		Set<Order> orders = purchaseOrderEntity.getOrders();
		for (Order order : orders) {
			order.setStatus("complete");
			orderRepository.save(order);
			
		}
		
		String monthOfPurchase = purchaseOrderEntity.getMonthOfPurchase();
		String installlmentNo = purchaseOrderEntity.getInstallmentNumber();
		LocalDate orderDate = purchaseOrderEntity.getStartDate();
		int orderYear = orderDate.getYear();
		List<OrderMasterDTO> quotations = populateOrderScreenService.findAllActiveQuotationOrder(orderYear,monthOfPurchase,installlmentNo);
		
		for (OrderMasterDTO item : quotations) {
			
			QuotationOrder qo = quotationOrderRepository.findById(Long.parseLong(item.getOrderId()));
			qo.setStatus("complete");
			quotationOrderRepository.save(qo);
		}
		
		
		
		
		 List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findClosedPurchaseOrderItemDetails(purchaseOrderIds);
		 
		
		 
		 
		 
		 
		 PurchaseOrderItemDetailDTO purchaseOrderdetail =purchaseOrderdetails.get(0);
		 			model.addAttribute("purchaseOrderId", purchaseOrderEntity.getId());
		 			model.addAttribute("orderDate", purchaseOrderEntity.getStartDate());
		 			model.addAttribute("monthOfPurchase", purchaseOrderEntity.getMonthOfPurchase());
					model.addAttribute("installmentNumber", purchaseOrderEntity.getInstallmentNumber());
					model.addAttribute("orderTotal", purchaseOrderEntity.getTotal());
					model.addAttribute("purchaseOrderdetails", purchaseOrderdetails);
					
					model.addAttribute("items", items);
		 return "closepurchaseorderandsendinstituionreport";
		// return "closepurchaseordersuccess";
	 }
	 
	 
	 @GetMapping("/showallcompletepurchaseorder")
		public String showAllCompletePurchaseOrder(Model model, HttpServletRequest request) throws Exception {

			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllCompletePurchaseOrders();
			System.out.println("Printing in showallcompletepurchaseorder and list size is " + OrderItemDTOActiveList.size());
			List<PurchaseOrderAndAssociatedOrderDTO> PurchaseOrderAndAssociatedOrdersForAllActivePurchaseOrder = populateOrderScreenService.findPurchaseOrderAndAssociatedOrdersForAllCompletePurchaseOrder();
			model.addAttribute("OrderItemDTOActiveList", PurchaseOrderAndAssociatedOrdersForAllActivePurchaseOrder);
			
			return "showallcompletepurchaseorder";
		}
	 
	 @GetMapping("/showcompletepurchaseorder/{orderId}")
	 public String showCompletePurchaseOrder(@PathVariable("orderId") long orderId, HttpServletResponse response,
				HttpServletRequest request, Model model) throws Exception {
		 
		 	Long orderID = Long.valueOf(orderId);
		 	 List<Long> purchaseOrderIds= new ArrayList<Long>();
			 purchaseOrderIds.add(orderID);
			 
			 	 List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findClosedPurchaseOrderItemDetails(purchaseOrderIds);
			 	 
			 	 System.out.println("printing purchaseOrderdetails size" + purchaseOrderdetails.size());
				  PurchaseOrderItemDetailDTO purchaseOrderdetail =purchaseOrderdetails.get(0);
		 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
		 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
					model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
					model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
					model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
					model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
					model.addAttribute("purchaseOrderdetails", purchaseOrderdetails);
		 
		 return "showcompletepurchaseorder";
	 }
		
	 
	 @GetMapping("/generatereport/{purchaseOrderId}") 
	 public String generateReport(@PathVariable("purchaseOrderId") long purchaseOrderId,Model model, HttpServletRequest request) throws Exception {
		 
		  List<Long> purchaseOrderIds= new ArrayList<Long>();
			 purchaseOrderIds.add(purchaseOrderId);
	        List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIds);
			 PurchaseOrderItemDetailDTO purchaseOrderdetail =purchaseOrderdetails.get(0);
			 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
			 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
						model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
						model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
						model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
						model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
						model.addAttribute("purchaseOrderdetails", purchaseOrderdetails);
						
						 HashSet<Long> institutionIds = new HashSet<>();
						 HashSet<Long> supplierIds = new HashSet<>();
						for (PurchaseOrderItemDetailDTO item : purchaseOrderdetails) {
							institutionIds.add(item.getInstitutionId());
							supplierIds.add(item.getDepartmentId());
							
						}
						
						List<Long> InstitutionIds= new ArrayList<Long>();
						List<Long> SupplierIds= new ArrayList<Long>();
						
						 Iterator<Long> Institutioniterator = institutionIds.iterator();
						 Iterator<Long> Supplieriterator1 = institutionIds.iterator();
						 
						 while (Institutioniterator.hasNext()) {
							 InstitutionIds.add(Institutioniterator.next());
						 }
						
						 while (Supplieriterator1.hasNext()) {
							 
							 SupplierIds.add(Supplieriterator1.next());
							 
						 }
						 System.out.println("Printing Supplier Ids" + SupplierIds);
						 SupplierIds.remove(Long.valueOf(1));
						 
						 System.out.println("Printing Supplier Ids" + SupplierIds);
						 
						 List<InstitutionDTO> institutionlist = new ArrayList<InstitutionDTO>();
						 
					//	 List<Institution> institutions = institutionRepository.findInstitutionByInstitutionList(InstitutionIds);
						 for (Long item : InstitutionIds) {
							 Institution institution = institutionRepository.findByInstitutionId(item.longValue());
							String institutionName = institution.getInstitutionName();
							InstitutionDTO institutionDTO = new InstitutionDTO();
							institutionDTO.setInstitutionId((int)(institution.getInstitutionId())); 
							institutionDTO.setInstitutionName(institutionName);
							institutionlist.add(institutionDTO);
						 }
						 
						 List<DepartmentDTO> departmentlist = new ArrayList<DepartmentDTO>(); 
					//	 List<Department> suppliers = departmentRepository.findDepartmentByDepartmentIdList(SupplierIds);
						 for (Long item : SupplierIds) {
							 
							 Department supplier = departmentRepository.findByDepartmentId(item.longValue());
							 if (supplier!=null) {
							String departmentName = supplier.getDepartmentName();
							 
							DepartmentDTO departmentDTO = new DepartmentDTO();
							departmentDTO.setDepartmentId((Long)(supplier.getDepartmentId())); 
							departmentDTO.setDepartmentName(departmentName);
							departmentlist.add(departmentDTO);
							 }
							 
							 
						 }
						 
		 List<DepartmentDTO> supplierDetails =  populateOrderScreenService.findAllDepartments();
		 model.addAttribute("supplierDetails", supplierDetails);
		
      
	// List<InstitutionDTO> institutionlist =  populateOrderScreenService.findAllInstitutions();
	 model.addAttribute("institutionlist", institutionlist);
	
		 return "showreport";
	 }
	 
	 
	 
	 @GetMapping("/generateitemreport/{purchaseOrderId}")
	 public String generateItemReport(@PathVariable("purchaseOrderId") long purchaseOrderId,Model model, HttpServletRequest request) throws Exception {
		 PurchaseOrder purchaseOrderEntity = purchaseOrderRepository.findById(purchaseOrderId);
		 List<PurchaseOrderItem> purchaseOrderItems = purchaseOrderEntity.getPurchaseOrderItems();
		 Set<Order> orders = purchaseOrderEntity.getOrders();
		 
			
		 	 List<Long> orderIds= new ArrayList<Long>();
			 
		 for (Order order: orders) {
			 orderIds.add(order.getId());
			 
		 }
		 List<Order> orderList = new ArrayList<>(orders);
		 
		 List<OrderItemDetailDTO> orderItemDetailDTOs = populateOrderScreenService.findOrderItemDetails(orderIds);
		 Map<String, ItemReportDTO> reportMap = new HashMap<>();

	        // Process each order
	        for (OrderItemDetailDTO orderItem : orderItemDetailDTOs) {
	        	System.out.println("Printing Order Item " + " -> Institution Name" + orderItem.getInstitutionName()+" -> Item Name" + orderItem.getItemName()+" -> Item Quantity" + orderItem.getQuantity());
	            reportMap.putIfAbsent(orderItem.getItemName(), new ItemReportDTO());
	            ItemReportDTO report = reportMap.get(orderItem.getItemName());

	            report.setItemName(orderItem.getItemName());
	            if (report.getInstitutionQuantities() == null) {
	                report.setInstitutionQuantities(new HashMap<>());
	            }

	            report.getInstitutionQuantities().putIfAbsent(orderItem.getInstitutionName(), 0.0);
	           // report.getInstitutionQuantities().put(orderItem.getInstitutionName(),
	                 //   report.getInstitutionQuantities().get(orderItem.getInstitutionName()) + orderItem.getQuantity());
	       
	            report.getInstitutionQuantities().put(orderItem.getInstitutionName(),
                 orderItem.getQuantity());
	            
	            System.out.println("Printing Insistution wise Item Quantity for Item " +report.getItemName() + "And for Institution " + orderItem.getInstitutionName()+ + report.getInstitutionQuantities().get(orderItem.getInstitutionName()));
	           
	          // report.getInstitutionQuantities().forEach( (k, v) -> { System.out.println(k + " -> " + v);
	           }

	        // Calculate total quantities
	        
	        List<ItemReportDTO> reportDTOs = new ArrayList<ItemReportDTO>();
	        
	        System.out.println("Printing reportMap.values()" + reportMap.values());;
	        for (ItemReportDTO report : reportMap.values()) {
	        	
	        	System.out.println("Printing Item Report Details"  + report.getInstitutionQuantities());
	            Double total = report.getInstitutionQuantities().values().stream().mapToDouble(Double::doubleValue).sum();
	            report.setTotalQuantity(total);
	            reportDTOs.add(report);
	            //report.getInstitutionQuantities().forEach( (k, v) -> { System.out.println(k + " -> " + v);
	        }
	        
	       // reportMap.forEach( (k, v) -> { System.out.println(k + " -> " + v.getItemName()+ " -> " + v.getTotalQuantity()); } );

	       // return new ArrayList<>(reportMap.values());
	        List<ItemReportDTO>  itemReportDTOs = new ArrayList<>(reportMap.values());
	        
	        List<String> institutions = getAllInstitutions();
	        
	        for (String institution: institutions) {
	        System.out.println("Printing Client Names" + institution);
	        }
	        
	        List<Long> purchaseOrderIds= new ArrayList<Long>();
			 purchaseOrderIds.add(purchaseOrderEntity.getId());
	        List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIds);
			 PurchaseOrderItemDetailDTO purchaseOrderdetail =purchaseOrderdetails.get(0);
			 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
			 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
						model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
						model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
						model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
						model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
						model.addAttribute("purchaseOrderdetails", purchaseOrderdetails);
	        model.addAttribute("report", reportDTOs);
	        model.addAttribute("institutions", institutions);
	        
	        return "showitemreportwithprint";
		 
		 
		
		 
	 }
	 
	 
	 
	 
	 public List<String> getAllInstitutions() {
	        // Fetch unique client names from orders
	        return populateOrderScreenService.findAllInstitutions().stream()
	                .map(InstitutionDTO::getInstitutionName)
	                .distinct()
	                .sorted()
	                .toList();
	    }
	 
	 
	 
	 @GetMapping("/showsupplierlist/{purchaseOrderId}")
	 public String showSupplierList(@PathVariable("purchaseOrderId") long purchaseOrderId,Model model, HttpServletRequest request) throws Exception {
		  List<Long> purchaseOrderIds= new ArrayList<Long>();
			 purchaseOrderIds.add(purchaseOrderId);
	        List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIds);
			 PurchaseOrderItemDetailDTO purchaseOrderdetail =purchaseOrderdetails.get(0);
			 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
			 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
						model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
						model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
						model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
						model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
						model.addAttribute("purchaseOrderdetails", purchaseOrderdetails);
		 List<DepartmentDTO> supplierDetails =  populateOrderScreenService.findAllDepartments();
		 model.addAttribute("supplierDetails", supplierDetails);
		 return "showsupplierlist";
	 }
	 
	 
	 @GetMapping("/generatesupplierreport")
	 public String generateSupplierReport(Model model, HttpServletRequest request) throws Exception {
		 long purchaseOrderId = Long.parseLong(request.getParameter("purchaseOrderId"));
			long departmentId = Long.parseLong(request.getParameter("departmentId"));
		  List<Long> purchaseOrderIds= new ArrayList<Long>();
		  purchaseOrderIds.add(purchaseOrderId);
		  List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIds);
			 PurchaseOrderItemDetailDTO purchaseOrderdetail =purchaseOrderdetails.get(0);
			 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
			 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
						model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
						model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
						model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
						model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
		  List<PurchaseOrderItemDetailDTO> supplierreportdeatils = populateOrderScreenService.findPurchaseOrderItemDetailsBySupplierId(purchaseOrderIds,departmentId);
		  
		  Set<Long> itemIdsOfSelectedOrders = new HashSet<>();
		  for (PurchaseOrderItemDetailDTO orderItem :supplierreportdeatils) {
			  itemIdsOfSelectedOrders.add(orderItem.getItemId());
		  }
		  List<PurchaseOrderItemDetailDTO>  PurchaseOrderItemDetailDTOs = new ArrayList<PurchaseOrderItemDetailDTO>();
		  for (Long itemId : itemIdsOfSelectedOrders) {
			  PurchaseOrderItemDetailDTO purchaseOrderItemDetailDTO = new PurchaseOrderItemDetailDTO();
			  purchaseOrderItemDetailDTO.setItemId(itemId);
			  
			  PurchaseOrderItemDetailDTOs.add(purchaseOrderItemDetailDTO);
				  }
				 
				 
				  for (PurchaseOrderItemDetailDTO orderItem :supplierreportdeatils) {
					 
					// System.out.println("Printing order item Record" + orderItem.toString());
					 for ( PurchaseOrderItemDetailDTO purchaseOrderItemDetailDTO :PurchaseOrderItemDetailDTOs) {
						// System.out.println("Printing Purchase order item Record" + purchaseOrderItem.toString());
						 
						 if (orderItem.getItemId() == purchaseOrderItemDetailDTO.getItemId()) {
							 System.out.println("OrderItem Quantity" + orderItem.getQuantity());
							 System.out.println("Quotation Order item Quantity" + purchaseOrderItemDetailDTO.getQuantity());
							 
							 if (orderItem.getQuantity()!=null) {
								 
								 if (purchaseOrderItemDetailDTO.getQuantity()!=null) {
									 purchaseOrderItemDetailDTO.setQuantity(purchaseOrderItemDetailDTO.getQuantity() + orderItem.getQuantity());
									 purchaseOrderItemDetailDTO.setUnitId(orderItem.getUnitId());
									 purchaseOrderItemDetailDTO.setUnitName(orderItem.getUnitName());
							 } else {
								 purchaseOrderItemDetailDTO.setQuantity(orderItem.getQuantity());
								 purchaseOrderItemDetailDTO.setUnitId(orderItem.getUnitId());
								 purchaseOrderItemDetailDTO.setUnitName(orderItem.getUnitName());
							 }
							 }
							 purchaseOrderItemDetailDTO.setItemName(orderItem.getItemName());
							 System.out.println("OrderItem Quantity" + orderItem.getQuantity());
							 System.out.println("Quotation Order item Quantity" + purchaseOrderItemDetailDTO.getQuantity());
							// purchaseOrderItem.setPurchaseOrder(purchaseOrder);
							// purchaseOrderItemRepository.save(purchaseOrderItem);
						 }
					 }
				  }
					 
					 
			model.addAttribute("supplierreportdeatils", PurchaseOrderItemDetailDTOs);
			 Department DepartmentEntity = departmentRepository.findByDepartmentId(departmentId);
			 String departmentName = DepartmentEntity.getDepartmentName();
			 model.addAttribute("departmentName", departmentName);
		  return "showsupplierreport";
	 }
	 
	 
	 @GetMapping("/showinstitutionlist/{purchaseOrderId}")
	 public String showInstitutionList(@PathVariable("purchaseOrderId") long purchaseOrderId,Model model, HttpServletRequest request) throws Exception {
		  List<Long> purchaseOrderIds= new ArrayList<Long>();
			 purchaseOrderIds.add(purchaseOrderId);
	        List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIds);
			 PurchaseOrderItemDetailDTO purchaseOrderdetail =purchaseOrderdetails.get(0);
			 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
			 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
						model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
						model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
						model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
						model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
						model.addAttribute("purchaseOrderdetails", purchaseOrderdetails);
		 List<InstitutionDTO> institutionlist =  populateOrderScreenService.findAllInstitutions();
		 model.addAttribute("institutionlist", institutionlist);
		 return "showinstitutionlist";
	 }
	 
	 
	 @GetMapping("/generateinstitutionreport")
	 public String generateInstitutionReport(Model model, HttpServletRequest request) throws Exception {
		 long purchaseOrderId = Long.parseLong(request.getParameter("purchaseOrderId"));
			long institutionId = Long.parseLong(request.getParameter("institutionId"));
			
			  List<Long> purchaseOrderIds= new ArrayList<Long>();
			  purchaseOrderIds.add(purchaseOrderId);
			
			 PurchaseOrder purchaseOrderEntity = purchaseOrderRepository.findById(purchaseOrderId);
			 List<PurchaseOrderItem> purchaseOrderItems = purchaseOrderEntity.getPurchaseOrderItems();
			 Set<Order> orders = purchaseOrderEntity.getOrders();
			 
				
			 	 List<Long> orderIds= new ArrayList<Long>();
				 
			 for (Order order: orders) {
				 
				 Order orderEntity = orderRepository.findById(order.getId());
				if (orderEntity.getInstitutionId()==institutionId) {
				 orderIds.add(order.getId());
				}
				 
			 }
			 List<Order> orderList = new ArrayList<>(orders);
			 
			 List<PurchaseOrderItemDetailDTO> institutionreportdeatils = populateOrderScreenService.findPurchaseOrderItemDetailsByInstitutionId(purchaseOrderIds,institutionId);
			 Institution InstitutionEntity = institutionRepository.findByInstitutionId(institutionId);
			 String institutionName = InstitutionEntity.getInstitutionName();
			 
		//  List<Long> purchaseOrderIds= new ArrayList<Long>();
		//  purchaseOrderIds.add(purchaseOrderId);
		  List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIds);
		  
		  DecimalFormat df = new DecimalFormat("0.00");
		    int ITEMS_PER_PAGE = 16; 
			double billtotallong = purchaseOrderEntity.getTotal();
			String amountinwords = "(Rupees in words  " + ConvertNumberToWords.numberToWords((long)billtotallong) + " only)";
			//Date billDate = purchaseOrderEntity.getEndDate();
			Date billDate = new Date();
			int billDateYear = YearMonth.now().getYear();
			String billDateYearStr = Integer.toString(billDateYear);
			String lastTwoDigitsOfbillDateYear = billDateYearStr.substring(2, 4);
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			
			String strDate = formatter.format(billDate);
			int totalNoofRows = 12;
			int orderdetailsize = institutionreportdeatils.size();
			
					
			int totalItems =institutionreportdeatils.size();
			int totalPages = (int) Math.ceil((double) totalItems / ITEMS_PER_PAGE);
			
			 List<List<PurchaseOrderItemDetailDTO>> orderItemPages = new ArrayList<>();
		        for (int i = 0; i < totalPages; i++) {
		            int start = i * ITEMS_PER_PAGE;
		            int end = Math.min(start + ITEMS_PER_PAGE, totalItems);
		            orderItemPages.add(institutionreportdeatils.subList(start, end));
		        }
		        
		        int sizeOFLastPage = 0;
		    
		        		List<PurchaseOrderItemDetailDTO> orderItemPage = orderItemPages.get(orderItemPages.size()-1);
		        		sizeOFLastPage = orderItemPage.size();
		        
		        int noOfEmptySpacesToBeAdded = ITEMS_PER_PAGE - sizeOFLastPage;
		        
		        
			 PurchaseOrderItemDetailDTO purchaseOrderdetail =purchaseOrderdetails.get(0);
			 
			  			model.addAttribute("orderItemPages", orderItemPages);
			  			model.addAttribute("lastTwoDigitsOfbillDateYear",lastTwoDigitsOfbillDateYear);
			  			model.addAttribute("billTotal",df.format(Math.round(billtotallong))); 
			  			model.addAttribute("amountinwords", amountinwords);
						model.addAttribute("noOfEmptySpacesToBeAdded", noOfEmptySpacesToBeAdded);
						model.addAttribute("date", strDate);
						model.addAttribute("pageSize", totalPages);
						model.addAttribute("itemperpage", ITEMS_PER_PAGE);
			    
			 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
			 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
						model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
						model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
						model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
						model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
						model.addAttribute("institutionName", institutionName);
		//  List<PurchaseOrderItemDetailDTO> institutionreportdeatils = populateOrderScreenService.findPurchaseOrderItemDetailsBySupplierId(purchaseOrderIds,departmentId);
			model.addAttribute("institutionreportdeatils", institutionreportdeatils);
			
			Map<String, Object> data = new HashMap<>();
			data.put("purchaseOrderdetail", purchaseOrderdetail);
			data.put("institutionreportdeatils", institutionreportdeatils);

			request.getSession().setAttribute("orderdownload", data);
			
			request.getSession().setAttribute("institutionreportdeatils", institutionreportdeatils);
			//request.getSession().setAttribute("orderdetail", orderdetails);
			 
		  return "showinstitutionreportwithpagebreak";
	 }
	 
	 
	 
	 @GetMapping("/exportpdfusingopenpdf")
	    public void exportToPDF(HttpServletResponse response, HttpServletRequest request) throws DocumentException, IOException {
	        response.setContentType("application/pdf");
	        List<PurchaseOrderItemDetailDTO> institutionreportdeatils =  (List<PurchaseOrderItemDetailDTO>)request.getSession().getAttribute("institutionreportdeatils");
	        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
	        String currentDateTime = dateFormatter.format(new Date());
	         
	        String headerKey = "Content-Disposition";
	        String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
	        response.setHeader(headerKey, headerValue);
	         
	      //  List<User> listUsers = service.listAll();
	         
	        UserPDFExporter exporter = new UserPDFExporter(institutionreportdeatils);
	       exporter.export(response);
	         
	    }
	 
	 @GetMapping("/downloadorderdetailspdf")
		public void downloadOrderdetailsPDF(HttpServletResponse response, HttpServletRequest request) throws IOException {
			Map orderdetailsforpdf = (Map) request.getSession().getAttribute("orderdownload");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
			String currentDateTime = dateFormatter.format(new Date());
			request.getSession().removeAttribute("orderdownload");
			PDFThymeleafExampleModified thymeleaf2Pdf = new PDFThymeleafExampleModified();
			ByteArrayInputStream exportedData = thymeleaf2Pdf.exportPdfFile("showinstitutionreporttemplate", orderdetailsforpdf);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=orderdetail_" + currentDateTime + ".pdf");
			IOUtils.copy(exportedData, response.getOutputStream());

		}
	 
	 @GetMapping("/exportpdffileusingopenhtmltopdf")
		public void exportPdFFileUsingOpenHTMLToPDF(HttpServletResponse response, HttpServletRequest request) throws IOException {
			Map orderdetailsforpdf = (Map) request.getSession().getAttribute("orderdownload");
			
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
			String currentDateTime = dateFormatter.format(new Date());
			request.getSession().removeAttribute("orderdownload");
			OpenHTMLToPDF OpenHTMLToPDF = new OpenHTMLToPDF();
			//ByteArrayInputStream exportedData = OpenHTMLToPDF.exportPdfFileUsingOpenHTMLToPDF("showinstitutionreporttemplate", orderdetailsforpdf);
		    OpenHTMLToPDF.exportPdfFileUsingOpenHTMLToPDF("showinstitutionreporttemplate", orderdetailsforpdf);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=orderdetail_" + currentDateTime + ".pdf");
		//	IOUtils.copy(exportedData, response.getOutputStream());

		}
	 
	 
	 @GetMapping("/downloadsupplierpdf")
		public void downloadSupplierPDF(HttpServletResponse response, HttpServletRequest request) throws IOException {
		 System.out.println("Printing in downloadsupplierpdf");
			Map orderdetailsforpdf = (Map) request.getSession().getAttribute("quotationdownload");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
			String currentDateTime = dateFormatter.format(new Date());
			request.getSession().removeAttribute("quotationdownload");
			PDFThymeleafExampleModified thymeleaf2Pdf = new PDFThymeleafExampleModified();
			ByteArrayInputStream exportedData = thymeleaf2Pdf.exportPdfFile("showsupplierquotationrequest", orderdetailsforpdf);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=orderdetail_" + currentDateTime + ".pdf");
			IOUtils.copy(exportedData, response.getOutputStream());

		}
	 
	 
	
	
	 @GetMapping("/showallactivepurchaseorderforupdatingorderitemrate")
		public String showAllActivePurchaseOrderForUpdatingOrderItemRate(Model model, HttpServletRequest request) throws Exception {
		 LocalDate currentDate = LocalDate.now();

	        // Get the start and end of the current month
	        YearMonth currentMonth = YearMonth.from(currentDate);
	        LocalDate startOfMonth = currentMonth.atDay(1); // First day of the current month
	        LocalDate endOfMonth = currentMonth.atEndOfMonth(); // Last day of the current month

	        // Define your custom date ranges within the current month
	        LocalDate startDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1); // First start date
	        LocalDate endDate1 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 15); // First end date

	        LocalDate startDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 16); // Second start date
	        
	        YearMonth yearMonth = YearMonth.from(currentDate);
	        int daysInCurrentMonth = yearMonth.lengthOfMonth();
	        
	        LocalDate endDate2 = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), daysInCurrentMonth); // First end date
	        // Define the variable to populate
	        String result = "";
	        String installmentNo= null;
	        String monthOfPurchase=null;
	        int currentYear = currentDate.getYear();
	        // Check if the current date is between the first range
	        if (!currentDate.isBefore(startDate1) && !currentDate.isAfter(endDate1)) {
	        	monthOfPurchase= LocalDate.now().getMonth().toString();
	            
	            result = "Value for first date range";
	            installmentNo = "2nd Installment";
	            
	        }
	        // Check if the current date is between the second range
	        else if (!currentDate.isBefore(startDate2) && !currentDate.isAfter(endDate2)) {
	        	LocalDate nextMonth = LocalDate.now().plusMonths(1);
	            
	            // Format next month to a string (e.g., "FEBRUARY")
	            String nextMonthStr = nextMonth.getMonth().toString();
	            monthOfPurchase = nextMonthStr;
	            installmentNo = "Ist Installment";
	            result = "Value for second date range";
	        }
	        // If the current date doesn't fall within any range
	        else {
	            result = "Date is not in any range";
	            installmentNo = "0";
	        }
			
	        
	        System.out.println("Printing Month Of Purchase and Installment No" + monthOfPurchase + " Installment no" + installmentNo );
				//List<OrderMasterDTO> quotations = populateOrderScreenService.findAllActiveQuotationOrder(currentYear,monthOfPurchase,installmentNo);

			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActivePurchaseOrders(currentYear,monthOfPurchase,installmentNo);
			
			model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
			
			return "showallactivepurchaseorderforupdatingorderitemrate";
		}
	 
	 @GetMapping("/showupdateorderitemrate/{orderId}")
	 public String showUpdateOrderItemRate(@PathVariable("orderId") long orderId, HttpServletResponse response,
				HttpServletRequest request, Model model) throws Exception {
		 
		 System.out.println("Printing Purchase Order Id from showupdateorderitemrate" + orderId);
		 List<Long> purchaseOrderIds= new ArrayList<Long>();
		 purchaseOrderIds.add(orderId);
		 List<PurchaseOrderAndAssociatedOrderDTO> PurchaseOrderAndAssociatedOrdersDTO = populateOrderScreenService.findPurchaseOrderAndAssociatedOrders(purchaseOrderIds);
		 
		 List<Long> orderIds= new ArrayList<Long>();
		 for (PurchaseOrderAndAssociatedOrderDTO item :PurchaseOrderAndAssociatedOrdersDTO) {
			 
			 System.out.println("Printing Order Id from showupdateorderitemrate" + item.getPurchaseOrderOrderId());
			 orderIds.add(item.getPurchaseOrderOrderId());
		 }
		// List<PurchaseOrderItemDetailDTO> purchaseOrderdetails = populateOrderScreenService.findPurchaseOrderItemDetails(purchaseOrderIds);
		 
		// List<OrderItemDetailDTO> orderItemDetailDTOs = populateOrderScreenService.findOrderItemDetails(orderIds);
		 
		 PurchaseOrder purchaseOrderEntity = purchaseOrderRepository.findById(orderId);
	
		 
		 List<PurchaseOrderItem> purchaseOrderItems = purchaseOrderEntity.getPurchaseOrderItems();
		 
		 System.out.println("Printing Purchase Order Id " + purchaseOrderEntity.getId());
		 System.out.println("Printing Purchase Order Item Count " + purchaseOrderItems.size());
		 for (PurchaseOrderItem purchaseOrderItem : purchaseOrderItems) {
			
			
			 for (Long orderID : orderIds) {
				System.out.println("Printing Order Id " + orderID);
				
				Order orderEntity = orderRepository.findById(orderID);
				
				 System.out.println("Printing Order Id " + orderEntity.getId());
				 if (orderEntity!=null) {
					
				 List<OrderItem> orderItems = orderEntity.getOrderitems();
				 System.out.println("Printing Order Item Count " + purchaseOrderItems.size());
			 
			 for (OrderItem orderItem : orderItems) {
				 Double itemAmount = 0.0;
				 if (orderItem.getItemId() == purchaseOrderItem.getItemId()) {
					 System.out.println("Printing Order Item Id" + purchaseOrderItem.getItemId());
					 System.out.println("Printing Purchase Order Item Id" + purchaseOrderItem.getItemId());
					 System.out.println("Printing Purchase Order Item Rate" + purchaseOrderItem.getItemRate());
					 orderItem.setItemRate(purchaseOrderItem.getItemRate());
					 System.out.println("Printing Order Item Rate" + orderItem.getItemRate());
					 if (orderItem.getItemRate()!=null) {
					 itemAmount = orderItem.getQuantity()*orderItem.getItemRate();
					 orderItem.setAmount(itemAmount);
					 System.out.println("Printing Order Item Amount" + orderItem.getAmount());
					 }
					
					 orderItemRepository.save(orderItem);
					
					 
				 }
			 }
			 
			
				 
				
			 }
				 
				
			
			// purchaseOrderRepository.save(purchaseOrderEntity);
			 
			 
				
			 
		 }
			
			 
			 
		 }
		 
		 
		
		 
		 for (Long orderID : orderIds) {
			 Double orderTotal = 0.0;
			 Double profit =0.0;
			 Double totalAmount =0.0;
				Order orderEntity = orderRepository.findById(orderID);
				List<OrderItem> orderItems = orderEntity.getOrderitems();
				for (OrderItem orderItem : orderItems) {
					
					if (orderItem !=null) {
					orderTotal = orderTotal+orderItem.getAmount();
					}
				}
				
				 System.out.println("Printing Order Total" + orderTotal);
				 if (orderEntity.getProfitMargin()!=null) {
					 orderEntity.setProfitMargin(orderEntity.getProfitMargin());
						profit = orderEntity.getProfitMargin()/100*orderTotal;
						System.out.println("Printing Profit " + profit);
					}
				 
				 System.out.println("Printing Order Total" + orderTotal);
				 totalAmount = orderTotal+profit;
				 System.out.println("Printing Order Total Variable Value" + orderTotal);
				 orderEntity.setTotal(orderTotal);
				 System.out.println("Printing Order Total" + orderEntity.getTotal());
				 orderEntity.setTotalAmount(totalAmount);
				 orderRepository.save(orderEntity);
			 
		 }
		 
		
		 
		 List<OrderMasterDTO> orderMasterList = new ArrayList<OrderMasterDTO>();
		 for (Long OrderID : orderIds) {
			 SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
			// Order orderEntity = orderRepository.findById(OrderID);
			 List<Long> orderids= new ArrayList<Long>();
			 orderids.add(OrderID);
			 List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderids);
			 OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
			 
			 
			 model.addAttribute("orderId", orderMasterDTO.getOrderId());
				model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
				model.addAttribute("OrderDate", orderMasterDTO.getStartDate());
				model.addAttribute("installmentNumber", orderMasterDTO.getInstallmentNumber());
				model.addAttribute("orderTotal", orderMasterDTO.getTotal());
				model.addAttribute("profitmargin", orderMasterDTO.getProfitMargin());
				model.addAttribute("orderGrandTotal", orderMasterDTO.getTotalAmount());
			 orderMasterList.add(orderMasterDTO);
		 }
		 
		 
		 
		 PurchaseOrderAndAssociatedOrderDTO purchaseOrderdetail = PurchaseOrderAndAssociatedOrdersDTO.get(0);
		 			model.addAttribute("purchaseOrderId", purchaseOrderdetail.getPurchaseOrderId());
		 			model.addAttribute("orderDate", purchaseOrderdetail.getStartDate());
					model.addAttribute("installmentNumber", purchaseOrderdetail.getInstallmentNumber());
					model.addAttribute("orderTotal", purchaseOrderdetail.getTotal());
					model.addAttribute("profitmargin", purchaseOrderdetail.getProfitMargin());
					model.addAttribute("orderGrandTotal", purchaseOrderdetail.getTotalAmount());
					model.addAttribute("purchaseOrderdetails", purchaseOrderdetail);
					model.addAttribute("orderMasterList", orderMasterList);
		 
			
		 
		 return "updateassociatedordersofpurchaseorder";
	 }
	 
	 
	 @GetMapping("/showallactiveorderforbilling")

		public String showDraftBill(Model model) throws Exception {
			List<OrderSearchDTO> allOrderForBillDraftList = populateOrderScreenService.findAllOrderForBillDraft();
			OrderIdsForBilling orderIdsForBilling = new OrderIdsForBilling();
			model.addAttribute("allOrderForBillDraftList", allOrderForBillDraftList);
			return "showallactiveorderforbilling";
		}
	 
	 
	 
		
	private void populateDropDowns(Model model) {
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		List<ItemDTO> itemlist = populateOrderScreenService.findAllItems();
		model.addAttribute("items", itemlist);
		

	}
	
	
	@RequestMapping(value = { "/showcreateitemphase" }, method = RequestMethod.GET)
	public String showCreateItemPhase(Model model) {
		ItemPhaseDTO itemPhaseDTO = new ItemPhaseDTO();
		model.addAttribute("itemPhaseDTO", itemPhaseDTO);
		List<ItemPhaseDTO> itemphaselist = populateOrderScreenService.findAllItemPhase();
		model.addAttribute("itemphaselist", itemphaselist);
		return "createitemphase";
	}

	@PostMapping("/createitemphase")
	public String createItemPhase(@Valid @ModelAttribute("ItemPhaseDTO") ItemPhaseDTO itemPhaseDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String itemPhaseName = itemPhaseDTO.getItemPhaseName();

		if (bindingResult.hasErrors()) {

			return "createitemratephase";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			ItemPhase itemPhase = modelMapper.map(itemPhaseDTO, ItemPhase.class);
			 try {

			itemPhaseRepository.save(itemPhase);
			model.addAttribute("itemPhaseName", itemPhaseName);
			return "createitemphasesuccess";

		}catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Item Rate Phase Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Item Rate Phase Name must be unique.");
			redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.itemRatePhase",
					bindingResult);
			redirectAttributes.addFlashAttribute("itemRatePhase", itemPhase);

            return "redirect:/showcreateitemphase"; // Return to form with error message
        }
	}
	}
	
	@RequestMapping(value = { "/showcreateinstitution" }, method = RequestMethod.GET)
	public String showCreateInstituion(Model model) {
		InstitutionDTO institutionDTO = new InstitutionDTO();
		model.addAttribute("institutionDTO", institutionDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		return "createinstitution";
	}

	@PostMapping("/createinstitution")
	public String createInstitution(@Valid @ModelAttribute("institutionDTO") InstitutionDTO institutionDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String institutionName = institutionDTO.getInstitutionName();

		if (bindingResult.hasErrors()) {

			return "createinstitution";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			Institution institution = modelMapper.map(institutionDTO, Institution.class);
			 try {

				 Institution institutionEntity = institutionRepository.save(institution);
			model.addAttribute("institutionName", institutionName);
			
			UserDto userDTO = new UserDto();
			userDTO.setEmail(institutionDTO.getEmail());
			Long institutionId = institutionEntity.getInstitutionId();
			
			userDTO.setInstitutionId(Integer.parseInt(String.valueOf(institutionId)));
			
			userDTO.setFirstName(institutionDTO.getFirstName());
			userDTO.setLastName(institutionDTO.getLastName());
			userDTO.setPassword(institutionDTO.getPassword());
			userDTO.setRoles(institutionDTO.getRoles());
			GroceryUser existing = userService.findByEmail(userDTO.getEmail());
			
			System.out.println("Printing Role Name" + userDTO.getRoles());
			if (existing != null) {
				bindingResult.rejectValue("email", null, "There is already an account registered with that email");
			}
			if (bindingResult.hasErrors()) {
				model.addAttribute("user", userDTO);
			//	return "register";
				//return "register";
			}
			userService.saveUser(userDTO);
			//return "redirect:/register?success";
		return "createinstitutionsuccess";
			 }catch (DataIntegrityViolationException e) {
		            model.addAttribute("error", "Institution Name must be unique.");
		            redirectAttributes.addFlashAttribute("error", "Institution Name must be unique.");
					redirectAttributes.addFlashAttribute("institution", institution);

		            return "redirect:/showcreateinstitution"; // Return to form with error message
		        }


		}
	}

	@RequestMapping(value = { "/showeditinstitution" }, method = RequestMethod.GET)
	public String showEditinstitution(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<InstitutionDTO> institutionlist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionlist);

		return "showeditinstitution";

	}

	@RequestMapping(value = "/editinstitution", params = { "updateinstitution" })

	public String updateinstitution(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String institutionIdString = orderSearchBillingDTO.getInstitutionId();
		Integer institutionId = 0;
		if (!institutionIdString.isEmpty()) {
			institutionId = Integer.parseInt(orderSearchBillingDTO.getInstitutionId());
		}
		Institution institutionfromDB = institutionRepository.findByInstitutionId(institutionId);
		List<InstitutionDTO> institutionDetails = populateOrderScreenService.findInstitutionById(Long.parseLong(orderSearchBillingDTO.getInstitutionId()));
		InstitutionDTO institutionDetail = institutionDetails.get(0);
		String institutionName = institutionfromDB.getInstitutionName();
		InstitutionDTO institutionDTO = new InstitutionDTO();
		institutionDTO.setInstitutionName(institutionDetail.getInstitutionName());
		institutionDTO.setUserName(institutionDetail.getUserName());
		institutionDTO.setEmail(institutionDetail.getEmail());
		request.getSession().setAttribute("institutionId", institutionId);
		model.addAttribute("institutionDTO", institutionDTO);

		return "editinstitution";
	}

	@RequestMapping(value = { "/saveinstitution" }, method = RequestMethod.GET)
	public String saveinstitution(@ModelAttribute("institutionDTO") InstitutionDTO institutionDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer institutionId = (Integer) request.getSession().getAttribute("institutionId");
		Institution institutionfromDB = institutionRepository.findByInstitutionId(institutionId);
		institutionfromDB.setInstitutionName(institutionDTO.getInstitutionName());
		 try {
		institutionRepository.save(institutionfromDB);
		UserDto user = new UserDto();
		user.setEmail(institutionDTO.getEmail());
		user.setPassword(institutionDTO.getPassword());
		GroceryUser existing = userService.findByEmail(user.getEmail());
		userService.updatePassword(user);
		
		model.addAttribute("updatedinstitutionName", institutionDTO.getInstitutionName());
		return "editinstitutionupdatesuccess";
		 }
		catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Institution Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Institution Name must be unique.");
			

            return "redirect:/showeditinstitution"; // Return to form with error message
        }
		
	}

	@RequestMapping(value = "/editinstitution", params = { "deleteinstitution" })

	public String deleteInstitution(@ModelAttribute("institutionDTO") InstitutionDTO institutionDTO,
			BindingResult bindingResult, Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long institutionId = institutionDTO.getInstitutionId();
		Institution institutionfromDB = institutionRepository.findByInstitutionId(institutionId);
		String institutionName = institutionfromDB.getInstitutionName();
		institutionRepository.delete(institutionfromDB);
		model.addAttribute("deletedInstitutioneName", institutionName);
		

		return "editinstitutiondeletesuccess";
	}

	@RequestMapping(value = { "/showcreatedepartment" }, method = RequestMethod.GET)
	public String showCreateDepartment(Model model) {
		DepartmentDTO departmentDTO = new DepartmentDTO();
		model.addAttribute("departmentDTO", departmentDTO);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		return "createdepartment";
	}

	@PostMapping("/createdepartment")
	public String createDepartment(@Valid @ModelAttribute("departmentDTO") DepartmentDTO departmentDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String departmentName = departmentDTO.getDepartmentName();

		if (bindingResult.hasErrors()) {

			return "createdepartment";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			Department department = modelMapper.map(departmentDTO, Department.class);

			try {
			departmentRepository.save(department);
			model.addAttribute("departmentName", departmentName);
			return "createdepartmentsuccess";
			}catch (DataIntegrityViolationException e) {
	            model.addAttribute("error", "Department Name must be unique.");
	            redirectAttributes.addFlashAttribute("error", "Department Name must be unique.");
				

	            return "redirect:/showcreatedepartment"; // Return to form with error message
	        }


		}
	}

	@RequestMapping(value = { "/showeditdepartment" }, method = RequestMethod.GET)
	public String showEditDepartment(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);

		return "showeditdepartment";

	}

	@RequestMapping(value = "/editdepartment", params = { "updatedepartment" })

	public String updatedepartment(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String departmentIdString = orderSearchBillingDTO.getDepartmentId();
		Integer departmentId = 0;
		if (!departmentIdString.isEmpty()) {
			departmentId = Integer.parseInt(orderSearchBillingDTO.getDepartmentId());
		}
		Department departmentfromDB = departmentRepository.findByDepartmentId(departmentId);
		String departmentName = departmentfromDB.getDepartmentName();
		DepartmentDTO departmentDTO = new DepartmentDTO();
		departmentDTO.setDepartmentName(departmentName);
		request.getSession().setAttribute("departmentId", departmentId);
		model.addAttribute("departmentDTO", departmentDTO);

		return "editdepartment";
	}

	@RequestMapping(value = { "/savedepartment" }, method = RequestMethod.GET)
	public String saveinstitution(@ModelAttribute("departmentDTO") DepartmentDTO departmentDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer departmentId = (Integer) request.getSession().getAttribute("departmentId");
		Department departmentfromDB = departmentRepository.findByDepartmentId(departmentId);
		departmentfromDB.setDepartmentName(departmentDTO.getDepartmentName());
		 try {

		departmentRepository.save(departmentfromDB);
		model.addAttribute("updateddepartmentName", departmentDTO.getDepartmentName());

		return "editdepartmentupdatesuccess";
		 }catch (DataIntegrityViolationException e) {
	            model.addAttribute("error", "Department Name must be unique.");
	            redirectAttributes.addFlashAttribute("error", "Department Name must be unique.");
				

	            return "redirect:/showeditdepartment"; // Return to form with error message
	        }

	}

	@RequestMapping(value = "/editdepartment", params = { "deletedepartment" })

	public String deleteDepartment(@ModelAttribute("departmentDTO") DepartmentDTO departmentDTO,
			BindingResult bindingResult, Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long departmentId = departmentDTO.getDepartmentId();
		Department departmentfromDB = departmentRepository.findByDepartmentId(departmentId);
		String departmentName = departmentfromDB.getDepartmentName();
		departmentRepository.delete(departmentfromDB);
		model.addAttribute("deletedDepartmentName", departmentName);

		return "editdepartmentdeletesuccess";
	}
	
	
	

	@RequestMapping(value = { "/showedititemphase" }, method = RequestMethod.GET)
	public String showEditItemPhase(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<ItemPhaseDTO> itemphaselist = populateOrderScreenService.findAllItemPhase();
		model.addAttribute("itemphases", itemphaselist);

		return "showedititemphase";

	}



	
	
	@RequestMapping(value = "/edititemphase", params = { "updateitemphase" })

	public String editItemPhase(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String itemPhaseIdString = orderSearchBillingDTO.getItemPhaseId();
		Integer itemPhaseId = 0;
		if (!itemPhaseIdString.isEmpty()) {
			itemPhaseId = Integer.parseInt(orderSearchBillingDTO.getItemPhaseId());
		}
		ItemPhase itemPhasefromDB = itemPhaseRepository.findByItemPhaseId(itemPhaseId);
		String itemPhaseName = itemPhasefromDB.getItemPhaseName();
		ItemPhaseDTO itemPhaseDTO = new ItemPhaseDTO();
		itemPhaseDTO.setItemPhaseName(itemPhaseName);
		request.getSession().setAttribute("itemPhaseId", itemPhaseId);
		model.addAttribute("itemPhaseDTO", itemPhaseDTO);

		return "edititemphase";
	}
	
	@RequestMapping(value = { "/saveitemphase" }, method = RequestMethod.GET)
	public String saveItemRatePhase(@ModelAttribute("itemRatePhaseDTO") ItemPhaseDTO itemRatePhaseDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer itemPhaseId = (Integer) request.getSession().getAttribute("itemPhaseId");
		ItemPhase itemPhasefromDB = itemPhaseRepository.findByItemPhaseId(itemPhaseId);
		itemPhasefromDB.setItemPhaseName(itemRatePhaseDTO.getItemPhaseName());
		 try {

		itemPhaseRepository.save(itemPhasefromDB);
		model.addAttribute("updateditemPhaseName", itemPhasefromDB.getItemPhaseName());

		return "edititemphaseupdatesuccess";
	}catch (DataIntegrityViolationException e) {
        model.addAttribute("error", "Item Rate Phase Name must be unique.");
        redirectAttributes.addFlashAttribute("error", "Item Rate Phase Name must be unique.");
		

        return "redirect:/showedititemphase"; // Return to form with error message
    }
}


	@RequestMapping(value = "/edititemphase", params = { "deleteitemphase" })

	public String editItemRatePhase(@ModelAttribute("itemRatePhaseDTO") ItemPhaseDTO itemRatePhaseDTO,
			BindingResult bindingResult, Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long itemPhaseId = itemRatePhaseDTO.getItemPhaseId();
		ItemPhase itemPhasefromDB = itemPhaseRepository.findByItemPhaseId(itemPhaseId);
		String itemPhaseName = itemPhasefromDB.getItemPhaseName();
		itemPhaseRepository.delete(itemPhasefromDB);
		model.addAttribute("deletedItemPhaseName", itemPhaseName);

		return "edititemphasenamedeletesuccess";
	}

	
	
	@RequestMapping(value = { "/showcreateitem" }, method = RequestMethod.GET)
	public String showCreateItem(Model model) {
		ItemDTO itemDTO = new ItemDTO();
		model.addAttribute("itemDTO", itemDTO);
		List<ItemPhaseDTO> itemPhaseList = populateOrderScreenService.findAllItemPhase();
		System.out.println("Printing Size of Phase List"+ itemPhaseList.size());
		model.addAttribute("itemphases", itemPhaseList);
		List<ItemDTO> itemlist = populateOrderScreenService.findAllItems();
		model.addAttribute("items", itemlist);
		return "createitem";
	}

	@PostMapping("/createitem")
	public String createItem(@Valid @ModelAttribute("itemDTO") ItemDTO itemDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String itemName = itemDTO.getItemName();

		if (bindingResult.hasErrors()) {

			return "createitem";
		} else {

			//ModelMapper modelMapper = new ModelMapper();
		//	Item item = modelMapper.map(itemDTO, Item.class);
			
			Item item = new Item();
			item.setItemPhaseId(itemDTO.getPhaseId());
			item.setItemName(itemDTO.getItemName());
			item.setItemRate(itemDTO.getItemRate());
			 try {
			itemRepository.save(item);
			model.addAttribute("itemName", itemName);
			return "createitemsuccess";

		}catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Item Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Item Name must be unique.");
			

            return "redirect:/showcreateitem"; // Return to form with error message
        }
	}

	}

	@RequestMapping(value = { "/showedititem" }, method = RequestMethod.GET)
	public String showEditItemRate(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<ItemDTO> itemlist = populateOrderScreenService.findAllItems();
		model.addAttribute("items", itemlist);

		return "showedititem";

	}

	@RequestMapping(value = "/edititem", params = { "updateitem" })

	public String editItemRate(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String itemIdString = orderSearchBillingDTO.getItemId();
		Integer itemId = 0;
		if (!itemIdString.isEmpty()) {
			itemId = Integer.parseInt(orderSearchBillingDTO.getItemId());
		}
		Item itemFromDB = itemRepository.findByItemId(itemId);
		Long phaseId = itemFromDB.getItemPhaseId();
		String itemName = itemFromDB.getItemName();
		Double itemRate = itemFromDB.getItemRate();
		
		ItemDTO editItemDTO = new ItemDTO();
		editItemDTO.setPhaseId(phaseId);
		editItemDTO.setItemName(itemName);
		editItemDTO.setItemRate(itemRate);
		
		List<ItemPhaseDTO> itemPhaseList = populateOrderScreenService.findAllItemPhase();
		model.addAttribute("itemphases", itemPhaseList);
		request.getSession().setAttribute("itemId", itemId);
		model.addAttribute("editItemDTO", editItemDTO);

		return "edititem";
	}

	@RequestMapping(value = { "/saveitem" }, method = RequestMethod.GET)
	public String saveItem(@ModelAttribute("editItemDTO") ItemDTO editItemDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer itemId = (Integer) request.getSession().getAttribute("itemId");
		Item itemIdFromDB = itemRepository.findByItemId(itemId);
		itemIdFromDB.setItemPhaseId(editItemDTO.getPhaseId());
		itemIdFromDB.setItemName(editItemDTO.getItemName());
		itemIdFromDB.setItemRate(editItemDTO.getItemRate());
		
		 try {
		itemRepository.save(itemIdFromDB);
		model.addAttribute("updatedItemRateName", editItemDTO.getItemName());

		return "edititemupdatesuccess";
	}catch (DataIntegrityViolationException e) {
        model.addAttribute("error", "Item Name must be unique.");
        redirectAttributes.addFlashAttribute("error", "Item Name must be unique.");
		

        return "redirect:/showedititem"; // Return to form with error message
    }
}


	@RequestMapping(value = "/edititem", params = { "deleteitem" })

	public String editItem(@ModelAttribute("editItemDTO") ItemDTO editItemDTO,
			BindingResult bindingResult, Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long itemId = editItemDTO.getItemId();
		Item itemIdFromDB = itemRepository.findByItemId(itemId);
		String itemName = itemIdFromDB.getItemName();
		itemRepository.delete(itemIdFromDB);
		model.addAttribute("deletedItemName", itemName);

		return "edititemdeletesuccess";
	}

	@RequestMapping(value = { "/showitembatchupdate" }, method = RequestMethod.GET)
	public String showItemBatchUpdate(Model model) {
		System.out.println("Printing from welcome");
		// String orderId = orderSearchResultDTO.getOrderId();
		// long orderid = Long.parseLong(orderId);
		//List<ItemRateDTO> findAllItemRates = populateOrderScreenService.findAllItemRates();
		List<Item> itemEntity = itemRepository.findAll();
//		 List<ItemRateDTO> itemRatelist=new ArrayList<ItemRateDTO>();
		ItemBatchDTO itemBatchDTO = new ItemBatchDTO();
		itemEntity.forEach(item -> {
			ItemDTO itemDTO = new ItemDTO();
			itemDTO.setItemId(item.getItemId());
			itemDTO.setPhaseId(item.getItemPhaseId());
		//    itemRateDTO.setPhaseName(item.getPhaseName());
			itemDTO.setItemName(item.getItemName());
			itemDTO.setItemRate(item.getItemRate());
			itemBatchDTO.add(itemDTO);
		});
		List<ItemPhaseDTO> itemPhaseList = populateOrderScreenService.findAllItemPhase();
		model.addAttribute("itemphases", itemPhaseList);

		model.addAttribute("itemBatchDTO", itemBatchDTO);
		// model.addAttribute("itemRatelist", itemRatelist);

		return "showitembatchupdate";
	}

	@RequestMapping(value = { "/saveitembatchupdate" }, method = RequestMethod.POST)
	public String saveItemBatchUpdate(@ModelAttribute("itemBatchDTO") ItemBatchDTO itemRateBatchDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		List<ItemDTO> items = itemRateBatchDTO.getItems();
		System.out.println("Printing no of items from Rates list"+items.size());
		 try {
	           batchUpdate(itemRateBatchDTO);
	           List<ItemDTO> itemList = populateOrderScreenService.findAllItems();
	           //List<ItemPhaseDTO> itemList = populateOrderScreenService.findAllItemPhase();
	       	List<Item> itemFromDB = itemRepository.findAll();
			List<ItemDTO> itemDTOs = new ArrayList<ItemDTO>();
			itemList.forEach(item -> {
				ItemDTO itemDTO = new ItemDTO();
				itemDTO.setItemId(item.getItemId());
				itemDTO.setPhaseId(item.getPhaseId());
				itemDTO.setPhaseName(item.getPhaseName());
				itemDTO.setItemName(item.getItemName());
				itemDTO.setItemRate(item.getItemRate());
				itemDTOs.add(itemDTO);
			});
			model.addAttribute("itemlist", itemDTOs);
			return "showitembatchupdatesuccess";
	          //  return "redirect:/batchUpdate";  // On success, redirect back to the same page
	        } catch (DataIntegrityViolationException e) {
	            // On duplicate exception, add an error message to the redirect attributes
	            redirectAttributes.addFlashAttribute("error", e.getMessage());
	            return "redirect:/showitembatchupdate";  // Redirect to the batchUpdate page with error message
	        }
		

	
	}
	
	 @Transactional
	    public void batchUpdate(ItemBatchDTO itemBatchDTO) throws DataIntegrityViolationException {
		 List<ItemDTO> items = itemBatchDTO.getItems();
		 System.out.println("Printing item rates list size"+ items);
	        for (ItemDTO item : items) {
	        	if (item.getItemId() != null) {
	        		Item itemIdFromDB = itemRepository.findByItemId(item.getItemId());
	        		itemIdFromDB.setItemPhaseId(item.getPhaseId());
	        		itemIdFromDB.setItemName(item.getItemName());
	        		itemIdFromDB.setItemRate(item.getItemRate());
	        		
					  try {
			            	itemRepository.save(itemIdFromDB);
			            } catch (DataIntegrityViolationException e) {
			                // Propagate the exception to be handled in the controller
			                throw new DataIntegrityViolationException("A duplicate entry was found.");
			            }
	        	}
	          
	        }
	    }
	 
	 
	 
	 @RequestMapping(value = { "/showcreateunit" }, method = RequestMethod.GET)
		public String showCreateUnit(Model model) {
			UnitDTO unitDTO = new UnitDTO();
			model.addAttribute("unitDTO", unitDTO);
			List<UnitDTO> unitlist = populateOrderScreenService.findAllUnits();
			model.addAttribute("units", unitlist);
			return "createunit";
		}

		@PostMapping("/createunit")
		public String createUnit(@Valid @ModelAttribute("unitDTO") UnitDTO unitDTO, BindingResult bindingResult,
				Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

			String unitName = unitDTO.getUnitName();

			if (bindingResult.hasErrors()) {

				return "createunit";
			} else {

				ModelMapper modelMapper = new ModelMapper();
				Unit unit = modelMapper.map(unitDTO, Unit.class);
				 try {
				unitRepository.save(unit);
				model.addAttribute("unitName", unitName);
				return "createunitsuccess";

			}catch (DataIntegrityViolationException e) {
	            model.addAttribute("error", "Unit Name must be unique.");
	            redirectAttributes.addFlashAttribute("error", "Unit Name must be unique.");
				

	            return "redirect:/showcreateunit"; // Return to form with error message
	        }

		}
		}

		@RequestMapping(value = { "/showeditunit" }, method = RequestMethod.GET)
		public String showEditUnit(Model model) {

			System.out.println("Printing from welcome");
			OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
			model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
			List<UnitDTO> unitlist = populateOrderScreenService.findAllUnits();
			model.addAttribute("units", unitlist);

			return "showeditunit";

		}

		@RequestMapping(value = "/editunit", params = { "updateunit" })

		public String updateUnit(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
				BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
				throws Exception {

			System.out.println("In showOrderSearchResultForOrderEdit method");
			String unitIdString = orderSearchBillingDTO.getUnitId();
			Integer unitId = 0;
			if (!unitIdString.isEmpty()) {
				unitId = Integer.parseInt(orderSearchBillingDTO.getUnitId());
			}
			Unit unitfromDB = unitRepository.findByUnitId(unitId);
			String unitName = unitfromDB.getUnitName();
			UnitDTO unitDTO = new UnitDTO();
			unitDTO.setUnitName(unitName);
			request.getSession().setAttribute("unitId", unitId);
			model.addAttribute("unitDTO", unitDTO);

			return "editunit";
		}

		@RequestMapping(value = { "/saveunit" }, method = RequestMethod.GET)
		public String saveUnit(@ModelAttribute("unitDTO") UnitDTO unitDTO, BindingResult bindingResult, Model model,
				HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes) throws Exception {

			System.out.println("In showOrderSearchResultForOrderEdit method");

			Integer unitId = (Integer) request.getSession().getAttribute("unitId");
			Unit unitfromDB = unitRepository.findByUnitId(unitId);
			unitfromDB.setUnitName(unitDTO.getUnitName());
			 try {
			unitRepository.save(unitfromDB);
			model.addAttribute("updatedunitName", unitDTO.getUnitName());

			return "editunitupdatesuccess";
		}catch (DataIntegrityViolationException e) {
	        model.addAttribute("error", "Unit Name must be unique.");
	        redirectAttributes.addFlashAttribute("error", "Unit Name must be unique.");
			

	        return "redirect:/showeditunit"; // Return to form with error message
	    }
	}



		@RequestMapping(value = "/editunit", params = { "deleteunit" })

		public String deleteUnit(@ModelAttribute("unitDTO") UnitDTO unitDTO, BindingResult bindingResult, Model model)
				throws Exception {

			System.out.println("In showOrderSearchResultForOrderEdit method");
			long unitId = unitDTO.getUnitId();
			Unit unitfromDB = unitRepository.findByUnitId(unitId);
			String unitName = unitfromDB.getUnitName();
			unitRepository.delete(unitfromDB);
			model.addAttribute("deletedUnitName", unitName);

			return "editunitdeletesuccess";
		}
		
		@RequestMapping(value = { "/showitemsearchforitemratehistory" }, method = RequestMethod.GET)
		public String showitemsearchforitemratehistory(Model model) {

			System.out.println("Printing from welcome");
			OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
			model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
			List<ItemDTO> itemlist = populateOrderScreenService.findAllItems();
			model.addAttribute("items", itemlist);

			return "showitemsearchforitemratehistory";

		}
		
		@PostMapping("/showitemratehistory")
		public String showItemRateHistory(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
				BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
				throws Exception {

			System.out.println("In showOrderSearchResultForOrderEdit method");
			String itemIdString = orderSearchBillingDTO.getItemId();
			Integer itemId = 0;
			if (!itemIdString.isEmpty()) {
				itemId = Integer.parseInt(orderSearchBillingDTO.getItemId());
			}
			Item itemFromDB = itemRepository.findByItemId(itemId);
			Long phaseId = itemFromDB.getItemPhaseId();
			String itemName = itemFromDB.getItemName();
			Double itemRate = itemFromDB.getItemRate();
			
			ItemDTO editItemDTO = new ItemDTO();
			editItemDTO.setPhaseId(phaseId);
			editItemDTO.setItemName(itemName);
			editItemDTO.setItemRate(itemRate);
			
			List<PurchaseOrderItemDetailDTO> itemRateHistory = populateOrderScreenService.findPurchaseOrderItemDetailsByItemId(itemId);
			List<PurchaseOrderItemDetailDTO> itemRateHistoryList = new ArrayList<PurchaseOrderItemDetailDTO>();
			
	    Set<Long> purchaseOrderIdsWithItemIds = new HashSet<>();
			
			for (PurchaseOrderItemDetailDTO item : itemRateHistory) {
				
				System.out.println("Printing Item History : Item Name" + item.getItemName() + "Item rate :" + item.getItemRate() + "Purchase Id :" + item.getPurchaseOrderId());
				if (!purchaseOrderIdsWithItemIds.contains(item.getPurchaseOrderId())) {
					itemRateHistoryList.add(item);
				}
				
				purchaseOrderIdsWithItemIds.add(item.getItemId());
			}
			
			
			model.addAttribute("itemRateHistoryList", itemRateHistoryList);
		//	request.getSession().setAttribute("itemId", itemId);
			model.addAttribute("editItemDTO", editItemDTO);

			return "showitemratehistory";
		}


}
