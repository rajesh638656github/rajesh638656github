package com.grocerybilling.controller;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import java.util.Arrays;
import java.lang.Math;
import java.time.YearMonth;
import org.modelmapper.ModelMapper;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.dao.DataIntegrityViolationException;
//import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.transaction.annotation.Transactional;

import com.grocerybilling.registrationlogin.dto.UserDto;
import com.grocerybilling.registrationlogin.entity.User;
import com.grocerybilling.registrationlogin.service.UserService;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;

import java.time.LocalDate;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.text.*;
import java.util.HashSet;
import java.util.Iterator;
import jakarta.validation.Valid;

import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.validation.ConstraintValidatorFactory;
import jakarta.validation.Configuration;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintViolation;
import com.grocerybilling.service.PopulateOrderScreenService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import com.grocerybilling.registrationlogin.dto.UserDto;
import com.grocerybilling.registrationlogin.entity.User;
import com.grocerybilling.registrationlogin.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import com.grocerybilling.service.PopulateOrderScreenService;
import com.grocerybilling.model.*;
import com.grocerybilling.registrationlogin.dto.UserDto;
import com.grocerybilling.registrationlogin.entity.User;
import com.grocerybilling.registrationlogin.service.UserService;
//import com.grocerybilling.model.SizeDTO;

import com.grocerybilling.DTO.OrderDTO;
import com.grocerybilling.DTO.BillOrderDTO;
import com.grocerybilling.DTO.DepartmentDTO;
import com.grocerybilling.DTO.InstitutionDTO;
import com.grocerybilling.DTO.ItemDTO;
import com.grocerybilling.DTO.ItemPriceDTO;
import com.grocerybilling.DTO.ItemBatchDTO;
import com.grocerybilling.DTO.ItemDTO;
import com.grocerybilling.DTO.ItemStatusDTO;
import com.grocerybilling.DTO.ItemPhaseDTO;
import com.grocerybilling.DTO.OrderDTO;
import com.grocerybilling.DTO.OrderItemDTO;

import com.grocerybilling.DTO.OrderUpdateDTO;
import com.grocerybilling.DTO.PhaseNameDTO;
import com.grocerybilling.DTO.OrderItemUpdateDTO;
import com.grocerybilling.DTO.OrderMasterDTO;
import com.grocerybilling.DTO.OrderAddItemDTO;
import com.grocerybilling.DTO.OrderItemAddItemDTO;
import com.grocerybilling.DTO.SizeDTO;
import com.grocerybilling.DTO.UnitDTO;
import com.grocerybilling.DTO.OrderItemPriceDTO;
import com.grocerybilling.entity.*;
import com.grocerybilling.repository.*;
import com.grocerybilling.util.*;
import com.grocerybilling.util.ConvertNumberToWords;

import jakarta.servlet.http.HttpServletResponse;

import com.grocerybilling.util.PDFThymeleaf;
import com.lowagie.text.DocumentException;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import org.apache.commons.io.IOUtils;
import jakarta.servlet.ServletOutputStream;



@Controller
public class GroceryBillingController {
	SecurityContextLogoutHandler logoutHandler = new SecurityContextLogoutHandler();
	@Autowired
	private UserService userService;
	@Autowired
	private PopulateOrderScreenService populateOrderScreenService;
	@Autowired
	private InstitutionRepository institutionRepository;
	@Autowired
	private DepartmentRepository departmentRepository;
	@Autowired
	private ItemRepository itemRepository;
	
	@Autowired
	private ItemPhaseRepository itemPhaseRepository;
	
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private OrderItemRepository orderItemRepository;
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		System.out.println("Init Binder is invoked");

		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));

	}

	@RequestMapping(value = { "/welcome" }, method = RequestMethod.GET)
	public String showWelcome(Model model) {
		System.out.println("Printing from welcome");
		return "welcome";
	}
	
	@GetMapping("index")
	public String home() {
		return "index";
	}

	@GetMapping("/login")
	public String loginForm() {
		return "login";
	}

	@PostMapping("/my/logout")
	public String performLogout(Authentication authentication, HttpServletRequest request) {
		// .. perform logout
		// this.logoutHandler.doLogout(request, response, authentication);
		this.logoutHandler.setInvalidateHttpSession(true);
		return "redirect:/home";
	}

	@GetMapping("register")
	public String showRegistrationForm(Model model) {
		UserDto user = new UserDto();
		model.addAttribute("user", user);
		return "register";
	}


	@GetMapping("/update-password")
	public String updatePasswordForm(Model model) {
		UserDto user = new UserDto();
		model.addAttribute("user", user);
		return "update-password";
	}
	
	
	
	@PostMapping("/update-password")
	public String saveNewPassword(@ModelAttribute("user") UserDto user, BindingResult result, Model model) {
		 try {
			 System.out.println("Printing Email ID"+user.getEmail());
		User existing = userService.findByEmail(user.getEmail());
		//System.out.println("Printing existing user id" + existing.getEmail());
    	//System.out.println("Printing existing Password" + existing.getPassword());
		model.addAttribute("user", user);
	
		if (existing == null) {
            model.addAttribute("error", "New passwords do not match");
            return "update-password";
        }
			
		userService.updatePassword(user);
        model.addAttribute("message", "Password updated successfully");
    } catch (Exception e) {
        // Handles exceptions during password update process.
        model.addAttribute("error", e.getMessage());
    }
    return "redirect:/update-password?success";
}
		
		
	

	
	// handler method to handle register user form submit request
	@PostMapping("/register/save")
	public String registration(@Valid @ModelAttribute("user") UserDto user, BindingResult result, Model model) {
		User existing = userService.findByEmail(user.getEmail());
		if (existing != null) {
			result.rejectValue("email", null, "There is already an account registered with that email");
		}
		if (result.hasErrors()) {
			model.addAttribute("user", user);
			return "register";
		}
		userService.saveUser(user);
		return "redirect:/register?success";
	}

	@GetMapping("/users")
	public String listRegisteredUsers(Model model) {
		List<UserDto> users = userService.findAllUsers();
		model.addAttribute("users", users);
		return "users";
	}
	
	
	@GetMapping(value = { "/createorder" })

	public String createOrder(OrderDTO orderDTO, Model model) {
		List<Item> ItemEntityList = itemRepository.findAllByOrderByItemPhaseId();
		List<String> phaseNames = new ArrayList<String>();
		
		ItemEntityList.forEach(item -> {

			OrderItemDTO orderItemDTO = new OrderItemDTO();
			orderItemDTO.setItemIdDB(item.getItemId());
			orderItemDTO.setPhaseIdDB(item.getItemPhaseId());
			orderItemDTO.setItemNameDB(item.getItemName());
			orderItemDTO.setItemRate(item.getItemRate());
			orderDTO.add(orderItemDTO);
			

		}); 
		
		List<ItemPhaseDTO> itemPhaseList = populateOrderScreenService.findAllItemPhase();
		model.addAttribute("itemPhaseList", itemPhaseList);
		model.addAttribute("orderDTO", orderDTO);

		populateDropDowns(model);
		return "createorder";
	}
	
	
	
	 @PostMapping("/saveorder")
	public String saveOrder(@ModelAttribute("orderDTO") OrderDTO orderDTO,
			BindingResult bindingResult, HttpServletRequest request, Model model, RedirectAttributes redirectAttributes) {
		 
		 DecimalFormat df = new DecimalFormat("0.00");
		 Order order = new Order();
		 order.setInstitutionId(orderDTO.getInstitutionId());
		 order.setDepartmentId(orderDTO.getDepartmentId());
		 order.setProfitMargin(orderDTO.getProfitMargin());
		 orderRepository.save(order);
		 
		 Long OrderId = order.getId();
		 
		 System.out.println("printing newly created orderid "+ OrderId);
		 
		 
		 List<OrderItemDTO> OrderItemDTOs = orderDTO.getOrderItemDTOs();
		 
			
			Double orderTotal = 0.0;
			for (OrderItemDTO orderItemDTO : OrderItemDTOs) {

				if (orderItemDTO.getItemId() != 0) {
					System.out.println("Printing Rate Item Id" + orderItemDTO.getItemId());
					OrderItem orderItem = new OrderItem();
					orderItem.setItemId(orderItemDTO.getItemId());
					Item itemRateEntity = itemRepository.findByItemId(orderItemDTO.getItemId());

					Long phaseName = itemRateEntity.getItemPhaseId();
					double itemRate = orderItemDTO.getItemRate();
					long quantity = orderItemDTO.getQuantity();
				
					
					
					System.out.println("Printing Rate " + itemRate);
				
					System.out.println("Printing Phase Name " + phaseName);
					
					orderItem.setQuantity(orderItemDTO.getQuantity());
				
					orderItem.setItemRate(Double.parseDouble(df.format(orderItemDTO.getItemRate())));
					
					System.out.println("Printing Quantity " + quantity);
					double itemAmount = 0.0;
					itemAmount = quantity * itemRate;
					System.out.println("Printing Amount " + itemAmount);
					orderItem.setAmount(Double.parseDouble(df.format(itemAmount)));
					orderItem.setOrder(order);
					orderItemRepository.save(orderItem);
					orderTotal = orderTotal+itemAmount;
			
			}
			}
			
			Order orderEntity = orderRepository.findById(OrderId);
			
			List<Long> orderIds = new ArrayList<Long>();
			orderIds.add(Long.valueOf(OrderId));

			
			orderEntity.setTotal(Double.parseDouble(df.format(orderTotal)));
			Double profitMargin = orderEntity.getProfitMargin();
			Double profit = 0.0;
			if (orderTotal != null && profitMargin != null) {
				profit = profitMargin/100*orderTotal;
			}
			
			orderEntity.setProfitMargin(orderDTO.getProfitMargin());
			orderEntity.setTotalAmount(Double.parseDouble(df.format(orderTotal + profit)));
			
			orderRepository.save(orderEntity);
			
			List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIds);
			List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIds);
			
			OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
			
			model.addAttribute("orderId", orderMasterDTO.getOrderId());
			model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
			model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
			model.addAttribute("orderTotal", orderMasterDTO.getTotal());
			model.addAttribute("profitmargin", orderMasterDTO.getProfitMargin());
			model.addAttribute("orderGrandTotal", orderMasterDTO.getTotalAmount());
			model.addAttribute("orderdetails", orderdetails);
			
			
			
		 
		 return "saveordersuccess";
	}
	 
	 
	 @GetMapping("/showallactiveorderforedit")
		public String showAllActiveOrderForEdit(Model model, HttpServletRequest request) throws Exception {

			List<OrderMasterDTO> OrderItemDTOActiveList = populateOrderScreenService.findAllActiveOrders();
			model.addAttribute("OrderItemDTOActiveList", OrderItemDTOActiveList);
			
			return "showallactiveorderforedit";
		}

	 
	 @GetMapping("/showeditorder/{orderId}")
	 public String showEditOrder(@PathVariable("orderId") long orderId, HttpServletResponse response,
				HttpServletRequest request, Model model) throws Exception {
		 
		 	Long orderID = orderId;
		 	
		 Order order = orderRepository.findById(orderID);
			
			
			
			List<OrderItemDTO> OrderItemDBDTOs = new ArrayList<OrderItemDTO>();
			List<OrderItem> orderItemEntityList = order.getOrderitems();
			orderItemEntityList.forEach(item -> {
				OrderItemDTO orderItemDTO = new OrderItemDTO();
				orderItemDTO.setOrderItemId(item.getId());
				System.out.println("Printing Order Item Price ID" + orderItemDTO.getOrderItemId());
				orderItemDTO.setItemId(item.getItemId());
				System.out.println("Printing Item Rate ID" + orderItemDTO.getItemId());
				if (item.getItemRate()!=null) {
					orderItemDTO.setItemRate(item.getItemRate());
				}
				System.out.println("Printing Item Rate" + orderItemDTO.getItemRate());
				orderItemDTO.setQuantity(item.getQuantity());
				orderItemDTO.setAmount(item.getAmount());
				OrderItemDBDTOs.add(orderItemDTO);
			});
			
			
			OrderDTO orderDTO = new OrderDTO();;
			orderDTO.setId(order.getId());
			orderDTO.setInstitutionId(order.getInstitutionId());
			orderDTO.setDepartmentId(order.getDepartmentId());
			orderDTO.setTotal(order.getTotal());
			orderDTO.setProfitMargin(order.getProfitMargin());
			orderDTO.setTotalAmount(order.getTotalAmount());
			
			//List<ItemDTO> itemList = new ArrayList<ItemDTO>();
			List<Item> ItemEntityList = itemRepository.findAll();
			ItemEntityList.forEach(item -> {
			//	String phaseName = item.getItemRatePhaseName();
				OrderItemDTO orderItemDTO = new OrderItemDTO();
				orderItemDTO.setItemIdDB(item.getItemId());
			//	itemPriceDTO.setPhaseNameDB(item.getPhaseName());
				orderItemDTO.setPhaseIdDB(item.getItemPhaseId());
				orderItemDTO.setItemNameDB(item.getItemName());
				orderItemDTO.setItemRate(item.getItemRate());
				orderDTO.add(orderItemDTO);
			//	ItemPriceDTO itemPhaseName = new ItemPriceDTO();
				//itemPhaseName.setItemNameDB(item.getItemRatePhaseName());
				
			

				

			}); 
			
			

			List<ItemPhaseDTO> itemRatePhaseList = populateOrderScreenService.findAllItemPhase();

			


			//List<ItemPriceDTO> ItemPriceDTOs = itemPriceCalculation.getItemPriceDTOs();
			//int sizeOfItemPriceArray1 = ItemPriceDTOs.size();

			

			
			int i = 0;
			for (OrderItemDTO orderItemDTO : orderDTO.getOrderItemDTOs()) {
				System.out.println("Printing index" + i);
				i = i + 1;
				System.out.println("Iterating through Bean Collection" + orderItemDTO.getItemId() + "::::"
						+ orderItemDTO.getItemIdDB() + ":::" + orderItemDTO.getItemRate());

			}

			for (OrderItemDTO orderItemDTO : OrderItemDBDTOs) {

				long selectedRateId = orderItemDTO.getItemId();
				System.out.println("Printing Selected Rate Id from DataBase" + selectedRateId);
				int tableIndex = 0;

				// ItemRateEntityList.forEach(item-> {
				for (Item item : ItemEntityList) {

					if (item.getItemId() == selectedRateId) {
						break;

					}
					tableIndex = tableIndex + 1;

					System.out.println("Printing Item Rate Index" + tableIndex);
				}

				// });

				
				if (tableIndex >=0 && tableIndex < ItemEntityList.size()) {
					OrderItemDTO OrderItemDTO = orderDTO.getOrderItemDTOs().get(tableIndex);

				System.out.println("Printing Corresponding Rate Id from Bean " + OrderItemDTO.getItemIdDB());
				System.out.println(
						"Printing Corresponding Rate Id from Bean Befroe updating " + OrderItemDTO.getItemId());
				OrderItemDTO.setItemId(orderItemDTO.getItemId());
				System.out.println(
						"Printing Corresponding Rate Id from Bean After updating " + OrderItemDTO.getItemId());
			
				OrderItemDTO.setItemRate(orderItemDTO.getItemRate());
				OrderItemDTO.setQuantity(orderItemDTO.getQuantity());
				OrderItemDTO.setAmount(OrderItemDTO.getAmount());
				}
			}
			
			List<ItemPhaseDTO> itemPhaseList = populateOrderScreenService.findAllItemPhase();
			model.addAttribute("itemPhaseList", itemPhaseList);
			model.addAttribute("orderDTO", orderDTO);
			model.addAttribute("orderDTO", orderDTO);

			populateDropDowns(model);

		 
		 return"editorder";
	 
	 }
	 
	 
	 @PostMapping("/saveeditorder")
		public String saveEditOrder(@ModelAttribute("orderDTO") OrderDTO orderDTO,
				BindingResult bindingResult, @RequestParam("Id") Long orderId, HttpServletRequest request, Model model, RedirectAttributes redirectAttributes) {
		 DecimalFormat df = new DecimalFormat("0.00");
		 Order orderEntity = orderRepository.findById(orderId);
		 List<OrderItem> orderItems = orderEntity.getOrderitems();
		// orderItemRepository.deleteAll(orderItems);
		 populateOrderScreenService.deleteOrderItems(orderId);
		 
		 List<OrderItemDTO> orderItemDTOs = orderDTO.getOrderItemDTOs();
		 
			Double orderTotal = 0.0;
			for (OrderItemDTO orderItemDTO : orderItemDTOs) {

				if (orderItemDTO.getItemId() != 0) {
					System.out.println("Printing Rate Item Id" + orderItemDTO.getItemId());
					OrderItem orderItem = new OrderItem();
					orderItem.setItemId(orderItemDTO.getItemId());
					Item itemRateEntity = itemRepository.findByItemId(orderItemDTO.getItemId());

					Long phaseName = itemRateEntity.getItemPhaseId();
					double itemRate = orderItemDTO.getItemRate();
					long quantity = orderItemDTO.getQuantity();
				
					
					
					System.out.println("Printing Rate " + itemRate);
				
					System.out.println("Printing Phase Name " + phaseName);
					
					orderItem.setQuantity(orderItemDTO.getQuantity());
				
					orderItem.setItemRate(orderItemDTO.getItemRate());
					
					System.out.println("Printing Quantity " + quantity);
					double itemAmount = 0.0;
					itemAmount = quantity * itemRate;
					System.out.println("Printing Amount " + itemAmount);
					orderItem.setAmount(itemAmount);
					orderItem.setOrder(orderEntity);
					orderItemRepository.save(orderItem);
					orderTotal = orderTotal+itemAmount;
			
			}
			}
		 
			List<Long> orderIds = new ArrayList<Long>();
			orderIds.add(orderEntity.getId());

			
			orderEntity.setTotal(Double.parseDouble(df.format(orderTotal)));
			Double profitMargin = orderEntity.getProfitMargin();
			Double profit = 0.0;
			if (orderTotal != null && profitMargin != null) {
				profit = profitMargin/100*orderTotal;
			}
			
			orderEntity.setProfitMargin(orderDTO.getProfitMargin());
			orderEntity.setTotalAmount(Double.parseDouble(df.format(orderTotal + profit)));
			orderRepository.save(orderEntity);
			
			List<OrderMasterDTO> orderMasterdetails = populateOrderScreenService.findOrderMasterDetails(orderIds);
			List<OrderItemDetailDTO> orderdetails = populateOrderScreenService.findOrderItemDetails(orderIds);
			
			OrderMasterDTO orderMasterDTO = orderMasterdetails.get(0);
			
			model.addAttribute("orderId", orderMasterDTO.getOrderId());
			model.addAttribute("institutionName", orderMasterDTO.getInstitutionName());
			model.addAttribute("departmentName", orderMasterDTO.getDepartmentName());
			model.addAttribute("orderTotal", orderMasterDTO.getTotal());
			model.addAttribute("profitMargin", orderMasterDTO.getProfitMargin());
			model.addAttribute("orderGrandTotal", orderMasterDTO.getTotalAmount());
			model.addAttribute("orderdetails", orderdetails);
			
			
			
		 
		 return "saveeditordersuccess";
		 
	 
	 }
	 
	 
	 @GetMapping("/showallactiveorderforbilling")

		public String showDraftBill(Model model) throws Exception {
			List<OrderSearchDTO> allOrderForBillDraftList = populateOrderScreenService.findAllOrderForBillDraft();
			OrderIdsForBilling orderIdsForBilling = new OrderIdsForBilling();
			model.addAttribute("allOrderForBillDraftList", allOrderForBillDraftList);
			return "showallactiveorderforbilling";
		}
	 
	 
	 
		
	private void populateDropDowns(Model model) {
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		List<ItemDTO> itemlist = populateOrderScreenService.findAllItems();
		model.addAttribute("items", itemlist);
		

	}
	
	
	@RequestMapping(value = { "/showcreateitemphase" }, method = RequestMethod.GET)
	public String showCreateItemPhase(Model model) {
		ItemPhaseDTO itemPhaseDTO = new ItemPhaseDTO();
		model.addAttribute("itemPhaseDTO", itemPhaseDTO);
		List<ItemPhaseDTO> itemphaselist = populateOrderScreenService.findAllItemPhase();
		model.addAttribute("itemphaselist", itemphaselist);
		return "createitemphase";
	}

	@PostMapping("/createitemphase")
	public String createItemPhase(@Valid @ModelAttribute("ItemPhaseDTO") ItemPhaseDTO itemPhaseDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String itemPhaseName = itemPhaseDTO.getItemPhaseName();

		if (bindingResult.hasErrors()) {

			return "createitemratephase";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			ItemPhase itemPhase = modelMapper.map(itemPhaseDTO, ItemPhase.class);
			 try {

			itemPhaseRepository.save(itemPhase);
			model.addAttribute("itemPhaseName", itemPhaseName);
			return "createitemphasesuccess";

		}catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Item Rate Phase Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Item Rate Phase Name must be unique.");
			redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.itemRatePhase",
					bindingResult);
			redirectAttributes.addFlashAttribute("itemRatePhase", itemPhase);

            return "redirect:/showcreateitemphase"; // Return to form with error message
        }
	}
	}
	
	@RequestMapping(value = { "/showcreateinstitution" }, method = RequestMethod.GET)
	public String showCreateInstituion(Model model) {
		InstitutionDTO institutionDTO = new InstitutionDTO();
		model.addAttribute("institutionDTO", institutionDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		return "createinstitution";
	}

	@PostMapping("/createinstitution")
	public String createInstitution(@Valid @ModelAttribute("institutionDTO") InstitutionDTO institutionDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String institutionName = institutionDTO.getInstitutionName();

		if (bindingResult.hasErrors()) {

			return "createinstitution";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			Institution institution = modelMapper.map(institutionDTO, Institution.class);
			 try {

			institutionRepository.save(institution);
			model.addAttribute("institutionName", institutionName);
			return "createinstitutionsuccess";
			 }catch (DataIntegrityViolationException e) {
		            model.addAttribute("error", "Institution Name must be unique.");
		            redirectAttributes.addFlashAttribute("error", "Institution Name must be unique.");
					redirectAttributes.addFlashAttribute("institution", institution);

		            return "redirect:/showcreateinstitution"; // Return to form with error message
		        }


		}
	}

	@RequestMapping(value = { "/showeditinstitution" }, method = RequestMethod.GET)
	public String showEditinstitution(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<InstitutionDTO> institutionlist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionlist);

		return "showeditinstitution";

	}

	@RequestMapping(value = "/editinstitution", params = { "updateinstitution" })

	public String updateinstitution(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String institutionIdString = orderSearchBillingDTO.getInstitutionId();
		Integer institutionId = 0;
		if (!institutionIdString.isEmpty()) {
			institutionId = Integer.parseInt(orderSearchBillingDTO.getInstitutionId());
		}
		Institution institutionfromDB = institutionRepository.findByInstitutionId(institutionId);
		String institutionName = institutionfromDB.getInstitutionName();
		InstitutionDTO institutionDTO = new InstitutionDTO();
		institutionDTO.setInstitutionName(institutionName);
		request.getSession().setAttribute("institutionId", institutionId);
		model.addAttribute("institutionDTO", institutionDTO);

		return "editinstitution";
	}

	@RequestMapping(value = { "/saveinstitution" }, method = RequestMethod.GET)
	public String saveinstitution(@ModelAttribute("institutionDTO") InstitutionDTO institutionDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer institutionId = (Integer) request.getSession().getAttribute("institutionId");
		Institution institutionfromDB = institutionRepository.findByInstitutionId(institutionId);
		institutionfromDB.setInstitutionName(institutionDTO.getInstitutionName());
		 try {
		institutionRepository.save(institutionfromDB);
		model.addAttribute("updatedinstitutionName", institutionDTO.getInstitutionName());
		return "editinstitutionupdatesuccess";
		 }
		catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Institution Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Institution Name must be unique.");
			

            return "redirect:/showeditinstitution"; // Return to form with error message
        }
		
	}

	@RequestMapping(value = "/editinstitution", params = { "deleteinstitution" })

	public String deleteInstitution(@ModelAttribute("institutionDTO") InstitutionDTO institutionDTO,
			BindingResult bindingResult, Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long institutionId = institutionDTO.getInstitutionId();
		Institution institutionfromDB = institutionRepository.findByInstitutionId(institutionId);
		String institutionName = institutionfromDB.getInstitutionName();
		institutionRepository.delete(institutionfromDB);
		model.addAttribute("deletedInstitutioneName", institutionName);

		return "editinstitutiondeletesuccess";
	}

	@RequestMapping(value = { "/showcreatedepartment" }, method = RequestMethod.GET)
	public String showCreateDepartment(Model model) {
		DepartmentDTO departmentDTO = new DepartmentDTO();
		model.addAttribute("departmentDTO", departmentDTO);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);
		return "createdepartment";
	}

	@PostMapping("/createdepartment")
	public String createDepartment(@Valid @ModelAttribute("departmentDTO") DepartmentDTO departmentDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String departmentName = departmentDTO.getDepartmentName();

		if (bindingResult.hasErrors()) {

			return "createdepartment";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			Department department = modelMapper.map(departmentDTO, Department.class);

			try {
			departmentRepository.save(department);
			model.addAttribute("departmentName", departmentName);
			return "createdepartmentsuccess";
			}catch (DataIntegrityViolationException e) {
	            model.addAttribute("error", "Department Name must be unique.");
	            redirectAttributes.addFlashAttribute("error", "Department Name must be unique.");
				

	            return "redirect:/showcreateitemratephase"; // Return to form with error message
	        }


		}
	}

	@RequestMapping(value = { "/showeditdepartment" }, method = RequestMethod.GET)
	public String showEditDepartment(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<DepartmentDTO> departmentlist = populateOrderScreenService.findAllDepartments();
		model.addAttribute("departments", departmentlist);

		return "showeditdepartment";

	}

	@RequestMapping(value = "/editdepartment", params = { "updatedepartment" })

	public String updatedepartment(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String departmentIdString = orderSearchBillingDTO.getDepartmentId();
		Integer departmentId = 0;
		if (!departmentIdString.isEmpty()) {
			departmentId = Integer.parseInt(orderSearchBillingDTO.getDepartmentId());
		}
		Department departmentfromDB = departmentRepository.findByDepartmentId(departmentId);
		String departmentName = departmentfromDB.getDepartmentName();
		DepartmentDTO departmentDTO = new DepartmentDTO();
		departmentDTO.setDepartmentName(departmentName);
		request.getSession().setAttribute("departmentId", departmentId);
		model.addAttribute("departmentDTO", departmentDTO);

		return "editdepartment";
	}

	@RequestMapping(value = { "/savedepartment" }, method = RequestMethod.GET)
	public String saveinstitution(@ModelAttribute("departmentDTO") DepartmentDTO departmentDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer departmentId = (Integer) request.getSession().getAttribute("departmentId");
		Department departmentfromDB = departmentRepository.findByDepartmentId(departmentId);
		departmentfromDB.setDepartmentName(departmentDTO.getDepartmentName());
		 try {

		departmentRepository.save(departmentfromDB);
		model.addAttribute("updateddepartmentName", departmentDTO.getDepartmentName());

		return "editdepartmentupdatesuccess";
		 }catch (DataIntegrityViolationException e) {
	            model.addAttribute("error", "Department Name must be unique.");
	            redirectAttributes.addFlashAttribute("error", "Department Name must be unique.");
				

	            return "redirect:/showeditdepartment"; // Return to form with error message
	        }

	}

	@RequestMapping(value = "/editdepartment", params = { "deletedepartment" })

	public String deleteDepartment(@ModelAttribute("departmentDTO") DepartmentDTO departmentDTO,
			BindingResult bindingResult, Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long departmentId = departmentDTO.getDepartmentId();
		Department departmentfromDB = departmentRepository.findByDepartmentId(departmentId);
		String departmentName = departmentfromDB.getDepartmentName();
		departmentRepository.delete(departmentfromDB);
		model.addAttribute("deletedDepartmentName", departmentName);

		return "editdepartmentdeletesuccess";
	}
	
	
	

	@RequestMapping(value = { "/showedititemphase" }, method = RequestMethod.GET)
	public String showEditItemPhase(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<ItemPhaseDTO> itemphaselist = populateOrderScreenService.findAllItemPhase();
		model.addAttribute("itemphases", itemphaselist);

		return "showedititemphase";

	}



	
	
	@RequestMapping(value = "/edititemphase", params = { "updateitemphase" })

	public String editItemPhase(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String itemPhaseIdString = orderSearchBillingDTO.getItemPhaseId();
		Integer itemPhaseId = 0;
		if (!itemPhaseIdString.isEmpty()) {
			itemPhaseId = Integer.parseInt(orderSearchBillingDTO.getItemPhaseId());
		}
		ItemPhase itemPhasefromDB = itemPhaseRepository.findByItemPhaseId(itemPhaseId);
		String itemPhaseName = itemPhasefromDB.getItemPhaseName();
		ItemPhaseDTO itemPhaseDTO = new ItemPhaseDTO();
		itemPhaseDTO.setItemPhaseName(itemPhaseName);
		request.getSession().setAttribute("itemPhaseId", itemPhaseId);
		model.addAttribute("itemPhaseDTO", itemPhaseDTO);

		return "edititemphase";
	}
	
	@RequestMapping(value = { "/saveitemphase" }, method = RequestMethod.GET)
	public String saveItemRatePhase(@ModelAttribute("itemRatePhaseDTO") ItemPhaseDTO itemRatePhaseDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer itemPhaseId = (Integer) request.getSession().getAttribute("itemPhaseId");
		ItemPhase itemPhasefromDB = itemPhaseRepository.findByItemPhaseId(itemPhaseId);
		itemPhasefromDB.setItemPhaseName(itemRatePhaseDTO.getItemPhaseName());
		 try {

		itemPhaseRepository.save(itemPhasefromDB);
		model.addAttribute("updateditemPhaseName", itemPhasefromDB.getItemPhaseName());

		return "edititemphaseupdatesuccess";
	}catch (DataIntegrityViolationException e) {
        model.addAttribute("error", "Item Rate Phase Name must be unique.");
        redirectAttributes.addFlashAttribute("error", "Item Rate Phase Name must be unique.");
		

        return "redirect:/showedititemphase"; // Return to form with error message
    }
}


	@RequestMapping(value = "/edititemphase", params = { "deleteitemphase" })

	public String editItemRatePhase(@ModelAttribute("itemRatePhaseDTO") ItemPhaseDTO itemRatePhaseDTO,
			BindingResult bindingResult, Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long itemPhaseId = itemRatePhaseDTO.getItemPhaseId();
		ItemPhase itemPhasefromDB = itemPhaseRepository.findByItemPhaseId(itemPhaseId);
		String itemPhaseName = itemPhasefromDB.getItemPhaseName();
		itemPhaseRepository.delete(itemPhasefromDB);
		model.addAttribute("deletedItemPhaseName", itemPhaseName);

		return "edititemphasenamedeletesuccess";
	}

	
	
	@RequestMapping(value = { "/showcreateitem" }, method = RequestMethod.GET)
	public String showCreateItem(Model model) {
		ItemDTO itemDTO = new ItemDTO();
		model.addAttribute("itemDTO", itemDTO);
		List<ItemPhaseDTO> itemPhaseList = populateOrderScreenService.findAllItemPhase();
		System.out.println("Printing Size of Phase List"+ itemPhaseList.size());
		model.addAttribute("itemphases", itemPhaseList);
		List<ItemDTO> itemlist = populateOrderScreenService.findAllItems();
		model.addAttribute("items", itemlist);
		return "createitem";
	}

	@PostMapping("/createitem")
	public String createItem(@Valid @ModelAttribute("itemDTO") ItemDTO itemDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String itemName = itemDTO.getItemName();

		if (bindingResult.hasErrors()) {

			return "createitem";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			Item item = modelMapper.map(itemDTO, Item.class);
			 try {
			itemRepository.save(item);
			model.addAttribute("itemName", itemName);
			return "createitemsuccess";

		}catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Item Name must be unique.");
            redirectAttributes.addFlashAttribute("error", "Item Name must be unique.");
			

            return "redirect:/showcreateitem"; // Return to form with error message
        }
	}

	}

	@RequestMapping(value = { "/showedititem" }, method = RequestMethod.GET)
	public String showEditItemRate(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<ItemDTO> itemlist = populateOrderScreenService.findAllItems();
		model.addAttribute("items", itemlist);

		return "showedititem";

	}

	@RequestMapping(value = "/edititem", params = { "updateitem" })

	public String editItemRate(@ModelAttribute("orderSearchBillingDTO") OrderSearchDTO orderSearchBillingDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		String itemIdString = orderSearchBillingDTO.getItemId();
		Integer itemId = 0;
		if (!itemIdString.isEmpty()) {
			itemId = Integer.parseInt(orderSearchBillingDTO.getItemId());
		}
		Item itemFromDB = itemRepository.findByItemId(itemId);
		Long phaseId = itemFromDB.getItemPhaseId();
		String itemName = itemFromDB.getItemName();
		Double itemRate = itemFromDB.getItemRate();
		ItemDTO editItemDTO = new ItemDTO();
		editItemDTO.setPhaseId(phaseId);
		editItemDTO.setItemName(itemName);
		editItemDTO.setItemRate(itemRate);
		List<ItemPhaseDTO> itemPhaseList = populateOrderScreenService.findAllItemPhase();
		model.addAttribute("itemphases", itemPhaseList);
		request.getSession().setAttribute("itemId", itemId);
		model.addAttribute("editItemDTO", editItemDTO);

		return "edititem";
	}

	@RequestMapping(value = { "/saveitem" }, method = RequestMethod.GET)
	public String saveItem(@ModelAttribute("editItemDTO") ItemDTO editItemDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");

		Integer itemId = (Integer) request.getSession().getAttribute("itemId");
		Item itemIdFromDB = itemRepository.findByItemId(itemId);
		itemIdFromDB.setItemPhaseId(editItemDTO.getPhaseId());
		itemIdFromDB.setItemName(editItemDTO.getItemName());
		itemIdFromDB.setItemRate(editItemDTO.getItemRate());
		 try {
		itemRepository.save(itemIdFromDB);
		model.addAttribute("updatedItemRateName", editItemDTO.getItemName());

		return "edititemupdatesuccess";
	}catch (DataIntegrityViolationException e) {
        model.addAttribute("error", "Item Name must be unique.");
        redirectAttributes.addFlashAttribute("error", "Item Name must be unique.");
		

        return "redirect:/showedititem"; // Return to form with error message
    }
}


	@RequestMapping(value = "/edititem", params = { "deleteitem" })

	public String editItem(@ModelAttribute("editItemDTO") ItemDTO editItemDTO,
			BindingResult bindingResult, Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		long itemId = editItemDTO.getItemId();
		Item itemIdFromDB = itemRepository.findByItemId(itemId);
		String itemName = itemIdFromDB.getItemName();
		itemRepository.delete(itemIdFromDB);
		model.addAttribute("deletedItemName", itemName);

		return "edititemdeletesuccess";
	}

	@RequestMapping(value = { "/showitembatchupdate" }, method = RequestMethod.GET)
	public String showItemBatchUpdate(Model model) {
		System.out.println("Printing from welcome");
		// String orderId = orderSearchResultDTO.getOrderId();
		// long orderid = Long.parseLong(orderId);
		//List<ItemRateDTO> findAllItemRates = populateOrderScreenService.findAllItemRates();
		List<Item> itemEntity = itemRepository.findAll();
//		 List<ItemRateDTO> itemRatelist=new ArrayList<ItemRateDTO>();
		ItemBatchDTO itemBatchDTO = new ItemBatchDTO();
		itemEntity.forEach(item -> {
			ItemDTO itemDTO = new ItemDTO();
			itemDTO.setItemId(item.getItemId());
			itemDTO.setPhaseId(item.getItemPhaseId());
		//    itemRateDTO.setPhaseName(item.getPhaseName());
			itemDTO.setItemName(item.getItemName());
			itemDTO.setItemRate(item.getItemRate());
			itemBatchDTO.add(itemDTO);
		});
		List<ItemPhaseDTO> itemPhaseList = populateOrderScreenService.findAllItemPhase();
		model.addAttribute("itemphases", itemPhaseList);

		model.addAttribute("itemBatchDTO", itemBatchDTO);
		// model.addAttribute("itemRatelist", itemRatelist);

		return "showitembatchupdate";
	}

	@RequestMapping(value = { "/saveitembatchupdate" }, method = RequestMethod.POST)
	public String saveItemBatchUpdate(@ModelAttribute("itemBatchDTO") ItemBatchDTO itemRateBatchDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes)
			throws Exception {

		List<ItemDTO> items = itemRateBatchDTO.getItems();
		System.out.println("Printing no of items from Rates list"+items.size());
		 try {
	           batchUpdate(itemRateBatchDTO);
	           List<ItemDTO> itemList = populateOrderScreenService.findAllItems();
	       	List<Item> itemFromDB = itemRepository.findAll();
			List<ItemDTO> itemDTOs = new ArrayList<ItemDTO>();
			itemList.forEach(item -> {
				ItemDTO itemDTO = new ItemDTO();
				itemDTO.setItemId(item.getItemId());
				itemDTO.setPhaseId(item.getPhaseId());
				itemDTO.setPhaseName(item.getPhaseName());
				itemDTO.setItemName(item.getItemName());
				itemDTO.setItemRate(item.getItemRate());
				itemDTOs.add(itemDTO);
			});
			model.addAttribute("itemlist", itemDTOs);
			return "showitembatchupdatesuccess";
	          //  return "redirect:/batchUpdate";  // On success, redirect back to the same page
	        } catch (DataIntegrityViolationException e) {
	            // On duplicate exception, add an error message to the redirect attributes
	            redirectAttributes.addFlashAttribute("error", e.getMessage());
	            return "redirect:/showitembatchupdate";  // Redirect to the batchUpdate page with error message
	        }
		

	
	}
	
	 @Transactional
	    public void batchUpdate(ItemBatchDTO itemBatchDTO) throws DataIntegrityViolationException {
		 List<ItemDTO> items = itemBatchDTO.getItems();
		 System.out.println("Printing item rates list size"+ items);
	        for (ItemDTO item : items) {
	        	if (item.getItemId() != null) {
	        		Item itemIdFromDB = itemRepository.findByItemId(item.getItemId());
	        		itemIdFromDB.setItemPhaseId(item.getPhaseId());
	        		itemIdFromDB.setItemName(item.getItemName());
	        		itemIdFromDB.setItemRate(item.getItemRate());
					  try {
			            	itemRepository.save(itemIdFromDB);
			            } catch (DataIntegrityViolationException e) {
			                // Propagate the exception to be handled in the controller
			                throw new DataIntegrityViolationException("A duplicate entry was found.");
			            }
	        	}
	          
	        }
	    }
	

	

}
