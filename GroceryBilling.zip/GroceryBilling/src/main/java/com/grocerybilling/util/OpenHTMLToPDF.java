package com.grocerybilling.util;
import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import com.grocerybilling.model.OrderItemDetailDTO;
import com.lowagie.text.DocumentException;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.spring6.*;
import org.thymeleaf.context.Context;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import org.xhtmlrenderer.pdf.ITextRenderer;
import org.xhtmlrenderer.pdf.ITextFontResolver;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

public class OpenHTMLToPDF {
	   private TemplateEngine createTemplateEngine() {
		   ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
	        templateResolver.setSuffix(".html");
	        templateResolver.setPrefix("pdf-templates/");
	        templateResolver.setTemplateMode(TemplateMode.HTML);

	      //  TemplateEngine templateEngine = new TemplateEngine();
	        SpringTemplateEngine templateEngine = new SpringTemplateEngine();
	        templateEngine.setTemplateResolver(templateResolver);
	        return templateEngine;
	   }
	   
		private String generateHtml(String templateFileName, Map<String, Object> data) {
	        TemplateEngine templateEngine = createTemplateEngine();
	        Context context = new Context();
	        context.setVariables(data);
	        String htmlContent = templateEngine.process(templateFileName, context);
	        return htmlContent;
	    }
		
		public void  exportPdfFileUsingOpenHTMLToPDF(String templateFileName, Map<String, Object> data) throws IOException, DocumentException {
	        String htmlContent = generateHtml(templateFileName, data);
	      /*  try {
	        	String outputFolder = "E:\\SimpleSolution\\order.pdf";
	            FileOutputStream fileOutputStream = new FileOutputStream(outputFolder);
	            ITextRenderer renderer = new ITextRenderer();
	            renderer.setDocumentFromString(htmlContent);
	            renderer.layout();
	            renderer.createPDF(fileOutputStream, false);
	            renderer.finishPDF();
	        } 
	        catch (FileNotFoundException e) {
	            e.printStackTrace();*/
	        ByteArrayInputStream byteArrayInputStream = null;
	        try {
	        	try {
	              //  final W3CDom w3cDom = new W3CDom();
	              //  final Document w3cDoc = w3cDom.fromJsoup(Jsoup.parse(readFile()));
	              //  final OutputStream outStream = new FileOutputStream("test.pdf");
	        		  ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	        	 OutputStream outStream = new FileOutputStream("test.pdf");
	        		//  ByteArrayOutputStream outStream = new ByteArrayOutputStream("test.pdf");
	        		 Document document = Jsoup.parse(htmlContent);
	        		
	        	     String cleanHtml = document.html();
	        	     System.out.println("Printing HTML" + cleanHtml);
	        		 

	                final PdfRendererBuilder pdfBuilder = new PdfRendererBuilder();
	                pdfBuilder.useFastMode();
	                pdfBuilder.withHtmlContent(cleanHtml, "/");
	              //  pdfBuilder.useFont(getClass().getResource("/fonts/myfont.ttf").getFile(), "MyCustomFont");
	                pdfBuilder.useFont(new File(OpenHTMLToPDF.class.getClassLoader().getResource("fonts/akshar.ttf").getFile()), "Latha");
	                pdfBuilder.toStream(outStream);

	                pdfBuilder.run();
	             //   byteArrayInputStream = new ByteArrayInputStream(outStream);
	                outStream.close();
	            } catch (Exception e) {
	                System.out.println("PDF could not be created: " + e.getMessage());
	            }

	   //    return byteArrayInputStream;
	   
		}catch (Exception e) {
            System.out.println("PDF could not be created: " + e.getMessage());
        }
		}

}
