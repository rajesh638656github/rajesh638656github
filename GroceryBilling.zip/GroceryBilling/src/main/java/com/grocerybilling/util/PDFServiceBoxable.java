package com.grocerybilling.util;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import be.quodlibet.boxable.*;

import java.io.IOException;
import java.util.List;
public class PDFServiceBoxable {

}
