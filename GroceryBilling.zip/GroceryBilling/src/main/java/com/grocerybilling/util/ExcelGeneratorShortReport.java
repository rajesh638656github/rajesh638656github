package com.grocerybilling.util;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.grocerybilling.DTO.OrderMasterDTO;
import com.grocerybilling.model.OrderItemDetailDTO;
public class ExcelGeneratorShortReport {
	 
	 private List < OrderMasterDTO > orderMasterDTO;
	    private XSSFWorkbook workbook;
	    private XSSFSheet sheet;

	   
	    public ExcelGeneratorShortReport(List < OrderMasterDTO > orderMasterDTO) {
	        this.orderMasterDTO = orderMasterDTO;
	        workbook = new XSSFWorkbook();
	    }
	    private void writeHeader() {
	        sheet = workbook.createSheet("OrderDetail");
	        Row row = sheet.createRow(0);
	        CellStyle style = workbook.createCellStyle();
	        XSSFFont font = workbook.createFont();
	        font.setBold(true);
	        font.setFontHeight(16);
	        style.setFont(font);
	        createCell(row, 0, "Order ID", style);
	        createCell(row, 1, "Institution Name", style);
	        createCell(row, 2, "Department Name", style);
	        createCell(row, 3, "Contact Person Name", style);
	        createCell(row, 4, "Contact Number", style);
	        createCell(row, 5, "Item Name", style);
	        createCell(row, 6, "Item Description", style);
	        createCell(row, 7, "Size", style);
	        createCell(row, 8, "Note", style);
	        createCell(row, 9, "Quantity", style);
	        createCell(row, 10, "Unit", style);
	        createCell(row, 11, "Price", style);
	        createCell(row, 12, "Item Status", style);
	        createCell(row, 13, "Comments", style);
	        createCell(row, 14, "Amount", style);
	        createCell(row, 15, "Total", style);
	    }
	    
	    private void writeHeaderForShortPendingOrderReport() {
	        sheet = workbook.createSheet("OrderDetail");
	        Row row = sheet.createRow(0);
	        CellStyle style = workbook.createCellStyle();
	        XSSFFont font = workbook.createFont();
	        font.setBold(true);
	        font.setFontHeight(16);
	        style.setFont(font);
	        createCell(row, 0, "Order ID", style);
	        createCell(row, 1, "Institution Name", style);
	        createCell(row, 2, "Department Name", style);
	        createCell(row, 3, "Contact Person Name", style);
	        createCell(row, 4, "Contact Number", style);
	        createCell(row, 5, "Start Date", style);
	        createCell(row, 6, "Total", style);
	    }
	    private void createCell(Row row, int columnCount, Object valueOfCell, CellStyle style) {
	        sheet.autoSizeColumn(columnCount);
	        Cell cell = row.createCell(columnCount);
	        if (valueOfCell instanceof Integer) {
	            cell.setCellValue((Integer) valueOfCell);
	        } else if (valueOfCell instanceof Long) {
	            cell.setCellValue((Long) valueOfCell);
	        } else if (valueOfCell instanceof String) {
	            cell.setCellValue((String) valueOfCell);
	        } else {
	            cell.setCellValue((Boolean) valueOfCell);
	        }
	        cell.setCellStyle(style);
	    }
	   
	    private void writeForShortPendingOrderReport() {
	        int rowCount = 1;
	        CellStyle style = workbook.createCellStyle();
	        XSSFFont font = workbook.createFont();
	        font.setFontHeight(14);
	        style.setFont(font);
	        for (OrderMasterDTO order: orderMasterDTO) {
	            Row row = sheet.createRow(rowCount++);
	            int columnCount = 0;
	            createCell(row, columnCount++, order.getOrderId(), style);
	            createCell(row, columnCount++, order.getInstitutionName(), style);
	            createCell(row, columnCount++, order.getInstallmentNumber(), style);
	            createCell(row, columnCount++, order.getContactPersonName(), style);
	            createCell(row, columnCount++, order.getContactNumber(), style);
	            createCell(row, columnCount++, order.getStartDate(), style);
	            createCell(row, columnCount++, order.getTotalAmount(), style);
	        }
	    }
	  
	    public void generateExcelFileForShortPendingOrderReport(HttpServletResponse response) throws IOException {
	    	writeHeaderForShortPendingOrderReport();
	    	writeForShortPendingOrderReport();
	        ServletOutputStream outputStream = response.getOutputStream();
	        workbook.write(outputStream);
	        workbook.close();
	        outputStream.close();
	    }


}
