package com.grocerybilling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroceryBillingApplicationTests {

	@Test
	void contextLoads() {
	}

}
