package com.transactionmanagement.util;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.transactionmanagement.DTO.TransactionDTO;



public class ExcelGenerator {
	 private List < TransactionDTO > transactionList;
	 
	    private XSSFWorkbook workbook;
	    private XSSFSheet sheet;

	    public ExcelGenerator(List < TransactionDTO > transactionList) {
	        this.transactionList = transactionList;
	        workbook = new XSSFWorkbook();
	    }
	   
	    private void writeHeader() {
	        sheet = workbook.createSheet("TransactionDetail");
	        Row row = sheet.createRow(0);
	        CellStyle style = workbook.createCellStyle();
	        XSSFFont font = workbook.createFont();
	        font.setBold(true);
	        font.setFontHeight(16);
	        style.setFont(font);
	        
	        
	        createCell(row, 0, "Account Name", style);
	        createCell(row, 1, "Amount", style);
	        createCell(row, 2, "Remarks", style);
	        createCell(row, 3, "Date", style);
	        createCell(row, 4, "Internal Transfer", style);
	        createCell(row, 5, "Institution Name", style);
	        
	    }
	    
	    private void writeHeaderForShortPendingOrderReport() {
	        sheet = workbook.createSheet("OrderDetail");
	        Row row = sheet.createRow(0);
	        CellStyle style = workbook.createCellStyle();
	        XSSFFont font = workbook.createFont();
	        font.setBold(true);
	        font.setFontHeight(16);
	        style.setFont(font);
	        createCell(row, 0, "Order No", style);
	        createCell(row, 1, "Institution Name", style);
	        createCell(row, 2, "Department Name", style);
	        createCell(row, 3, "Contact Person Name", style);
	        createCell(row, 4, "Contact Number", style);
	        createCell(row, 5, "Start Date", style);
	        createCell(row, 6, "Total", style);
	    }
	    private void createCell(Row row, int columnCount, Object valueOfCell, CellStyle style) {
	        sheet.autoSizeColumn(columnCount);
	        Cell cell = row.createCell(columnCount);
	        if (valueOfCell instanceof Integer) {
	            cell.setCellValue((Integer) valueOfCell);
	        } else if (valueOfCell instanceof Long) {
	            cell.setCellValue((Long) valueOfCell);
	        } else if (valueOfCell instanceof String) {
	            cell.setCellValue((String) valueOfCell);
	        } else if (valueOfCell instanceof Double) {
	            cell.setCellValue(String.valueOf(valueOfCell));
	        } else {
	            cell.setCellValue((Boolean) valueOfCell);
	        }
	        cell.setCellStyle(style);
	    }
	    private void write() {
	        int rowCount = 1;
	        CellStyle style = workbook.createCellStyle();
	        XSSFFont font = workbook.createFont();
	        font.setFontHeight(14);
	        style.setFont(font);
	        for (TransactionDTO transaction: transactionList) {
	            Row row = sheet.createRow(rowCount++);
	            int columnCount = 0;
	            
	            createCell(row, columnCount++, transaction.getAccountName(), style);
	            createCell(row, columnCount++, transaction.getAmount(), style);
	            createCell(row, columnCount++, transaction.getRemarks(), style);
	            createCell(row, columnCount++, transaction.getDate(), style);
	            createCell(row, columnCount++, transaction.getInternalTransfer(), style);
	            createCell(row, columnCount++, transaction.getInstitutionName(), style);
	            
	        
	        }
	    }
	    private void writeForShortPendingOrderReport() {
	        int rowCount = 1;
	        CellStyle style = workbook.createCellStyle();
	        XSSFFont font = workbook.createFont();
	        font.setFontHeight(14);
	        style.setFont(font);
	        for (TransactionDTO transaction: transactionList) {
	            Row row = sheet.createRow(rowCount++);
	            int columnCount = 0;
	            
	            createCell(row, columnCount++, transaction.getAccountName(), style);
	            createCell(row, columnCount++, transaction.getAmount(), style);
	            createCell(row, columnCount++, transaction.getRemarks(), style);
	            createCell(row, columnCount++, transaction.getDate(), style);
	         //   createCell(row, columnCount++, transaction.getDownloadStatus(), style);
	            createCell(row, columnCount++, transaction.getInternalTransfer(), style);
	            createCell(row, columnCount++, transaction.getInstitutionName(), style);
	        }
	    }
	    public void generateExcelFile(HttpServletResponse response) throws IOException {
	        writeHeader();
	        write();
	        ServletOutputStream outputStream = response.getOutputStream();
	        workbook.write(outputStream);
	        workbook.close();
	        outputStream.close();
	    }
	    public void generateExcelFileForShortPendingOrderReport(HttpServletResponse response) throws IOException {
	    	writeHeaderForShortPendingOrderReport();
	    	writeForShortPendingOrderReport();
	        ServletOutputStream outputStream = response.getOutputStream();
	        workbook.write(outputStream);
	        workbook.close();
	        outputStream.close();
	    }
}
