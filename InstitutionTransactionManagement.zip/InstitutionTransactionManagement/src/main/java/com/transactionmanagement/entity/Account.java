package com.transactionmanagement.entity;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "account", uniqueConstraints = @UniqueConstraint(columnNames = {"account_no"}))

public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "account_id")
	private long accountId;
	@Column(name = "account_name", nullable = false)
	private String accountName;
	@Column(name = "account_number")
	private String accountNumber;
	@Column(name = "ifcs_code")
	private String ifcsCode;
	@Column(name = "branch")
	private String branch;
	@Column(name = "city")
	private String city;
	@Column(name = "remarks")
	private String remarks;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Account(long accountId, String accountName, String accountNumber, String ifcsCode, String branch, String city,
			String remarks) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.accountNumber = accountNumber;
		this.ifcsCode = ifcsCode;
		this.branch = branch;
		this.city = city;
		this.remarks = remarks;
	}


	public long getAccountId() {
		return accountId;
	}


	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}


	public String getAccountName() {
		return accountName;
	}


	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}


	public String getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}


	
	public String getIfcsCode() {
		return ifcsCode;
	}


	public void setIfcsCode(String ifcsCode) {
		this.ifcsCode = ifcsCode;
	}


	public String getBranch() {
		return branch;
	}


	public void setBranch(String branch) {
		this.branch = branch;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	
	
	
	
}
