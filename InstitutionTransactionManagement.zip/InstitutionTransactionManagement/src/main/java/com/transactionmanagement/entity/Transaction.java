package com.transactionmanagement.entity;
import java.util.Objects;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "transaction")

public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "transaction_id")
	private long transactionId;
	@Column(name = "account_name")
	private String accountName;
	@Column(name = "amount")
	private Double amount;
	@Column(name = "remarks")
	private String remarks;
	@Column(name = "date")
	private Date date;
	@Column(name = "download_status")
	private String downloadStatus;
	@Column(name = "institution_id")
	private long institutionId;
	@Column(name = "internal_transfer")
	private String internalTransfer;
	
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(long transactionId, String accountName, Double amount, String remarks, Date date, String downloadStatus,
			long institutionId, String internalTransfer) {
		super();
		this.transactionId = transactionId;
		this.accountName = accountName;
		this.amount = amount;
		this.remarks = remarks;
		this.date = date;
		this.downloadStatus = downloadStatus;
		this.institutionId = institutionId;
		this.internalTransfer = internalTransfer;
	}
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	
	public String getDownloadStatus() {
		return downloadStatus;
	}
	public void setDownloadStatus(String downloadStatus) {
		this.downloadStatus = downloadStatus;
	}
	
	
	
	public long getInstitutionId() {
		return institutionId;
	}
	public void setInstitutionId(long institutionId) {
		this.institutionId = institutionId;
	}
	public String getInternalTransfer() {
		return internalTransfer;
	}
	public void setInternalTransfer(String internalTransfer) {
		this.internalTransfer = internalTransfer;
	}
	
	
		

}
