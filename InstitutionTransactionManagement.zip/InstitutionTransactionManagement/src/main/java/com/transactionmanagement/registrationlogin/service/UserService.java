package com.transactionmanagement.registrationlogin.service;

import com.transactionmanagement.registrationlogin.dto.UserDto;
import com.transactionmanagement.registrationlogin.entity.GroceryUser;

import java.util.List;

public interface UserService {
    void saveUser(UserDto userDto);
    
    void saveAdminUser(UserDto userDto);
    
    void updatePassword(UserDto userDto);

    GroceryUser findByEmail(String email);

    List<UserDto> findAllUsers();
    
    GroceryUser findByName(String name);
}
