package com.transactionmanagement.DTO;

import java.util.regex.Pattern;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;
import lombok.AllArgsConstructor;
@Data
//@AllArgsConstructor

public class AccountDTO {
	
	private long accountId;
	
	private String accountName;
	
	private String accountNumber;
	
	private String ifcsCode;
	
	private String branch;
	
	private String city;
	
	private String remarks;

	public AccountDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public AccountDTO(long accountId, String accountName, String accountNumber, String ifcsCode, String branch, String city,
			String remarks) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.accountNumber = accountNumber;
		this.ifcsCode = ifcsCode;
		this.branch = branch;
		this.city = city;
		this.remarks = remarks;
	}

	public AccountDTO(long accountId, String accountName, String accountNumber, String ifcsCode, String branch) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.accountNumber = accountNumber;
		this.ifcsCode = ifcsCode;
		this.branch = branch;
	}


	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}


	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	

	public String getIfcsCode() {
		return ifcsCode;
	}

	public void setIfcsCode(String ifcsCode) {
		this.ifcsCode = ifcsCode;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	 // Helper method to format display text
    public String getDisplayText() {
        return accountName + " (" + accountNumber + ") - " + branch + " [" + ifcsCode + "]";
    }
    
    // Helper method to highlight matches
    public String highlightMatches(String query) {
        String regex = "(?i)(" + Pattern.quote(query) + ")";
        return getDisplayText()
            .replaceAll(regex, "<strong>$1</strong>");
    }


	







	



	

}
