package com.transactionmanagement.DTO;

public class Installment {
	
	private int currentYear;
	private String monthOfPurchase;
	private String installmentNo;
	
	
	
	
	public Installment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Installment(int currentYear, String monthOfPurchase, String installmentNo) {
		super();
		this.currentYear = currentYear;
		this.monthOfPurchase = monthOfPurchase;
		this.installmentNo = installmentNo;
	}
	
	public int getCurrentYear() {
		return currentYear;
	}
	public void setCurrentYear(int currentYear) {
		this.currentYear = currentYear;
	}
	public String getMonthOfPurchase() {
		return monthOfPurchase;
	}
	public void setMonthOfPurchase(String monthOfPurchase) {
		this.monthOfPurchase = monthOfPurchase;
	}
	public String getInstallmentNo() {
		return installmentNo;
	}
	public void setInstallmentNo(String installmentNo) {
		this.installmentNo = installmentNo;
	}
	

}
