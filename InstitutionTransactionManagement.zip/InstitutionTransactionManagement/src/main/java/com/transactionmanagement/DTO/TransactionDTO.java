package com.transactionmanagement.DTO;

import java.util.Date;

public class TransactionDTO {
	private long transactionId;
	private long accountId;
	private String accountName;
	private Double amount;
	private String remarks;
	private String date;
	private String downloadStatus;
	private long institutionId;
	private String institutionName;
	private String internalTransfer;
	public TransactionDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TransactionDTO(long transactionId, long accountId, String accountName, Double amount,
			String remarks, String date, String downloadStatus, long institutionId, String institutionName,
			String internalTransfer) {
		super();
		this.transactionId = transactionId;
		this.accountId = accountId;
		this.accountName = accountName;
		this.amount = amount;
		this.remarks = remarks;
		this.date = date;
		this.downloadStatus = downloadStatus;
		this.institutionId = institutionId;
		this.institutionName = institutionName;
		this.internalTransfer = internalTransfer;
	}
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDownloadStatus() {
		return downloadStatus;
	}
	public void setDownloadStatus(String downloadStatus) {
		this.downloadStatus = downloadStatus;
	}
	public long getInstitutionId() {
		return institutionId;
	}
	public void setInstitutionId(long institutionId) {
		this.institutionId = institutionId;
	}
	public String getInstitutionName() {
		return institutionName;
	}
	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}
	public String getInternalTransfer() {
		return internalTransfer;
	}
	public void setInternalTransfer(String internalTransfer) {
		this.internalTransfer = internalTransfer;
	}
	
	
		

}
