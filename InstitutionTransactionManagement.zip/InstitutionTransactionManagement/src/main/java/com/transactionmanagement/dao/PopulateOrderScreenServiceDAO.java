package com.transactionmanagement.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.*;
import java.sql.Types;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementCallback;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.transactionmanagement.DTO.DepartmentDTO;
import com.transactionmanagement.DTO.InstitutionDTO;
import com.transactionmanagement.DTO.TransactionDTO;
import com.transactionmanagement.dao.*;

@Component
public class PopulateOrderScreenServiceDAO {

	// @Autowired
	// PreparedStatement ps;
	@Autowired
	JdbcTemplate jdbc;
	@Autowired
	NamedParameterJdbcTemplate namedjdbcTemplateObject;

	public List<InstitutionDTO> findAllInstitutions() throws Exception {
		try {

			return jdbc.query("SELECT i.INSTITUTION_ID,i.INSTITUTION_NAME from INSTITUTION I "
					//+ "JOIN users u on u.institution_id = i.institution_id "
					+ "ORDER BY INSTITUTION_NAME", new InstitutionMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	
	public List<InstitutionDTO> findInstitutionById(long institutionId) throws Exception {
		try {

			SqlParameterSource parameters = new MapSqlParameterSource("institutionId", institutionId);
			return namedjdbcTemplateObject.query("SELECT i.INSTITUTION_ID,i.INSTITUTION_NAME from INSTITUTION I "
				//	+ "JOIN users u on u.institution_id = i.institution_id "
					+ "where i.institution_id IN (:institutionId) ORDER BY INSTITUTION_NAME", parameters, new InstitutionMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	
	
	
	public int createInstitution(String institutionName) throws Exception {
		try {

			int orderdetailstatus = jdbc.update("INSERT INTO INSTITUTION (INSTITUTION_NAME) values(?)",
					institutionName);

			return orderdetailstatus;

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}

	public int createDepartment(String departmentName) throws Exception {
		try {

			int departmentCreateStatus = jdbc.update("INSERT INTO DEPARTMENT (DEPARTMENT_NAME) values(?)",
					departmentName);

			return departmentCreateStatus;

		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	
	public List<TransactionDTO> findAllActiveTransactions() throws Exception {
		try {

			
			return jdbc.query("SELECT t.transaction_id,t.account_name,t.amount, t.date, t.institution_id,i.institution_name,t.download_status,t.internal_transfer,t.remarks from transaction t"
					+ " JOIN INSTITUTION I ON t.INSTITUTION_ID = I.INSTITUTION_ID"
					+ " where download_status='no'"
					+ " ORDER BY INSTITUTION_NAME ", new TransactionMapper());
		} catch (InvalidResultSetAccessException e) {
			System.out.println(e);
			throw new RuntimeException(e);
		} catch (DataAccessException e) {
			System.out.println(e);
			throw new Exception("A problem occurred while retrieving my data", e);
		}

	}
	

}