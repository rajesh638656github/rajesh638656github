package com.transactionmanagement.dao;
import com.transactionmanagement.DTO.DepartmentDTO;
import com.transactionmanagement.DTO.TransactionDTO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;;

public class TransactionMapper implements RowMapper<TransactionDTO> {
	public TransactionDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/MM/yyyy");
		TransactionDTO transactionDTO = new TransactionDTO();
		transactionDTO.setTransactionId(rs.getLong("transaction_id"));
		transactionDTO.setAccountName(rs.getString("ACCOUNT_NAME"));
		transactionDTO.setAmount(rs.getDouble("amount"));
		transactionDTO.setInstitutionId(rs.getLong("institution_id"));
		transactionDTO.setInstitutionName(rs.getString("institution_name"));
		transactionDTO.setInternalTransfer(rs.getString("internal_transfer"));
		transactionDTO.setRemarks(rs.getString("remarks"));
		transactionDTO.setDownloadStatus(rs.getString("download_status"));
		
		if (rs.getDate("date") != null) {
			transactionDTO.setDate(dateformate.format(rs.getDate("date")));
		}
		
		return transactionDTO;
	}



}
