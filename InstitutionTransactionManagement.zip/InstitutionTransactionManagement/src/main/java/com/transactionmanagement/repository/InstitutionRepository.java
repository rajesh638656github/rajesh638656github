package com.transactionmanagement.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.transactionmanagement.entity.Institution;
@Repository
public interface InstitutionRepository extends JpaRepository<Institution, Integer> {
	Institution findByInstitutionId(long institutionId);
	
	 
}
