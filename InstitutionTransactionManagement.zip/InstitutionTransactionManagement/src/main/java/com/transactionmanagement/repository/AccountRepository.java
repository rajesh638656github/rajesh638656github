package com.transactionmanagement.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Pageable;

import com.transactionmanagement.entity.Account;
import com.transactionmanagement.DTO.AccountDTO;


@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {
	Account findByAccountId(long AccountId);
	
	//public interface AccountRepository extends JpaRepository<Account, Long> {

	 @Query("SELECT a FROM Account a WHERE " +
	            "LOWER(a.accountName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
	            "LOWER(a.accountNumber) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
	            "LOWER(a.ifcsCode) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
	            "LOWER(a.branch) LIKE LOWER(CONCAT('%', :keyword, '%'))")
	    List<Account> searchByKeyword(@Param("keyword") String keyword);
	}
	



