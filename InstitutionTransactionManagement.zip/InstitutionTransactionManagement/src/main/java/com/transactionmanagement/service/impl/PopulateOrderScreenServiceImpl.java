package com.transactionmanagement.service.impl;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import com.transactionmanagement.DTO.DepartmentDTO;
import com.transactionmanagement.DTO.InstitutionDTO;
import com.transactionmanagement.DTO.TransactionDTO;
import com.transactionmanagement.DTO.AccountDTO;
import com.transactionmanagement.dao.*;
import com.transactionmanagement.repository.AccountRepository;
import com.transactionmanagement.service.*;

import io.micrometer.common.util.StringUtils;

import java.util.List;
import java.util.Collections;
import java.util.Date;
import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import com.transactionmanagement.entity.Account;

@Service
@AllArgsConstructor

public class PopulateOrderScreenServiceImpl implements PopulateOrderScreenService {

	@Autowired
	private PopulateOrderScreenServiceDAO populateOrderScreenServiceDAO;
	@Autowired
	private AccountRepository accountRepository;

	@Override
	public List<InstitutionDTO> findAllInstitutions() {
		try {

			return populateOrderScreenServiceDAO.findAllInstitutions();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	
	public List<InstitutionDTO> findInstitutionById(long institutionId) {
		try {

			return populateOrderScreenServiceDAO.findInstitutionById(institutionId);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	public int createInstitution(String institutionName) {
		try {

			return populateOrderScreenServiceDAO.createInstitution(institutionName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}

	
	public List<Account> searchAccounts(String keyword) {
      
        
        System.out.println("Printing Parameters in Service Implementation" +keyword);
        List<Account> results = accountRepository.searchByKeyword(keyword);
        System.out.println("Printing in account search method result size" + results.size());
        
        return results;
        //return accountRepository.searchAccounts(searchTerm, PageRequest.of(0, limit));
    }
	
	public List<TransactionDTO> findAllActiveTransactions() {
		try {

			return populateOrderScreenServiceDAO.findAllActiveTransactions();
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException(e);
		}

	}
	

}
