package com.transactionmanagement.service;



import com.transactionmanagement.DTO.DepartmentDTO;
import com.transactionmanagement.DTO.InstitutionDTO;
import com.transactionmanagement.DTO.AccountDTO;
import com.transactionmanagement.DTO.TransactionDTO;
import com.transactionmanagement.entity.Account;
//import com.transactionmanagement.model.*;

import java.util.List;
import java.util.Date;


public interface PopulateOrderScreenService {
	public List<InstitutionDTO> findAllInstitutions();
	
	public List<InstitutionDTO> findInstitutionById(long institutionId);

	public int createInstitution(String institutionName);
	
	public List<Account> searchAccounts(String keyword);
	
	public List<TransactionDTO> findAllActiveTransactions();

	


}
