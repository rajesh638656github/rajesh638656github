package com.transactionmanagement.controller;

import com.transactionmanagement.service.PopulateOrderScreenService;
import com.transactionmanagement.entity.Institution;
import com.transactionmanagement.entity.Account;
import com.transactionmanagement.entity.Transaction;
import com.transactionmanagement.repository.InstitutionRepository;
import com.transactionmanagement.repository.AccountRepository;
import com.transactionmanagement.repository.TransactionRepository;
//import com.transactionmanagement.model.OrderSearchDTO;
import com.transactionmanagement.DTO.DepartmentDTO;
import com.transactionmanagement.DTO.InstitutionDTO;

import com.transactionmanagement.util.ExcelGenerator;
import com.transactionmanagement.DTO.AccountDTO;
import com.transactionmanagement.DTO.TransactionDTO;

import com.transactionmanagement.registrationlogin.dto.UserDto;
import com.transactionmanagement.registrationlogin.entity.GroceryUser;
import com.transactionmanagement.registrationlogin.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
//import com.transactionmanagement.service.PopulateOrderScreenService;
import com.transactionmanagement.model.*;
import com.transactionmanagement.registrationlogin.dto.UserDto;
import com.transactionmanagement.registrationlogin.entity.GroceryUser;
import com.transactionmanagement.registrationlogin.service.UserService;

import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;

import java.beans.PropertyEditorSupport;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.transaction.annotation.Transactional;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;

import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.validation.ConstraintValidatorFactory;
import jakarta.validation.Configuration;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintViolation;

import com.transactionmanagement.registrationlogin.dto.UserDto;
import com.transactionmanagement.registrationlogin.entity.GroceryUser;
import com.transactionmanagement.registrationlogin.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
//import com.grocerybilling.service.PopulateOrderScreenService;
//import com.grocerybilling.model.*;
import com.transactionmanagement.registrationlogin.dto.UserDto;
import com.transactionmanagement.registrationlogin.entity.GroceryUser;
import com.transactionmanagement.registrationlogin.service.UserService;

import com.transactionmanagement.service.PopulateOrderScreenService;

//import com.grocerybilling.model.SizeDTO;
@Controller
public class TransactionManagementController {
	SecurityContextLogoutHandler logoutHandler = new SecurityContextLogoutHandler();
	@Autowired
	private UserService userService;
	@Autowired
	private PopulateOrderScreenService populateOrderScreenService;
	@Autowired
	private InstitutionRepository institutionRepository;

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private TransactionRepository transactionRepository;

	@ModelAttribute
	public void addCurrentPath(HttpServletRequest request, Model model) {
		model.addAttribute("currentPath", request.getRequestURI());
	}

	@ModelAttribute("currentPath")
	public String getCurrentPath(HttpServletRequest request) {
		return request.getRequestURI();
	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		System.out.println("Init Binder is invoked");

		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));

	}

	@InitBinder
	public void initBinderForDouble(WebDataBinder binder) {
		binder.registerCustomEditor(Double.class, new PropertyEditorSupport() {
			@Override
			public void setAsText(String text) {
				if (text == null || text.trim().isEmpty()) {
					setValue(null); // Allow empty values without marking as invalid
				} else {
					try {
						setValue(Double.parseDouble(text)); // Convert valid numeric input
					} catch (NumberFormatException e) {
						setValue(-1.0); // Use a sentinel value to indicate invalid input
					}
				}
			}
		});
	}

	@RequestMapping(value = { "/welcome" }, method = RequestMethod.GET)
	public String showWelcome(Model model, Authentication authentication) {
		System.out.println("Printing from welcome");

		String returnPage = null;
		String userName = null;
		if (authentication != null) {
			User user = (User) authentication.getPrincipal();
			String role = user.getAuthorities().toString();
			userName = user.getUsername();

			if (role.contains("ROLE_ADMIN")) {
				returnPage = "admin-welcome"; // Thymeleaf template for admin
			} else if (role.contains("ROLE_USER")) {
				returnPage = "user-welcome"; // Thymeleaf template for user
			}
		}
		model.addAttribute("userName", userName);
		return returnPage;
	}

	@GetMapping("index")
	public String home() {
		return "index";
	}

	@GetMapping("/login")
	public String loginForm() {
		return "login";
	}

	@PostMapping("/my/logout")
	public String performLogout(Authentication authentication, HttpServletRequest request) {
		// .. perform logout
		// this.logoutHandler.doLogout(request, response, authentication);
		this.logoutHandler.setInvalidateHttpSession(true);
		return "redirect:/home";
	}

	@GetMapping("register/admin")
	public String showRegistrationForm(Model model) {
		UserDto user = new UserDto();
		model.addAttribute("user", user);
		populateDropDowns(model);
		return "registeradmin";
	}

	@GetMapping("register/user")
	public String showRegistrationFormUser(Model model) {
		UserDto user = new UserDto();
		model.addAttribute("user", user);
		populateDropDowns(model);
		return "registeruser";
	}

	@PostMapping("/register/admin/save")
	public String registrationAdmin(@Valid @ModelAttribute("user") UserDto user, BindingResult result, Model model) {
		GroceryUser existing = userService.findByEmail(user.getEmail());

		System.out.println("Printing Role Name" + user.getRoles());
		if (existing != null) {
			result.rejectValue("email", null, "There is already an account registered with that email");
		}
		if (result.hasErrors()) {
			model.addAttribute("user", user);
			return "register/admin";
		}
		userService.saveUser(user);
		return "redirect:/register?success";
	}

	@PostMapping("/register/user/save")
	public String registrationUser(@Valid @ModelAttribute("user") UserDto user, BindingResult result, Model model) {
		GroceryUser existing = userService.findByEmail(user.getEmail());

		System.out.println("Printing Role Name" + user.getRoles());
		if (existing != null) {
			result.rejectValue("email", null, "There is already an account registered with that email");
		}
		if (result.hasErrors()) {
			model.addAttribute("user", user);
			return "register/user";
		}
		userService.saveUser(user);
		model.addAttribute("userName", user.getEmail());
		return "createusersuccess";
	}

	@GetMapping("/update-password")
	public String updatePasswordForm(Model model) {
		UserDto user = new UserDto();
		model.addAttribute("user", user);
		return "update-password";
	}

	@PostMapping("/update-password")
	public String saveNewPassword(@ModelAttribute("user") UserDto user, BindingResult result, Model model) {
		try {
			System.out.println("Printing Email ID" + user.getEmail());
			GroceryUser existing = userService.findByEmail(user.getEmail());
			// System.out.println("Printing existing user id" + existing.getEmail());
			// System.out.println("Printing existing Password" + existing.getPassword());
			model.addAttribute("user", user);

			if (existing == null) {
				model.addAttribute("error", "New passwords do not match");
				return "update-password";
			}

			userService.updatePassword(user);
			model.addAttribute("message", "Password updated successfully");
		} catch (Exception e) {
			// Handles exceptions during password update process.
			model.addAttribute("error", e.getMessage());
		}
		return "redirect:/update-password?success";
	}

	// handler method to handle register user form submit request

	@GetMapping("/users")
	public String listRegisteredUsers(Model model) {
		List<UserDto> users = userService.findAllUsers();

		model.addAttribute("users", users);
		return "users";
	}

	private void populateDropDowns(Model model) {
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);

	}

	@RequestMapping(value = { "/showcreateinstitution" }, method = RequestMethod.GET)
	public String showCreateInstituion(Model model) {
		InstitutionDTO institutionDTO = new InstitutionDTO();
		model.addAttribute("institutionDTO", institutionDTO);
		List<InstitutionDTO> institutionslist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionslist);
		return "createinstitution";
	}

	@PostMapping("/createinstitution")
	public String createInstitution(@Valid @ModelAttribute("institutionDTO") InstitutionDTO institutionDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request,
			RedirectAttributes redirectAttributes) {

		String institutionName = institutionDTO.getInstitutionName();

		if (bindingResult.hasErrors()) {

			return "createinstitution";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			Institution institution = modelMapper.map(institutionDTO, Institution.class);
			try {

				Institution institutionEntity = institutionRepository.save(institution);
				model.addAttribute("institutionName", institutionName);

				/*
				 * UserDto userDTO = new UserDto(); userDTO.setEmail(institutionDTO.getEmail());
				 * Long institutionId = institutionEntity.getInstitutionId();
				 * 
				 * userDTO.setInstitutionId(Integer.parseInt(String.valueOf(institutionId)));
				 * 
				 * userDTO.setFirstName(institutionDTO.getFirstName());
				 * userDTO.setLastName(institutionDTO.getLastName());
				 * userDTO.setPassword(institutionDTO.getPassword());
				 * userDTO.setRoles(institutionDTO.getRoles()); GroceryUser existing =
				 * userService.findByEmail(userDTO.getEmail());
				 * 
				 * System.out.println("Printing Role Name" + userDTO.getRoles()); if (existing
				 * != null) { bindingResult.rejectValue("email", null,
				 * "There is already an account registered with that email"); } if
				 * (bindingResult.hasErrors()) { model.addAttribute("user", userDTO); // return
				 * "register"; //return "register"; } userService.saveUser(userDTO);
				 */
				// return "redirect:/register?success";
				return "createinstitutionsuccess";
			} catch (DataIntegrityViolationException e) {
				model.addAttribute("error", "Institution Name must be unique.");
				redirectAttributes.addFlashAttribute("error", "Institution Name must be unique.");
				redirectAttributes.addFlashAttribute("institution", institution);

				return "redirect:/showcreateinstitution"; // Return to form with error message
			}

		}
	}

	@RequestMapping(value = { "/showeditinstitutionupdate" }, method = RequestMethod.GET)
	public String showEditinstitution(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<InstitutionDTO> institutionlist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionlist);

		return "showeditinstitutionupdate";

	}

	@RequestMapping(value = { "/showeditinstitutiondelete" }, method = RequestMethod.GET)
	public String showeditinstitutiondelete(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<InstitutionDTO> institutionlist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionlist);

		return "showeditinstitutiondelete";

	}

	
	@RequestMapping(value = "/showallinstitutionforeditanddelete")
	public String showallinstitutionforeditanddelete(Model model) {

		System.out.println("Printing from welcome");
		OrderSearchDTO orderSearchBillingDTO = new OrderSearchDTO();
		//model.addAttribute("orderSearchBillingDTO", orderSearchBillingDTO);
		List<InstitutionDTO> institutionlist = populateOrderScreenService.findAllInstitutions();
		model.addAttribute("institutions", institutionlist);

		return "showallinstitutionforeditanddelete";

	}
	
	@RequestMapping(value = "/editinstitution/{institutionId}")

	public String editinstitution(@PathVariable("institutionId") Integer institutionId,
			Model model, HttpServletRequest request, HttpSession session)
			throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
	//	String institutionIdString = orderSearchBillingDTO.getInstitutionId();
	//	Integer institutionId = 0;
	//	if (!institutionIdString.isEmpty()) {
			//institutionId = Integer.parseInt(orderSearchBillingDTO.getInstitutionId());
		//}
		Institution institutionfromDB = institutionRepository.findByInstitutionId(institutionId);
		List<InstitutionDTO> institutionDetails = populateOrderScreenService
				.findInstitutionById(institutionId);
		InstitutionDTO institutionDetail = institutionDetails.get(0);
		String institutionName = institutionfromDB.getInstitutionName();
		InstitutionDTO institutionDTO = new InstitutionDTO();
		institutionDTO.setInstitutionId(institutionId);
				
		institutionDTO.setInstitutionName(institutionName);
		// institutionDTO.setUserName(institutionDetail.getUserName());
		// institutionDTO.setEmail(institutionDetail.getEmail());
		//request.getSession().setAttribute("institutionId", institutionId);
		model.addAttribute("institutionDTO", institutionDTO);

		return "editinstitution";
	}

	@RequestMapping(value = { "/saveinstitution" }, method = RequestMethod.GET)
	public String saveinstitution(@ModelAttribute("institutionDTO") InstitutionDTO institutionDTO,@RequestParam("institutionID") String institutionID,
			BindingResult bindingResult, Model model, HttpServletRequest request, HttpSession session,
			RedirectAttributes redirectAttributes) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
		//String institutionIdRequest = request.getParameter("institutionId");
		//Integer institutionId = (Integer) request.getSession().getAttribute("institutionId");
		Institution institutionfromDB = institutionRepository.findByInstitutionId(Long.parseLong(institutionID));
				
		institutionfromDB.setInstitutionName(institutionDTO.getInstitutionName());
		try {
			institutionRepository.save(institutionfromDB);
			UserDto user = new UserDto();
			// user.setEmail(institutionDTO.getEmail());
			// user.setPassword(institutionDTO.getPassword());
			//GroceryUser existing = userService.findByEmail(user.getEmail());
		//	userService.updatePassword(user);

			model.addAttribute("updatedinstitutionName", institutionDTO.getInstitutionName());
			return "editinstitutionupdatesuccess";
		} catch (DataIntegrityViolationException e) {
			model.addAttribute("error", "Institution Name must be unique.");
			redirectAttributes.addFlashAttribute("error", "Institution Name must be unique.");

			return "redirect:/showeditinstitution"; // Return to form with error message
		}

	}

	@RequestMapping(value = "/editinstitutiondelete/{institutionId}")

	public String deleteInstitution(@PathVariable("institutionId") long institutionId,
			 Model model) throws Exception {

		System.out.println("In showOrderSearchResultForOrderEdit method");
	//	long institutionId = institutionDTO.getInstitutionId();
		Institution institutionfromDB = institutionRepository.findByInstitutionId(institutionId);
		String institutionName = institutionfromDB.getInstitutionName();
		institutionRepository.delete(institutionfromDB);
		model.addAttribute("deletedInstitutioneName", institutionName);

		return "editinstitutiondeletesuccess";
	}

	@RequestMapping(value = { "/showcreateaccount" }, method = RequestMethod.GET)
	public String showCreateAccount(Model model) {
		AccountDTO accountDTO = new AccountDTO();
		model.addAttribute("accountDTO", accountDTO);
		// List<InstitutionDTO> institutionslist =
		// populateOrderScreenService.findAllInstitutions();
		// model.addAttribute("institutions", institutionslist);
		return "createaccount";
	}

	@PostMapping("/createaccount")
	public String createAccount(@Valid @ModelAttribute("accountDTO") AccountDTO accountDTO, BindingResult bindingResult,
			Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {

		String accountName = accountDTO.getAccountName();

		if (bindingResult.hasErrors()) {

			return "createaccount";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			Account account = modelMapper.map(accountDTO, Account.class);
			try {

				Account AccountEntity = accountRepository.save(account);
				model.addAttribute("accountName", accountName);
				return "createaccountsuccess";
			} catch (DataIntegrityViolationException e) {
				model.addAttribute("error", "account Name must be unique.");
				redirectAttributes.addFlashAttribute("error", "account Name must be unique.");
				redirectAttributes.addFlashAttribute("account", account);

				return "redirect:/showcreateaccount"; // Return to form with error message
			}

		}
	}

	@RequestMapping(value = { "/showcreatetransaction" }, method = RequestMethod.GET)
	public String showCreateTransaction(Model model) {
		TransactionDTO transactionDTO = new TransactionDTO();
		model.addAttribute("transactionDTO", transactionDTO);
		// List<InstitutionDTO> institutionslist =
		// populateOrderScreenService.findAllInstitutions();
		// model.addAttribute("institutions", institutionslist);
		return "createtransaction";
	}

	@PostMapping("/createtransaction")
	public String createTransaction(@Valid @ModelAttribute("transactionDTO") TransactionDTO transactionDTO,
			BindingResult bindingResult, Model model, HttpServletRequest request, RedirectAttributes redirectAttributes,
			Authentication authentication) {

		String accountName = transactionDTO.getAccountName();

		if (bindingResult.hasErrors()) {

			return "createtransaction";
		} else {

			ModelMapper modelMapper = new ModelMapper();
			Integer institutionId = null;
			System.out.println("Printing from welcome");
			if (authentication != null) {
				User user = (User) authentication.getPrincipal();
				String role = user.getAuthorities().toString();
				String userName = user.getUsername();
				System.out.println("Printing User Name" + userName);
				GroceryUser groceryUser = userService.findByEmail(userName);
				institutionId = groceryUser.getInstitutionId();
				transactionDTO.setInstitutionId(institutionId);
			}

			String internalTransfer = transactionDTO.getInternalTransfer();
			
			System.out.println("Printing the value sof internal trnasfer  " +internalTransfer);
			
			
			if (internalTransfer == null) {
				transactionDTO.setInternalTransfer("No");
			}

			if (internalTransfer != null) {
				transactionDTO.setInternalTransfer("Yes");
			}
			
			

			transactionDTO.setDownloadStatus("no");

		//	Transaction transaction = modelMapper.map(transactionDTO, Transaction.class);
			try {
				
				Transaction transaction = new Transaction();
				transaction.setAccountName(transactionDTO.getAccountName());
				transaction.setAmount(transactionDTO.getAmount());
				transaction.setDate(new Date());
				transaction.setInstitutionId(transactionDTO.getInstitutionId());
				transaction.setInternalTransfer(transactionDTO.getInternalTransfer());
				transaction.setRemarks(transactionDTO.getRemarks());
				transaction.setDownloadStatus(transactionDTO.getDownloadStatus());
				
				Transaction TransactionEntity = transactionRepository.save(transaction);
				model.addAttribute("accountName", accountName);
				return "createtransactionsuccess";
			} catch (DataIntegrityViolationException e) {
				model.addAttribute("error", "Transaction Id must be unique.");
				redirectAttributes.addFlashAttribute("error", "Transaction must be unique.");
				redirectAttributes.addFlashAttribute("transaction", transactionDTO);

				return "redirect:/createtransaction"; // Return to form with error message
			}

		}
	}

	@ResponseBody
	@GetMapping("/accountsearch")
	public List<Map<String, String>> searchAccounts(@RequestParam("q") String query) {

		System.out.println("Printing in account search method");

		List<Account> accounts = populateOrderScreenService.searchAccounts(query);

		return accounts.stream().map(account -> {
			Map<String, String> map = new HashMap<>();
			map.put("id", Long.toString(account.getAccountId()));

			map.put("accountName", account.getAccountName());
			map.put("accountNumber", account.getAccountNumber());
			map.put("ifsc", account.getIfcsCode());
			map.put("branch", account.getBranch());
			return map;
		}).collect(Collectors.toList());

	}
	

	@GetMapping("/showallactivetransactions")
	public String showallactivetransactions(HttpServletResponse response, HttpServletRequest request,Model model)
			throws IOException {
		List<TransactionDTO> transactionDetails = populateOrderScreenService.findAllActiveTransactions();
		model.addAttribute("transactionDetails", transactionDetails);
		
	
		return "showallactivetransactions";
	}
	

	@GetMapping("/downloadinstitutiontransactionsinexcelformat")
	public String downloadinstitutiontransactionsinexcelformat(HttpServletResponse response, HttpServletRequest request)
			throws IOException {

		response.setContentType("application/octet-stream");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=institution_transaction_details" + currentDateTime + ".xlsx";
		response.setHeader(headerKey, headerValue);

		List<TransactionDTO> transactionDetails = populateOrderScreenService.findAllActiveTransactions();

		System.out.println("printing no of records" + transactionDetails.size());

		ExcelGenerator generator = new ExcelGenerator(transactionDetails);

		generator.generateExcelFile(response);

		for (TransactionDTO transaction : transactionDetails) {
			Transaction TransactionEntity = transactionRepository.findByTransactionId(transaction.getTransactionId());
			TransactionEntity.setDownloadStatus("complete");
		}
		return "institutiontransactionsdownladsuccess";

	}
}
